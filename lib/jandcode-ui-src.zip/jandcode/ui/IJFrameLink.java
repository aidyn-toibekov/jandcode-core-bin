package jandcode.ui;

import javax.swing.*;

/**
 * Ссылка на JFrame для окон
 */
public interface IJFrameLink {

    JFrame getJFrame();

}
