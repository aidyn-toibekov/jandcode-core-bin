package jandcode.ui;

/**
 * Событие - компонент скрыт.
 */
public interface OnHide {

    void onHide(UiControl ctrl);

}
