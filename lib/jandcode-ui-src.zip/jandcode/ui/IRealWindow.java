package jandcode.ui;

import java.awt.*;

/**
 * Интерфейс для реальных окон
 */
public interface IRealWindow {

    public UiWindow getUiWindow();

    public void setUiWindow(UiWindow win);

    public Dimension getSize();

    public void setSize(Dimension d);

    public void setLocation(Point p);

    public Point getLocation();

    public void refresh();

    public void setTitle(String s);

}
