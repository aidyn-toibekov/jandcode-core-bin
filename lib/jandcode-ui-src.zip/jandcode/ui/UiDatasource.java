package jandcode.ui;

/**
 * Источник данных для control
 */
@Deprecated
public class UiDatasource {

    /**
     * true - сейчас работает перенос данных в control
     */
    public boolean isDataToControlWork() {
        return false;
    }

}
