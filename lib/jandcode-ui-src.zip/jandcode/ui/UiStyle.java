package jandcode.ui;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import javax.swing.border.*;
import java.awt.*;
import java.util.List;

/**
 * Стиль UI. Цвета, шрифты, рамки...
 */
public class UiStyle extends UiComp {

    private Color _background;
    private Color _foreground;
    private Font _font;

    private Object _borderSelf;
    private Object _borderInside;
    private Object _borderOutside;

    private Boolean _opaque;
    private String _hAlign;
    private String _vAlign;

    private Dimension _size;

    private ListComp<UiStyle> _childs;

    //////


    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        // каждый дочерний рассматриваем как uistyle
        for (Rt ch : rt.getChilds()) {
            UiStyle st = getUi().createStyle(ch);
            addUiStyle(st);
        }
    }

    /**
     * Настроить объект, присвоив значения из строки
     *
     * @param s строка, описывающая инициализацию
     */
    public void parse(String s) {
        List<UtCnv.ComplexValue> pr = UtCnv.toComplexList(s);
        String fontData = "";
        for (UtCnv.ComplexValue p : pr) {
            if (p.hasName("background")) {
                setBackground(p.getValue());
            } else if (p.hasName("foreground")) {
                setForeground(p.getValue());
            } else if (p.hasName("font")) {
                setFont(p);
            } else if (p.getName().startsWith("font")) {
                fontData += p.getName() + ":" + p.getValue() + ";";
            } else if (p.hasName("border")) {
                setBorder(p.getValue());
            } else if (p.hasName("borderinside")) {
                setBorderInside(p.getValue());
            } else if (p.hasName("borderoutside")) {
                setBorderOutside(p.getValue());
            } else if (p.hasName("opaque")) {
                setOpaque(UtCnv.toBoolean(p.getValue()));
            } else if (p.hasName("halign")) {
                setHAlign(p.getValue());
            } else if (p.hasName("valign")) {
                setVAlign(p.getValue());
            } else if (p.hasName("size")) {
                setSize(p.getValue());
            } else if (p.hasName("width")) {
                setWidth(p.getValueInt());
            } else if (p.hasName("height")) {
                setHeight(p.getValueInt());
            } else {
                throw new XError("Параметр [%s] не допустим в описании стиля [%s]", p.getName(), s);
            }
        }
        if (fontData.length() > 0) {
            setFont(fontData);
        }
    }

    ////// child

    public UiStyle getOwner() {
        return (UiStyle) super.getOwner();
    }

    public void addUiStyle(UiStyle st) {
        if (_childs == null) {
            _childs = new ListComp<UiStyle>(this);
        }
        _childs.add(st);
    }

    /**
     * Получить дочерний стиль по имени.
     *
     * @param path путь к дочернему стилю через '/'
     * @return стиль с указанным путем из списка дочерних. Если такого дочернего нет,
     *         то возвращается последний найденный в пути, включая сам родительский
     */
    public UiStyle child(String path) {
        if (path == null || path.length() == 0) {
            return this;
        }
        UiStyle res = this;
        String[] ar = path.split("/");
        for (String s : ar) {
            if (res._childs != null) {
                UiStyle st = res._childs.find(s);
                if (st != null) {
                    res = st;
                } else {
                    return res;
                }
            } else {
                return res;
            }
        }
        return res;
    }

    //////

    /**
     * Цвет фона
     */
    public void setBackground(Object background) {
        _background = getUi().getColorService().getColor(background);
    }

    public Color getBackground() {
        if (_background == null && getOwner() != null) {
            return getOwner().getBackground();
        }
        return _background;
    }

    //////

    /**
     * Цвет текста
     */
    public void setForeground(Object foreground) {
        _foreground = getUi().getColorService().getColor(foreground);
    }

    public Color getForeground() {
        if (_foreground == null && getOwner() != null) {
            return getOwner().getForeground();
        }
        return _foreground;
    }

    //////

    /**
     * Рамка
     */
    public void setBorder(Object border) {
        _borderSelf = border;
    }

    public Border getBorder() {
        return getUi().getBorderService().getBorder(getBorderOutside(), getBorderSelf(), getBorderInside());
    }

    private Object getBorderSelf() {
        if (_borderSelf == null && getOwner() != null) {
            return getOwner().getBorderSelf();
        }
        return _borderSelf;
    }

    //////

    /**
     * Внутренняя рамка.
     */
    public void setBorderInside(Object borderInside) {
        _borderInside = borderInside;
    }

    private Object getBorderInside() {
        if (_borderInside == null && getOwner() != null) {
            return getOwner().getBorderInside();
        }
        return _borderInside;
    }

    //////

    /**
     * Внешняя рамка объекта.
     *
     * @param borderOutside рамка (см. FactoryBorder)
     */
    public void setBorderOutside(Object borderOutside) {
        _borderOutside = borderOutside;
    }

    public Object getBorderOutside() {
        if (_borderOutside == null && getOwner() != null) {
            return getOwner().getBorderOutside();
        }
        return _borderOutside;
    }

    //////

    /**
     * Шрифт
     */
    public void setFont(Object font) {
        _font = getUi().getFontService().getFont(getFont(), font);
    }

    public Font getFont() {
        if (_font == null && getOwner() != null) {
            return getOwner().getFont();
        }
        return _font;
    }

    /**
     * Стиль шрифта
     */
    public void setFontStyle(String font) {
        _font = getUi().getFontService().getFont(getFont(), "style:" + font);
    }

    /**
     * Размер шрифта. Может быть как явным размером, так и числом с + и -
     */
    public void setFontSize(String size) {
        _font = getUi().getFontService().getFont(getFont(), "size:" + size);
    }

    /**
     * Имя шрифта
     */
    public void setFontName(String name) {
        _font = getUi().getFontService().getFont(getFont(), "name:" + name);
    }

    //////

    /**
     * Непрозрачность
     */

    public void setOpaque(Boolean opaque) {
        _opaque = opaque;
    }

    public Boolean getOpaque() {
        return _opaque;
    }

    //////

    /**
     * Горизонтальное выравниваение
     */
    public void setHAlign(String hAlign) {
        _hAlign = hAlign;
    }

    public String getHAlign() {
        return _hAlign;
    }

    //////

    /**
     * Вертикальное выравнивание
     */
    public void setVAlign(String vAlign) {
        _vAlign = vAlign;
    }

    public String getVAlign() {
        return _vAlign;
    }

    //////

    /**
     * Размер. По умолчанию control его игнорирует. Для каждого
     * control необходима своя обработка
     */
    public void setSize(String size) {
        setSize(UtCnv.toDimension(size));
    }

    /**
     * Ширина. Часть свойства size
     */
    public void setWidth(int v) {
        if (_size == null) {
            _size = new Dimension();
        }
        _size.width = v;
    }

    /**
     * Высота. Часть свойства size
     */
    public void setHeight(int v) {
        if (_size == null) {
            _size = new Dimension();
        }
        _size.height = v;
    }

    public void setSize(Dimension size) {
        _size = size;
    }

    public Dimension getSize() {
        if (_size == null && getOwner() != null) {
            return getOwner().getSize();
        }
        return _size;
    }


}
