package jandcode.ui;

import jandcode.app.*;
import jandcode.app.impl.*;
import jandcode.ui.impl.*;
import jandcode.ui.std.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Предок для всех control
 */
public abstract class UiControl extends UiComp {

    protected static ListComp<UiControl> EMPTY_CONTROL_LIST = new ListCompDummy<UiControl>();
    protected static ListComp<UiAction> EMPTY_ACTION_LIST = new ListCompDummy<UiAction>();
    protected static ListComp<UiMenu> EMPTY_MENU_LIST = new ListCompDummy<UiMenu>();

    static {
        EMPTY_ACTION_LIST.setNotFoundMessage("Action [{0}] not found");
        EMPTY_CONTROL_LIST.setNotFoundMessage("Control [{0}] not found");
        EMPTY_MENU_LIST.setNotFoundMessage("Menu [{0}] not found");
    }

    protected ListComp<UiControl> _controls;
    protected ListComp<UiAction> _actions;
    protected ListComp<UiMenu> _menus;
    protected JComponent _ctrl;
    protected Object _border;
    protected Object _borderInside;
    protected Object _borderOutside;
    protected EventsHolder _events;
    protected String _firstControlName;
    protected Object _lay;
    protected boolean _hidden;
    protected ListenerPopupMenu _listenerPopupMenu;
    protected UiStyle _uiStyle;


    public UiControl() {
        _controls = EMPTY_CONTROL_LIST;
        _actions = EMPTY_ACTION_LIST;
        _menus = EMPTY_MENU_LIST;
        _events = new EventsHolder();
    }

    protected void constructor() {
        createCtrl();
        try {
            onConstructor();
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    /**
     * Метод перекрывается для настройки экземпляра. Вызывается в конструкторе.
     */
    protected void onConstructor() throws Exception {
    }

    /**
     * Владелец
     */
    public UiControl getOwner() {
        return (UiControl) super.getOwner();
    }

    ////// ctrl

    /**
     * Создание реального JComponent. Перекрывается в потомках.
     * Нужно создать JComponent и присвоить его в setCtrl().
     */
    protected abstract void createCtrl();

    /**
     * Связанный JComponent
     */
    public JComponent getCtrl() {
        return _ctrl;
    }

    public void setCtrl(JComponent ctrl) {
        _ctrl = ctrl;
    }

    ////// controls

    /**
     * Дочерние UiControl
     */
    public ListComp<UiControl> getControls() {
        return _controls;
    }

    /**
     * Список дочерних, включая все дочерние дочерних
     */
    @Deprecated
    public List<UiControl> getDeepControls() {
        List<UiControl> res = new ArrayList<UiControl>();
        internal_getDeepControls(this, res);
        return res;
    }

    protected void internal_getDeepControls(UiControl from, List<UiControl> res) {
        for (UiControl z : from.getControls()) {
            res.add(z);
        }
        for (UiControl z : from.getControls()) {
            internal_getDeepControls(z, res);
        }
    }

    /**
     * Поиск control.
     *
     * @param path путь к control через "/". Если начинается с '@' то поиск ведется начиная с topframe.
     *             Если равен '@' - возвращается topframe
     * @return null, если не найден
     */
    public UiControl findControl(String path) {
        UiControl from = this;
        if (path.startsWith("@")) {
            from = getTopFrame();
            if (from == null) {
                return null;
            }
            if (path.length() == 1) {
                // Только '@' - возвращает topframe
                return from;
            }
            path = path.substring(1);
        }
        return from.internalFind(path);
    }

    /**
     * Получить control по пути (имени).
     *
     * @param path путь (имя)
     * @return ошибка, если не найден
     */
    public UiControl control(String path) {
        UiControl c = findControl(path);
        if (c == null) {
            throw new XError("Control [{0}] not found", path);
        }
        return c;
    }

    protected UiControl internalFind(String path) {
        if (path == null || path.length() == 0) {
            return null;
        }
        if (path.indexOf("/") == -1) {
            return internalFindInChilds(path);
        } else {
            UiControl from = this;
            String[] pt = path.split("/");
            for (String pti : pt) {
                from = from.internalFindInChilds(pti);
                if (from == null) {
                    return null;
                }
            }
            return from;
        }
    }

    /**
     * Найти среди дочерних, с учетом вложенных.
     */
    protected UiControl internalFindInChilds(String name) {
        if (name == null || name.length() == 0) {
            return null;
        }
        UiControl r = _controls.find(name);
        if (r != null) {
            return r;
        }
        if (_controls.size() > 0) {
            for (UiControl c : _controls) {
                if (!(c instanceof UiFrame)) {
                    r = c.internalFindInChilds(name);
                    if (r != null) {
                        return r;
                    }
                }
            }
        }
        return null;
    }

    public UiControl addControl(UiControl it) {
        return addControl(it, it.getLay());
    }

    public UiControl addControl(UiControl it, Object layoutConstr) {
        if (_controls == EMPTY_CONTROL_LIST) {
            _controls = new ListComp<UiControl>(this);
            _controls.setNotFoundMessage(EMPTY_CONTROL_LIST.getNotFoundMessage());
        }
        if (!it.hasName()) {
            it.setName("_" + _controls.size());
        }
        _controls.add(it);
        onAddControl(it, layoutConstr);
        return it;
    }

    protected void onAddControl(UiControl it, Object layoutConstr) {
        if (!it.isHidden()) {
            getCtrl().add(it.getCtrl(), layoutConstr);
        }
    }

    public void removeControl(UiControl it) {
        int idx = _controls.indexOf(it);
        if (idx != -1) {
            _controls.remove(idx);
            onRemoveControl(it);
        }
    }

    public void removeControl(String name) {
        UiControl it = _controls.find(name);
        if (it != null) {
            _controls.remove(it);
            onRemoveControl(it);
        }
    }

    protected void onRemoveControl(UiControl it) {
        getCtrl().remove(it.getCtrl());
    }

    /**
     * Удалить все control
     */
    public void removeControlAll() {
        getControls().clear();
        getCtrl().removeAll();
        LayoutManager layout = getLayout();
        if (layout instanceof TableLayoutExt) {
            ((TableLayoutExt) layout).clear();
        }
    }

    ////// lay

    /**
     * layout constraint по умолчанию
     */
    public Object getLay() {
        return _lay;
    }

    public void setLay(Object lay) {
        _lay = lay;
    }

    ////// frame

    /**
     * Фрейм, на котором находится этот UiControl. Возвращает null, если этот control является
     * свободным фреймом, либо фреймом верхнего уровня.
     */
    public UiFrame getFrame() {
        UiControl f = getOwner();
        while (f != null) {
            if (f instanceof UiFrame) {
                return (UiFrame) f;
            }
            f = f.getOwner();
        }
        return null;
    }

    /**
     * Фрейм верхнего уровня, на котором находится этот control. Для фрейма верхнего уровня
     * возвращается он сам.
     */
    public UiFrame getTopFrame() {
        if (this instanceof UiFrame && ((UiFrame) this).isTopFrame()) {
            return (UiFrame) this;
        }
        UiFrame f = getFrame();
        while (f != null) {
            if (f.isTopFrame()) {
                return f;
            }
            f = f.getFrame();
        }
        return null;
    }

    ////// border

    protected void resetBorder() {
        getCtrl().setBorder(getUi().getBorderService().getBorder(_borderOutside, _border, _borderInside));
    }

    /**
     * Рамка объекта (см. {@link BorderService}).
     */
    public void setBorder(Object border) {
        _border = border;
        resetBorder();
    }

    public Border getBorder() {
        return getCtrl().getBorder();
    }

    /**
     * Внутренняя рамка объекта.
     */
    public void setBorderInside(Object borderInside) {
        _borderInside = borderInside;
        resetBorder();
    }

    /**
     * Внешняя рамка объекта.
     */
    public void setBorderOutside(Object borderOutside) {
        if (_border == null) {
            _border = getCtrl().getBorder();
        }
        _borderOutside = borderOutside;
        resetBorder();
    }

    /**
     * Установка заголовка на рамке объекта. Заголовок устанавливается только в том случае, если
     * рамка поддерживает установку заголовков.
     */
    public void setBorderTitle(String text) {
        getUi().getBorderService().setBorderTitle(getBorder(), text);
    }

    ////// colors

    public void setBackground(Object desc) {
        getCtrl().setBackground(getUi().getColorService().getColor(desc));
    }

    public Color getBackground() {
        return getCtrl().getBackground();
    }

    public void setForeground(Object desc) {
        getCtrl().setForeground(getUi().getColorService().getColor(desc));
    }

    public Color getForeground() {
        return getCtrl().getForeground();
    }

    ///// opaque

    public void setOpaque(boolean isOpaque) {
        getCtrl().setOpaque(isOpaque);
    }

    public boolean isOpaque() {
        return getCtrl().isOpaque();
    }

    ////// visible

    public void setVisible(boolean aFlag) {
        getCtrl().setVisible(aFlag);
    }

    public boolean isVisible() {
        return getCtrl().isVisible();
    }

    ////// enable

    public void setEnabled(boolean enabled) {
        getCtrl().setEnabled(enabled);
    }

    public boolean isEnabled() {
        return getCtrl().isEnabled();
    }

    ////// prefsize

    /**
     * Вызывается при установке prefsize. Предназначен для перекрытия. По умолчанию
     * устанавливает prefsize для своего компонента, причем если одна из координат
     * установлена в <=0, то для нее берется prefsize установленный к текущему моменту
     *
     * @param d размер
     */
    protected void onSetPrefSize(Dimension d) {
        if (d != null) {
            if (d.width <= 0 || d.height <= 0) {
                d = new Dimension(d);  // копия
                Dimension d1 = getPrefSize();
                if (d.width <= 0) {
                    d.width = d1.width;
                }
                if (d.height <= 0) {
                    d.height = d1.height;
                }
            }
        }
        getCtrl().setPreferredSize(d);
    }

    public Dimension getPrefSize() {
        return getCtrl().getPreferredSize();
    }

    public boolean isPrefSize() {
        return getCtrl().isPreferredSizeSet();
    }

    /**
     * Если ширина или высота установлена в -1, то она не изменяется
     */
    public void setPrefSize(int width, int height) {
        onSetPrefSize(new Dimension(width, height));
    }

    /**
     * Если ширина или высота установлена в -1, то она не изменяется
     */
    public void setPrefSize(Dimension size) {
        onSetPrefSize(size);
    }

    /**
     * Если ширина или высота установлена в -1, то она не изменяется.
     *
     * @param s строка вида 'WIDTH,HEIGHT'
     */
    public void setPrefSize(String s) {
        setPrefSize(UtCnv.toDimension(s));
    }

    ////// size

    public Dimension getSize(Dimension rv) {
        return getCtrl().getSize(rv);
    }

    public Dimension getSize() {
        return getCtrl().getSize();
    }

    public void setSize(Dimension d) {
        getCtrl().setSize(d);
    }

    public void setSize(int width, int height) {
        getCtrl().setSize(width, height);
    }

    ////// location

    public void setLocation(Point p) {
        getCtrl().setLocation(p);
    }

    public Point getLocation() {
        return getCtrl().getLocation();
    }

    public void setLocation(int x, int y) {
        getCtrl().setLocation(x, y);
    }

    ////// font

    public Font getFont() {
        return getCtrl().getFont();
    }

    public void setFont(Object desc) {
        getCtrl().setFont(getUi().getFontService().getFont(getCtrl().getFont(), desc));
    }

    //////

    /**
     * Перерисовать control
     */
    public void refresh() {
        getCtrl().paintImmediately(getCtrl().getVisibleRect());
    }

    /**
     * Перерисовать фрейм, на котором находится control
     */
    public void refreshFrame() {
        UiFrame f = getFrame();
        if (f != null) {
            f.refresh();
        } else {
            if (this instanceof UiFrame) {
                refresh();
            }
        }
    }

    //////

    /**
     * Может ли объект получать фокус
     */
    public void setFocusable(boolean flag) {
        getCtrl().setFocusable(flag);
    }

    public boolean isFocusable() {
        return getCtrl().isFocusable();
    }

    /**
     * Устанавливает фокус на этом объекте, если это возможно.
     *
     * @return true, если фокус был удачно установлен
     */
    public boolean setFocus() {
        return getCtrl().requestFocusInWindow();
    }

    /**
     * Является ли объект сфокусированным.
     *
     * @return true, если является сфокусорованным
     */
    public boolean isFocus() {
        return getCtrl().isFocusOwner();
    }

    /**
     * Возвращает сфокусированный объект. Поиск ведется среди дочерних и самого себя.
     *
     * @return ссылку на сфокусированный объект или null, если нет сфокусированных
     */
    public UiControl getFocused() {
        if (isFocus() && getControls().size() == 0) {
            return this;
        }

        for (UiControl c : getControls()) {
            UiControl f = c.getFocused();
            if (f != null) {
                return f;
            }
        }

        return null;
    }

    //////

    /**
     * Текст всплывающей подсказки
     */
    public void setTooltip(String text) {
        getCtrl().setToolTipText(text);
    }

    public String getTooltip() {
        return getCtrl().getToolTipText();
    }

    ////// layout

    public LayoutManager getLayout() {
        return getCtrl().getLayout();
    }

    public void setLayout(LayoutManager mgr) {
        getCtrl().setLayout(mgr);
    }

    ////// firstControl

    public String getFirstControlName() {
        return _firstControlName == null ? "" : _firstControlName;
    }

    public void setFirstControlName(String name) {
        _firstControlName = name;
    }

    /**
     * Устанавливает фокус на первом дочернем control или на себе (если возможно).
     * Имя дочернего control, на котором необходимо установить фокус, определяется
     * getFirstControlName. Если значение не установлено, то выбирается
     * первый дочерний control, на который можно установить фокус.
     *
     * @return true, если фокус установлен
     */
    public boolean selectFirstControl() {
        if (isFocusable() && isEnabled() && getControls().size() == 0) {
            setFocus();
            return true;
        }

        String s = getFirstControlName();
        if (s.length() != 0) {
            UiControl ctrl = findControl(s);
            if (ctrl != null) {
                if (ctrl.selectFirstControl()) {
                    return true;
                }
            }
        }

        for (UiControl c : getControls()) {
            if (c.selectFirstControl()) {
                return true;
            }
        }

        return false;
    }

    //////

    /**
     * Скрытый control. Такой control создается, помещается в список владельца, но не попадает
     * для отображения. Его можно использовать по своему усмотрению, например поместить на toolbar
     */
    public void setHidden(boolean hidden) {
        _hidden = hidden;
    }

    public boolean isHidden() {
        return _hidden;
    }

    ////// actions

    /**
     * actions, связанные с этим control
     */
    public ListComp<UiAction> getActions() {
        return _actions;
    }

    /**
     * Добавить action
     */
    public void addAction(UiAction it) {
        if (_actions == EMPTY_ACTION_LIST) {
            _actions = new ListComp<UiAction>(this);
            _actions.setNotFoundMessage(EMPTY_ACTION_LIST.getNotFoundMessage());
        }
        if (!it.hasName()) {
            it.setName("_" + _actions.size());
        }
        _actions.add(it);
    }

    /**
     * Найти action по имени.
     *
     * @param name
     * @return null, если не найдена
     */
    public UiAction findAction(String name) {
        return _actions.find(name);
    }

    /**
     * Найти action по имени.
     *
     * @param name
     * @return error, если не найдена
     */
    public UiAction action(String name) {
        return _actions.get(name);
    }

    ////// menus

    /**
     * menus
     */
    public ListComp<UiMenu> getMenus() {
        return _menus;
    }

    /**
     * Добавить menu
     */
    public void addMenu(UiMenu it) {
        if (_menus == EMPTY_MENU_LIST) {
            _menus = new ListComp<UiMenu>(this);
            _menus.setNotFoundMessage(EMPTY_MENU_LIST.getNotFoundMessage());
        }
        if (!it.hasName()) {
            it.setName("_" + _menus.size());
        }
        _menus.add(it);
    }

    /**
     * Найти menu по имени.
     *
     * @param name
     * @return null, если не найдена
     */
    public UiMenu findMenu(String name) {
        return _menus.find(name);
    }

    /**
     * Найти menu по имени.
     *
     * @param name
     * @return error, если не найдена
     */
    public UiMenu menu(String name) {
        return _menus.get(name);
    }

    ////// popup

    /**
     * Возвращает popupmenu для control. Или null, если нет popupmenu
     */
    protected CtPopupMenu getPopupMenu(int x, int y) {
        UiMenu m = findMenu("popup");
        if (m == null) {
            return null;
        }
        if (m.getItems().size() > 0) {
            CtPopupMenu popup = getUi().getObjectFactory().create(CtPopupMenu.class);
            popup.fill(m);
            return popup;
        } else {
            return null;  // нечего показывать
        }
    }

    /**
     * Показывает popup меню в указанном месте. Меню показывается, если оно определено
     *
     * @param x x-координата
     * @param y y-координата
     */
    public void showPopupMenu(int x, int y) {
        CtPopupMenu m = getPopupMenu(x, y);
        if (m != null) {
            m.popup(this, x, y);
        }
    }

    /**
     * Включит/выключить возможность показа popup menu для этого control
     */
    public void setPopup(boolean usePopup) {
        if (usePopup) {
            if (_listenerPopupMenu == null) {
                _listenerPopupMenu = new ListenerPopupMenu(this);
                getCtrl().addMouseListener(_listenerPopupMenu);
            }
        } else {
            if (_listenerPopupMenu != null) {
                getCtrl().removeMouseListener(_listenerPopupMenu);
                _listenerPopupMenu = null;
            }
        }
    }

    public boolean isPopup() {
        return _listenerPopupMenu != null;
    }

    ////// events

    /**
     * Все обработчики событий
     */
    public EventsHolder getEvents() {
        return _events;
    }

    /**
     * Добавить обработчик события
     */
    public void removeEvent(Object eventHandler) {
        _events.remove(eventHandler);
    }

    ////// event: focus

    public void addEvent(OnFocusChange h) {
        _events.add(h);
    }

    /**
     * Генерация события об изменении фокуса
     *
     * @param self true - изменился свой фокус, false - изменился фокус когото из детей
     * @param lost true - фокус потерян, false - фокус взят
     */
    public void fireFocusChange(boolean self, boolean lost) {
        onFocusChange(self, lost);
        for (OnFocusChange h : _events.list(OnFocusChange.class)) {
            h.onFocusChange(this, self, lost);
        }
    }

    protected void onFocusChange(boolean self, boolean lost) {
    }

    ////// event: change

    public void addEvent(OnChange h) {
        _events.add(h);
    }

    public void fireChange() {
        onChange();
        for (OnChange h : _events.list(OnChange.class)) {
            h.onChange(this);
        }
    }

    protected void onChange() {
    }

    ////// event: show

    public void addEvent(OnShow h) {
        _events.add(h);
    }

    public void fireShow() {
        onShow();
        notifyShow();
        for (OnShow h : _events.list(OnShow.class)) {
            h.onShow(this);
        }
    }

    protected void onShow() {
    }

    /**
     * Генерация onShow для дочерних объектов
     */
    protected void notifyShow() {
        for (UiControl c : getControls()) {
            c.fireShow();
        }
    }

    ////// event: hide

    public void addEvent(OnHide h) {
        _events.add(h);
    }

    public void fireHide() {
        onHide();
        notifyHide();
        for (OnHide h : _events.list(OnHide.class)) {
            h.onHide(this);
        }
    }

    protected void onHide() {
    }

    /**
     * Генерация onShow для дочерних объектов
     */
    protected void notifyHide() {
        for (UiControl c : getControls()) {
            c.fireHide();
        }
    }

    ////// style

    public UiStyle getUiStyle() {
        if (_uiStyle == null) {
            _uiStyle = getUi().getObjectFactory().create(UiStyle.class);
        }
        return _uiStyle;
    }

    public void setUiStyle(UiStyle st) {
        _uiStyle = st;
        if (st.getBackground() != null) {
            setBackground(st.getBackground());
        }
        if (st.getForeground() != null) {
            setForeground(st.getForeground());
        }
        if (st.getFont() != null) {
            setFont(st.getFont());
        }
        if (st.getBorder() != null) {
            getCtrl().setBorder(st.getBorder());
        }
        if (st.getOpaque() != null) {
            getCtrl().setOpaque(st.getOpaque());
        }
    }

    public void setUiStyle(String st) {
        setUiStyle(getUi().createStyle(st));
    }

    /**
     * Присвоить стиль себе и всем своим дочерним
     */
    public void setUiStyleDeep(UiStyle st) {
        setUiStyle(st);
        for (UiControl control : getControls()) {
            control.setUiStyleDeep(st);
        }
    }

}
