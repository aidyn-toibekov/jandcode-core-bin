package jandcode.ui;

import jandcode.ui.impl.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Фрейм. То, что является содержимым окна.
 */
public class UiFrame extends CustomPanel {

    // для окна
    protected UiWindow window;
    protected String closeCm;
    //
    private String _windowName;
    private String _interiorName;
    private VariantMap _showParam;

    protected void onConstructor() throws Exception {
        super.onConstructor();
        _windowName = "empty";
        _interiorName = "empty";
        _showParam = new VariantMap();
    }

    ////// window

    /**
     * Окно, на которой показан фрейм
     */
    public UiWindow getWindow() {
        if (window == null) {
            throw new XError("Окно не назначено");
        }
        return window;
    }

    /**
     * Показано ли сейчас окно
     */
    public boolean hasWindow() {
        return window != null;
    }

    /**
     * Имя окна по умолчанию, в котором будет показан фрейм
     */
    public String getWindowName() {
        return _windowName;
    }

    public void setWindowName(String windowName) {
        _windowName = windowName;
    }

    ////// interior

    public UiInterior getInterior() {
        return getWindow().getInterior();
    }

    /**
     * Имя интерьера
     */
    public String getInteriorName() {
        return _interiorName;
    }

    public void setInteriorName(String interiorName) {
        _interiorName = interiorName;
    }

    //////

    /**
     * Признак для фрейма верхнего уровня
     */
    public boolean isTopFrame() {
        return getOwner() != null;
    }

    ////// show

    /**
     * Параметры показа фрейма. Зависят от окна и обрабатываются окном.
     */
    public VariantMap getShowParam() {
        return _showParam;
    }

    /**
     * Показать фрейм в окне
     *
     * @param windowName   в каком окне (по умолчанию getWindowName())
     * @param interiorName в каком интерьере (по умолчанию getInteriorName())
     * @param showParam    с какими параметрами (по умолчанию getShowParam()). Может быть
     *                     Map или строкой, которая преобразуется в Map
     *                     через {@link UtCnv#toMap(java.lang.String)}
     * @return getCloseCm(), если окно было модальное. Иначе ""
     */
    public String show(String windowName, String interiorName, Object showParam) {
        if (window != null) {
            throw new XError("Фрейм уже показан");
        }
        if (interiorName != null) {
            _interiorName = interiorName;
        }
        if (windowName != null) {
            _windowName = windowName;
        }
        if (showParam != null) {
            if (showParam instanceof Map) {
                _showParam.putAll((Map) showParam);
            } else if (showParam instanceof String) {
                _showParam.putAll(UtCnv.toMap((String) showParam));
            } else {
                throw new XError("showParam должен быть Map или String");
            }
        }
        UiWindow w = getUi().createWindow(getWindowName());
        w.show(this);
        return getCloseCm();
    }

    /**
     * Показ окна в окне и интерьере по умолчанию
     */
    public String show() {
        return show(null, null, null);
    }

    ////// event: onClose

    public void addEvent(OnClose h) {
        _events.add(h);
    }

    public boolean fireClose(String cm) {
        OnClose.Param p = new OnClose.Param();
        p.setCm(cm);
        onClose(p);
        if (p.isEnableClose()) {
            for (OnClose h : getEvents().list(OnClose.class)) {
                h.onClose(this, p);
                if (!p.isEnableClose()) {
                    break;
                }
            }
        }
        return p.isEnableClose();
    }

    protected void onClose(OnClose.Param p) {
    }

    public void close(String cm) {
        if (window == null) {
            return;
        }
        window.performClose(cm);
    }

    public void close() {
        close("cancel");
    }


    //////

    /**
     * Команда, с которой фрейм был закрыт (ok, cancel, ...)
     */
    public String getCloseCm() {
        return closeCm == null ? "" : closeCm.toLowerCase();
    }

    //////

}
