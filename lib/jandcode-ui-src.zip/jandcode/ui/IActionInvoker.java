package jandcode.ui;

/**
 * Интерфейс для control, которые владеют action и могут предоставить способ
 * выполнить action без явного назначения события OnAction.
 * Например ввести соглашения, что методы с определенным названием - это
 * обработчики action.
 */
public interface IActionInvoker {

    /**
     * Вызывается из UiAction, когда она собирается выполнится.
     *
     * @param a какая action
     * @return true, если обработчик был найден и вызван
     */
    boolean fireAction(UiAction a);

}
