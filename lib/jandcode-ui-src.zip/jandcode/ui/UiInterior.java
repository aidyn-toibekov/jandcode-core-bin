package jandcode.ui;

import jandcode.ui.impl.*;
import jandcode.utils.error.*;

/**
 * Интерьер, в котором показывается фрейм внутри окна.
 */
public abstract class UiInterior extends CustomPanel {

    protected UiWindow window;
    private UiFrame _frame;

    /**
     * Окно, на которой показан фрейм
     */
    public UiWindow getWindow() {
        if (window == null) {
            throw new XError("Окно не назначено");
        }
        return window;
    }

    /**
     * Фрейм
     */
    public UiFrame getFrame() {
        return _frame;
    }

    /**
     * Вызывается окном
     */
    protected void setFrame(UiFrame frame) {
        _frame = frame;
        onSetFrame();
    }

    /**
     * Разместить фрейм в этом методе
     */
    protected abstract void onSetFrame();

}
