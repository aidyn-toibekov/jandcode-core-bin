package jandcode.ui;

import jandcode.app.*;
import jandcode.ui.impl.*;
import jandcode.ui.std.*;
import jandcode.utils.*;
import jandcode.utils.easyxml.*;
import jandcode.utils.error.*;

import java.awt.*;
import java.util.*;

/**
 * Построитель интерфесов
 */
public abstract class UiBuilder extends Comp {

    protected StackList<UiControl> stack = new StackList<UiControl>();
    protected UiControl root;

    /**
     * Загрузить указанные данные и построить control по ним. Зависят от реализации.
     */
    public abstract void load(Object data) throws Exception;

    public UiService getUi() {
        return getApp().service(UiService.class);
    }

    /**
     * Корневой компонент (для кого строим)
     */
    public UiControl getRoot() {
        if (root == null) {
            throw new XError("Не установлен root");
        }
        return root;
    }

    public void setRoot(UiControl root) {
        this.root = root;
        stack.clear();
        push(root);
    }

    ////// stack

    /**
     * Поместить в стек. Теперь все добавляется на него
     */
    public UiControl push(UiControl z) {
        stack.add(z);
        return z;
    }

    /**
     * Вытащить последний из стека. Теперь добавление пойдет на предыдущий
     */
    public UiControl pop() {
        if (stack.size() <= 1) {
            throw new XError("Нарушение баланса вызова push/pop");
        }
        return stack.pop();
    }

    /**
     * Последняя панель. На нее добавляются дочерние.
     */
    public UiControl getLast() {
        return stack.last();
    }

    ////// attrs

    /**
     * Присвоить свойства
     *
     * @param cur  кому
     * @param data откуда
     */
    public void setAttrs(UiControl cur, EasyXml data) {
        setAttrs(cur, data.getAttrs());
    }

    /**
     * Присвоить свойства
     *
     * @param cur  кому
     * @param data откуда
     */
    public void setAttrs(UiControl cur, Map data) {
        if (data == null || data.isEmpty()) {
            return;
        }
        //
        String s;
        TableLayoutExt lay = getLayoutTable(cur);
        //
        s = UtString.toString(data.get("layself"));
        if (s.length() > 0) {
            if (lay != null) {
                lay.cm(s);
            }
        }
        //
        s = UtString.toString(data.get("layowner"));
        if (s.length() > 0) {
            UiControl own = cur.getOwner();
            if (own == null) {
                // еще не добавлен. Используем last
                own = getLast();
            }
            if (own != null) {
                TableLayoutExt layown = getLayoutTable(own);
                if (layown != null) {
                    layown.cm(s);
                }
            }
        }
        //
        s = UtString.toString(data.get("_debug"));
        if (s.length() > 0) {
            cur.setBackground(s);
        }
        //
        cur.setRtAttrs(data);
    }

    ////// table layout

    /**
     * Возвращает UiLayoutTable для control
     */
    public TableLayoutExt getLayoutTable(UiControl z) {
        LayoutManager curLay = z.getLayout();
        if (curLay == null) {
            curLay = new TableLayoutExt();
            z.setLayout(curLay);
            return (TableLayoutExt) curLay;
        } else if (curLay instanceof TableLayoutExt) {
            return (TableLayoutExt) curLay;
        }
        return null;
    }

    ////// menu

    /**
     * Заполнение меню
     *
     * @param menuContainerName что заполнить (CtMenuBar, CtToolBar)
     * @param menu              чем заполнить (UiMenu)
     */
    public void fillMenu(String menuContainerName, UiMenu menu) {
        IMenuContainer mc = (IMenuContainer) getLast().control(menuContainerName);
        mc.fill(menu);
    }

    /**
     * Заполнение меню
     *
     * @param menuContainerName что заполнить (CtMenuBar, CtToolBar)
     * @param menuName          чем заполнить (UiMenu). Если не указано, имя считается
     *                          равным menuContainerName
     */
    public void fillMenu(String menuContainerName, String menuName) {
        if (menuName == null) {
            menuName = menuContainerName;
        }
        fillMenu(menuContainerName, getLast().menu(menuName));
    }

    /**
     * Вызов {@link UiBuilder#fillMenu(java.lang.String, java.lang.String)}
     * с параметром menuName=null
     */
    public void fillMenu(String menuAndMenuContainerName) {
        fillMenu(menuAndMenuContainerName, (String) null);
    }
}
