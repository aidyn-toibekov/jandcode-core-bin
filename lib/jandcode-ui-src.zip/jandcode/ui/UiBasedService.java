package jandcode.ui;

import jandcode.app.*;

/**
 * Базовый класс для сервисов ui
 */
public abstract class UiBasedService extends CompRt {

    public UiService getUi() {
        return getApp().service(UiService.class);
    }

}
