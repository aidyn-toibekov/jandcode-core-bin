package jandcode.ui;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.logging.*;

/**
 * Сервис окон с сообщениями
 */
public abstract class MsgboxService extends UiBasedService {

    /**
     * Сообщение об ошибке
     */
    public void showError(Throwable e) {
        ErrorInfo ei = UtError.createErrorInfo(e);
        if (UtLog.isOn()) {
            LogFactory.getLog(MsgboxService.class).error(e, e);
            //
            ErrorFormatter fmt = getApp().service(ErrorService.class).getErrorFormatter("ui");
            String msg = fmt.getMessage(e);
            LogFactory.getLog(MsgboxService.class).error("\n" + msg);
        }
        showError(ei.getText());
    }

    /**
     * Сообщение об ошибке
     */
    public abstract void showError(String msg);

    /**
     * Обычное сообщение
     */
    public abstract void showMsg(String msg);

    /**
     * Подтверждение (да/нет)
     */
    public abstract boolean showYN(String msg);

    /**
     * Подтверждение (да/нет/отмена) Возвращает: 1-да, 0-нет, -1-отмена
     */
    public abstract int showYNC(String msg);

}

