package jandcode.ui;

import jandcode.app.*;

/**
 * Предок для Ui-компонентов
 */
public class UiComp extends CompRt {

    protected String _title;

    public void setTitle(String title) {
        _title = title;
    }

    public String getTitle() {
        return _title == null ? "" : _title;
    }

    public UiService getUi() {
        return getApp().service(UiService.class);
    }
}
