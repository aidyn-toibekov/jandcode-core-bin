package jandcode.ui;

import javax.swing.*;
import javax.swing.border.*;

/**
 * Рамки
 */
public abstract class BorderService extends UiBasedService {

    /**
     * Получить рамку по описанию.
     *
     * @param desc описание. Может быть именем рамки, строкой через ',', или объектом Border.
     *             Если строка через ',' из 2-х частей - это размер пустой рамки по x и y. Если из 4-х
     *             частей - это размер пустой в порядке t,l,b,r
     * @return рамка. Может возвращать null
     */
    public abstract Border getBorder(Object desc);

    /**
     * Установка заголовка на рамке. Заголовок устанавливается только в том случае, если
     * рамка поддерживает установку заголовков.
     *
     * @param border рамка
     * @param text   текст заголовка
     */
    public abstract void setBorderTitle(Border border, String text);

    /**
     * Создать комплексную рамку.
     *
     * @param outsideborder Внешняя (обычно пустая)
     * @param border        Своя
     * @param insideborder  Внутренняя (обычно пустая)
     */
    public Border getBorder(Object outsideborder, Object border, Object insideborder) {
        Border ou = getBorder(outsideborder);
        Border br = getBorder(border);
        Border in = getBorder(insideborder);

        if (ou == null && br == null && in == null) {
            return null;
        }

        Border b1 = null;
        if (ou != null && br != null) {
            b1 = BorderFactory.createCompoundBorder(ou, br);
        } else if (ou != null) {
            b1 = ou;
        } else if (br != null) {
            b1 = br;
        }

        Border b2 = null;
        if (b1 != null && in != null) {
            b2 = BorderFactory.createCompoundBorder(b1, in);
        } else if (b1 != null) {
            b2 = b1;
        } else if (in != null) {
            b2 = in;
        }

        return b2;
    }

}
