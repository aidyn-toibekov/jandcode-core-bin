package jandcode.ui;

import javax.swing.*;

/**
 * Иконки и картинки.
 * Картинки хранятся в каталогах, добавленных через addPath.
 * Внутри каталоги по типам: iconXX, где XX-тип (например "16" или "32").
 */
public abstract class IconService extends UiBasedService {

    /**
     * Получить картинку по типу и имени.
     * Если картинки нет, возвращается null.
     */
    public abstract ImageIcon getIcon(String type, String name);

    /**
     * Картинка по типу 16 и имени
     */
    public ImageIcon getIcon16(String name) {
        return getIcon("16", name);
    }

    /**
     * Картинка по типу 32 и имени
     */
    public ImageIcon getIcon32(String name) {
        return getIcon("32", name);
    }

}
