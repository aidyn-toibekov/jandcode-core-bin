package jandcode.ui.std;

import jandcode.ui.std.impl.*;
import jandcode.utils.*;

/**
 * Поле ввода для long
 */
public class CtInputLong extends CustomInputNumNatural {

    public Long getValue() {
        return UtCnv.toLong(getCtrl().getText());
    }
}