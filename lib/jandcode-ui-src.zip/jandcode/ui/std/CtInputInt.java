package jandcode.ui.std;

import jandcode.ui.std.impl.*;
import jandcode.utils.*;

/**
 * Поле ввода для int
 */
public class CtInputInt extends CustomInputNumNatural {

    protected void onConstructor() throws Exception {
        super.onConstructor();
        setMinValue(Integer.MIN_VALUE);
        setMaxValue(Integer.MAX_VALUE);
    }

    public Integer getValue() {
        return UtCnv.toInt(getCtrl().getText());
    }

    ////// document

    protected long strToLong(String s) {
        return Integer.parseInt(s);
    }

}