package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.ui.std.impl.*;

import javax.swing.*;

public class CtMenuBar extends CustomMenuContainer {

    protected void createCtrl() {
        setCtrl(new JMenuBar());
        getCtrl().setBorder(null);
    }

    public JMenuBar getCtrl() {
        return (JMenuBar) super.getCtrl();
    }

    public boolean isEmpty() {
        return getCtrl().getMenuCount() == 0;
    }

    public void fill(UiMenu m) {
        m.sort();
        getCtrl().removeAll();
        fillMenu(m, getCtrl());
    }

}
