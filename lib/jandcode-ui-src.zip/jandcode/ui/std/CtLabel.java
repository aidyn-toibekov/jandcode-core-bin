package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.utils.error.*;

import javax.swing.*;

/**
 * Метка
 */
public class CtLabel extends UiControl {

    public class CTRL extends JLabel {

        public CTRL() {
            setFocusable(false);
        }

        void setHalign(String align) {
            if (align.equals("center") || align.equals("c")) {
                setHorizontalAlignment(JLabel.CENTER);
            } else if (align.equals("left") || align.equals("l")) {
                setHorizontalAlignment(JLabel.LEFT);
            } else if (align.equals("right") || align.equals("r")) {
                setHorizontalAlignment(JLabel.RIGHT);
            } else {
                throw new XError("Invalid align constant [%s]", align);
            }
        }

        void setValign(String align) {
            if (align.equals("center") || align.equals("c")) {
                setVerticalAlignment(JLabel.CENTER);
            } else if (align.equals("top") || align.equals("t")) {
                setVerticalAlignment(JLabel.TOP);
            } else if (align.equals("bottom") || align.equals("b")) {
                setVerticalAlignment(JLabel.BOTTOM);
            } else {
                throw new XError("Invalid align constant [%s]", align);
            }
        }

        void setAlign(String align) {
            String[] lst = align.split(",");
            if (lst.length != 2) {
                throw new XError("Invalid align constant [%s], expected 2 values delimited ','", align);
            }
            setHalign(lst[0]);
            setValign(lst[1]);
        }
    }


    protected void createCtrl() {
        setCtrl(new CTRL());
    }

    public CTRL getCtrl() {
        return (CTRL) super.getCtrl();
    }

    public void setTitle(String text) {
        super.setTitle(text);
        getCtrl().setText(text);
    }

    public void setVAlign(String align) {
        getCtrl().setValign(align);
    }

    public void setHAlign(String align) {
        getCtrl().setHalign(align);
    }

    public void setAlign(String align) {
        getCtrl().setAlign(align);
    }

    public void setUiStyle(UiStyle st) {
        super.setUiStyle(st);
        if (st.getHAlign() != null) {
            setHAlign(st.getHAlign());
        }
        if (st.getVAlign() != null) {
            setVAlign(st.getVAlign());
        }
    }

}
