package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.ui.std.impl.*;

/**
 * Пустое окно на основе JFrame
 */
public class WnDialog extends UiWindow {

    protected void createCtrl() {
        ctrl = new JDialogRealWindow(this.getUi());
    }

    public JDialogRealWindow getCtrl() {
        return (JDialogRealWindow) super.getCtrl();
    }

    protected void doShow() {
        getCtrl().getContentPane().removeAll();
        getCtrl().getContentPane().add(getInterior().getCtrl());
        getCtrl().setModal(true);
        getCtrl().pack();
        getCtrl().setLocationRelativeTo(null);
        getCtrl().setVisible(true);
    }

    protected void doClose() {
        getCtrl().setVisible(false);
        getCtrl().dispose();
    }

}
