package jandcode.ui.std.impl;

import jandcode.ui.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.event.*;

/**
 * Предок для строковых Input
 */
public abstract class CustomInputString extends UiControl implements
        DocumentListener, FocusListener, IUiDatasourceLink, IValue {

    private InputDocument _document;
    private int _width;
    private UiDatasource _uiDatasource;

    public class CTRL extends JTextField implements IUiControlLink {
        public UiControl getUiControl() {
            return CustomInputString.this;
        }
    }

    public class InputDocument extends PlainDocument {

        public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
            if (getUiDatasource().isDataToControlWork()) {
                super.insertString(offs, str, a);
            } else {
                if (str == null || str.length() == 0) {
                    return;
                }
                String s = getText(0, getLength());
                if (s == null) {
                    s = "";
                }
                try {
                    s = doInsertString(s, offs, str);
                    if (s.length() > 0) {
                        super.insertString(offs, str, a);
                    }
                } catch (Exception e) {
                    throw new XErrorWrap(e);
                }
            }
        }

    }

    protected void createCtrl() {
        setCtrl(new CTRL());
        getUi().initKeysForEditor(getCtrl(), false, true);
    }

    public JTextField getCtrl() {
        return (JTextField) super.getCtrl();
    }

    protected void onConstructor() throws Exception {
        super.onConstructor();
        createDocument();
        setWidth(10);
        getCtrl().addFocusListener(this);
        _uiDatasource = new UiDatasource();
    }

    public UiDatasource getUiDatasource() {
        return _uiDatasource;
    }

    //////

    protected void createDocument() {
        _document = new InputDocument();
        _document.addDocumentListener(this);
        getCtrl().setDocument(_document);
    }

    ////// DocumentListener

    public void changedUpdate(DocumentEvent e) {
    }

    public void insertUpdate(DocumentEvent e) {
        if (getUiDatasource().isDataToControlWork()) {
            return;
        }
        fireChange();
    }

    public void removeUpdate(DocumentEvent e) {
        if (getUiDatasource().isDataToControlWork()) {
            return;
        }
        fireChange();
    }

    ////// text

    public Object getValue() {
        return getCtrl().getText();
    }

    public void setValue(Object value) {
        String s = UtString.toString(value);
        getCtrl().setText(s);
    }

    ////// width

    public void setWidth(int width) {
        _width = width;
        if (_width > 0) {
            getCtrl().setColumns(width);
        }
    }

    public int getWidth() {
        return _width;
    }

    ////// document

    /**
     * Попытка ввести строку.
     *
     * @param cur  куда (текущее стостояние поле ввода)
     * @param offs в какую позицию
     * @param str  какая строка пытается ввестись
     * @return строка для вставки. Если ничего фильтровать не нужно, просто возвращается str.
     *         вообще ничего вводить нельзя, нужно возвратить пустую строку
     * @throws Exception
     */
    protected String doInsertString(String cur, int offs, String str) throws Exception {
        return str;
    }

    ////// focus

    public void focusGained(FocusEvent e) {
        // через механизм onFocusChange не работает selectAll! (выделение сбрасывается...)
        getCtrl().selectAll();
    }

    public void focusLost(FocusEvent e) {
    }

}
