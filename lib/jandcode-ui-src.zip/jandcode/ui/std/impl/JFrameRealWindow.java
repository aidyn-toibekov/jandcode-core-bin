package jandcode.ui.std.impl;

import jandcode.ui.*;

import javax.swing.*;
import java.awt.event.*;

/**
 * IRealWindow на основе JFrame
 */
public class JFrameRealWindow extends JFrame implements IRealWindow, WindowListener {

    private UiWindow _window;
    private boolean _firstActivate;

    public JFrameRealWindow() {
        addWindowListener(this);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        _firstActivate = true;
    }

    public UiWindow getUiWindow() {
        return _window;
    }

    public void setUiWindow(UiWindow window) {
        _window = window;
    }

    public void refresh() {
        JComponent c = (JComponent) getContentPane();
        c.paintImmediately(c.getVisibleRect());
    }

    public void windowActivated(WindowEvent e) {
        if (_firstActivate) {
            _firstActivate = false;
            getUiWindow().getFrame().selectFirstControl();
        }
    }

    public void windowClosed(WindowEvent e) {

    }

    public void windowClosing(WindowEvent e) {
        getUiWindow().performClose("cancel");
    }

    public void windowDeactivated(WindowEvent e) {

    }

    public void windowDeiconified(WindowEvent e) {

    }

    public void windowIconified(WindowEvent e) {

    }

    public void windowOpened(WindowEvent e) {

    }
}
