package jandcode.ui.std.impl;

import jandcode.ui.*;
import jandcode.ui.std.*;

import javax.swing.*;

public abstract class CustomMenuContainer extends UiControl implements IMenuContainer {

    protected void fillMenu(UiMenu act, JComponent menu) {
        boolean needSeparator = false;
        for (UiMenu a : act.getItems()) {
            if (a.isSubMenu()) {
                JMenu submenu = new JMenu(a.getTitle());
                fillMenu(a, submenu);
                menu.add(submenu);
                needSeparator = true;
            } else if (a.isSeparator()) {
                if (needSeparator) {
                    if (a != act.getLastItem()) {
                        if (menu instanceof JPopupMenu) {
                            ((JPopupMenu) menu).addSeparator();
                        } else if (menu instanceof JMenu) {
                            ((JMenu) menu).addSeparator();
                        }
                    }
                    needSeparator = false;
                }
            } else if (a.isAction()) {
                JMenuItem item = new JMenuItem(a.getAction().getSwingAction());
                if (a.hasIconName()) {
                    ImageIcon ic = getUi().getImageService().getIcon16(a.getIconName());
                    item.setIcon(ic);
                }
                menu.add(item);
                needSeparator = true;
            }
        }
    }

}
