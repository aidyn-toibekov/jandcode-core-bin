package jandcode.ui.std.impl;

import jandcode.ui.*;

import javax.swing.*;
import java.awt.*;

/**
 * Враппер вокруг JFrame для реализации IRealWindow
 */
public class JFrameWrapperRealWindow implements IRealWindow {

    private UiWindow _window;
    private JFrame wrap;

    public JFrameWrapperRealWindow() {
    }

    public JFrameWrapperRealWindow(JFrame wrap) {
        this.wrap = wrap;
    }

    public JFrame getWrap() {
        return wrap;
    }

    public void setWrap(JFrame wrap) {
        this.wrap = wrap;
    }

    public UiWindow getUiWindow() {
        return _window;
    }

    public void setUiWindow(UiWindow window) {
        _window = window;
    }

    public Dimension getSize() {
        return wrap.getSize();
    }

    public void setSize(Dimension d) {
        wrap.setSize(d);
    }

    public void setLocation(Point p) {
        wrap.setLocation(p);
    }

    public Point getLocation() {
        return wrap.getLocation();
    }

    public void refresh() {
        JComponent c = (JComponent) wrap.getContentPane();
        if (c == null) {
            return;
        }
        c.paintImmediately(c.getVisibleRect());
    }

    public void setTitle(String s) {
        wrap.setTitle(s);
    }
}
