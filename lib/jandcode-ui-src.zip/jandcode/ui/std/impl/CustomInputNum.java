package jandcode.ui.std.impl;

import javax.swing.*;
import java.awt.event.*;

/**
 * Общий предок для ввода чисел
 */
public abstract class CustomInputNum extends CustomInputString {

    private boolean _alignRight;

    protected void onConstructor() throws Exception {
        super.onConstructor();
        _alignRight = true;
    }

    //////

    /**
     * Выравнивание вправо неактивного control
     */
    public void setAlignRight(boolean alignRight) {
        _alignRight = alignRight;
    }

    public boolean isAlignRight() {
        return _alignRight;
    }

    //////

    public void focusGained(FocusEvent e) {
        if (isAlignRight()) {
            getCtrl().setHorizontalAlignment(JTextField.LEFT);
        }
        super.focusGained(e);
    }

    public void focusLost(FocusEvent e) {
        if (isAlignRight()) {
            getCtrl().setHorizontalAlignment(JTextField.RIGHT);
        }
        super.focusLost(e);
    }

    //////

}