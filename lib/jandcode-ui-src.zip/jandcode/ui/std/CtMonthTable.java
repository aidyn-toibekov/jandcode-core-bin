package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.utils.*;
import org.joda.time.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * Таблица с днями месяца для календаря
 */
public class CtMonthTable extends UiControl {

    public static String STYLE_LABEL = "label";
    public static String STYLE_DAYNAME = "label/dayname";
    public static String STYLE_HOLYDAYNAME = "label/holydayname";
    public static String STYLE_DAY = "label/day";
    public static String STYLE_HOLYDAY = "label/holyday";
    public static String STYLE_TODAY = "today";
    public static String STYLE_LINEDAYNAME = "linedayname";
    public static String STYLE_SELECTED = "selected";
    public static String STYLE_SELECTED_INACTIVE = "selected.inactive";
    public static String STYLE_NOTMONTH = "label/notmonth";

    private DateTime _date;
    private DateTime _leftTopDate;
    private DateTime _bomDate;

    private int _startWeekDay;

    private Locale _locale;
    private boolean _setDateWork;

    private Dimension _prefSize;
    private boolean _showBottomLine;

    /**
     * Модель месяца
     */
    public class MonthModel extends AbstractTableModel {

        /**
         * Дата, которую будем возвращаеть из модели
         */
        private MutableDateTime _resDate;

        public MonthModel() {
            _resDate = new MutableDateTime();
            _resDate.setMillisOfDay(0);
        }

        public int getRowCount() {
            return 7;
        }

        public int getColumnCount() {
            return 7;
        }

        public Object getValueAt(int row, int column) {
            if (row == 0) {
                return null;
            }
            _resDate.setDate(_leftTopDate);
            _resDate.addDays((row - 1) * 7 + column);
            return _resDate;
        }

    }

    /**
     * Отрисовщик ячейки таблицы
     */
    public class CellRender implements TableCellRenderer {

        private CtLabel renderDay;

        public CellRender() {
            renderDay = getUi().getObjectFactory().create(CtLabel.class);
            renderDay.setUiStyle(getUiStyle().child(STYLE_LABEL));
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus,
                int row, int column) {
            renderDay.setTitle("");
            String style = STYLE_LABEL;

            ReadableDateTime d = (ReadableDateTime) value;

            if (value == null) {
                if (row == 0) {
                    // названия месяцев
                    DateTime dw = _leftTopDate.plusDays(column);
                    renderDay.setTitle(dw.dayOfWeek().getAsShortText(_locale));
                    if (dw.dayOfWeek().get() >= DateTimeConstants.SATURDAY) {
                        style = STYLE_HOLYDAYNAME;
                    } else {
                        style = STYLE_DAYNAME;
                    }
                }
            } else {
                renderDay.setTitle(d.toString("d"));
                style = STYLE_DAY;
                if (d.getDayOfWeek() >= DateTimeConstants.SATURDAY) {
                    style = STYLE_HOLYDAY;
                }
                if (_bomDate.getMonthOfYear() != d.getMonthOfYear()) {
                    style = STYLE_NOTMONTH;
                }
                if (UtDate.isToday(d)) {
                    style = STYLE_TODAY;
                }
            }

            renderDay.setUiStyle(getUiStyle().child(style));

            if (isSelected) {
                if (table.hasFocus()) {
                    renderDay.setUiStyle(getUiStyle().child(STYLE_SELECTED));
                } else {
                    renderDay.setUiStyle(getUiStyle().child(STYLE_SELECTED_INACTIVE));
                }
            }

            return renderDay.getCtrl();
        }
    }

    /**
     * Внутренний control
     */
    public class JpMonthTable_internal extends JTable {

        public void changeSelection(int rowIndex, int columnIndex, boolean toggle, boolean extend) {
            if (rowIndex < 1) {
                // запрещаем выделять строку с названием дней недели
                return;
            }
            super.changeSelection(rowIndex, columnIndex, toggle, extend);
            if (!toggle && !extend) {
                MutableDateTime dt = (MutableDateTime) getValueAt(rowIndex, columnIndex);
                if (dt != null) {
                    setDate(dt.toDateTime());
                }
            }
        }

        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // линия, отделяющая таблицу с днями
            Color c = getUiStyle().child(STYLE_LINEDAYNAME).getForeground();
            if (c == null) {
                c = Color.black;
            }
            g.setColor(c);
            int y = getRowHeight(0) - 2;
            g.drawLine(0, y, getWidth(), y);
            if (_showBottomLine) {
                g.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1);
            }
        }

        protected void processKeyEvent(KeyEvent e) {
            if (e.getID() == KeyEvent.KEY_PRESSED) {
                if (e.getKeyCode() == KeyEvent.VK_UP && getSelectedRow() == 1) {
                    setDate(getDate().minusDays(7));
                    return;
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN && getSelectedRow() == 6) {
                    setDate(getDate().plusDays(7));
                    return;
                } else if (e.getKeyCode() == KeyEvent.VK_LEFT && getSelectedColumn() == 0) {
                    setDate(getDate().minusDays(1));
                    return;
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT && getSelectedColumn() == 6) {
                    setDate(getDate().plusDays(1));
                    return;
                } else if (e.getKeyCode() == KeyEvent.VK_PAGE_DOWN && e.getModifiers() == 0) {
                    setDate(getDate().plusMonths(1));
                    return;
                } else if (e.getKeyCode() == KeyEvent.VK_PAGE_UP && e.getModifiers() == 0) {
                    setDate(getDate().minusMonths(1));
                    return;
                } else if (e.getKeyCode() == KeyEvent.VK_PAGE_DOWN &&
                        e.getModifiers() == KeyEvent.CTRL_MASK) {
                    setDate(getDate().plusYears(1));
                    return;
                } else if (e.getKeyCode() == KeyEvent.VK_PAGE_UP &&
                        e.getModifiers() == KeyEvent.CTRL_MASK) {
                    setDate(getDate().minusYears(1));
                    return;
                }
            }
            super.processKeyEvent(e);

        }

        public Dimension getPreferredSize() {
            if (isPreferredSizeSet()) {
                return super.getPreferredSize();
            } else {
                return _prefSize;
            }
        }
    }


    protected void createCtrl() {
        setCtrl(new JpMonthTable_internal());
    }

    public JTable getCtrl() {
        return (JTable) super.getCtrl();
    }

    protected void onConstructor() throws Exception {
        super.onConstructor();
        ///
        getUi().initTabKeys(getCtrl());
        ///
        _locale = Locale.getDefault();
        _startWeekDay = DateTimeConstants.MONDAY;
        ///
        getCtrl().setModel(new MonthModel());
        getCtrl().getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        getCtrl().getColumnModel().getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        getCtrl().setShowGrid(false);
        getCtrl().setCellSelectionEnabled(true);
        //
        //
        setUiStyle("calendar");
        //
        setDateInternal(new DateTime("1990-01-01"));
    }

    //////////////

    /**
     * Изменение даты.
     *
     * @param date новая дата
     * @return true, если изменилась
     */
    private boolean setDateInternal(DateTime date) {
        if (date == null) {
            date = new DateTime();
        }
        date = date.withMillisOfDay(0);
        if (!date.equals(_date)) {
            _date = date.withMillisOfDay(0);
            _bomDate = _date.withDayOfMonth(1);
            _leftTopDate = _bomDate.withDayOfWeek(_startWeekDay);
            return true;
        } else {
            return false;
        }
    }


    /**
     * Текущая дата
     */
    public DateTime getDate() {
        return _date;
    }

    public void setDate(DateTime date) {
        if (_setDateWork) {
            return;
        }
        _setDateWork = true;
        try {
            DateTime saveLeftTopDate = _leftTopDate;
            if (setDateInternal(date)) {

                int d = Days.daysBetween(_leftTopDate, getDate()).getDays();
                int row = d / 7 + 1;
                int col = d % 7;

                if (row != getCtrl().getSelectedRow()) {
                    getCtrl().setRowSelectionInterval(row, row);
                }
                if (col != getCtrl().getSelectedColumn()) {
                    getCtrl().setColumnSelectionInterval(col, col);
                }

                if (!saveLeftTopDate.equals(_leftTopDate)) {
                    refresh();
                }

                fireChange();
            }
        } finally {
            _setDateWork = false;
        }
    }

    //////

    public Locale getLocale() {
        return _locale;
    }

    public void setLocale(Locale locale) {
        _locale = locale;
    }
    //////

    public void setUiStyle(UiStyle st) {
        super.setUiStyle(st);

        Dimension szLabel = st.child(STYLE_LABEL).getSize();
        if (szLabel == null) {
            szLabel = new Dimension(20, 20);
        }
        Dimension szDayName = st.child(STYLE_DAYNAME).getSize();
        if (szDayName == null) {
            szDayName = new Dimension(20, 20);
        }

        int wcell = Math.max(szLabel.width, szDayName.width);

        getCtrl().setRowHeight(szLabel.height);
        getCtrl().setRowHeight(0, szDayName.height);

        int colCount = getCtrl().getColumnCount();
        int rowCount = getCtrl().getRowCount();
        int w = wcell * colCount;
        int h = szDayName.height + (rowCount - 1) * szLabel.height;

        _prefSize = new Dimension(w, h);

        // render тоже здесь!
        getCtrl().setDefaultRenderer(Object.class, new CellRender());
    }

    /**
     * Показывать нижнюю линию
     *
     * @param showBottomLine
     */
    public void setShowBottomLine(boolean showBottomLine) {
        _showBottomLine = showBottomLine;
    }

    public boolean isShowBottomLine() {
        return _showBottomLine;
    }

}


