package jandcode.ui.std;

import jandcode.ui.*;

public class FrMsgBox extends UiFrame implements OnClick {

    protected void onConstructor() throws Exception {
        super.onConstructor();
        //
        setWindowName("dialog");
        setInteriorName("empty");
        //
        getUi().createBuilder(this).load("/jandcode/ui/std/forms/FrMsgBox.ui.xml");
    }

    public void onClick(UiControl ctrl) throws Exception {
        close(ctrl.getName());
    }

    public void addButton(String key, String title, String shortcut) {
        CtButton b = getUi().getObjectFactory().create(CtButton.class);
        b.setName(key);
        b.setTitle(title);
        b.setShortcut(shortcut);
        b.addEvent(this);
        control("buttons-panel").addControl(b);
    }

    public void setMessage(String s) {
        CtMemo m = (CtMemo) control("message");
        m.setValue(s);
    }

    public void setIcon(String s) {
        CtIcon m = (CtIcon) control("icon");
        m.setIcon(s);
    }

}
