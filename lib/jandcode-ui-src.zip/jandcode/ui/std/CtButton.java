package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.utils.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Кнопка
 */
public class CtButton extends UiControl {

    public static int MINWIDTH = 75;

    private String _shortcut;
    private boolean _flat;
    private Dimension _prefSize;

    public class CTRL extends JButton implements IUiControlLink {
        public CTRL() {
            getUi().initKeysForEditor(this, true, false);
        }

        public UiControl getUiControl() {
            return CtButton.this;
        }

        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            if (_prefSize == null) {
                if (!isPreferredSizeSet()) {
                    if (d.width < MINWIDTH) {
                        d.width = MINWIDTH;
                    }
                }
                return d;
            } else {
                Dimension d1 = new Dimension(_prefSize);
                if (d1.width <= 0) {
                    d1.width = d.width;
                }
                if (d1.height <= 0) {
                    d1.height = d.height;
                }
                return d1;
            }
        }

        protected void fireActionPerformed(ActionEvent event) {
            try {
                // перерисовка
                CtButton.this.refreshFrame();
                // исполнение
                super.fireActionPerformed(event);
                // событие
                CtButton.this.onClick();
                for (OnClick h : getEvents().list(OnClick.class)) {
                    h.onClick(CtButton.this);
                }
            } catch (Exception e) {
                getUi().getMsgboxService().showError(e);
            }
        }

    }

    protected void createCtrl() {
        setCtrl(new CTRL());
    }

    public JButton getCtrl() {
        return (JButton) super.getCtrl();
    }

    protected void onSetPrefSize(Dimension d) {
        _prefSize = d;
    }

    ////// event: onClick

    public void addEvent(OnClick h) {
        _events.add(h);
    }

    public void fireClick() {
        ((CTRL) getCtrl()).fireActionPerformed(new ActionEvent(getCtrl(), 0, ""));
    }

    protected void onClick() throws Exception {
    }

    //////

    public void setTitle(String text) {
        super.setTitle(text);
        getCtrl().setText(text);
    }

    //////

    public void setShortcut(String shortcut) {
        _shortcut = shortcut;
        if (UtString.empty(shortcut)) {
            return;
        }
        getUi().bindShortcut(getCtrl(), shortcut, new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (isFocus() || setFocus()) {
                    fireClick();
                }
            }
        });
    }

    public String getShortcut() {
        return _shortcut == null ? "" : _shortcut;
    }

    //////

    /**
     * Плоская кнопка. Такая кнопка при наведении курсора мыши получит эффект с рамкой. А без мыши
     * будет выглядеть как текст. Как на toolbar.
     */
    public void setFlat(boolean flat) {
        if (_flat == flat) {
            return;
        }
        _flat = flat;
        if (_flat) {
            getCtrl().setRolloverEnabled(true);
            setBorder("buttonrolloved");
        } else {
            getCtrl().setRolloverEnabled(false);
            setBorder("button");
        }
    }

    public boolean isFlat() {
        return _flat;
    }

}
