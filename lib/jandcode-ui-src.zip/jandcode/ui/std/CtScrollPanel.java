package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.utils.error.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Панель для скроллирования содержащихся в ней объектов
 */
public class CtScrollPanel extends UiControl {

    private JComponent _internalControl;

    /**
     * true - используется как стационарный. Первый добавленный в xc
     * дочерний control будет скроллироваться. Иначе - используется как предок для
     * скроллируемых компонентов (например - список)
     */
    protected boolean _stationary;


    protected void createCtrl() {
        setCtrl(new JScrollPane());
    }

    public JScrollPane getCtrl() {
        return (JScrollPane) super.getCtrl();
    }

    protected void onConstructor() throws Exception {
        super.onConstructor();

        getCtrl().addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                if (_stationary && (!isHScroll() || !isVScroll())) {
                    // в стационарном режиме - меняем размер дочернего, если есть
                    // ограничения по видимости полос скроллинга
                    getInternalControl().setPreferredSize(null);
                    Dimension ps = getInternalControl().getPreferredSize();
                    if (!isHScroll()) {
                        ps.width = getCtrl().getWidth() - UIManager.getDefaults().getInt("ScrollBar.width");
                    }
                    if (!isVScroll()) {
                        ps.height = getCtrl().getHeight() - UIManager.getDefaults().getInt("ScrollBar.width");
                    }
                    getInternalControl().setPreferredSize(ps);
                }
            }
        });

    }

    /**
     * Скроллируемый control
     */
    public JComponent getInternalControl() {
        return _internalControl;
    }

    public void setInternalControl(JComponent internalControl) {
        _internalControl = internalControl;
    }

    protected void onAddControl(UiControl item, Object layoutConstr) {
        if (getInternalControl() != null) {
            throw new XError("scrollpanel must have only one child control");
        }
        getCtrl().setViewportView(item.getCtrl());
        setInternalControl(item.getCtrl());
        _stationary = true;
    }

    public boolean isHScroll() {
        return getCtrl().getHorizontalScrollBarPolicy() == ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
    }

    public void setHScroll(boolean hscroll) {
        if (hscroll) {
            getCtrl().setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        } else {
            getCtrl().setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        }
    }

    public boolean isVScroll() {
        return getCtrl().getVerticalScrollBarPolicy() == ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
    }

    public void setVScroll(boolean vscroll) {
        if (vscroll) {
            getCtrl().setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        } else {
            getCtrl().setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        }
    }

    public void setForeground(Object fg) {
        super.setForeground(fg);
        if (getInternalControl() != null) {
            getInternalControl().setForeground(getUi().getColorService().getColor(fg));
        }
    }

    public void setBackground(Object bg) {
        super.setBackground(bg);
        if (getInternalControl() != null) {
            getInternalControl().setBackground(getUi().getColorService().getColor(bg));
        }
    }


    public boolean isFocusable() {
        if (getInternalControl() != null) {
            return getInternalControl().isFocusable();
        } else {
            return false;
        }
    }


    public void setFocusable(boolean flag) {
        if (getInternalControl() != null) {
            getInternalControl().setFocusable(flag);
        }
    }


    public boolean setFocus() {
        if (getInternalControl() != null) {
            return getInternalControl().requestFocusInWindow();
        }
        return false;
    }


    public boolean isFocus() {
        if (getInternalControl() != null) {
            return getInternalControl().isFocusOwner();
        }
        return super.isFocus();
    }

}
