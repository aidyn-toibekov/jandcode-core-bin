package jandcode.ui.std;

import jandcode.ui.*;

/**
 * Контейнер меню
 */
public interface IMenuContainer {

    /**
     * Есть ли элементы
     */
    boolean isEmpty();

    /**
     * Заполнить из m
     */
    void fill(UiMenu m);

}
