package jandcode.ui.std;

import jandcode.ui.*;

import java.awt.*;

public class ItDialog extends UiInterior implements OnClick {

    protected void onConstructor() throws Exception {
        super.onConstructor();
        //
        getUi().createBuilder(this).load("/jandcode/ui/std/forms/ItDialog.ui.xml");
        //
        buildButtonsPanel(control("buttons-panel"));
    }

    protected void buildButtonsPanel(UiControl panel) {
        addButton("ok", "Ок", "Ctrl+Enter");
        addButton("cancel", "Отмена", "Esc");
    }

    public void onClick(UiControl ctrl) throws Exception {
        getFrame().close(ctrl.getName());
    }

    public void addButton(String key, String title, String shortcut) {
        CtButton b = getUi().getObjectFactory().create(CtButton.class);
        b.setName(key);
        b.setTitle(title);
        b.setShortcut(shortcut);
        b.addEvent(this);
        control("buttons-panel").addControl(b);
    }

    protected void onSetFrame() {
        UiControl p = control("frame-place");
        p.getCtrl().setLayout(new BorderLayout());
        p.getCtrl().add(getFrame().getCtrl(), BorderLayout.CENTER);
    }

}
