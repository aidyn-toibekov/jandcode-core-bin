package jandcode.ui.std;

import jandcode.utils.*;
import jandcode.utils.variant.*;

import javax.swing.*;

/**
 * Memo
 */
public class CtMemo extends CtScrollPanel implements IValue {

    protected void onConstructor() throws Exception {
        super.onConstructor();

        setInternalControl(new JTextArea(""));
        getCtrl().setViewportView(getInternalControl());
        getInternalControl().setLineWrap(true);
        getInternalControl().setWrapStyleWord(true);

        setFont(UIManager.getFont("Label.font"));
    }

    public JTextArea getInternalControl() {
        return (JTextArea) super.getInternalControl();
    }

    public String getValue() {
        return getInternalControl().getText();
    }

    public void setValue(Object v) {
        String s = UtString.toString(v);
        getInternalControl().setText(s);
        setCaretPositionBegin();
    }

    public void setReadOnly(boolean readOnly) {
        getInternalControl().setEditable(!readOnly);
    }

    public boolean isReadOnly() {
        return !getInternalControl().isEditable();
    }

    public int getCaretPosition() {
        return getInternalControl().getCaretPosition();
    }

    public void setCaretPosition(int position) {
        getInternalControl().setCaretPosition(position);
    }

    public void setCaretPositionEnd() {
        setCaretPosition(getTitle().length());
    }

    public void setCaretPositionBegin() {
        setCaretPosition(0);
    }

    public void setFont(Object font) {
        super.setFont(font);
        getInternalControl().setFont(getUi().getFontService().getFont(getInternalControl().getFont(), font));
    }

}

