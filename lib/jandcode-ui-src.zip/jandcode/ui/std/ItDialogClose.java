package jandcode.ui.std;

import jandcode.ui.*;

public class ItDialogClose extends ItDialog {

    protected void buildButtonsPanel(UiControl panel) {
        addButton("cancel", "Закрыть", "Esc");
    }
}
