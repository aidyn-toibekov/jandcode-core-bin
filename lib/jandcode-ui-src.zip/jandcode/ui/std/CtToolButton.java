package jandcode.ui.std;

import jandcode.ui.*;

import javax.swing.*;
import java.awt.*;

public class CtToolButton extends UiControl {

    private UiAction _action;
    private String _iconType;

    protected void createCtrl() {
        setCtrl(new JButton());
        getCtrl().setFocusable(false);
        getCtrl().setMargin(new Insets(0, 0, 0, 0));
        getCtrl().setRolloverEnabled(true);
    }

    public JButton getCtrl() {
        return (JButton) super.getCtrl();
    }

    protected void onConstructor() throws Exception {
        super.onConstructor();
        _iconType = "16";
    }

    public UiAction getAction() {
        return _action;
    }

    public void setAction(UiAction action) {
        _action = action;
        if (_action != null) {
            getCtrl().setAction(action.getSwingAction());
            getCtrl().setText("");
            getCtrl().setToolTipText(action.makeTooltip());
            getCtrl().setIcon(getUi().getImageService().getIcon(getIconType(), action.getIconName()));
            if (getCtrl().getIcon() == null) {
                getCtrl().setIcon(getUi().getImageService().getIcon(getIconType(), "tool"));
            }
        }
    }

    /**
     * Тип картинки. По умолчанию : "16"
     *
     * @param iconType
     */
    public void setIconType(String iconType) {
        _iconType = iconType;
    }

    public String getIconType() {
        return _iconType;
    }

    public void setIcon(String imageName) {
        getCtrl().setIcon(getUi().getImageService().getIcon(getIconType(), imageName));
    }

    public void setIcon(ImageIcon image) {
        getCtrl().setIcon(image);
    }

    public String getTitle() {
        return getCtrl().getText();
    }

    public void setTitle(String text) {
        getCtrl().setText(text);
    }

}
