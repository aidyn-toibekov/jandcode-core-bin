package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.ui.impl.*;
import org.joda.time.*;

import java.awt.event.*;

public class CtCalendar extends CustomPanel {

    CtMonthTable _monthTable;

    public static interface ICalendar {
        public void setCalendar(CtCalendar calendar);
    }

    /**
     * Для смены месяца из меню
     */
    public static class ActionChangeMonth extends UiAction implements ICalendar {
        private int _month;
        CtCalendar calendar;

        public void setCalendar(CtCalendar calendar) {
            this.calendar = calendar;
        }

        public int getMonth() {
            return _month;
        }

        public void setMonth(int month) {
            _month = month;
            DateTime d = new DateTime().withMonthOfYear(_month);
            setTitle(d.toString("MM - MMMM"));
        }

        protected void onAction() throws Exception {
            calendar.setDate(calendar.getDate().withMonthOfYear(getMonth()));
        }
    }

    /**
     * Для смены года из меню
     */
    public static class ActionChangeYear extends UiAction implements ICalendar {
        private int _year;
        CtCalendar calendar;

        public void setCalendar(CtCalendar calendar) {
            this.calendar = calendar;
        }

        public int getYear() {
            return _year;
        }

        public void setYear(int year) {
            _year = year;
            setTitle("" + _year);
        }

        protected void onAction() throws Exception {
            calendar.setDate(calendar.getDate().withYear(getYear()));
        }
    }

    /**
     * Кнопка навигации по годам,месяцам
     */
    public static class ControlNavButton extends CtButton implements ICalendar {

        CtCalendar calendar;

        public void setCalendar(CtCalendar calendar) {
            this.calendar = calendar;
        }

        protected void onClick() throws Exception {
            String nm = getName();
            if (nm.equals("ym")) {
                calendar.setDate(calendar.getDate().minusYears(1));
            } else if (nm.equals("mm")) {
                calendar.setDate(calendar.getDate().minusMonths(1));
            } else if (nm.equals("yp")) {
                calendar.setDate(calendar.getDate().plusYears(1));
            } else if (nm.equals("mp")) {
                calendar.setDate(calendar.getDate().plusMonths(1));
            }
        }

//        protected void onFillActionLink(OnFillActionLinkParam p) {
//            super.onFillActionLink(p);
//            if (p.getAct().hasNamePopup()) {
//                if (getName().startsWith("m")) {
//                    for (int i = 1; i < 12; i++) {
//                        ActionChangeMonth a = new ActionChangeMonth();
//                        a.setMonth(i);
//                        a.setCalendar(calendar);
//                        p.getAct().addItem(a);
//                    }
//                } else if (getName().startsWith("y")) {
//                    int delta = 1;
//                    if (getName().charAt(1) == 'm') {
//                        delta = -1;
//                    }
//                    int curYear = calendar.getDate().getYear();
//                    for (int i = 1; i < 12; i++) {
//                        ActionChangeYear a = new ActionChangeYear();
//                        curYear = curYear + delta;
//                        a.setYear(curYear);
//                        a.setCalendar(calendar);
//                        p.getAct().addItem(a);
//                    }
//                }
//            }
//        }
    }

    /**
     * Кнопка навигации по годам,месяцам
     */
    public static class ControlYMLabel extends CtLabel implements ICalendar {
        CtCalendar calendar;

        protected void onConstructor() throws Exception {
            super.onConstructor();
            getCtrl().addMouseListener(new MouseAdapter() {
                public void mouseReleased(MouseEvent e) {
                    showPopupMenu(e.getX(), e.getY());
                }
            });
        }

        public void setCalendar(CtCalendar calendar) {
            this.calendar = calendar;
        }

//        protected void onFillActionLink(OnFillActionLinkParam p) {
//            super.onFillActionLink(p);
//            if (p.getAct().hasNamePopup()) {
//                if (getName().startsWith("m")) {
//                    for (int i = 1; i < 12; i++) {
//                        ActionChangeMonth a = new ActionChangeMonth();
//                        a.setMonth(i);
//                        a.setCalendar(calendar);
//                        p.getAct().addItem(a);
//                    }
//                } else if (getName().startsWith("y")) {
//                    int delta = 1;
//                    int curYear = calendar.getDate().getYear() - 6;
//                    for (int i = 1; i < 12; i++) {
//                        ActionChangeYear a = new ActionChangeYear();
//                        curYear = curYear + delta;
//                        a.setYear(curYear);
//                        a.setCalendar(calendar);
//                        p.getAct().addItem(a);
//                    }
//                }
//            }
//        }

    }

    protected void onConstructor() throws Exception {
        super.onConstructor();
        getUi().createBuilder(this).load("/jandcode/ui/std/CtCalendar.ui.xml");
        setUiStyle("calendar");
        _monthTable = (CtMonthTable) control("month");
        _monthTable.addEvent(new OnChange() {
            public void onChange(UiControl ctrl) {
                DateTime d = getDate();
                control("month.label").setTitle(d.toString("MMMM"));
                control("year.label").setTitle(d.toString("yyyy"));
            }
        });
        CtButton b;

        DateTime today = new DateTime();

        b = (CtButton) control("today");
        b.setTitle("Сегодня: " + today.toString("dd MMMM yyyy"));
        b.addEvent(new OnClick() {
            public void onClick(UiControl ctrl) {
                setDate(new DateTime());
            }
        });

        ((ControlNavButton) control("ym")).setCalendar(this);
        ((ControlNavButton) control("yp")).setCalendar(this);
        ((ControlNavButton) control("mm")).setCalendar(this);
        ((ControlNavButton) control("mp")).setCalendar(this);
        ((ControlYMLabel) control("year.label")).setCalendar(this);
        ((ControlYMLabel) control("month.label")).setCalendar(this);

        setDate(new DateTime());
        _monthTable.fireChange();
    }

    public void setUiStyle(UiStyle st) {
        super.setUiStyle(st);
        control("header").setUiStyleDeep(st.child("header"));
        control("month.panel").setUiStyleDeep(st);
        control("footer").setUiStyleDeep(st.child("footer"));
    }

    public DateTime getDate() {
        return _monthTable.getDate();
    }

    public void setDate(DateTime dt) {
        _monthTable.setDate(dt);
    }

    public boolean setFocus() {
        if (_monthTable != null) {
            return _monthTable.setFocus();
        }
        return false;
    }


    public boolean isFocus() {
        if (_monthTable != null) {
            return _monthTable.isFocus();
        }
        return super.isFocus();
    }

}
