package jandcode.ui.std;

import jandcode.ui.std.impl.*;

/**
 * Редактор string
 */
public class CtInputString extends CustomInputString {

    private int _maxLength = 0;

    ////// maxlenght

    /**
     * Максимальная длина строки в поле ввода
     */
    public void setMaxLength(int maxLength) {
        _maxLength = maxLength;
    }

    public int getMaxLength() {
        return _maxLength;
    }

    //////

    protected String doInsertString(String cur, int offs, String str) throws Exception {
        if (getMaxLength() != 0) {
            if (cur.length() == getMaxLength()) {
                str = "";
            } else {
                if (cur.length() + str.length() > getMaxLength()) {
                    int n = getMaxLength() - cur.length();
                    str = str.substring(0, n);
                }
            }
        }
        return str;
    }

}
