package jandcode.ui.std;

import jandcode.ui.*;

import javax.swing.*;

/**
 * Разделитель
 */
public class CtSeparator extends UiControl {

    protected void createCtrl() {
        setCtrl(new JSeparator());
    }

    public JSeparator getCtrl() {
        return (JSeparator) super.getCtrl();
    }

    protected void onConstructor() throws Exception {
        super.onConstructor();
    }

    public void setVert(boolean flag) {
        if (flag) {
            getCtrl().setOrientation(JSeparator.VERTICAL);
        } else {
            getCtrl().setOrientation(JSeparator.HORIZONTAL);
        }
    }

}
