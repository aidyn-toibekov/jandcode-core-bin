package jandcode.ui.std;

import jandcode.ui.impl.*;

public class CtPanel extends CustomPanel {

    public void setTitle(String text) {
        // если текст присваивается и рамка titled - заменяем заголовок на рамке
        super.setTitle(text);
        setBorderTitle(text);
    }

    public void setBorder(Object border) {
        // если текст присваивается и рамка titled - заменяем заголовок на рамке
        super.setBorder(border);
        setTitle(getTitle());
    }

    public void setBorderOutside(Object borderOutside) {
        super.setBorderOutside(borderOutside);
        setTitle(getTitle());
    }

    public void setBorderInside(Object borderInside) {
        super.setBorderInside(borderInside);
        setTitle(getTitle());
    }

}
