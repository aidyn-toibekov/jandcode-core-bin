package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.ui.std.impl.*;

import javax.swing.*;

/**
 * Пустое окно на основе JFrame
 */
public class WnEmpty extends UiWindow implements IJFrameLink {

    protected void createCtrl() {
        ctrl = new JFrameRealWindow();
    }

    public JFrameRealWindow getCtrl() {
        return (JFrameRealWindow) super.getCtrl();
    }

    public JFrame getJFrame() {
        return getCtrl();
    }

    protected void doShow() {
        getCtrl().getContentPane().removeAll();
        getCtrl().getContentPane().add(getInterior().getCtrl());
        getCtrl().pack();
        getCtrl().setLocationRelativeTo(null);
        getCtrl().setVisible(true);
    }

    protected void doClose() {
        getCtrl().setVisible(false);
        getCtrl().dispose();
    }

}
