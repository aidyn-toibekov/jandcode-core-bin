package jandcode.ui.std;

import jandcode.ui.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

/**
 * Иконка
 */
public class CtIcon extends UiControl {

    private ImageIcon _icon;
    private String _iconType;
    private String _iconName;

    public class CTRL extends JLabel {

        private int _width = 32;
        private int _height = 32;

        public CTRL() {
            setFocusable(false);
        }

        public Dimension getPreferredSize() {
            Border b = getBorder();
            if (b != null) {
                Insets ins = b.getBorderInsets(this);
                return new Dimension(_width + ins.left + ins.right, _height + ins.top + ins.bottom);
            } else {
                return new Dimension(_width, _height);
            }
        }

        public void setImage(ImageIcon image) {
            _height = 0;
            _width = 0;
            try {
                setIcon(image);
                if (getIcon() != null) {
                    _width = getIcon().getIconWidth();
                    _height = getIcon().getIconHeight();
                }
            } catch (Exception e) {
            }
        }


    }

    protected void createCtrl() {
        setCtrl(new CTRL());
    }

    public CTRL getCtrl() {
        return (CTRL) super.getCtrl();
    }

    protected void onConstructor() throws Exception {
        super.onConstructor();
        _iconType = "32";
    }

    protected void resetIcon() {
        getCtrl().setImage(getIcon());
    }

    public ImageIcon getIcon() {
        return _icon;
    }

    public void setIcon(String iconName) {
        _iconName = iconName;
        setIcon(getUi().getImageService().getIcon(getIconType(), iconName));
    }

    public void setIcon(ImageIcon image) {
        _icon = image;
        resetIcon();
    }

    public String getIconType() {
        return _iconType;
    }

    public void setIconType(String iconType) {
        _iconType = iconType;
        _icon = getUi().getImageService().getIcon(getIconType(), _iconName);
        resetIcon();
    }

    //////

    protected void onSetPrefSize(Dimension d) {
        // ничего не делаем
    }

}
