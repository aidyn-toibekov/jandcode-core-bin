package jandcode.ui.std;

import jandcode.ui.*;

import java.awt.*;

/**
 * Пустой интерьер без оформления
 */
public class ItEmpty extends UiInterior {

    protected void onSetFrame() {
        getCtrl().setLayout(new BorderLayout());
        getCtrl().add(getFrame().getCtrl(), BorderLayout.CENTER);
    }

}
