package jandcode.ui.std;

import jandcode.ui.*;

import javax.swing.*;

public class CtToolBar extends UiControl implements IMenuContainer {

    private String _iconType;

    protected void createCtrl() {
        setCtrl(new JToolBar());
        getCtrl().setFloatable(false);
        getCtrl().setRollover(true);
        getCtrl().setFocusable(false);
    }

    public JToolBar getCtrl() {
        return (JToolBar) super.getCtrl();
    }

    protected void onConstructor() throws Exception {
        super.onConstructor();
        _iconType = "16";
    }

    public boolean isEmpty() {
        return getCtrl().getComponentCount() == 0;
    }

    /**
     * Тип картинки. По умолчанию : "16"
     *
     * @param iconType
     */
    public void setIconType(String iconType) {
        _iconType = iconType;
    }

    public String getIconType() {
        return _iconType;
    }

    /**
     * Заполнение меню.
     *
     * @param m
     */
    public void fill(UiMenu m) {
        m.sort();
        getCtrl().removeAll();
        for (UiMenu a : m.getItems()) {
            if (a.isControl()) {
                getCtrl().add(a.getControl().getCtrl());
            } else if (a.isSeparator()) {
                if (a != m.getLastItem()) {
                    getCtrl().addSeparator();
                }
            } else if (a.isAction()) {
                CtToolButton it = (CtToolButton) getUi().createControl("toolbutton");
                it.setIconType(getIconType());
                it.setAction(a.getAction());
                if (a.hasIconName()) {
                    it.setIcon(a.getIconName());
                }
                getCtrl().add(it.getCtrl());
            }
        }
    }

}
