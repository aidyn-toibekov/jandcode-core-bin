package jandcode.ui.std;

import jandcode.ui.*;
import jandcode.ui.std.impl.*;
import jandcode.utils.error.*;

import javax.swing.*;
import java.awt.*;

/**
 * popup меню
 */
public class CtPopupMenu extends CustomMenuContainer {

    protected void createCtrl() {
        setCtrl(new JPopupMenu());
    }

    public JPopupMenu getCtrl() {
        return (JPopupMenu) super.getCtrl();
    }

    public boolean isEmpty() {
        return getCtrl().getComponentCount() == 0;
    }

    public void fill(UiMenu m) {
        m.sort();
        getCtrl().removeAll();
        fillMenu(m, getCtrl());
    }

    public void popup(Object invoker, int x, int y) {
        if (invoker instanceof UiControl) {
            getCtrl().show(((UiControl) invoker).getCtrl(), x, y);
        } else if (invoker instanceof Component) {
            getCtrl().show((Component) invoker, x, y);
        } else {
            throw new XError("Попытка вызова popup для не control");
        }
    }

}
