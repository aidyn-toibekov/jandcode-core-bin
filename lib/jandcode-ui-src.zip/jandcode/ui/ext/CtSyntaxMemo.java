package jandcode.ui.ext;

import jandcode.ui.std.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;
import org.fife.ui.rsyntaxtextarea.*;
import org.fife.ui.rtextarea.*;

/**
 * memo с подсветкой синтаксиса
 */
public class CtSyntaxMemo extends CtScrollPanel implements IValue {

    protected void onConstructor() throws Exception {
        super.onConstructor();

        setInternalControl(new RSyntaxTextArea());
        getInternalControl().setCaretPosition(0);
        getInternalControl().setAnimateBracketMatching(false);
        getInternalControl().setAntiAliasingEnabled(true);
        getInternalControl().setHighlightCurrentLine(false);
        //
        getCtrl().setIconRowHeaderEnabled(false);
        getCtrl().setLineNumbersEnabled(false);
        //
        getCtrl().setViewportView(getInternalControl());
        getInternalControl().setLineWrap(false);
        getInternalControl().setWrapStyleWord(true);
    }

    public RTextScrollPane getCtrl() {
        return (RTextScrollPane) super.getCtrl();
    }

    protected void createCtrl() {
        setCtrl(new RTextScrollPane());
    }

    public RSyntaxTextArea getInternalControl() {
        return (RSyntaxTextArea) super.getInternalControl();
    }

    public String getValue() {
        return getInternalControl().getText();
    }

    public void setValue(Object v) {
        String s = UtString.toString(v);
        getInternalControl().setText(s);
        setCaretPositionBegin();
    }

    public void setReadOnly(boolean readOnly) {
        getInternalControl().setEditable(!readOnly);
    }

    public boolean isReadOnly() {
        return !getInternalControl().isEditable();
    }

    public int getCaretPosition() {
        return getInternalControl().getCaretPosition();
    }

    public void setCaretPosition(int position) {
        getInternalControl().setCaretPosition(position);
    }

    public void setCaretPositionEnd() {
        setCaretPosition(getTitle().length());
    }

    public void setCaretPositionBegin() {
        setCaretPosition(0);
    }

    public void setFont(Object font) {
        super.setFont(font);
        getInternalControl().setFont(getUi().getFontService().getFont(getInternalControl().getFont(), font));
    }

    //////

    public void setSyntax(String name) {
        getInternalControl().setSyntaxEditingStyle("text/" + name);
    }

    public void setShowLineNum(boolean v) {
        getCtrl().setLineNumbersEnabled(v);
    }

    public void setWordWrap(boolean v) {
        getInternalControl().setLineWrap(v);
    }

}

