package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.utils.*;

import javax.swing.*;

public class MsgboxServiceDefaultImpl extends MsgboxService {

    private String formatMsg(String msg) {
        return UtString.wrapLine(msg, 80);
    }

    private JFrame getMainFrame() {
        return getUi().getMainJFrame();
    }

    public void showError(String msg) {
        JOptionPane.showMessageDialog(getMainFrame(), formatMsg(msg), "Ошибка",
                JOptionPane.ERROR_MESSAGE);
    }

    public void showMsg(String msg) {
        JOptionPane.showMessageDialog(getMainFrame(), formatMsg(msg), "Сообщение",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public boolean showYN(String msg) {
        Object[] options = {"Да", "Нет"};
        int n = JOptionPane.showOptionDialog(getMainFrame(), formatMsg(msg), "Подтверждение",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options,
                options[0]);
        return (n == 0);
    }

    public int showYNC(String msg) {
        Object[] options = {"Да", "Нет", "Отмена"};
        int n = JOptionPane.showOptionDialog(getMainFrame(), formatMsg(msg), "Подтверждение",
                JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
                options, options[0]);
        if (n == 0) {
            n = 1;
        } else if (n == 1) {
            n = 0;
        } else {
            n = -1;
        }
        return n;
    }
}
