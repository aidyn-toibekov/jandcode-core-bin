package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class FontServiceImpl extends FontService {

    public FontServiceImpl() {
        setFontStandart(UIManager.getFont("Label.font"));
    }

    public Font getFont(Font based, Object desc) {
        if (based == null) {
            based = getFontStandart();
        }
        if (desc == null) {
            return based;
        }
        if (desc instanceof Font) {
            return (Font) desc;
        }
        if (desc instanceof String) {
            String str = (String) desc;
            if (UtString.empty(str)) {
                return based;
            }
            VariantMap p = UtCnv.toMap(str);

            if (p.size() == 0) {
                return based;
            }

            String fn = based.getName();
            int sz = based.getSize();
            int style = based.getStyle();

            for (String key : p.keySet()) {
                if ("name".equals(key) || "fontname".equals(key)) {
                    fn = p.getValueString(key, fn);
                } else if ("style".equals(key) || "fontstyle".equals(key)) {
                    List<String> lst = UtCnv.toList(p.getValueString(key));
                    style = 0;
                    for (String s : lst) {
                        int n = 0;
                        if (s.equalsIgnoreCase("bold")) {
                            n = Font.BOLD;
                        } else if (s.equalsIgnoreCase("italic")) {
                            n = Font.ITALIC;
                        }
                        style = style | n;
                    }
                } else if ("size".equals(key) || "fontsize".equals(key)) {
                    int newsz = p.getValueInt(key);
                    String s = p.getValueString(key);
                    if (newsz == 0 && s.startsWith("+")) {
                        newsz = UtCnv.toInt(s.substring(1));
                    }
                    if (newsz != 0) {
                        if (s.startsWith("+") || s.startsWith("-")) {
                            sz = sz + newsz;
                        } else {
                            sz = newsz;
                        }
                    }
                }
            }
            return new Font(fn, style, sz);
        }
        return based;
    }

}
