package jandcode.ui.impl;

import jandcode.ui.*;

/**
 * Обработчик ошибок для UI
 */
public class UiErrorHandler implements Thread.UncaughtExceptionHandler {

    private UiService ui;

    public UiErrorHandler(UiService ui) {
        this.ui = ui;
    }

    public UiService getUi() {
        return ui;
    }

    public void uncaughtException(Thread t, Throwable e) {
        getUi().getMsgboxService().showError(e);
    }

}


