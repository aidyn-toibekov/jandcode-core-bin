package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.utils.*;

import javax.swing.*;

public class ShortcutServiceImpl extends ShortcutService {

    private HashMapNoCase<String> _keys = new HashMapNoCase<String>();

    public ShortcutServiceImpl() {
        addKey("Ctrl", "ctrl");
        addKey("Shift", "shift");
        addKey("Alt", "alt");

        addKey("Esc", "ESCAPE");
        addKey("Ins", "INSERT");
        addKey("Del", "DELETE");
        addKey("Backspace", "BACK_SPACE");
        addKey("Home", "HOME");
        addKey("End", "END");
        addKey("PgUp", "PAGE_DONW");
        addKey("PgDn", "PAGE_UP");
        addKey("Up", "UP");
        addKey("Down", "DOWN");
        addKey("Left", "LEFT");
        addKey("Right", "RIGHT");
        addKey("Enter", "ENTER");
        addKey("Tab", "TAB");
        addKey("Space", "SPACE");
        addKey(".", "PERIOD");
    }

    /**
     * Добавить соответсвие между правильным и swing.
     *
     * @param name      имя правильное
     * @param swingName swing значение
     */
    public void addKey(String name, String swingName) {
        _keys.put(name, swingName);
    }

    protected String getKey(String name) {
        String s = _keys.get(name);
        if (s == null) {
            return name;
        } else {
            return s;
        }
    }

    /**
     * Получить swing KeyStroke для правильного представления (типа 'Ctrl+F5' => 'ctrl F5')
     */
    public KeyStroke getKeyStroke(String text) {
        StringBuilder acc = new StringBuilder();
        String s[] = text.split("\\+");
        if (s != null) {
            for (String value : s) {
                if (acc.length() != 0) {
                    acc.append(" ");
                }
                acc.append(getKey(value));
            }
        }
        return KeyStroke.getKeyStroke(acc.toString());
    }

}
