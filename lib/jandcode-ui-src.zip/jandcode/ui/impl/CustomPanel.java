package jandcode.ui.impl;

import jandcode.ui.*;

import javax.swing.*;

/**
 * Предок для панель-ориентированных компонентов
 */
public abstract class CustomPanel extends UiControl {

    public class CTRL extends JPanel implements IUiControlLink {
        public CTRL() {
            setLayout(new TableLayoutExt());
        }

        public UiControl getUiControl() {
            return CustomPanel.this;
        }
    }

    protected void createCtrl() {
        setCtrl(new CTRL());
    }

    public JPanel getCtrl() {
        return (JPanel) super.getCtrl();
    }

}
