package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import javax.swing.*;
import java.awt.*;

public class ColorServiceImpl extends ColorService {

    private HashMapNoCase<Color> _colors = new HashMapNoCase<Color>();

    public ColorServiceImpl() {
        UIManager.getDefaults().put("Table.gridColor", new Color(192, 192, 192));

        addColor("selectionForegroundNotActive", Color.BLACK);
        addColor("selectionBackgroundNotActive", new Color(192, 192, 255));
        addColor("selectionForegroundNotFocus", Color.BLACK);
        addColor("selectionBackgroundNotFocus", Color.LIGHT_GRAY);

        addColor("black", new Color(0, 0, 0));
        addColor("maroon", new Color(128, 0, 0));
        addColor("green", new Color(0, 128, 0));
        addColor("olive", new Color(128, 128, 0));
        addColor("navy", new Color(0, 0, 128));
        addColor("purple", new Color(128, 0, 128));
        addColor("teal", new Color(0, 128, 128));
        addColor("gray", new Color(128, 128, 128));

        addColor("silver", new Color(192, 192, 192));
        addColor("red", new Color(255, 0, 0));
        addColor("lime", new Color(0, 255, 0));
        addColor("yellow", new Color(255, 255, 0));
        addColor("blue", new Color(0, 0, 255));
        addColor("fuchsia", new Color(255, 0, 255));
        addColor("aqua", new Color(0, 255, 255));
        addColor("white", new Color(255, 255, 255));

        addColor("moneygreen", new Color(192, 220, 192));
        addColor("skyblue", new Color(166, 202, 240));
        addColor("cream", new Color(255, 251, 240));
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt x = rt.findChild("color");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                addColor(x1);
            }
        }
    }

    /**
     * Добавить поименнованный цвет
     */
    public void addColor(String name, Color color) {
        _colors.put(name, color);
    }

    /**
     * Добавить поименнованный цвет из rt.
     * Имя узла - имя цвета. Описание цвета в атрибутах r,g,b.
     */
    public void addColor(Rt rt) {
        Color c = new Color(rt.getValueInt("r", 0), rt.getValueInt("g", 0), rt.getValueInt("b", 0));
        addColor(rt.getName(), c);
    }

    public Color getColor(Object desc) {
        if (desc instanceof Color) {
            return (Color) desc;
        }
        if (desc instanceof CharSequence) {
            String nm = desc.toString();
            Color res = _colors.get(nm);
            if (res != null) {
                return res;
            }
            Object ob = UIManager.getDefaults().get(nm);
            if (ob instanceof Color) {
                return (Color) ob;
            }
        }
        return _colors.get("black");
    }

}
