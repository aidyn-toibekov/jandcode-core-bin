package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.utils.*;
import jandcode.utils.easyxml.*;
import jandcode.utils.error.*;

/**
 * Построитель из xml-файлов.
 * Каждый узел - control. Каждый атрибут - свойство. Имя узла - тип control.
 */
public class UiBuilderImpl extends UiBuilder {

    private HashMapNoCase<String> usedNames = new HashMapNoCase<String>();

    public void load(Object data) throws Exception {
        usedNames.clear();
        //
        EasyXml node = new EasyXml();
        //
        if (data instanceof Class) {
            String fn = UtCnv.toVfsFile((Class) data, ".ui.xml");
            node.load().fromFileObject(fn);
        } else if (data instanceof EasyXml) {
            node = (EasyXml) data;
        } else {
            node.load().fromFileObject(UtCnv.toVfsPath(UtString.toString(data)));
        }
        //
        setAttrs(getRoot(), node);
        handleNode(getRoot(), node);
    }

    protected void handleNode(UiControl cur, EasyXml node) {
        if (node.hasChilds()) {
            getLayoutTable(cur);
            push(cur);
            for (EasyXml child : node) {
                if (child.hasName("action")) {
                    handleNodeAction(child);
                } else if (child.hasName("menu")) {
                    handleNodeMenu(child);
                } else {
                    UiControl z = null;
                    String nameAttr = child.getAttrs().getValueString("name");
                    if (nameAttr.length() > 0) {
                        if (usedNames.containsKey(nameAttr)) {
                            throw new XError("Имя компонента [{0}] встретилось дважды", nameAttr);
                        }
                        usedNames.put(nameAttr, nameAttr);
                        z = cur.findControl(nameAttr);
                    }
                    if (z == null) {
                        String controlClass = child.getValueString("@class");
                        if (!UtString.empty(controlClass)) {
                            z = getUi().createControl(child.getName(), getApp().getClass(controlClass));
                        } else {
                            z = getUi().createControl(child.getName());
                        }
                        if (nameAttr.length() > 0) {
                            z.setName(nameAttr);
                        }
                        setAttrs(z, child);
                        getLast().addControl(z);
                        handleNode(z, child);
                    } else {
                        setAttrs(z, child);
                        handleNode(z, child);
                    }
                }
            }
            pop();
        }
    }

    protected UiAction handleNodeAction(EasyXml node) {
        String name = node.getAttrs().getValueString("name");
        String parent = node.getAttrs().getValueString("parent", "sys");
        UiAction act = getUi().createAction(parent);
        if (!UtString.empty(name)) {
            act.setName(name);
        }
        act.setRtAttrs(node.getAttrs());
        getLast().addAction(act);
        return act;
    }

    //////

    protected void handleNodeMenu(EasyXml node) {
        String nm = node.getAttrs().getValueString("name", null);
        //
        UiMenu m = getLast().findMenu(nm);
        if (m == null) {
            m = getApp().service(UiService.class).getObjectFactory().create(UiMenu.class);
            m.setName(nm);
            getLast().addMenu(m);
        }
        //
        handleNodeMenu(m, node);
    }

    protected void handleNodeMenu(UiMenu root, EasyXml node) {
        for (EasyXml child : node) {
            if (child.hasName("action")) {
                UiAction act = handleNodeAction(child);
                UiMenu it = getApp().service(UiService.class).getObjectFactory().create(UiMenu.class);
                it.setLink(act);
                it.setWeight(child.getValueInt("@weight", 50));
                root.addItem(it);
            } else if (child.hasName("menu") || child.hasName("item")) {
                String name = child.getValueString("@name");
                UiMenu it = null;
                boolean created = false;
                if (!UtString.empty(name)) {
                    it = root.getItems().find(name);
                }
                if (it == null) {
                    it = getApp().service(UiService.class).getObjectFactory().create(UiMenu.class);
                    created = true;
                }
                it.setRtAttrs(child.getAttrs());
                String s;
                s = child.getAttrs().getValueString("action");
                if (s.length() > 0) {
                    it.setLink(getLast().action(s));
                }
                s = child.getAttrs().getValueString("control");
                if (s.length() > 0) {
                    it.setLink(getLast().control(s));
                }
                if (created) {
                    root.addItem(it);
                }
                handleNodeMenu(it, child);
            } else if (child.hasName("separator")) {
                UiMenu it = getApp().service(UiService.class).getObjectFactory().create(UiMenu.class);
                it.setRtAttrs(child.getAttrs());
                it.setTitle("-");
                root.addItem(it);
            } else {
                throw new XError("Неправильное имя узла [{0}]", child.getName());
            }
        }
    }

}
