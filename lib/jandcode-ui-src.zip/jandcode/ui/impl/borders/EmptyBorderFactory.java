package jandcode.ui.impl.borders;

import jandcode.ui.*;

import javax.swing.*;
import javax.swing.border.*;

public class EmptyBorderFactory implements IBorderFactory {
    public Border createBorder() {
        return BorderFactory.createEmptyBorder();
    }
}
