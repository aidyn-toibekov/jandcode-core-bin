package jandcode.ui.impl.borders;

import jandcode.ui.*;

import javax.swing.*;
import javax.swing.border.*;

public class LoweredBorderFactory implements IBorderFactory {
    public Border createBorder() {
        return BorderFactory.createLoweredBevelBorder();
    }
}
