package jandcode.ui.impl.borders;

import jandcode.ui.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;

public class ButtonRollovedBorderFactory implements IBorderFactory {
    public Border createBorder() {
        UIDefaults table = UIManager.getLookAndFeelDefaults();
        return new CompoundBorder(new BasicBorders.RolloverButtonBorder(
                table.getColor("controlShadow"),
                table.getColor("controlDkShadow"),
                table.getColor("controlHighlight"),
                table.getColor("controlLtHighlight")),
                BorderFactory.createEmptyBorder(3, 3, 3, 3));
    }
}
