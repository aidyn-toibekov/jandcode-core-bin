package jandcode.ui.impl.borders;

import jandcode.ui.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class LineredBorderFactory implements IBorderFactory {
    public Border createBorder() {
        return BorderFactory.createLineBorder(Color.red);
    }
}
