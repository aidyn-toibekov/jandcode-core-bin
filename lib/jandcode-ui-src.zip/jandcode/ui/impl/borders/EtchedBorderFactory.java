package jandcode.ui.impl.borders;

import jandcode.ui.*;

import javax.swing.*;
import javax.swing.border.*;

public class EtchedBorderFactory implements IBorderFactory {
    public Border createBorder() {
        return BorderFactory.createEtchedBorder();
    }
}
