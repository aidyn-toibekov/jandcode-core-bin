package jandcode.ui.impl.borders;

import jandcode.ui.*;

import javax.swing.*;
import javax.swing.border.*;

public class EditorBorderFactory implements IBorderFactory {
    public Border createBorder() {
        return UIManager.getDefaults().getBorder("TextField.border");
    }
}
