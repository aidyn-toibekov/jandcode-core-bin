package jandcode.ui.impl;

import info.clearthought.layout.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Расширенный TableLayout для UiBuilder
 */
public class TableLayoutExt extends TableLayout {

    // реальная строка и колонка
    protected int row = 0;
    protected int col = 0;

    // размер разделителей строк и колонок по умолчанию
    protected int spaceColDef = 4;
    protected int spaceRowDef = 4;

    // режим flow - добавляются колонки, а не строки
    protected boolean flowMode = false;

    // кому принадлежит
    protected Container container;

    // выравнивания по умолчанию для колонок и строк
    protected HashMap<Integer, CellConstr> colsAlign;
    protected HashMap<Integer, CellConstr> rowsAlign;

    public void clear() {
        row = 0;
        col = 0;
        spaceColDef = 4;
        spaceRowDef = 4;
        flowMode = false;
        colsAlign = null;
        rowsAlign = null;
    }

    public class CellConstr {
        public int spanCol;
        public char hAlign = 'f';
        public char vAlign = 'f';

        public void fromString(String s) {
            List<UtCnv.ComplexValue> lst = UtCnv.toComplexList(s);
            for (UtCnv.ComplexValue cv : lst) {
                String nm = cv.getName().toLowerCase();
                //
                if ("spancol".equals(nm)) {
                    spanCol = cv.getValueInt();

                } else {
                    makeAlign(nm);
                }
            }
        }

        protected void makeAlign(String param) {
            boolean useH = false;
            boolean useV = false;
            boolean full = false;
            boolean center = false;

            param = param.toLowerCase();

            if ("g".equals(param)) {
                vAlign = 'g';
                hAlign = 'g';
                return;
            } else if ("gr".equals(param)) {
                vAlign = 'g';
                hAlign = 'f';
                return;
            } else if ("gc".equals(param)) {
                vAlign = 'f';
                hAlign = 'g';
                return;
            } else if ("f".equals(param) || "ff".equals(param)) {
                vAlign = 'f';
                hAlign = 'f';
                return;
            }

            for (int i = 0; i < param.length(); i++) {
                char c = param.charAt(i);
                if (c == ' ' || c == ',') {
                    // пропускаем
                } else if (c == 'r' || c == 'l') {
                    hAlign = c;
                    useH = true;
                } else if (c == 't' || c == 'b') {
                    vAlign = c;
                    useV = true;
                } else if (c == 'c') {
                    center = true;
                } else if (c == 'f') {
                    full = true;
                } else {
                    throw new XError("Bad char [{0}] in align constant [{1}]", c, param);
                }
            }
            if (center) {
                if (!useH && !useV) {
                    hAlign = 'c';
                    vAlign = 'c';
                } else if (useH) {
                    vAlign = 'c';
                } else if (useV) {
                    hAlign = 'c';
                }
            }
            if (full) {
                if (!useH && !useV) {
                    hAlign = 'f';
                    vAlign = 'f';
                } else if (useH) {
                    vAlign = 'f';
                } else if (useV) {
                    hAlign = 'f';
                }
            }
        }

        public TableLayoutConstraints toTableLayoutConstraint() {
            TableLayoutConstraints res = new TableLayoutConstraints();
            res.col1 = col;
            res.row1 = row;
            if (spanCol < 1) {
                res.col2 = col;
            } else {
                res.col2 = col + (spanCol - 1) * 2;
            }
            res.row2 = row;

            if (hAlign == 'f' || hAlign == 'g') {
                res.hAlign = TableLayoutConstants.FULL;
            } else if (hAlign == 'l') {
                res.hAlign = TableLayoutConstants.LEFT;
            } else if (hAlign == 'r') {
                res.hAlign = TableLayoutConstants.RIGHT;
            } else if (hAlign == 'c') {
                res.hAlign = TableLayoutConstants.CENTER;
            }

            if (vAlign == 'f' || vAlign == 'g') {
                res.vAlign = TableLayoutConstants.FULL;
            } else if (vAlign == 't') {
                res.vAlign = TableLayoutConstants.TOP;
            } else if (vAlign == 'b') {
                res.vAlign = TableLayoutConstants.BOTTOM;
            } else if (vAlign == 'c') {
                res.vAlign = TableLayoutConstants.CENTER;
            }

            return res;
        }
    }


    public TableLayoutExt() {
        // делаем сразу одну строку и колонк
        insertColumn(0, TableLayoutConstants.PREFERRED);
        insertRow(0, TableLayoutConstants.PREFERRED);
    }

    ////// cm

    /**
     * Выполнить команды lay
     */
    public void cm(String commands) {
        List<UtCnv.ComplexValue> lst = UtCnv.toComplexList(commands);
        for (UtCnv.ComplexValue cv : lst) {
            String n2 = cv.getName2();
            int pos = -1;
            if (!UtString.empty(n2)) {
                pos = UtCnv.toInt(n2, -1);
            }
            execCm(cv.getName(), pos, cv.getValue());
        }
    }

    protected void execCm(String cm, int rcNum, String param) {
        cm = cm.toLowerCase();
        if ("colcount".equals(cm) || "countcol".equals(cm) || "cols".equals(cm)) {
            int n = UtCnv.toInt(param);
            checkRC(n * 2 - 1, -1);

        } else if ("rowcount".equals(cm) || "countrow".equals(cm) || "rows".equals(cm)) {
            int n = UtCnv.toInt(param);
            checkRC(-1, n * 2 - 1);

        } else if ("pos".equals(cm)) {
            Point p = UtCnv.toPoint(param);
            col = p.x * 2;
            row = p.y * 2;
            checkRC(col, row);

        } else if ("move".equals(cm)) {
            Point p = UtCnv.toPoint(param);
            col = col + p.x * 2;
            row = row + p.y * 2;
            checkRC(col, row);

        } else if ("flow".equals(cm)) {
            flowMode = UtCnv.toBoolean(param, true);

        } else if ("defcolspace".equals(cm) || "defspacecol".equals(cm)) {
            spaceColDef = UtCnv.toInt(param, 4);

        } else if ("defrowspace".equals(cm) || "defspacerow".equals(cm)) {
            spaceRowDef = UtCnv.toInt(param, 4);

        } else if ("colspace".equals(cm) || "spacecol".equals(cm)) {
            double attr = convertAttrRC(param);
            int p = col + 1;
            if (rcNum != -1) {
                p = rcNum * 2 + 1;
            }
            checkRC(p + 1, -1);
            setColumn(p, attr);

        } else if ("rowspace".equals(cm) || "spacerow".equals(cm)) {
            double attr = convertAttrRC(param);
            int p = row + 1;
            if (rcNum != -1) {
                p = rcNum * 2 + 1;
            }
            checkRC(-1, p + 1);
            setRow(p, attr);

        } else if ("col".equals(cm)) {
            double attr = convertAttrRC(param);
            int p = col;
            if (rcNum != -1) {
                p = rcNum * 2;
            }
            checkRC(p, -1);
            setColumn(p, attr);

        } else if ("row".equals(cm)) {
            double attr = convertAttrRC(param);
            int p = row;
            if (rcNum != -1) {
                p = rcNum * 2;
            }
            checkRC(-1, p);
            setRow(p, attr);

        } else if ("colalign".equals(cm) || "aligncol".equals(cm)) {
            int p = col;
            if (rcNum != -1) {
                p = rcNum * 2;
            }
            checkRC(p, -1);
            if (colsAlign == null) {
                colsAlign = new HashMap<Integer, CellConstr>();
            }
            CellConstr cc = new CellConstr();
            cc.fromString(param);
            colsAlign.put(p, cc);

        } else if ("rowalign".equals(cm) || "alignrow".equals(cm)) {
            int p = row;
            if (rcNum != -1) {
                p = rcNum * 2;
            }
            checkRC(-1, p);
            if (rowsAlign == null) {
                rowsAlign = new HashMap<Integer, CellConstr>();
            }
            CellConstr cc = new CellConstr();
            cc.fromString(param);
            rowsAlign.put(p, cc);

        } else {
            throw new XError("Invalid layout command [{0}]", cm);
        }
    }

    ////// internals

    public void addLayoutComponent(Component component, Object constraint) {

        CellConstr cc = new CellConstr();
        if (constraint != null) {
            if (constraint instanceof String) {
                cc.fromString((String) constraint);
            } else {
                throw new IllegalArgumentException("Constraint for the component must be String");
            }
        } else {
            CellConstr cc1 = null;
            if (colsAlign != null) {
                cc1 = colsAlign.get(col);
            }
            if (cc1 == null && rowsAlign != null) {
                cc1 = rowsAlign.get(row);
            }
            if (cc1 != null) {
                cc = cc1;
            }
        }

        // забираем parent в качестве моего контейнера у первого компонента
        if (container == null) {
            if (component != null) {
                if (component.getParent() != null) {
                    container = component.getParent();
                }
            }
        }

        TableLayoutConstraints tc = cc.toTableLayoutConstraint();
        checkRC(col, row);
        super.addLayoutComponent(component, tc);
        moveOnAdd();
        if (cc.spanCol > 1) {
            for (int i = 1; i < cc.spanCol; i++) {
                moveOnAdd();
            }
        }

        // grow
        if (cc.hAlign == 'g' || cc.vAlign == 'g') {
            Component cont = container;
            Component cur = component;
            while (cont != null) {
                if (cont instanceof Container) {
                    LayoutManager lay1 = ((Container) cont).getLayout();
                    if (lay1 instanceof TableLayoutExt) {
                        TableLayoutExt lay2 = (TableLayoutExt) lay1;
                        TableLayoutConstraints c1 = lay2.getConstraints(cur);
                        if (c1 == null) {
                            break;
                        }
                        if (cc.hAlign == 'g') {
                            lay2.setColumn(c1.col1, TableLayoutConstants.FILL);
                        }
                        if (cc.vAlign == 'g') {
                            lay2.setRow(c1.row1, TableLayoutConstants.FILL);
                        }
                        if (c1.hAlign != TableLayoutConstants.FULL || c1.vAlign != TableLayoutConstants.FULL) {
                            c1.hAlign = TableLayoutConstants.FULL;
                            c1.vAlign = TableLayoutConstants.FULL;
                            lay2.setConstraints(cur, c1);
                        }
                    } else {
                        break;
                    }
                } else {
                    break;
                }
                //
                cur = cont;
                cont = cont.getParent();
            }
        }

    }

    /**
     * Проверка наличия колонки и строки с указанными номерами и досоздание, если нету
     */
    protected void checkRC(int c, int r) {
        if (c > 0) {
            while (getNumColumn() < c) {
                insertColumn(getNumColumn(), spaceColDef);
                insertColumn(getNumColumn(), TableLayoutConstants.PREFERRED);
            }
        }
        if (r > 0) {
            while (getNumRow() < r) {
                insertRow(getNumRow(), spaceRowDef);
                insertRow(getNumRow(), TableLayoutConstants.PREFERRED);
            }
        }
    }

    /**
     * Конвертация атрибутов строки или колонки в TableLayout атрибуты.
     * attr: p,f,m,SIZE
     */
    protected double convertAttrRC(String attr) {
        if (attr == null) {
            return TableLayoutConstants.PREFERRED;
        }
        String v = attr.toLowerCase();
        if (v.equals("p")) {
            return TableLayoutConstants.PREFERRED;
        } else if (v.equals("f")) {
            return TableLayoutConstants.FILL;
        } else if (v.equals("m")) {
            return TableLayoutConstants.MINIMUM;
        } else {
            return UtCnv.toDouble(attr, TableLayoutConstants.FILL);
        }
    }

    /**
     * Переместить указатель при добавлении элемента
     */
    protected void moveOnAdd() {
        if (!flowMode) {
            col = col + 2;
            if (col > getNumColumn()) {
                col = 0;
                row = row + 2;
            }
        } else {
            col = col + 2;
        }
    }

}
