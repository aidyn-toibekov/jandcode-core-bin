package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.ui.impl.borders.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class BorderServiceImpl extends BorderService {

    private HashMapNoCase<IBorderFactory> _borders = new HashMapNoCase<IBorderFactory>();

    public BorderServiceImpl() {
        addBorder("button", new ButtonBorderFactory());
        addBorder("buttonrolloved", new ButtonRollovedBorderFactory());
        addBorder("editor", new EditorBorderFactory());
        addBorder("empty", new EmptyBorderFactory());
        addBorder("etched", new EtchedBorderFactory());
        addBorder("lineblack", new LineblackBorderFactory());
        addBorder("linegray", new LinegrayBorderFactory());
        addBorder("linered", new LineredBorderFactory());
        addBorder("lowered", new LoweredBorderFactory());
        addBorder("raised", new RaisedBorderFactory());
        addBorder("titled", new TitledBorderFactory());

    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt x = rt.findChild("border");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                addBorder(x1);
            }
        }
    }

    /**
     * Все рамки
     */
    public HashMapNoCase<IBorderFactory> getBorders() {
        return _borders;
    }

    /**
     * Добавить поименнованную рамку
     */
    public void addBorder(String name, IBorderFactory border) {
        _borders.put(name, border);
    }

    /**
     * Добавить поименнованную рамку из rt.
     * Имя узла - имя рамки. Атрибут class - класс фабрики
     */
    public void addBorder(Rt rt) {
        IBorderFactory a = (IBorderFactory) getApp().service(UiService.class).getObjectFactory().create(rt);
        addBorder(rt.getName(), a);
    }

    public Border getBorder(Object desc) {
        if (desc == null) {
            return null;
        }
        if (desc instanceof Border) {
            return (Border) desc;
        }
        if (desc instanceof String) {
            String s = (String) desc;
            if (s.length() == 0) {
                return null;
            }
            if (s.indexOf(',') == -1) {
                IBorderFactory bf = _borders.get(s);
                if (bf == null) {
                    return null;
                }
                return bf.createBorder();

            } else {
                Insets z = UtCnv.toInsets(s);
                return BorderFactory.createEmptyBorder(z.top, z.left, z.bottom, z.right);
            }
        }
        return null;
    }

    public void setBorderTitle(Border border, String text) {
        if (border == null) {
            return;
        }
        if (border instanceof TitledBorder) {
            ((TitledBorder) border).setTitle(text);
        } else {
            if (border instanceof CompoundBorder) {
                setBorderTitle(((CompoundBorder) border).getInsideBorder(), text);
                setBorderTitle(((CompoundBorder) border).getOutsideBorder(), text);
            }
        }
    }
}
