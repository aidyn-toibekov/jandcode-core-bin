package jandcode.ui.impl;

import jandcode.ui.*;

import java.awt.event.*;

/**
 * Listener для реакции на показ popup menu
 */
public class ListenerPopupMenu extends MouseAdapter {

    private UiControl control;

    public ListenerPopupMenu(UiControl control) {
        this.control = control;
    }

    public void mousePressed(MouseEvent e) {
        maybeShowPopup(e);
    }

    public void mouseReleased(MouseEvent e) {
        maybeShowPopup(e);
    }

    private void maybeShowPopup(MouseEvent e) {
        if (e.isPopupTrigger()) {
            control.showPopupMenu(e.getX(), e.getY());
        }
    }

}
