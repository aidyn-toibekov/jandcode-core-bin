package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.utils.vdir.*;
import org.apache.commons.vfs2.*;

import javax.swing.*;
import java.io.*;

public class IconServiceImpl extends IconService {

    protected VDirVfs _imagesVDir = new VDirVfs();
    protected HashMapNoCase<ImageIcon> _cache = new HashMapNoCase<ImageIcon>();
    protected String[] _extensions = new String[]{".png", ".gif", ".jpg"};


    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt x = rt.findChild("path");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                addPath(x1);
            }
        }
    }

    /**
     * Добавить путь до папки с картинками
     */
    public void addPath(String path) {
        _imagesVDir.addRoot(path);
    }

    /**
     * Добавить путь до папки с картинками.
     * В атрибуте 'path' - путь до папки images
     */
    public void addPath(Rt rt) {
        String path = rt.getValueString("path", null);
        addPath(path);
    }

    /**
     * Попытка загрузить из ресурса. Возвращает ImageIcon или null, если не найдено
     */
    protected ImageIcon loadImageIcon(String fn) {
        try {
            FileObject fo = UtFile.getFileObject(fn);
            ImageIcon im = null;
            InputStream stm = fo.getContent().getInputStream();
            try {
                byte[] b = new byte[stm.available()];
                if (stm.read(b) > 0) {
                    im = new ImageIcon(b);
                }
            } finally {
                stm.close();
            }
            return im;
        } catch (Exception e) {
            return null;
        }
    }

    public ImageIcon getIcon(String type, String name) {
        String key = type + "|" + name;
        if (_cache.containsKey(key)) {
            return _cache.get(key);
        }

        synchronized (this) {
            VFile fi = null;
            for (String ext : _extensions) {
                fi = _imagesVDir.findFile("icon" + type + "/" + name + ext);
                if (fi != null) {
                    break;
                }
            }

            if (fi == null) {
                _cache.put(key, null);
                return null;
            }

            ImageIcon im = loadImageIcon(fi.getRealPath());
            _cache.put(key, im);
            return im;
        }
    }

}
