package jandcode.ui.impl;

import jandcode.ui.*;
import jandcode.ui.std.*;

public class MsgboxServiceNiceImpl extends MsgboxService {

    public void showError(String msg) {
        FrMsgBox f = getUi().getObjectFactory().create(FrMsgBox.class);
        f.setTitle("Ошибка");
        f.setMessage(msg);
        f.setIcon("error");
        f.addButton("ok", "Ок", "Esc");
        f.show();
    }

    public void showMsg(String msg) {
        FrMsgBox f = getUi().getObjectFactory().create(FrMsgBox.class);
        f.setTitle("Сообщение");
        f.setMessage(msg);
        f.setIcon("info");
        f.addButton("ok", "Ок", "Esc");
        f.show();
    }

    public boolean showYN(String msg) {
        FrMsgBox f = getUi().getObjectFactory().create(FrMsgBox.class);
        f.setTitle("Подтверждение");
        f.setMessage(msg);
        f.setIcon("info");
        f.addButton("yes", "Да", null);
        f.addButton("no", "Нет", "Esc");
        String r = f.show();
        return "yes".equals(r);
    }

    public int showYNC(String msg) {
        FrMsgBox f = getUi().getObjectFactory().create(FrMsgBox.class);
        f.setTitle("Подтверждение");
        f.setMessage(msg);
        f.setIcon("info");
        f.addButton("yes", "Да", null);
        f.addButton("no", "Нет", null);
        f.addButton("cancel", "Отмена", "Esc");
        String r = f.show();
        if ("yes".equals(r)) {
            return 1;
        } else if ("no".equals(r)) {
            return 0;
        } else {
            return -1;
        }
    }

}
