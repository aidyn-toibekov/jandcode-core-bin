package jandcode.ui;

import jandcode.utils.*;

import javax.swing.*;
import java.awt.event.*;

/**
 * action. Обертка вокруг Swing Action
 */
public class UiAction extends UiComp {

    private AbstractAction _swingAction;
    private String _shortcut;
    private String _iconName;
    private String _tooltip;
    protected EventsHolder _events;

    public class SwingAction extends AbstractAction {

        public UiAction getUiAction() {
            return UiAction.this;
        }

        public void actionPerformed(ActionEvent e) {
            try {
                Object own = getUiAction().getOwner();
                if (own instanceof UiControl) {
                    ((UiControl) own).refreshFrame();
                }
                getUiAction().onAction();
                for (OnAction h : _events.list(OnAction.class)) {
                    h.onAction(UiAction.this);
                }
            } catch (Exception e1) {
                getUi().getMsgboxService().showError(e1);
            }
        }
    }

    public UiAction() {
        _swingAction = new SwingAction();
        _events = new EventsHolder();
    }

    public AbstractAction getSwingAction() {
        return _swingAction;
    }

    /**
     * Владелец - control
     */
    public UiControl getOwner() {
        return (UiControl) super.getOwner();
    }

    /**
     * Косвенный владелец - frame
     */
    public UiFrame getFrame() {
        UiControl own = getOwner();
        if (own == null) {
            return null;
        }
        if (own instanceof UiFrame) {
            return (UiFrame) own;
        }
        return own.getFrame();
    }

    ////// event: onAction

    public void addEvent(OnAction h) {
        _events.add(h);
    }

    public void fireAction() {
        getSwingAction().actionPerformed(new ActionEvent(getSwingAction(), 0, ""));
    }

    protected void onAction() throws Exception {
        callOwnerActionMethod();
    }

    /**
     * Если владелец action поддерживает IActionInvoker, то вызывается
     * fireAction у него.
     */
    protected boolean callOwnerActionMethod() throws Exception {
        UiControl f = getOwner();
        if (f == null) {
            return false;
        }
        if (f instanceof IActionInvoker) {
            return ((IActionInvoker) f).fireAction(this);
        }
        return false;
    }

    //////

    public void setTitle(String title) {
        super.setTitle(title);
        getSwingAction().putValue(Action.NAME, title);
    }

    public String getShortcut() {
        return _shortcut == null ? "" : _shortcut;
    }

    public void setShortcut(String shortcut) {
        _shortcut = shortcut;
        getSwingAction().putValue(Action.ACCELERATOR_KEY, getUi().getShortcutService().getKeyStroke(shortcut));
    }

    public String getIconName() {
        return _iconName == null ? "" : _iconName;
    }

    public void setIcon(String iconName) {
        _iconName = iconName;
        setIcon(getUi().getImageService().getIcon16(_iconName));
    }

    public void setIcon(ImageIcon icon) {
        getSwingAction().putValue(Action.SMALL_ICON, icon);
    }

    public String getTooltip() {
        return _tooltip == null ? "" : _tooltip;
    }

    public void setTooltip(String tooltip) {
        _tooltip = tooltip;
        getSwingAction().putValue(Action.SHORT_DESCRIPTION, _tooltip);
    }

    public String makeTooltip() {
        String s = getTitle();
        if (!UtString.empty(getShortcut())) {
            s = s + " (" + getShortcut() + ")";
        }
        return s;
    }

}
