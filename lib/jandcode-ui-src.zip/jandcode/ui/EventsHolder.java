package jandcode.ui;

import java.util.*;

/**
 * Универсальное хранилище обработчиков событий
 */
public class EventsHolder {

    private static List<Object> EMPTY_LIST = Collections.unmodifiableList(new ArrayList<Object>());

    private List<Object> _handlers = EMPTY_LIST;

    /**
     * Добавить обработчик
     */
    public void add(Object handler) {
        if (handler == null) {
            return;
        }
        if (_handlers == EMPTY_LIST) {
            _handlers = new ArrayList<Object>();
        }
        _handlers.add(handler);
    }

    /**
     * Удалить обработчик
     */
    public void remove(Object handler) {
        if (_handlers == EMPTY_LIST) {
            return;
        }
        _handlers.remove(handler);
    }

    /**
     * Получить список обработчиков, реализующих интерфейс clazz
     *
     * @return всегда не пустой список
     */
    public <A> List<A> list(Class<A> clazz) {
        List<A> res = null;
        for (Object handler : _handlers) {
            if (clazz.isAssignableFrom(handler.getClass())) {
                if (res == null) {
                    res = new ArrayList<A>();
                }
                res.add((A) handler);
            }
        }
        if (res == null) {
            return (List<A>) EMPTY_LIST;
        }
        return res;
    }

}
