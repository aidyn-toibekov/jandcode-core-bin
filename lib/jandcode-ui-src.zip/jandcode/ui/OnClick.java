package jandcode.ui;

/**
 * Событие - компонент щелкнул.
 */
public interface OnClick {

    void onClick(UiControl ctrl) throws Exception;

}
