package jandcode.ui;

import java.awt.*;

/**
 * Цвета
 */
public abstract class ColorService extends UiBasedService {

    /**
     * Получить цвет
     */
    public abstract Color getColor(Object desc);

}
