package jandcode.ui;

/**
 * Событие - фокус поменялся
 */
public interface OnFocusChange {

    /**
     * Генерация события об изменении фокуса
     *
     * @param ctrl для кого
     * @param self true - изменился свой фокус, false - изменился фокус когото из детей
     * @param lost true - фокус потерян, false - фокус взят
     */
    void onFocusChange(UiControl ctrl, boolean self, boolean lost);

}
