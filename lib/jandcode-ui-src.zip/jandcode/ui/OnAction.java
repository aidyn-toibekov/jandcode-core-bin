package jandcode.ui;

/**
 * Событие - action сработал
 */
public interface OnAction {

    void onAction(UiAction ctrl) throws Exception;

}
