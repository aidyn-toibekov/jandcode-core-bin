package jandcode.ui.test;

import jandcode.ui.*;

import javax.imageio.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;

/**
 * Показ фрейма для тестов
 */
public class RobotFrame {

    private RobotFrame _parent;
    private JComponent _jcomponent;
    private Window _jwindow;
    private UiControl _control;
    private TestExtUi _testExt;
    private int _numScreenShot = 0;
    private Robot robot;

    public RobotFrame(UiControl control, RobotFrame parent, TestExtUi testExt) throws Exception {
        robot = new Robot();
        robot.setAutoWaitForIdle(true);

        this._control = control;
        this._jcomponent = control.getCtrl();
        this._parent = parent;
        this._testExt = testExt;
        if (parent != null) {
            _testExt = parent._testExt;
        }
    }

    public UiService getUi() {
        return _testExt.getUi();
    }

    //////

    /**
     * Разрешен ли показ модальных
     */
    public boolean isEnableModal() {
        return !_testExt.test.isBatchMode();
    }

    //////

    public void refresh() {
        _jcomponent.paintImmediately(_jcomponent.getVisibleRect());
    }

    //////

    public void screenShot(String fileName, Insets inset) throws Exception {
        if (inset == null) {
            inset = new Insets(0, 0, 0, 0);
        }

        robot.waitForIdle();
        robot.waitForIdle();

        refresh();
        robot.waitForIdle();
        robot.waitForIdle();

        Point xy = _jcomponent.getLocation();
        Dimension wh = _jcomponent.getSize();
        SwingUtilities.convertPointToScreen(xy, _jcomponent);

        if (_jwindow != null) {
            xy = _jwindow.getLocation();
            wh = _jwindow.getSize();
        }

        Rectangle r = new Rectangle(xy.x - inset.left, xy.y - inset.top,
                wh.width + inset.right + inset.left, wh.height + inset.bottom + inset.right);

        if (r.width == 0) {
            r.width = 10;
        }
        if (r.height == 0) {
            r.height = 10;
        }
        BufferedImage image = robot.createScreenCapture(r);
        File file = new File(fileName);
        file.getParentFile().mkdirs();
        ImageIO.write(image, "png", file);
    }

    public int nextNumScreenShot() {
        if (_parent != null) {
            return _parent.nextNumScreenShot();
        } else {
            _numScreenShot++;
            return _numScreenShot;
        }
    }

    public int getNumScreenShot() {
        if (_parent != null) {
            return _parent.getNumScreenShot();
        } else {
            return _numScreenShot;
        }
    }

    public String getScreenShotFile(String suffix) {
        if (suffix == null) {
            suffix = "" + nextNumScreenShot();
        }
        return "temp/screenshoots/" + _testExt.test.getClass().getSimpleName() + "/" +
                _testExt.test.getTestName() + "_" + suffix + ".png";
    }

    public void screenShot(Insets inset) throws Exception {
        screenShot(getScreenShotFile(null), inset);
    }

    public void screenShot() throws Exception {
        screenShot(null);
    }

    public void screenShot(int inset) throws Exception {
        screenShot(new Insets(inset, inset, inset, inset));
    }

    /**
     * Изготовление 3-х снимков: в текущем размере, при уменьшении на resize и при увеличении на resize
     *
     * @param resize
     */
    public void screenShotResize(int resize) throws Exception {
        if (_jwindow == null) {
            return;
        }

        // normal
        screenShot();

        Dimension sz = _jwindow.getSize();

        sz.width = sz.width - resize;
        sz.height = sz.height - resize;
        _jwindow.setSize(sz);

        // small
        screenShot(getScreenShotFile("" + getNumScreenShot() + "_small"), null);

        sz.width = sz.width + resize + resize;
        sz.height = sz.height + resize + resize;
        _jwindow.setSize(sz);

        // big
        screenShot(getScreenShotFile("" + getNumScreenShot() + "_big"), null);

        sz.width = sz.width - resize;
        sz.height = sz.height - resize;
        _jwindow.setSize(sz);
    }

    //////

    /**
     * Текущая JFrame
     */
    public JFrame getJFrame() {
        return (JFrame) _jwindow;
    }

    //////

    public void show(IRobotFrameRunner runner, boolean modalModeAfterRun) throws Exception {
        robot.waitForIdle();
        robot.waitForIdle();

        RobotFrame saveRF = _testExt.robotFrame;
        _testExt.robotFrame = this;
        //
        JFrame f = new JFrame();
        _jwindow = f;
        f.setContentPane(_jcomponent);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        if (runner != null) {
            runner.run(this);
        }
        if (modalModeAfterRun) {
            modalMode();
        }

        robot.waitForIdle();
        robot.waitForIdle();

        f.setVisible(false);

        robot.waitForIdle();
        robot.waitForIdle();

        //
        _testExt.robotFrame = saveRF;
    }

    /**
     * Перевод текущего окна в модальный режим.
     * мда...
     */
    public void modalMode() {
        if (!isEnableModal()) {
            return;
        }
        final JDialog d = new JDialog(null, "Modal mode", Dialog.ModalityType.DOCUMENT_MODAL);
        //
        JPanel cp = new JPanel();
        //
        JButton b = new JButton("PRESS TO STOP MODAL MODE");
        b.setPreferredSize(new Dimension(200, 50));
        b.setBackground(getUi().getColorService().getColor("gray"));
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                d.setVisible(false);
            }
        });
        cp.add(b);
        //
        d.setContentPane(cp);
        //
        if (_jwindow != null) {
            d.addWindowListener(new WindowAdapter() {
                public void windowActivated(WindowEvent e) {
                    _jwindow.requestFocus();
                }
            });
            //
            _jwindow.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                    d.setVisible(false);
                }
            });
        }
        //
        d.pack();
        d.setLocation(0, 0);
        d.setVisible(true);
    }
}
