package jandcode.ui.test;

/**
 * Обработчик для RobotFrame
 */
public interface IRobotFrameRunner {

    public void run(RobotFrame r) throws Exception;

}
