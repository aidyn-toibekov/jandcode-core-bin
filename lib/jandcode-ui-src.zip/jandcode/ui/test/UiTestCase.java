package jandcode.ui.test;

import jandcode.app.test.*;

/**
 * Предок для ui-тестов
 */
public abstract class UiTestCase extends AppTestCase {

    // расширение для ui
    public TestExtUi ui = createExt(TestExtUi.class);

}
