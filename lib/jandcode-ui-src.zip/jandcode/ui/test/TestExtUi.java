package jandcode.ui.test;

import jandcode.app.*;
import jandcode.app.test.*;
import jandcode.ui.*;
import jandcode.ui.impl.*;
import jandcode.ui.std.*;
import jandcode.utils.easyxml.*;
import jandcode.utils.rt.*;
import jandcode.utils.test.*;

import javax.swing.*;

/**
 * Расширения для тестов ui
 */
public class TestExtUi extends TestExt {

    public UiService ui;

    // текущий robotframe
    public RobotFrame robotFrame;

    public void setUp() throws Exception {
        super.setUp();
        ui = test.getExt(TestExtApp.class).service(UiService.class);
    }

    public UiService getUi() {
        return ui;
    }

    //////

    public RobotFrame createRobotFrame(UiControl control) throws Exception {
        return new RobotFrame(control, null, this);
    }

    ////// show

    public void show(UiControl control, boolean modalModeAfterRun, IRobotFrameRunner run) throws Exception {
        RobotFrame r = createRobotFrame(control);
        r.show(run, modalModeAfterRun);
    }

    public void show(UiControl control) throws Exception {
        show(control, false, new IRobotFrameRunner() {
            public void run(RobotFrame r) throws Exception {
                r.screenShot();
            }
        });
    }

    public void show(UiControl control, IRobotFrameRunner run) throws Exception {
        show(control, false, run);
    }

    public void showModal(UiControl control, IRobotFrameRunner run) throws Exception {
        show(control, true, run);
    }

    public void showModal(UiControl control) throws Exception {
        show(control, true, new IRobotFrameRunner() {
            public void run(RobotFrame r) throws Exception {
                r.screenShot();
            }
        });
    }

    //////

    /**
     * Обертка JComponent в UiControl
     */
    public UiControl toControl(JComponent comp) {
        CustomPanel p = create(CtPanel.class);
        p.setCtrl(comp);
        return p;
    }

    /**
     * Пауза. Работает, когда тест запускается индивидуально.
     */
    public void modalMode() throws Exception {
        RobotFrame r = createRobotFrame(create(CtPanel.class));
        r.modalMode();
    }

    /**
     * Показать xml панель
     *
     * @param resource
     * @throws Exception
     */
    public void showUiXml(String resource) throws Exception {
        CtPanel p = create(CtPanel.class);
        getUi().createBuilder(p).load(resource);
        showModal(p);
    }

    /**
     * Построить control из xml resourceName, используя ее дочерний узел childNode
     */
    public void buildControl(UiControl control, String resourceName, String childNode) throws Exception {
        EasyXml r = new EasyXml();
        r.load().fromRes(resourceName);
        EasyXml r1 = r.getChild(childNode);
        getUi().createBuilder(control).load(r1);
    }

    /**
     * Создать и построить control из xml resourceName, используя ее дочерний узел childNode
     */
    public CtPanel buildControl(String resourceName, String childNode) throws Exception {
        CtPanel p = create(CtPanel.class);
        buildControl(p, resourceName, childNode);
        return p;
    }

    ////// ObjectFactory

    public ObjectFactory getObjectFactory() {
        return getUi().getObjectFactory();
    }

    public Object create(Rt rt, Class cls, IIniter beforeIniter) {
        return getObjectFactory().create(rt, cls, beforeIniter);
    }

    public <A> A create(Class<A> cls) {
        return getObjectFactory().create(cls);
    }

    public Object create(Rt rt, Class cls) {
        return getObjectFactory().create(rt, cls);
    }

    public <A> A create(Class<A> cls, IIniter beforeIniter) {
        return getObjectFactory().create(cls, beforeIniter);
    }

    public Object create(Rt rt) {
        return getObjectFactory().create(rt);
    }

    public Object create(Rt rt, IIniter beforeIniter) {
        return getObjectFactory().create(rt, beforeIniter);
    }
}
