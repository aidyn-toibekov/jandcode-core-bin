package jandcode.ui;

import java.awt.*;

/**
 * Шрифты
 */
public abstract class FontService extends UiBasedService {

    private Font _fontStandart;

    /**
     * Получить шрифт по его описанию.
     * Описание может быть строкой вида: name:имя;style:STYLE;size:SIZE,
     * где STYLE: bold, italic; size: размер.
     * или вида: fontname:имя;fontstyle:STYLE;fontsize:SIZE.
     * Если некоторые параметры не указаны, то они берутся из базового шрифта based
     * <p/>
     * Если размер со знаком '+' или '-', то это соответсвтенно +/- от базового размера
     * <p/>
     * Если based не укзан, берется собственный getFontStandart()
     */
    public abstract Font getFont(Font based, Object desc);

    /**
     * Вызов getFont(null, desc)
     */
    public Font getFont(Object desc) {
        return getFont(null, desc);
    }

    /**
     * Стандартный font
     */
    public Font getFontStandart() {
        return _fontStandart;
    }

    public void setFontStandart(Font font) {
        _fontStandart = font;
    }

}
