package jandcode.ui;

import javax.swing.*;

/**
 * Shortcuts
 */
public abstract class ShortcutService extends UiBasedService {

    /**
     * Получить swing KeyStroke для правильного представления (типа 'Ctrl+F5' => 'ctrl F5')
     */
    public abstract KeyStroke getKeyStroke(String text);

}
