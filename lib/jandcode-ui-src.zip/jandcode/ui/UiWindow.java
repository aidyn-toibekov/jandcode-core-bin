package jandcode.ui;

import jandcode.utils.error.*;

import java.awt.*;

/**
 * Окно
 */
public abstract class UiWindow extends UiComp {

    protected UiFrame frame;
    protected UiInterior interior;
    protected IRealWindow ctrl;

    ////// ctrl

    /**
     * Реальное окно
     */
    public IRealWindow getCtrl() {
        if (ctrl == null) {
            throw new XError("Окно не создано");
        }
        return ctrl;
    }

    /**
     * Создание реального окна
     */
    protected abstract void createCtrl();

    //////

    /**
     * Показываемый фрейм
     */
    public UiFrame getFrame() {
        return frame;
    }

    /**
     * Интерьер
     */
    public UiInterior getInterior() {
        return interior;
    }

    //////

    /**
     * Показать фрейм
     */
    public void show(UiFrame frame) {
        this.frame = frame;
        interior = getUi().createInterior(frame.getInteriorName());
        interior.setFrame(frame);
        frame.window = this;
        //
        createCtrl();
        ctrl.setUiWindow(this);
        setTitle(frame.getTitle());
        //
        interior.fireShow();
        frame.fireShow();
        //
        doShow();
    }

    /**
     * Физический показ окна
     */
    protected abstract void doShow();

    /**
     * Закрыть окно с указанной командой. Возвращает true если удачно закрыли
     */
    public boolean performClose(String cm) {
        if (frame.fireClose(cm)) {
            frame.closeCm = cm;
            try {
                frame.fireHide();
            } finally {
                close();
            }
            return true;
        }
        return false;
    }

    /**
     * Физическое безусловное закрытие окна
     */
    public void close() {
        doClose();
        clearLinks();
    }

    /**
     * Физическое безусловное закрытие окна
     */
    protected abstract void doClose();

    /**
     * Очистка всех ссылок. Вызывается при закрытии в close()
     */
    protected void clearLinks() {
        if (frame != null) {
            frame.window = null;
        }
        if (ctrl != null) {
            ctrl.setUiWindow(null);
        }
        interior = null;
        frame = null;
        ctrl = null;
    }

    //////

    public Dimension getSize() {
        return getCtrl().getSize();
    }

    public void setSize(Dimension d) {
        getCtrl().setSize(d);
    }

    public void setLocation(Point p) {
        getCtrl().setLocation(p);
    }

    public Point getLocation() {
        return getCtrl().getLocation();
    }

    public void refresh() {
        getCtrl().refresh();
    }

    public void setTitle(String title) {
        super.setTitle(title);
        if (ctrl != null) {
            ctrl.setTitle(title);
        }
    }

}
