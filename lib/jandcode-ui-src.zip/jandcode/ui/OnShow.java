package jandcode.ui;

/**
 * Событие - компонент показан.
 */
public interface OnShow {

    void onShow(UiControl ctrl);

}
