package jandcode.ui;

@Deprecated
public interface IUiDatasourceLink {

    UiDatasource getUiDatasource();

}
