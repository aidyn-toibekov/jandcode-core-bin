package jandcode.ui;

import jandcode.app.*;
import jandcode.ui.impl.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import jandcode.ui.FocusManager;

/**
 * Сервис ui
 */
public class UiService extends CompRt implements IServiceHolder, IObjectFactoryLink, IActivate, IIniter {

    // была ли активация
    private static boolean _activated = false;

    private static FocusManager _focusManager;

    protected ServiceContainer _services = new ServiceContainer();
    private Object _mainFrame;
    protected ListNamed<CacheItem> _controls = new ListNamed<CacheItem>();
    protected ListNamed<CacheItem> _builders = new ListNamed<CacheItem>();
    protected ListNamed<CacheItem> _windows = new ListNamed<CacheItem>();
    protected ListNamed<CacheItem> _interiors = new ListNamed<CacheItem>();
    protected ListNamed<CacheItem> _actions = new ListNamed<CacheItem>();
    protected ListNamed<CacheItem> _frames = new ListNamed<CacheItem>();
    protected ListNamed<CacheItem> _styles = new ListNamed<CacheItem>();
    private ObjectFactory objectFactory = new ObjectFactory(this);

    class CacheItem extends Named {
        Rt rt;

        CacheItem(Rt rt) {
            this.rt = rt;
            setName(rt.getName());
        }

        Object create() {
            Object a = objectFactory.create(rt);
            if (a instanceof CompRt) {
                ((CompRt) a).setName("");
            }
            return a;
        }

        Object create(Class cls) {
            Object a = objectFactory.create(cls);
            objectFactory.setRt(a, rt);
            if (a instanceof CompRt) {
                ((CompRt) a).setName("");
            }
            return a;
        }
    }

    public UiService() {
        _controls.setNotFoundMessage("UiControl [{0}] не найден");
        _builders.setNotFoundMessage("UiBuilder [{0}] не найден");
        _interiors.setNotFoundMessage("UiInterior [{0}] не найден");
        _windows.setNotFoundMessage("UiWindow [{0}] не найден");
        _actions.setNotFoundMessage("UiAction [{0}] не найден");
        _frames.setNotFoundMessage("UiFrame [{0}] не найден");
        _styles.setNotFoundMessage("UiStyle [{0}] не найден");
    }

    /**
     * Активирован ли ui
     */
    public static boolean isActivated() {
        return _activated;
    }

    public void activate() throws Exception {
        if (_activated) {
            return;
        }

        // фокус
        _focusManager = new FocusManager(this);
        KeyboardFocusManager focusManager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        focusManager.addPropertyChangeListener(_focusManager);

        // L&F
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

        // Error handler
        if (!getApp().isTest()) {
            // обработчики ошибок регистрируем только в не тестовой среде
            Thread.setDefaultUncaughtExceptionHandler(new UiErrorHandler(this));
        }

        //
        _activated = true;
    }

    protected void fillCashedItem(ListNamed<CacheItem> items, String type) {
        Rt z = getApp().getRt().findChild(type);
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                CacheItem di = new CacheItem(z1);
                items.add(di);
            }
        }
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt apprt = getApp().getRt();

        // сервисы
        _services.addAll(rt.findChild("service"), objectFactory);

        // cashed items
        fillCashedItem(_controls, "uicontrol");
        fillCashedItem(_builders, "uibuilder");
        fillCashedItem(_actions, "uiaction");
        fillCashedItem(_interiors, "uiinterior");
        fillCashedItem(_windows, "uiwindow");
        fillCashedItem(_frames, "uiframe");
        fillCashedItem(_styles, "uistyle");
    }

    ////// services

    public <A extends Object> A service(Class<A> clazz) {
        return _services.get(clazz);
    }

    public ServiceContainer getServices() {
        return _services;
    }

    public MsgboxService getMsgboxService() {
        return service(MsgboxService.class);
    }

    public ColorService getColorService() {
        return service(ColorService.class);
    }

    public ShortcutService getShortcutService() {
        return service(ShortcutService.class);
    }

    public IconService getImageService() {
        return service(IconService.class);
    }

    public BorderService getBorderService() {
        return service(BorderService.class);
    }

    public FontService getFontService() {
        return service(FontService.class);
    }

    ////// factory


    public void initObject(Object obj) throws Exception {
        getApp().initObject(obj);
        if (obj instanceof UiControl) {
            ((UiControl) obj).constructor(); // вызываем конструктор объекта после инициализации!
        }
    }

    public ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    ////// factory utilites

    /**
     * Создать новый экземпляр control
     */
    public UiControl createControl(String name) {
        return (UiControl) _controls.get(name).create();
    }

    /**
     * Создать новый экземпляр control с указанным классом
     */
    public UiControl createControl(String name, Class cls) {
        return (UiControl) _controls.get(name).create(cls);
    }

    /**
     * Создать новый экземпляр builder
     */
    public UiBuilder createBuilder(String name) {
        return (UiBuilder) _builders.get(name).create();
    }

    /**
     * Создать новый экземпляр builder с именем 'default' для control
     */
    public UiBuilder createBuilder(UiControl control) {
        UiBuilder b = createBuilder("default");
        b.setRoot(control);
        return b;
    }

    /**
     * Создать новый экземпляр builder с именем name для control
     */
    public UiBuilder createBuilder(UiControl control, String name) {
        UiBuilder b = createBuilder(name);
        b.setRoot(control);
        return b;
    }

    /**
     * Создать новый экземпляр UiWindow
     */
    public UiWindow createWindow(String name) {
        return (UiWindow) _windows.get(name).create();
    }

    /**
     * Создать новый экземпляр UiInterior
     */
    public UiInterior createInterior(String name) {
        return (UiInterior) _interiors.get(name).create();
    }

    /**
     * Создать новый экземпляр UiAction
     */
    public UiAction createAction(String name) {
        return (UiAction) _actions.get(name).create();
    }

    /**
     * Создать новый экземпляр UiFrame
     */
    public UiFrame createFrame(String name) {
        return (UiFrame) _frames.get(name).create();
    }

    /**
     * Создать новый экземпляр UiFrame
     */
    public UiStyle createStyle(String name) {
        CacheItem a = _styles.find(name);
        if (a != null) {
            return (UiStyle) a.create(UiStyle.class);
        }
        if (name.contains(":")) {
            UiStyle st = objectFactory.create(UiStyle.class);
            st.parse(name);
            return st;
        }
        throw new XError(_styles.getNotFoundMessage(), name);
    }

    /**
     * Создать новый экземпляр UiFrame
     */
    public UiStyle createStyle(Rt rt) {
        return (UiStyle) objectFactory.create(rt, UiStyle.class);
    }

    ////// mainframe

    /**
     * Установить главный фрейм окна (JFrame или UiFrame)
     */
    public void setMainFrame(Object frame) {
        _mainFrame = frame;
    }

    public UiFrame getMainFrame() {
        if (_mainFrame instanceof UiFrame) {
            return (UiFrame) _mainFrame;
        }
        return null;
    }

    /**
     * Главное окно приложения
     */
    public JFrame getMainJFrame() {
        if (_mainFrame == null) {
            return null;
        }
        if (_mainFrame instanceof JFrame) {
            return (JFrame) _mainFrame;
        }
        if (_mainFrame instanceof UiFrame) {
            UiFrame f = (UiFrame) _mainFrame;
            if (f.hasWindow()) {
                if (f.getWindow() instanceof IJFrameLink) {
                    return ((IJFrameLink) f.getWindow()).getJFrame();
                }
            }
        }
        return null;
    }

    ////// utils

    /**
     * Назначить исполнение actions на клавишу, глобально в пределах компонента
     *
     * @param shortcut Клавиша
     * @param action   Action
     */
    public void bindShortcut(JComponent c, String shortcut, Action action) {
        if (UtString.empty(shortcut)) {
            return;
        }
        c.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).
                put(getShortcutService().getKeyStroke(shortcut), action);
        c.getActionMap().put(action, action);
    }

    /**
     * Настройка клавиш для редакторов в диалоге - вверх,вниз и enter
     */
    public void initKeysForEditor(JComponent ctrl, boolean includeLeftRight, boolean includeEnter) {
        // down
        Set forwardKeys = ctrl.getFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS);
        Set newForwardKeys = new HashSet(forwardKeys);
        if (includeEnter) {
            newForwardKeys.add(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0));
        }
        newForwardKeys.add(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0));
        if (includeLeftRight) {
            newForwardKeys.add(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0));
        }
        ctrl.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,
                newForwardKeys);

        //up
        Set backKeys = ctrl.getFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS);
        Set newBackKeys = new HashSet(backKeys);
        newBackKeys.add(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0));
        if (includeLeftRight) {
            newBackKeys.add(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0));
        }
        ctrl.setFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,
                newBackKeys);
    }

    /**
     * Настройка клавиш tab и shift+tab для изменения сфокусированного объекта
     *
     * @param ctrl
     */
    public void initTabKeys(JComponent ctrl) {
        // tab должен фокус менять
        Set<KeyStroke> h = new HashSet<KeyStroke>();
        h.add(KeyStroke.getKeyStroke(KeyEvent.VK_TAB, 0));
        ctrl.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS, h);
        h = new HashSet<KeyStroke>();
        h.add(KeyStroke.getKeyStroke(KeyEvent.VK_TAB, KeyEvent.SHIFT_MASK));
        ctrl.setFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS, h);
    }

    /**
     * Перевод ширины в символах в ширину в точках. Приблизительно!
     *
     * @param charWidth ширина в символах
     * @return ширина в точках
     */
    public int charWidthToPointWidth(int charWidth) {
        return charWidth * 7;
    }

    /**
     * Получить явного владельца указанного Component (JComponent)
     *
     * @param c Component (JComponent)
     * @return null, если не определен
     */
    public UiControl getUiControl(Component c) {
        if (c instanceof IUiControlLink) {
            return ((IUiControlLink) c).getUiControl();
        }
        return null;
    }


}
