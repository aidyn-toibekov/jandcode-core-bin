package jandcode.ui;

import javax.swing.border.*;

/**
 * Интерфейс для фабрики рамок
 */
public interface IBorderFactory {

    /**
     * Создать новый экземпляр рамки
     */
    public Border createBorder();

}
