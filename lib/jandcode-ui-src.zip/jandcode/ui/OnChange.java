package jandcode.ui;

/**
 * Событие - компонент поменялся.
 */
public interface OnChange {

    void onChange(UiControl ctrl);

}
