package jandcode.ui;

/**
 * Ссылка на UiControl
 */
public interface IUiControlLink {

    UiControl getUiControl();

}
