package jandcode.ui;

/**
 * Событие - закрытие фрейма
 */
public interface OnClose {

    public static class Param {

        private String _cm = "";
        private boolean _enableClose = true;

        /**
         * Команда закрытия окна (ok, cancel, ...)
         */
        public String getCm() {
            return _cm;
        }

        public void setCm(String cm) {
            _cm = cm;
        }

        /**
         * Разрешить/запретить закрытие окна
         *
         * @param enableClose false - окно закрывать нельзя. По умолчанию - true
         */
        public void setEnableClose(boolean enableClose) {
            _enableClose = enableClose;
        }

        public boolean isEnableClose() {
            return _enableClose;
        }

        /**
         * Команда ok
         *
         * @return true, если cm="ok"
         */
        public boolean isOk() {
            return "ok".equalsIgnoreCase(getCm());
        }

        /**
         * Команда cancel
         *
         * @return true, если cm="cancel"
         */
        public boolean isCancel() {
            return "cancel".equalsIgnoreCase(getCm());
        }

    }

    void onClose(UiFrame frame, Param p);

}
