package jandcode.ui;

import jandcode.app.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Элемент меню. Принадлежит control.
 */
public class UiMenu extends CompRt {

    protected static ListComp<UiMenu> EMPTY_LIST = new ListComp<UiMenu>();

    static {
        EMPTY_LIST.setNotFoundMessage("UiMenu [{0}] not found");
    }

    private ListComp<UiMenu> _items = EMPTY_LIST;
    private int _index;
    private int _weight = 50;
    private String _title;
    private Object _link;  // UiAction, UiControl
    private String _iconName;

    //////

    public String getTitle() {
        if (_title == null || _title.length() == 0) {
            if (_link instanceof UiAction) {
                return ((UiAction) _link).getTitle();
            } else if (_link instanceof UiControl) {
                return ((UiControl) _link).getTitle();
            } else {
                return "";
            }
        }
        return _title;
    }

    public void setTitle(String title) {
        _title = title;
    }

    //////

    public String getIconName() {
        if (_iconName == null || _iconName.length() == 0) {
            if (_link instanceof UiAction) {
                return ((UiAction) _link).getIconName();
            } else {
                return "";
            }
        }
        return _iconName;
    }

    public void setIconName(String iconName) {
        _iconName = iconName;
    }

    public boolean hasIconName() {
        return _iconName != null && _iconName.length() > 0;
    }

    //////

    public int getIndex() {
        return _index;
    }

    public void setIndex(int index) {
        _index = index;
    }

    //////

    public int getWeight() {
        return _weight;
    }

    public void setWeight(int weight) {
        _weight = weight;
    }

    //////

    public Object getLink() {
        return _link;
    }

    public void setLink(Object link) {
        if (link == null || link instanceof UiAction || link instanceof UiControl) {
            _link = link;
        } else {
            throw new XError("link должен быть UiAction или UiControl");
        }
    }

    //////

    public ListComp<UiMenu> getItems() {
        return _items;
    }

    public UiMenu addItem(UiMenu it) {
        if (_items == EMPTY_LIST) {
            _items = new ListComp<UiMenu>(this);
            _items.setNotFoundMessage(EMPTY_LIST.getNotFoundMessage());
        }
        if (!it.hasName()) {
            it.setName("_" + _items.size());
        }
        it.setIndex(_items.size());
        _items.add(it);
        return it;
    }

    public UiMenu getLastItem() {
        return _items.last();
    }

    ////// sort

    /**
     * Сортировка (рекурсивная) по весу и индексу.
     */
    public void sort() {
        if (_items != EMPTY_LIST) {
            Collections.sort(_items, new ComparatorItem());
            for (UiMenu z : _items) {
                z.sort();
            }
        }
    }

    class ComparatorItem implements Comparator<UiMenu> {
        public int compare(UiMenu o1, UiMenu o2) {
            Integer i1 = o1.getWeight();
            Integer i2 = o2.getWeight();
            int n = i1.compareTo(i2);
            if (n == 0) {
                i1 = o1.getIndex();
                i2 = o2.getIndex();
                n = i1.compareTo(i2);
            }
            return n;
        }
    }

    //////

    public boolean isControl() {
        return _link instanceof UiControl;
    }

    public UiControl getControl() {
        return (UiControl) _link;
    }

    public boolean isSeparator() {
        return _title != null && _title.equals("-");
    }

    public boolean isAction() {
        return _link instanceof UiAction;
    }

    public UiAction getAction() {
        return (UiAction) _link;
    }

    public boolean isSubMenu() {
        return !isSeparator() && (_items.size() > 0 || _link == null);
    }


}
