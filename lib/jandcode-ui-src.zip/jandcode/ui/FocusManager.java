package jandcode.ui;

import java.awt.*;
import java.beans.*;
import java.util.*;


/**
 * Глобальный focus менеджер
 */
public class FocusManager implements PropertyChangeListener {

    private ArrayList<UiControl> _lostList = new ArrayList<UiControl>();
    private ArrayList<UiControl> _gainList = new ArrayList<UiControl>();
    private UiService ui;

    public FocusManager(UiService ui) {
        this.ui = ui;
    }

    public UiService getUi() {
        return ui;
    }

    public void propertyChange(PropertyChangeEvent evt) {
        String pn = evt.getPropertyName();

        if (!("focusOwner".equals(pn))) {
            return;
        }

        if (evt.getOldValue() instanceof Component) {
            fillList(_lostList, (Component) evt.getOldValue());
        }

        if (evt.getNewValue() instanceof Component) {
            fillList(_gainList, (Component) evt.getNewValue());
            notifyFocusChange();
        }

    }

    /**
     * Заполнение списка control
     *
     * @param lst куда (очищается)
     * @param c   начиная с него и всех его предков до формы включительно
     */
    private void fillList(ArrayList<UiControl> lst, Component c) {
        lst.clear();

        Component cur = c;
        while (cur != null) {
            UiControl ct = getUi().getUiControl(cur);
            if (ct != null) {
                lst.add(ct);
                if (ct instanceof UiFrame && ((UiFrame) ct).isTopFrame()) {
                    return;  // на верхнем фрейме - прекращаем
                }
            }
            cur = cur.getParent();
        }

    }

    private void notifyFocusChange() {
        // выясняем, кому это нужно
        int idxLost = _lostList.size() - 1;
        int idxGain = _gainList.size() - 1;
        int sz = Math.min(_lostList.size(), _gainList.size());

        // выявляем одинаковые
        if (sz > 0) {
            for (int i = 0; i < sz; i++) {
                if (idxLost >= 0 && idxGain >= 0) {
                    if (_lostList.get(idxLost) != _gainList.get(idxGain)) {
                        break;
                    }
                } else {
                    break;
                }
                idxGain--;
                idxLost--;
            }
        }

        // кричим
        for (int i = 0; i <= idxLost; i++) {
            _lostList.get(i).fireFocusChange(i == 0, true);
        }
        for (int i = 0; i <= idxGain; i++) {
            _gainList.get(i).fireFocusChange(i == 0, false);
        }

    }


}
