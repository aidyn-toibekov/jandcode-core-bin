package jandcode.wax.excelreport;

import org.apache.commons.vfs2.*;

import java.io.*;

/**
 * Генератор отчетов на excel
 */
public abstract class ExcelReport {

    /**
     * Создает в отчете новый лист по образу и подобию страницы шаблона
     * с индексом templateSheetIndex
     *
     * @param templateSheetIndex
     * @return
     */
    public abstract ReportSheet addSheet(int templateSheetIndex);

    /**
     * Сохраняет результат в указанном файле
     *
     * @param fn имя файла vfs
     */
    public abstract void saveResult(String fn) throws Exception;

    /**
     * Сохраняет результат в указанном потоке. Поток автоматом не закрывается
     */
    public abstract void saveResult(OutputStream st) throws Exception;

}
