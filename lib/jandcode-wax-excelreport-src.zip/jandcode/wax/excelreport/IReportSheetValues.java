package jandcode.wax.excelreport;

public interface IReportSheetValues {
}
