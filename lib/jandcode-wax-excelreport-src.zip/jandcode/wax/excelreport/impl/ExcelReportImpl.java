package jandcode.wax.excelreport.impl;

import jandcode.utils.*;
import jandcode.wax.excelreport.*;
import org.apache.commons.vfs2.*;
import org.apache.poi.hssf.usermodel.*;

import java.io.FileNotFoundException;
import java.io.*;

public class ExcelReportImpl extends ExcelReport {

    protected HSSFWorkbook wbTemplate;
    protected HSSFWorkbook wbResult;

    public ExcelReportImpl(String fn) throws Exception {
        openTemplate(fn);
    }

    protected void openTemplate(String fn) throws Exception {
        FileObject fo = UtFile.getFileObject(fn);
        if (!fo.exists()) {
            throw new FileNotFoundException(fo.toString());
        }
        InputStream fs = fo.getContent().getInputStream();
        try {
            wbTemplate = new HSSFWorkbook(fs);
        } finally {
            fs.close();
        }
        //
        wbResult = new HSSFWorkbook();
    }

    public ReportSheet addSheet(int templateSheetIndex) {
        HSSFSheet shRes = wbResult.createSheet();
        HSSFSheet shTml = wbTemplate.getSheetAt(templateSheetIndex);
        return new ReportSheetImpl(shTml, shRes);
    }

    public void saveResult(String fn) throws Exception {
        FileObject fo = UtFile.getFileObject(fn);
        OutputStream fs = fo.getContent().getOutputStream();
        try {
            wbResult.write(fs);
        } finally {
            fs.close();
        }
    }

    public void saveResult(OutputStream st) throws Exception {
        wbResult.write(st);
    }

}
