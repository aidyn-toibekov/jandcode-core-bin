package jandcode.wax.excelreport.impl;

import jandcode.wax.excelreport.*;

public class ExcelReportServiceImpl extends ExcelReportService {

    public ExcelReport openTemplate(String fn) throws Exception {
        ExcelReportImpl res = new ExcelReportImpl(fn);
        return res;
    }

}
