package jandcode.wax.excelreport.impl.databinder;

import jandcode.utils.*;
import jandcode.utils.variant.*;

public class DataBinderIValueNamed extends DataBinder {

    public String getVarValue(Object data, String varname, String varparam) {
        return UtCnv.toString(((IValueNamed) data).getValue(varname));
    }

}
