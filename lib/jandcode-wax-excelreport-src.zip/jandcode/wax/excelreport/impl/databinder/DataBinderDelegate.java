package jandcode.wax.excelreport.impl.databinder;

import jandcode.dbm.data.*;
import jandcode.utils.variant.*;

import java.util.*;

public class DataBinderDelegate extends DataBinder {

    private DataBinderDataRecord record;
    private DataBinderDataStore store;
    private DataBinderMap map;
    private DataBinderIValueNamed valueNamed;
    private DataBinderDataBox box;

    public String getVarValue(Object data, String varname, String varparam) {
        if (data instanceof DataStore) {
            if (store == null) {
                store = new DataBinderDataStore();
            }
            return store.getVarValue(data, varname, varparam);
        } else if (data instanceof DataRecord) {
            if (record == null) {
                record = new DataBinderDataRecord();
            }
            return record.getVarValue(data, varname, varparam);
        } else if (data instanceof DataBox) {
            if (box == null) {
                box = new DataBinderDataBox();
            }
            return box.getVarValue(data, varname, varparam);
        } else if (data instanceof IValueNamed) {
            if (valueNamed == null) {
                valueNamed = new DataBinderIValueNamed();
            }
            return valueNamed.getVarValue(data, varname, varparam);
        } else if (data instanceof Map) {
            if (map == null) {
                map = new DataBinderMap();
            }
            return map.getVarValue(data, varname, varparam);
        }
        return "";
    }

}
