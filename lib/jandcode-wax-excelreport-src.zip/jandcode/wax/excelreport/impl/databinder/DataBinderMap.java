package jandcode.wax.excelreport.impl.databinder;

import jandcode.utils.*;

import java.util.*;

public class DataBinderMap extends DataBinder {

    public String getVarValue(Object data, String varname, String varparam) {
        return UtCnv.toString(((Map) data).get(varname));
    }

}
