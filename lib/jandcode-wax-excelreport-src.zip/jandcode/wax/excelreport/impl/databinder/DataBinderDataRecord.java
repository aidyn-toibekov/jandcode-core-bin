package jandcode.wax.excelreport.impl.databinder;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

public class DataBinderDataRecord extends DataBinder {

    public String getVarValue(Object data, String varname, String varparam) {
        DataRecord d = (DataRecord) data;
        Field f = d.getDomain().f(varname);
        if (f.hasDict()) {
            if (UtString.empty(varparam)) {
                return d.getDictText(varname);
            } else {
                return d.getDictText(varname, varparam);
            }
        } else {
            return d.getValueString(varname);
        }
    }

}
