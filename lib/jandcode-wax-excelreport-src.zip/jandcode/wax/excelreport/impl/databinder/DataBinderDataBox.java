package jandcode.wax.excelreport.impl.databinder;

import jandcode.dbm.data.*;
import jandcode.utils.*;

public class DataBinderDataBox extends DataBinder {

    private DataBinderDelegate delegate = new DataBinderDelegate();

    public String getVarValue(Object data, String varname, String varparam) {
        DataBox d = (DataBox) data;
        int a = varname.indexOf('/');
        if (a == -1) {
            return UtCnv.toString(d.get(varname));
        }
        String ar[] = varname.split("/");
        Object v1 = d.get(ar[0]);
        return delegate.getVarValue(v1, ar[1], varparam);
    }

}
