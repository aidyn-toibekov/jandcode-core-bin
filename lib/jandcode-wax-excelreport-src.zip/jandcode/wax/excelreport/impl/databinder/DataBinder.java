package jandcode.wax.excelreport.impl.databinder;

public abstract class DataBinder {

    public String getVarValue(Object data, String varname, String varparam) {
        return "";
    }

}
