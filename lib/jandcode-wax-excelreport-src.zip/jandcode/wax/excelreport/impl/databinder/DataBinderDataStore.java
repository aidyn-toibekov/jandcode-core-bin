package jandcode.wax.excelreport.impl.databinder;

import jandcode.dbm.data.*;

public class DataBinderDataStore extends DataBinder {

    private DataBinderDataRecord delegate = new DataBinderDataRecord();

    public String getVarValue(Object data, String varname, String varparam) {
        return delegate.getVarValue(((DataStore) data).getCurRec(), varname, varparam);
    }
}
