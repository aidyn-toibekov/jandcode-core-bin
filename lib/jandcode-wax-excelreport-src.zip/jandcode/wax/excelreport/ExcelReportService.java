package jandcode.wax.excelreport;

import jandcode.app.*;

public abstract class ExcelReportService extends CompRt {

    /**
     * Открыть шаблон
     *
     * @param fn имя файла vfs
     */
    public abstract ExcelReport openTemplate(String fn) throws Exception;


}
