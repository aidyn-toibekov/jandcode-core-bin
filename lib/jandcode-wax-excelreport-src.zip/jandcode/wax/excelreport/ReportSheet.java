package jandcode.wax.excelreport;

/**
 * Лист отчета
 */
public abstract class ReportSheet {

    /**
     * Устанавливает надпись на листе отчета (то, что на вкладке листа)
     */
    public abstract void setSheetTitle(String title);

    /**
     * Выводит указанный поименнованный регион в текущую позицию отчета
     *
     * @param nameBand имя региона
     * @param data     данные для подстановок
     */
    public abstract void out(String nameBand, Object data);

    /**
     * Есть ли такой band
     */
    public abstract boolean hasBand(String nameBand);

}
