package jandcode.utils.vdir.impl;

import jandcode.utils.vdir.*;

import java.util.*;

public class VFileImpl extends VFile {

    private VDir own;
    private String vpath;
    private String rpath;
    private boolean dir;
    private int index;

    public VFileImpl(VDir own, String vpath, String rpath, boolean dir, int index) {
        this.own = own;
        this.vpath = vpath;
        this.rpath = rpath;
        this.dir = dir;
        this.index = index;
    }

    public String getVirtualPath() {
        return vpath;
    }

    public String getRealPath() {
        return this.rpath;
    }

    public List<String> getRealPathList() {
        return own.getRealPathList(vpath);
    }

    public boolean isDir() {
        return dir;
    }

    public int getIndex() {
        return index;
    }
}
