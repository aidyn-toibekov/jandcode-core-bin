package jandcode.utils.vdir;

public class VRootInfo {

    private String rootPath;
    private String prefix;

    public VRootInfo(String rootPath, String prefix) {
        this.rootPath = rootPath;
        this.prefix = prefix;
    }

    public String getRootPath() {
        return rootPath;
    }

    public String getPrefix() {
        return prefix;
    }

}
