package jandcode.utils.vdir;

import jandcode.utils.*;
import org.apache.commons.vfs2.*;

import java.util.*;

/**
 * Представление файла/каталога в виртуальном каталоге
 */
public abstract class VFile {

    /**
     * Виртуальный путь
     */
    public abstract String getVirtualPath();

    /**
     * Реальный путь
     */
    public abstract String getRealPath();

    /**
     * Все реальные пути. Используется для объектов, которые присутствуют
     * в нескольких реальных путях.
     */
    public abstract List<String> getRealPathList();

    /**
     * Имя файла без пути
     */
    public String getFileName() {
        return UtFile.filename(getVirtualPath());
    }

    /**
     * Расширение файла
     */
    public String getExt() {
        return UtFile.ext(getVirtualPath());
    }

    /**
     * Аналог {@link VFile#getRealPath()}
     *
     * @return
     */
    public String toString() {
        return getRealPath();
    }

    /**
     * Является ли каталогом
     *
     * @return
     */
    public abstract boolean isDir();

    /**
     * Является ли файлом
     *
     * @return
     */
    public boolean isFile() {
        return !isDir();
    }

    /**
     * Индекс файла в виртуальном каталоге. Чем меньше индекс, тем выше приоритет
     */
    public abstract int getIndex();

    /**
     * Возвращает реальный FileObject
     */
    public FileObject getRealFileObject() {
        return UtFile.getFileObject(getRealPath());
    }

}
