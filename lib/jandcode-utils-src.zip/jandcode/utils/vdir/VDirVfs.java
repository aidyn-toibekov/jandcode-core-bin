package jandcode.utils.vdir;

import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.vfs2.*;

import java.util.*;

/**
 * Реализация виртуального каталога через VFS
 */
public class VDirVfs extends VDir {

    protected List<String> roots = new ArrayList<String>();
    protected List<RootPath> rootPaths = new ArrayList<RootPath>();

    class RootPath {
        FileObject path;
        String prefix;

        RootPath(FileObject path, String prefix) {
            this.path = path;
            this.prefix = prefix;
        }

        boolean isEmpty() {
            return prefix.length() == 0;
        }

        String prepareVPath(String path1) {
            if (!isEmpty()) {
                if (path1.equals(prefix)) {
                    return "";
                }
                if (!path1.startsWith(prefix + "/")) {
                    // префикс есть. Путь с префикса не начинается. Пропускаем
                    return null;
                }
                // удаляем префикс из запрашиваемого пути
                path1 = path1.substring(prefix.length() + 1);
            }
            return path1;
        }

        /**
         * Для пути path возвращает dummy-папку.
         * Например: префикс у каталога aaa/sss/ddd, передаем путь aaa, получаем sss
         *
         * @return null, если нет
         */
        String getDummyFolder(String path) {
            if (prefix.startsWith(path + "/")) {
                String dd = prefix.substring(path.length() + 1);
                String[] ar = dd.split("/");
                if (ar.length > 0) {
                    return ar[0];
                }
            }
            return null;
        }
    }

    public void addRoot(String path) {
        addRoot(path, "");
    }

    public void addRoot(String path, String prefixPath) {
        prefixPath = normalize(prefixPath);
        FileObject fo = UtFile.getFileObject(path);
        String fn = fo.toString();
        if (roots.contains(fn)) {
            return;
        }
        roots.add(0, fn);
        rootPaths.add(0, new RootPath(fo, prefixPath));
    }

    public List<VFile> findFiles(String path0) {
        int index = 0;
        path0 = normalize(path0);
        List<VFile> res = new ArrayList<VFile>();
        HashSet<String> used = new HashSet<String>();
        HashSet<String> dummyDirs = new HashSet<String>();
        try {
            for (RootPath root : rootPaths) {
                String path1 = root.prepareVPath(path0);
                if (path1 == null) {
                    String dd = root.getDummyFolder(path0);
                    if (dd != null) {
                        dummyDirs.add(dd);
                    }
                    continue;
                }
                FileObject f = root.path.resolveFile(path1);
                if (f.exists() && f.getType() == FileType.FOLDER) {
                    FileObject[] lst = f.getChildren();
                    for (FileObject f1 : lst) {
                        String nm = f1.getName().getBaseName();
                        if (!used.contains(nm)) {
                            used.add(nm);
                            res.add(createItem(path0 + "/" + nm, f1.toString(), f1.getType() == FileType.FOLDER, index));
                        }
                    }
                }
                index++;
            }
            if (dummyDirs.size() > 0) {
                for (String s : dummyDirs) {
                    if (!used.contains(s)) {
                        res.add(createItem(path0 + "/" + s, "DUMMY", true, index));
                        index++;
                    }
                }
            }
        } catch (FileSystemException e) {
            throw new RuntimeException(e);
        }
        return res;
    }

    public VFile findFile(String path0) {
        int index = 0;
        try {
            path0 = normalize(path0);
            for (RootPath root : rootPaths) {
                String path1 = root.prepareVPath(path0);
                if (path1 == null) {
                    continue;
                }
                FileObject fn = root.path.resolveFile(path1);
                if (fn.exists()) {
                    return createItem(path0, fn.toString(), fn.getType() == FileType.FOLDER, index);
                }
                index++;
            }
        } catch (FileSystemException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public List<String> getRealPathList(String path0) {
        List<String> res = new ArrayList<String>();
        try {
            path0 = normalize(path0);
            for (RootPath root : rootPaths) {
                String path1 = root.prepareVPath(path0);
                if (path1 == null) {
                    continue;
                }
                FileObject fn = root.path.resolveFile(path1);
                if (fn.exists()) {
                    res.add(fn.toString());
                }
            }
        } catch (FileSystemException e) {
            throw new RuntimeException(e);
        }
        return res;
    }

    public List<String> getRoots() {
        return roots;
    }

    public String getVirtualPath(String absolutePath) {
        try {
            FileObject f = UtFile.getFileObject(absolutePath);
            for (RootPath root : rootPaths) {
                String p = root.path.getName().getRelativeName(f.getName());
                if (p != null && p.indexOf("..") == -1) {
                    if (root.isEmpty()) {
                        p = root.prefix + "/" + p;
                    }
                    return normalize(p);
                }
            }
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        return null;
    }

    public List<VFile> getFileEntry(String virtualPath) {
        ArrayList<VFile> res = new ArrayList<VFile>();
        int index = 0;
        try {
            virtualPath = normalize(virtualPath);
            for (RootPath root : rootPaths) {
                String path1 = root.prepareVPath(virtualPath);
                if (path1 == null) {
                    continue;
                }
                FileObject fn = root.path.resolveFile(path1);
                if (fn.exists()) {
                    res.add(createItem(virtualPath, fn.toString(), fn.getType() == FileType.FOLDER, index));
                }
                index++;
            }
        } catch (FileSystemException e) {
            throw new RuntimeException(e);
        }
        return res;
    }

    public List<VRootInfo> getRootInfos() {
        List<VRootInfo> res = new ArrayList<VRootInfo>();
        for (RootPath root : rootPaths) {
            res.add(new VRootInfo(root.path.toString(), root.prefix));
        }
        return res;
    }
}
