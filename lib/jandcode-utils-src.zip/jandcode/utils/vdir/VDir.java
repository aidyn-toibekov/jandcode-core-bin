package jandcode.utils.vdir;

import jandcode.utils.vdir.impl.*;

import java.util.*;

/**
 * Виртуальный каталог. Собирается из нескольких реальных каталогов,
 * которые используются как корни и обеспечивает прозрачный доступ так,
 * как будно все файлы лежат в одном месте. По запросам возвращает
 * объекты {@link VFile}.
 */
public abstract class VDir {

    /**
     * Нормализация строки, содержащей условный путь. Заменяются '\' на '/', убираются
     * слеши в начале и конце, '..' удаляются
     *
     * @param path путь
     * @return нормализованный путь
     */
    public static String normalize(String path) {
        if (path == null) {
            return "";
        }
        if (path.contains("..")) {
            path = path.replace("..", "");
        }
        if (path.indexOf('\\') != -1) {
            path = path.replace("\\", "/");
        }
        while (path.contains("//")) {
            path = path.replace("//", "/");
        }
        while (path.startsWith("/")) {
            path = path.substring(1);
        }
        while (path.endsWith("/")) {
            path = path.substring(0, path.length() - 1);
        }
        return path;
    }

    /**
     * Объединение путей
     *
     * @param path
     * @param childPaths
     * @return нормализованный объединенный путь
     */
    public static String join(String path, String... childPaths) {
        path = normalize(path);
        for (String childPath : childPaths) {
            String p = normalize(childPath);
            if (p.length() > 0) {
                if (path.length() > 0) {
                    path = path + "/";
                }
                path = path + p;
            }
        }
        return path;
    }

    /**
     * Все корни в порядке приоритета
     */
    @Deprecated
    public abstract List<String> getRoots();

    /**
     * Информация о все корнях в порядке приоритета
     */
    public abstract List<VRootInfo> getRootInfos();

    /**
     * Добавить корень
     */
    public abstract void addRoot(String path);

    /**
     * Добавить корень с указанным префиксом пути
     */
    public abstract void addRoot(String path, String prefixPath);

    /**
     * Найти список дочерних файлов (и каталогов) в указанном пути
     *
     * @param path виртуальный путь
     */
    public abstract List<VFile> findFiles(String path);

    /**
     * Найти файл (или каталог)
     *
     * @param path виртуальный путь
     */
    public abstract VFile findFile(String path);

    /**
     * Все реальные пути. Используется для объектов, которые присутствуют
     * в нескольких реальных путях.
     */
    public abstract List<String> getRealPathList(String path);

    /**
     * Все файлы с указанным путем в виртуальном каталоге
     */
    public abstract List<VFile> getFileEntry(String virtualPath);

    /**
     * Получить виртуальный путь для реального. Возвращает null, если абсолютный путь
     * не из этого виртуального каталога.
     */
    public abstract String getVirtualPath(String absolutePath);

    //////

    /**
     * Создание элемента виртуального каталога. Используется и перекрывается реализатором.
     */
    protected VFile createItem(String vpath, String rpath, boolean dir, int index) {
        return new VFileImpl(this, vpath, rpath, dir, index);
    }

}
