package jandcode.utils;

import jandcode.utils.rt.*;
import jandcode.utils.rt.impl.*;

import java.util.*;

/**
 * Статические утилиты для rt
 */
public class UtRt {

    /**
     * Возвращает список источников (исходных файлов) для rt
     */
    public static List<String> getRootSources(Rt rt) {
        ArrayList<String> res = new ArrayList<String>();
        Rt root = rt.getRoot();
        if (root instanceof RtRootImpl) {
            HashMap<String, RtSourceHolderImpl.SourceItem> srcs = ((RtSourceHolderImpl) ((RtRootImpl) root).getSourceHolder()).getBySource();
            res.addAll(srcs.keySet());
        }
        return res;
    }

    /**
     * Возвращает true, если rt имеет собственный атрибут attrName и его значение true
     */
    public static boolean isTagged(Rt rt, String attrName) {
        return rt.hasSelfAttr(attrName) && rt.getValueBoolean(attrName);
    }

    /**
     * Возвращает true, если rt имеет собственный атрибут "abstract" и его значение true
     */
    public static boolean isAbstract(Rt rt) {
        return isTagged(rt, "abstract"); //NON-NLS
    }

    /**
     * Наложить данные в to из from. Если у from есть предки, то последовательно
     * накладываются все предки и потом from.
     */
    public static void joinSelf(Rt to, Rt from) {
        List<Rt> parents = getParentList(from);
        if (!parents.isEmpty()) {
            for (int i = parents.size() - 1; i >= 0; i--) {  // в обратном порядке
                Rt parent = parents.get(i);
                joinSelfInternal(to, parent, false);
            }
        }
        joinSelfInternal(to, from, false);
    }

    private static void joinSelfInternal(Rt to, Rt from, boolean inclParent) {
        for (IRtAttr attr : from.getSelfAttrs()) {
            String kn = attr.getName();
            if (!inclParent && Rt.PARENT.equalsIgnoreCase(kn)) {
                continue;
            }
            to.setValue(kn, attr.getValue());
        }
        for (Rt xx : from.getSelfChilds()) {
            Rt x1 = to.findChild(xx.getName(), true);
            joinSelfInternal(x1, xx, true);
        }
    }

    /**
     * Наложить раскрытые данные в to из from
     */
    public static void joinExpanded(Rt to, Rt from) {
        joinExpandedInternal(to, from, false);
    }

    private static void joinExpandedInternal(Rt to, Rt from, boolean inclParent) {
        for (IRtAttr attr : from.getAttrs()) {
            String kn = attr.getName();
            if (!inclParent && Rt.PARENT.equalsIgnoreCase(kn)) {
                continue;
            }
            to.setValue(kn, attr.getValue());
        }
        for (Rt xx : from.getChilds()) {
            Rt x1 = to.findChild(xx.getName(), true);
            joinExpandedInternal(x1, xx, true);
        }
    }

    /**
     * Возвращает список объектов, из которых строятся значения для r
     */
    public static List<Rt> getParentList(Rt r) {
        return (List) ((RtImpl) r).getParents();
    }

    /**
     * Получение списка модулей из корневой rt root
     *
     * @param root корневая rt. В ней будет искаться элемент module
     * @return
     */
    public static RtModuleList getModules(Rt root) {
        RtModuleList res = new RtModuleList();
        Rt rtmodules = root.findChild("module");
        if (rtmodules != null) {
            for (Rt rtmodule : rtmodules.getChilds()) {
                RtModule m = new RtModule();
                m.setName(rtmodule.getName());
                m.setPath(rtmodule.getValueString("path", ""));
                Rt depends = rtmodule.findChild("depend");
                if (depends != null) {
                    for (Rt depend : depends.getChilds()) {
                        m.getDepend().add(depend.getName());
                    }
                }
                res.add(m);
            }
        }
        return res;
    }

}
