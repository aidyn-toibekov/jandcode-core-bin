package jandcode.utils;

import org.joda.time.*;

import java.util.*;

/**
 * Типы данных
 */
public class DataType {

    public static final int OBJECT = 0;
    public static final int INT = 1;
    public static final int LONG = 2;
    public static final int DOUBLE = 3;
    public static final int DATETIME = 4;
    public static final int STRING = 5;
    public static final int BOOLEAN = 6;
    public static final int BLOB = 7;

    /**
     * Имена типов, используемы для поименования типов в тексте
     */
    protected static final String[] typeNames = {"object", "int", "long", //NON-NLS NON-NLS
            "double", "datetime", "string", "boolean", "blob"}; //NON-NLS NON-NLS NON-NLS NON-NLS

    /**
     * Получить тип по его имени
     */
    public static int nameToDataType(String name) {
        int cnt = typeNames.length;
        for (int i = 0; i < cnt; i++) {
            if (name.compareToIgnoreCase(typeNames[i]) == 0) {
                return i;
            }
        }
        return 0;
    }

    /**
     * Получить имя типа по его коду
     */
    public static String dataTypeToName(int dataType) {
        if (dataType >= 0 && dataType < typeNames.length) {
            return typeNames[dataType];
        } else {
            return typeNames[0];
        }
    }

    /**
     * Имена типов
     */
    public static String[] getDataTypeNames() {
        return typeNames;
    }

    /**
     * Получить тип данных для класса
     */
    public static int getDataType(Class value) {
        if (value == null) {
            return OBJECT;
        } else if (value == int.class) {
            return INT;
        } else if (value == double.class) {
            return DOUBLE;
        } else if (value == long.class) {
            return LONG;
        } else if (value == boolean.class) {
            return BOOLEAN;
        } else if (value == String.class) {
            return STRING;
        } else if (value == Integer.class) {
            return INT;
        } else if (value == Long.class) {
            return LONG;
        } else if (value == Byte.class) {
            return INT;
        } else if (value == Short.class) {
            return INT;
        } else if (value == Double.class) {
            return DOUBLE;
        } else if (value == Float.class) {
            return DOUBLE;
        } else if (value == DateTime.class) {
            return DATETIME;
        } else if (Date.class.isAssignableFrom(value)) {
            return DATETIME;
        } else if (value == byte[].class) {
            return BLOB;
        } else if (value == Boolean.class) {
            return BOOLEAN;
        } else if (CharSequence.class.isAssignableFrom(value)) {
            return STRING;
        } else {
            return OBJECT;
        }
    }

    /**
     * Получить тип данных для значения
     */
    public static int getDataType(Object value) {
        if (value == null) {
            return OBJECT;
        }
        return getDataType(value.getClass());
    }

    /**
     * Перевести объект value в значение типа dataType
     */
    public static Object toDataType(Object value, int dataType) {
        switch (dataType) {
            case INT:
                return UtCnv.toInt(value);
            case LONG:
                return UtCnv.toLong(value);
            case DOUBLE:
                return UtCnv.toDouble(value);
            case DATETIME:
                return UtCnv.toDateTime(value);
            case BOOLEAN:
                return UtCnv.toBoolean(value);
            case STRING:
                return UtCnv.toString(value);
            case BLOB:
                return UtCnv.toByteArray(value);
            case DataType.OBJECT:
                return value;
            default:
                return null;
        }
    }

    /**
     * true, если тип данных - число
     *
     * @param dt тип данных
     */
    public static boolean isNumber(int dt) {
        return dt == INT || dt == LONG || dt == DOUBLE;
    }

}
