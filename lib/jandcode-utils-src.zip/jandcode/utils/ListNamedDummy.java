package jandcode.utils;

import jandcode.utils.error.*;

/**
 * Поименнованный список, в который не добавляются значения. Для заглушек.
 */
public class ListNamedDummy<TYPE extends INamed> extends ListNamed<TYPE> {
    protected void onAdd(TYPE it) {
        throw new XError("Readonly list");
    }
}
