package jandcode.utils;

import org.joda.time.*;

import java.text.*;
import java.util.*;

/**
 * Утилиты для даты и времени
 */
public class UtDate {

    /**
     * Специальная дата, которая рассматривается как пустая
     */
    public static DateTime EMPTY_DATE = new DateTime("0", DateTimeZone.UTC);

    /**
     * Специальная дата, которая рассматривается как пустая дата конца
     */
    public static DateTime EMPTY_DATE_END = new DateTime("3333-12-31");
    private static DateTime fix_EMPTY_DATE_END = EMPTY_DATE_END.minusDays(2);

    /**
     * Стандартный формат даты
     */
    public static String FORMAT_DATE = "yyyy-MM-dd"; //NON-NLS
    /**
     * Стандартный формат даты и времени
     */
    public static String FORMAT_DATETIME = "yyyy-MM-dd'T'HH:mm:ss"; //NON-NLS

    /**
     * Стандартный формат времени
     */
    public static String FORMAT_TIME = "HH:mm:ss"; //NON-NLS

    /**
     * Стандартный формат даты и времени с милисекундами
     */
    public static String FORMAT_DATETIME_MSEC = "yyyy-MM-dd'T'HH:mm:ss.SSS"; //NON-NLS

    /**
     * Стандартный формат времени с милисекундами
     */
    public static String FORMAT_TIME_MSEC = "HH:mm:ss.SSS"; //NON-NLS

    public static String FORMAT_DATETIME_GMT = "EEE, dd MMM yyyy HH:mm:ss z"; //NON-NLS
    public static SimpleDateFormat FORMATTER_DATETIME_GMT = new SimpleDateFormat(FORMAT_DATETIME_GMT, Locale.US);

    private static final int[] DAYS_PER_MONTH = {
            0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
    };

    /**
     * Перевод даты в строку. В зависимости от существующих чатей даты формат подбирается
     * автоматом
     *
     * @param dt дата
     * @return строка
     */
    public static String toString(DateTime dt) {
        if (dt == null) {
            return "";
        }

        if (dt.equals(EMPTY_DATE)) {
            return "";
        }

        int year = dt.getYear();
        int msec = dt.getMillisOfSecond();

        if (year == 0) {
            if (msec == 0) {
                return dt.toString(FORMAT_TIME);
            } else {
                return dt.toString(FORMAT_TIME_MSEC);
            }
        }

        if (dt.getMillisOfDay() == 0) {
            return dt.toString(FORMAT_DATE);
        }

        if (msec == 0) {
            return dt.toString(FORMAT_DATETIME);
        } else {
            return dt.toString(FORMAT_DATETIME_MSEC);
        }
    }

    /**
     * Проверка на пустую дату
     *
     * @param d
     * @return
     */
    public static boolean isEmpty(DateTime d) {
        return d == null || d.equals(EMPTY_DATE) || d.equals(EMPTY_DATE_END) || d.isAfter(fix_EMPTY_DATE_END);
    }

    /**
     * Проверка на пустую дату
     *
     * @param d
     * @return
     */
    public static boolean isEmpty(Date d) {
        return d == null || isEmpty(new DateTime(d));
    }

    /**
     * Очистить время в дате
     *
     * @param dt дата и время
     * @return дата без времени
     */
    public static DateTime clearTime(DateTime dt) {
        return dt.withMillisOfDay(0);
    }

    /**
     * Возвращает массив индексов дней недели для недели, которая начинается с from
     *
     * @param from константа дня недели (DateTimeConstants.XXX)
     * @return массив из 7 чисел
     */
    public static int[] getDayWeekIndexes(int from) {
        int[] res = new int[7];
        for (int i = 0; i < 7; i++) {
            res[i] = from;
            from++;
            if (from > 7) {
                from = 1;
            }
        }
        return res;
    }

    /**
     * Возвращает массив полных названией дней недели для недели, которая начинается с from
     *
     * @param from   константа дня недели (DateTimeConstants.XXX)
     * @param locale для какой локали
     * @return массив из 7 строк
     */
    public static String[] getDayWeekNames(int from, Locale locale) {
        int[] res = getDayWeekIndexes(from);
        String[] ress = new String[res.length];
        DateFormatSymbols df = new DateFormatSymbols(locale);
        String[] a = df.getWeekdays();
        for (int i = 0; i < res.length; i++) {
            int n = res[i] + 1;
            if (n > 7) {
                n = 1;
            }
            ress[i] = a[n];
        }
        return ress;
    }

    /**
     * Возвращает массив полных названией дней недели для недели, которая начинается с from
     *
     * @param from константа дня недели (DateTimeConstants.XXX)
     * @return массив из 7 строк
     */
    public static String[] getDayWeekNames(int from) {
        return getDayWeekNames(from, Locale.getDefault());
    }

    /**
     * Возвращает массив полных названией дней недели для недели, которая начинается с from
     *
     * @param from   константа дня недели (DateTimeConstants.XXX)
     * @param locale для какой локали
     * @return массив из 7 строк
     */
    public static String[] getDayWeekShortNames(int from, Locale locale) {
        int[] res = getDayWeekIndexes(from);
        String[] ress = new String[res.length];
        DateFormatSymbols df = new DateFormatSymbols(locale);
        String[] a = df.getShortWeekdays();
        for (int i = 0; i < res.length; i++) {
            int n = res[i] + 1;
            if (n > 7) {
                n = 1;
            }
            ress[i] = a[n];
        }
        return ress;
    }

    /**
     * Возвращает массив полных названией дней недели для недели, которая начинается с from
     *
     * @param from константа дня недели (DateTimeConstants.XXX)
     * @return массив из 7 строк
     */
    public static String[] getDayWeekShortNames(int from) {
        return getDayWeekShortNames(from, Locale.getDefault());
    }

    /**
     * Проверка, что дата - это сегодня
     *
     * @param dt проверяемая дата
     * @return true, если дата=сегодня
     */
    public static boolean isToday(ReadableDateTime dt) {
        DateTime today = new DateTime().withMillisOfDay(0);
        return today.equals(dt.toDateTime().withMillisOfDay(0));
    }

    /**
     * Возвращает сегодняшнюю дату без времени
     *
     * @return дата без времени
     */
    public static DateTime today() {
        return new DateTime().withMillisOfDay(0);
    }

    /**
     * Возвращает сегодняшнюю дату без времени в стандартном формате java
     *
     * @return дата без времени
     */
    public static Date todayJava() {
        return today().toDate();
    }

    /**
     * Проверка на високосный год
     *
     * @param year
     * @return
     */
    public static boolean isLeap(int year) {
        return ((GregorianCalendar) GregorianCalendar.getInstance()).isLeapYear(year);
    }

    /**
     * Число дней в месяце
     *
     * @param year
     * @param month
     * @return
     */
    public static int getDaysInMonth(int year, int month) {
        int a = DAYS_PER_MONTH[month];
        if (month == 2 && isLeap(year)) {
            a++;
        }
        return a;
    }

    /**
     * Проеобразование не до конца оформленной даты в нормальную
     *
     * @param s      исходная строка, например '12','12.','12.4'
     * @param format формат даты для исходной строки
     * @param based  откуда брать недостающие части
     * @return дата или null, если нельзя преобразовать
     */
    public static DateTime partialStringToDate(String s, String format, DateTime based) {
        if (format == null || format.length() == 0) {
            return null;
        }

        // y,m,d
        String[] parts = new String[3];
        parts[0] = "";
        parts[1] = "";
        parts[2] = "";
        int cur_parts = 0;
        int last_s_idx = 0;
        boolean empty = true;

        format = format + "|"; // концовочка

        for (int i = 0; i < format.length(); i++) {
            char c = format.charAt(i);
            if (Character.isLetter(c)) {
                if (c == 'y') {
                    cur_parts = 0;
                } else if (c == 'M') {
                    cur_parts = 1;

                } else if (c == 'd') {
                    cur_parts = 2;
                } else {
                    return null;
                }
            } else {
                // думаем что разделитель
                int a = s.indexOf(c, last_s_idx);
                if (a == -1) {
                    // нет такого, считаем что закончилася
                    parts[cur_parts] = s.substring(last_s_idx).trim();
                    if (parts[cur_parts].length() > 0) {
                        empty = false;
                    }
                    break;
                } else {
                    parts[cur_parts] = s.substring(last_s_idx, a).trim();
                    if (parts[cur_parts].length() > 0) {
                        empty = false;
                    }
                    last_s_idx = a + 1;
                }
            }
        }

        if (empty) {
            return null; // все части пустые
        }

        int y = based.getYear();
        int m = based.getMonthOfYear();
        int d = based.getDayOfMonth();

        String z;

        // год
        z = parts[0].trim();
        if (z.length() != 0) {
            int v = _strToInt(z);
            if (v == 0) {
                return null;
            }
            if (z.length() == 4) {
                y = v;
            } else if (z.length() == 2) {
                if (v > 50) {
                    y = (y / 100 - 1) * 100 + v;
                } else {
                    y = (y / 100) * 100 + v;
                }
            } else {
                return null;
            }
        }

        // месяц
        z = parts[1].trim();
        if (z.length() != 0) {
            int v = _strToInt(z);
            if (v == 0) {
                return null;
            }
            if (v >= 1 && v <= 12) {
                m = v;
            } else {
                return null;
            }
        }

        // день
        z = parts[2].trim();
        if (z.length() != 0) {
            int v = _strToInt(z);
            if (v == 0) {
                return null;
            }
            if (v >= 1 && v <= getDaysInMonth(y, m)) {
                d = v;
            } else {
                return null;
            }
        }

        return new DateTime(y, m, d, 0, 0, 0, 0);
    }

    private static int _strToInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return 0;
        }
    }

    /**
     * Проеобразование не до конца оформленного времени в нормальную дату
     *
     * @param s      исходная строка, например '12','12:','12:4'
     * @param format формат времени для исходной строки
     * @param based  откуда брать недостающие части
     * @return дата или null, если нельзя преобразовать
     */
    public static DateTime partialStringToTime(String s, String format, DateTime based) {
        if (format == null || format.length() == 0) {
            return null;
        }

        // h,m,s
        String[] parts = new String[3];
        parts[0] = "";
        parts[1] = "";
        parts[2] = "";
        int cur_parts = 0;
        int last_s_idx = 0;
        boolean empty = true;

        format = format + "|"; // концовочка

        for (int i = 0; i < format.length(); i++) {
            char c = format.charAt(i);
            if (Character.isLetter(c)) {
                if (c == 'H') {
                    cur_parts = 0;
                } else if (c == 'm') {
                    cur_parts = 1;
                } else if (c == 's') {
                    cur_parts = 2;
                } else {
                    return null;
                }
            } else {
                // думаем что разделитель
                int a = s.indexOf(c, last_s_idx);
                if (a == -1) {
                    // нет такого, считаем что закончилася
                    parts[cur_parts] = s.substring(last_s_idx).trim();
                    if (parts[cur_parts].length() > 0) {
                        empty = false;
                    }
                    break;
                } else {
                    parts[cur_parts] = s.substring(last_s_idx, a).trim();
                    if (parts[cur_parts].length() > 0) {
                        empty = false;
                    }
                    last_s_idx = a + 1;
                }
            }
        }

        if (empty) {
            return null; // все части пустые
        }

        int y = based.getYear();
        int m = based.getMonthOfYear();
        int d = based.getDayOfMonth();

        int hour = based.getHourOfDay();
        int min = based.getMinuteOfHour();
        int sec = based.getSecondOfMinute();

        String z;

        // час
        z = parts[0].trim();
        if (z.length() != 0 && !"0".equals(z) && !"00".equals(z)) {
            int v = _strToInt(z);
            if (v == 0) {
                return null;
            }
            if (v >= 0 && v <= 23) {
                hour = v;
            } else {
                return null;
            }
        }

        // минута
        z = parts[1].trim();
        if (z.length() != 0 && !"0".equals(z) && !"00".equals(z)) {
            int v = _strToInt(z);
            if (v == 0) {
                return null;
            }
            if (v >= 0 && v <= 59) {
                min = v;
            } else {
                return null;
            }
        }

        // секунды
        z = parts[2].trim();
        if (z.length() != 0 && !"0".equals(z) && !"00".equals(z)) {
            int v = _strToInt(z);
            if (v == 0) {
                return null;
            }
            if (v >= 0 && v <= 59) {
                sec = v;
            } else {
                return null;
            }
        }

        return new DateTime(y, m, d, hour, min, sec, 0);
    }

    ////// GMT

    /**
     * Перевод даты в строку GMT
     *
     * @param d
     * @return
     */
    public static String dateToStringGMT(Date d) {
        return dateToStringGMT(new DateTime(d));
    }

    /**
     * Перевод даты в строку GMT
     *
     * @param d
     * @return
     */
    public static String dateToStringGMT(DateTime d) {
        DateTime d1 = d.withZone(DateTimeZone.UTC);
        return d1.toString(FORMAT_DATETIME_GMT, Locale.US);
    }

    /**
     * Перевод строки GMT в дату
     *
     * @param s исходная строка
     * @return null, если неправильная строка
     */
    public static DateTime stringToDateTimeGMT(String s) {
        try {
            Date d = FORMATTER_DATETIME_GMT.parse(s);
            return new DateTime(d);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Перевод строки GMT в дату
     *
     * @param s
     * @return null, если неправильная строка
     */
    public static Date stringToDateGMT(String s) {
        DateTime d = stringToDateTimeGMT(s);
        if (d == null) {
            return null;
        }
        return d.toDate();
    }

    /**
     * Сколько дней между датами
     *
     * @param d1
     * @param d2
     * @return
     */
    public static int daysBetween(ReadableInstant d1, ReadableInstant d2) {
        return Days.daysBetween(d1, d2).getDays();
    }
}
