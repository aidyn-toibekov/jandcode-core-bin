package jandcode.utils;

import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Построитель для сложных структуированных Map. Например для json.
 */
public class MapBuilder {

    protected Class classMap = LinkedHashMap.class;
    protected Class classList = ArrayList.class;
    protected String keyErrors = "errors"; //NON-NLS
    protected String keySuccess = "success"; //NON-NLS

    //////

    public Class getClassMap() {
        return classMap;
    }

    public void setClassMap(Class classMap) {
        this.classMap = classMap;
    }

    //////

    public Class getClassList() {
        return classList;
    }

    public void setClassList(Class classList) {
        this.classList = classList;
    }

    //////

    public String getKeyErrors() {
        return keyErrors;
    }

    public void setKeyErrors(String keyErrors) {
        this.keyErrors = keyErrors;
    }

    //////

    public String getKeySuccess() {
        return keySuccess;
    }

    public void setKeySuccess(String keySuccess) {
        this.keySuccess = keySuccess;
    }

    //////

    /**
     * Установить ключ успешности
     */
    public void setSuccess(Map m, boolean b) {
        m.put(keySuccess, b);
    }

    public void normalizeSuccess(Map m) {
        if (!m.containsKey(keySuccess)) {
            setSuccess(m, true);
        }
    }

    //////

    /**
     * Возвращает значение ключа, если его нет - создает указанный экземпляр
     *
     * @param key ключ
     * @param cls какой экземпляр создавать, если ключ не существует
     */
    public <AA extends Object> AA get(Map m, String key, Class<AA> cls) {
        AA itm = (AA) m.get(key);
        if (itm == null) {
            itm = (AA) UtClass.createInst(cls);
            m.put(key, itm);
        }
        return itm;
    }

    /**
     * Возвращает значение ключа, если его нет - создает список
     */
    public List getList(Map m, String key) {
        return (List) get(m, key, classList);
    }

    /**
     * Возвращает значение ключа, если его нет - создает map
     */
    public Map getMap(Map m, String key) {
        return (Map) get(m, key, classMap);
    }

    /**
     * Добавить rt
     */
    public void join(Map m, Rt rt) {
        if (rt == null) {
            return;
        }
        for (IRtAttr attr : rt.getAttrs()) {
            m.put(attr.getName(), attr.getValue());
        }
        for (Rt rt1 : rt.getChilds()) {
            Map m1 = getMap(m, rt1.getName());
            join(m1, rt1);
        }
    }

    /**
     * Добавить rt с автоопределением json-типов boolean, number
     */
    public void joinJson(Map m, Rt rt) {
        if (rt == null) {
            return;
        }
        for (IRtAttr attr : rt.getAttrs()) {
            Object v = attr.getValue();
            if (v instanceof String) {
                String s = (String) v;
                if (UtString.isBoolean(s)) {
                    m.put(attr.getName(), UtCnv.toBoolean(s));
                } else if (UtString.isLong(s)) {
                    m.put(attr.getName(), UtCnv.toLong(s));
                } else if (UtString.isNumber(s)) {
                    m.put(attr.getName(), UtCnv.toDouble(s));
                } else {
                    m.put(attr.getName(), s);
                }
            } else {
                m.put(attr.getName(), attr.getValue());
            }
        }
        for (Rt rt1 : rt.getChilds()) {
            Map m1 = getMap(m, rt1.getName());
            joinJson(m1, rt1);
        }
    }

    ////// errors

    /**
     * Добавить ошибку
     *
     * @param fieldName для какого поля
     * @param error     объект - ошибка
     */
    public void addError(Map m, String fieldName, Object error) {
        setSuccess(m, false);
        List lst = getList(m, keyErrors);
        String txt = "error!"; //NON-NLS
        //
        if (error instanceof Throwable) {
            ErrorInfo ei = UtError.createErrorInfo((Throwable) error);
            List<Map<String, String>> evalidate = new ArrayList<Map<String, String>>();
            for (Throwable ev : ei.getExceptions()) {
                if (ev instanceof ErrorValidate) {
                    evalidate.addAll(((ErrorValidate) ev).getValidateErrors());
                }
            }
            if (evalidate.size() > 0) {
                // ошибки валидации, разбитые по полям
                for (Map<String, String> ve : evalidate) {
                    addError(m, ve.get(ErrorValidate.FIELD), ve.get(ErrorValidate.TEXT));
                }
                return;
            } else {
                txt = ei.getText();
            }
        } else {
            txt = error.toString();
        }
        //
        Map m1 = (Map) UtClass.createInst(classMap);
        m1.put("text", txt); //NON-NLS
        if (!UtString.empty(fieldName)) {
            m1.put("field", fieldName); //NON-NLS
        }
        lst.add(m1);
    }

    /**
     * Добавить ошибку
     *
     * @param error объект - ошибка
     */
    public void addError(Map m, Object error) {
        addError(m, null, error);
    }

}
