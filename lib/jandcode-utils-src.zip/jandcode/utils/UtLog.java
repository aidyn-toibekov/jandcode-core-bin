package jandcode.utils;

import jandcode.utils.error.*;
import jandcode.utils.io.*;
import org.apache.commons.vfs2.*;
import org.apache.log4j.*;

import java.util.*;

/**
 * Утилиты логирования через log4j
 */
public class UtLog {

    /**
     * Свойства для отключенного логгирования по умолчанию
     */
    protected static String logOffPropertiesAsString = "log4j.rootLogger=OFF, NULL\n" + //NON-NLS
            "log4j.appender.NULL=org.apache.log4j.varia.NullAppender"; //NON-NLS

    /**
     * Свойства для включенного логгирования по умолчанию
     */
    protected static String logOnPropertiesAsString = "log4j.rootLogger=INFO, CONSOLE\n" + //NON-NLS
            "log4j.appender.CONSOLE=org.apache.log4j.ConsoleAppender\n" + //NON-NLS
            "log4j.appender.CONSOLE.layout=org.apache.log4j.PatternLayout\n" + //NON-NLS
            "log4j.appender.CONSOLE.layout.ConversionPattern=%d{HH:mm:ss,SSS} %-6p %-15c{1} - %m%n\n" + //NON-NLS
            "log4j.logger.org.apache.commons.vfs=OFF"; //NON-NLS

    protected static final int _status_on = 1;
    protected static final int _status_off = 2;

    protected static Properties _logOnProperties = new Properties();
    protected static Properties _logOffProperties = new Properties();

    /**
     * Включено или выключено логирование
     */
    private static int _status;

    static {
        try {
            UtLoad.fromString(new PropertiesLoader(_logOffProperties), logOffPropertiesAsString);
            UtLoad.fromString(new PropertiesLoader(_logOnProperties), logOnPropertiesAsString);
            logOff();
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    //////

    /**
     * Отключение логгирования
     */
    public static void logOff() {
        if (_status != _status_off) {
            PropertyConfigurator.configure(_logOffProperties);
            _status = _status_off;
        }
    }

    /**
     * Включение логгирования
     */
    public static void logOn() {
        if (_status != _status_on) {
            PropertyConfigurator.configure(_logOnProperties);
            _status = _status_on;
        }
    }

    /**
     * Возвращает true, если логгирование включено
     */
    public static boolean isOn() {
        return _status == _status_on;
    }

    /**
     * Установить свойства логгирования, используемый в методе {@link UtLog#logOn()}.
     * Перед установкой старые свойства очищаются.
     */
    public static void setProperties(Properties properties) {
        _logOnProperties.clear();
        _logOnProperties.putAll(properties);
    }

    /**
     * Текущие свойства для включенного логгирования.
     */
    public static Properties getProperties() {
        return _logOnProperties;
    }

    /**
     * Установить свойства логгирования, используемый в методе {@link UtLog#logOn()}.
     * Перед установкой старые свойства очищаются.
     */
    public static void setProperties(String properties) {
        Properties p = new Properties();
        try {
            UtLoad.fromString(new PropertiesLoader(p), properties);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        setProperties(p);
    }

    /**
     * Установить свойства логгирования из файла в формате файла log4j.properties.
     * Если файл не существует, вызов игнорируется.
     *
     * @param filename имя файла в формате VFS
     */
    public static void loadProperties(String filename) {
        FileObject f = UtFile.getFileObject(filename);
        try {
            if (!f.exists()) {
                return;
            }
        } catch (FileSystemException e) {
            return;
        }
        Properties p = new Properties();
        try {
            UtLoad.fromFileObject(new PropertiesLoader(p), f);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        setProperties(p);
    }

}
