package jandcode.utils;

import java.text.*;
import java.util.*;

/**
 * Список поименнованных элементов.
 * <p/>
 * При добавлении элемента, который уже содержится в списке, старый элемент заменяется.
 */
public class ListNamed<TYPE extends INamed> implements List<TYPE> {

    protected LinkedHashMap<String, TYPE> _map = new LinkedHashMap<String, TYPE>();
    protected ArrayList<TYPE> _list = new ArrayList<TYPE>();
    private String _notFoundMessage = "Not found element [{0}]";
    protected boolean _ignoreCase = true;

    /**
     * Вызывается перед добавлением элемента в список
     */
    protected void onAdd(TYPE it) {
        String n = it.getName();
        if (n == null || n.length() == 0) {
            throw new RuntimeException("Not set name for store in ListNamed");
        }
    }

    /**
     * Вызывается после удаления элемента из списка
     */
    protected void onRemove(TYPE it) {
    }

    /**
     * Возвращает ключ, с которым будет хранится в Map
     */
    protected String makeKey(Object key) {
        String s = UtString.toString(key);
        if (_ignoreCase) {
            s = s.toLowerCase();
        }
        return s;
    }

    //////

    /**
     * Игнорировать ли регистр в именах
     */
    public boolean isIgnoreCase() {
        return _ignoreCase;
    }

    public void setIgnoreCase(boolean ignoreCase) {
        _ignoreCase = ignoreCase;
    }

    /**
     * Поиск по имени. Возвращает null, если не найдено
     */
    public TYPE find(String name) {
        String key = makeKey(name);
        return _map.get(key);
    }

    /**
     * Поиск по имени. Генерит ошибку, если не найдено
     */
    public TYPE get(String name) {
        String key = makeKey(name);
        TYPE it = _map.get(key);
        if (it == null) {
            throw new RuntimeException(MessageFormat.format(getNotFoundMessage(), name));
        }
        return it;
    }

    /**
     * Сортировка по имени
     */
    public void sort() {
        Collections.sort(_list, new NamedComparator());
    }

    /**
     * Сортировка как хочется
     */
    public void sort(Comparator cmp) {
        Collections.sort(_list, cmp);
    }

    /**
     * Обратить порядок элементов в списке
     */
    public void reverse() {
        Collections.reverse(_list);
    }

    /**
     * Сообщение об ошибке, когда не найден элемент. <code>{0}</code> заменяется на
     * имя не найденного элемента.
     */
    public void setNotFoundMessage(String notFoundMessage) {
        _notFoundMessage = notFoundMessage;
    }

    public String getNotFoundMessage() {
        return _notFoundMessage;
    }

    ////// collection interface

    public int size() {
        return _list.size();
    }

    public boolean isEmpty() {
        return _list.isEmpty();
    }

    public boolean contains(Object o) {
        if (o instanceof CharSequence) {
            String key = makeKey(o);
            return _map.containsKey(key);
        } else {
            return _list.contains(o);
        }
    }

    public Iterator<TYPE> iterator() {
        return _list.iterator();
    }

    public Object[] toArray() {
        return _list.toArray();
    }

    public <T> T[] toArray(T[] a) {
        return _list.toArray(a);
    }

    public boolean add(TYPE it) {
        onAdd(it);
        String key = makeKey(it.getName());
        if (_map.containsKey(key)) {
            TYPE itPrev = _map.remove(key);
            int idx = _list.indexOf(itPrev);
            _map.put(key, it);
            _list.set(idx, it);
            onRemove(itPrev);
        } else {
            _map.put(key, it);
            _list.add(it);
        }

        return true;
    }

    public boolean remove(Object o) {
        if (o instanceof CharSequence) {
            String key = makeKey(o);
            TYPE a = _map.remove(key);
            _list.remove(a);
            onRemove(a);
        } else if (o instanceof Number) {
            int idx = ((Number) o).intValue();
            TYPE it = _list.get(idx);
            String key = makeKey(it.getName());
            _map.remove(key);
            _list.remove(idx);
            onRemove(it);
        } else {
            String key = makeKey(((TYPE) o).getName());
            TYPE a = _map.remove(key);
            if (a != null) {
                _list.remove(a);
                onRemove(a);
            }
        }
        return true;
    }

    public boolean containsAll(Collection<?> c) {
        return _list.containsAll(c);
    }

    public boolean addAll(Collection<? extends TYPE> c) {
        if (c != null) {
            for (TYPE it : c) {
                add(it);
            }
            return c.size() > 0;
        }
        return false;
    }

    public boolean removeAll(Collection<?> c) {
        if (c != null) {
            for (Object it : c) {
                remove(it);
            }
            return c.size() > 0;
        }
        return false;
    }

    public boolean retainAll(Collection<?> c) {
        throw new UnsupportedOperationException("retainAll");
    }

    public void clear() {
        _map.clear();
        _list.clear();
    }

    ////// list interface

    public void add(int index, TYPE it) {
        onAdd(it);
        String key = makeKey(it.getName());

        if (_map.containsKey(key)) {
            TYPE itPrev = _map.remove(key);
            int idx = _list.indexOf(itPrev);
            _map.put(key, it);
            _list.remove(idx);
            _list.add(idx, it);
            onRemove(itPrev);
        } else {
            _map.put(key, it);
            _list.add(index, it);
        }

    }

    public boolean addAll(int index, Collection<? extends TYPE> c) {
        if (c != null) {
            for (TYPE it : c) {
                add(index, it);
                index++;
            }
            return c.size() > 0;
        }
        return false;
    }

    public TYPE get(int index) {
        return _list.get(index);
    }

    public TYPE set(int index, TYPE element) {
        onAdd(element);
        TYPE it = _list.get(index);
        String key = makeKey(it.getName());
        String newName = makeKey(element.getName());
        if (!key.equals(newName) && _map.containsKey(newName)) {
            throw new RuntimeException(MessageFormat.format("Duplicate name [{0}] in ListNamed", newName));
        }
        _map.remove(key);
        _map.put(newName, element);
        _list.set(index, element);
        onRemove(it);
        return it;
    }

    public TYPE remove(int index) {
        TYPE it = _list.remove(index);
        String key = makeKey(it.getName());
        _map.remove(key);
        onRemove(it);
        return it;
    }

    public int indexOf(Object o) {
        if (o instanceof CharSequence) {
            String key = makeKey(o);
            TYPE it = _map.get(key);
            if (it == null) {
                return -1;
            }
            o = it;
        }
        return _list.indexOf(o);
    }

    public int lastIndexOf(Object o) {
        return indexOf(o);
    }

    public ListIterator<TYPE> listIterator() {
        return _list.listIterator();
    }

    public ListIterator<TYPE> listIterator(int index) {
        return _list.listIterator(index);
    }

    public List<TYPE> subList(int fromIndex, int toIndex) {
        return _list.subList(fromIndex, toIndex);
    }

}
