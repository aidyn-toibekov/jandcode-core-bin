package jandcode.utils;

import java.util.*;

/**
 * Объект для универсального представления деревьев
 */
public class TreeNode<LINK, NODE extends TreeNode> {

    private static ArrayList emptyList = new ArrayList();

    private LINK _link;
    protected NODE _parent;
    private ArrayList<NODE> _childs;
    private boolean _collapsed;

    /**
     * Ссылка на объект, связанный с этим узлом
     */
    public LINK getLink() {
        return _link;
    }

    public void setLink(LINK link) {
        _link = link;
    }

    /**
     * Ссылка на родительский узел
     */
    public NODE getParent() {
        return _parent;
    }

    public void setParent(NODE parent) {
        _parent = parent;
    }

    /**
     * Список детей
     */
    public Iterable<NODE> getChilds() {
        if (_childs == null) {
            return emptyList;
        }
        return _childs;
    }

    /**
     * Список детей как список. Если детей нет - возвращается null.
     * Возвращается реальный внутренний список, все модификации в нем, отразятся и в узле.
     */
    public ArrayList<NODE> getChildsAsList() {
        if (_childs != null && _childs.size() == 0) {
            return null;
        }
        return _childs;
    }

    /**
     * Есть ли дети
     */
    public boolean hasChilds() {
        return _childs != null && _childs.size() > 0;
    }

    /**
     * Добавить дочерний узел
     */
    public NODE addChild(NODE node) {
        if (_childs == null) {
            _childs = new ArrayList<NODE>();
        }
        node._parent = this;
        _childs.add(node);
        return node;
    }

    /**
     * Добавить дочерний узел в указанное место
     */
    public NODE addChild(int toIndex, NODE node) {
        if (_childs == null) {
            _childs = new ArrayList<NODE>();
        }
        node._parent = this;
        _childs.add(toIndex, node);
        return node;
    }

    /**
     * Удалить дочерний элемент
     */
    public NODE removeChild(int index) {
        if (_childs == null) {
            return null;
        }
        return _childs.remove(index);
    }

    /**
     * Удалить дочерний элемент
     */
    public NODE removeChild(NODE node) {
        if (_childs == null) {
            return null;
        }
        if (_childs.remove(node)) {
            return node;
        } else {
            return null;
        }
    }

    /**
     * Возвращает уровень, на котором находится узел.
     * Для корневого возвращается 0
     */
    public int getLevel() {
        int res = 0;
        TreeNode cur = this;
        while (cur != null) {
            if (cur._parent != null) {
                res++;
            }
            cur = cur._parent;
        }
        return res;
    }

    /**
     * Возвращает корневой узел
     */
    public NODE getParentRoot() {
        TreeNode cur = this;
        while (cur != null) {
            if (cur._parent == null) {
                return (NODE) cur;
            }
            cur = cur._parent;
        }
        return null;
    }

    /**
     * Возвращает родительский узел, который находится на level уровне
     */
    public NODE getParent(int level) {
        int myLevel = getLevel();
        TreeNode cur = this;
        while (myLevel != level && cur != null) {
            myLevel--;
            cur = cur._parent;
        }
        return (NODE) cur;
    }

    /**
     * Количество детей
     */
    public int getCountChilds() {
        if (_childs == null) {
            return 0;
        }
        return _childs.size();
    }

    /**
     * Получить дочерний элемент по индексу
     */
    public NODE getChild(int index) {
        if (_childs == null) {
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: 0");
        }
        return (NODE) _childs.get(index);
    }


    /**
     * Сортировка всех детей всех узлов по правилам comparator
     */
    public void sortDeep(Comparator<NODE> comparator) {
        if (_childs != null) {
            Collections.sort(_childs, comparator);
            for (NODE n : _childs) {
                n.sortDeep(comparator);
            }
        }
    }

    /**
     * Сортировка всех детей указанного узлов (вложенные не сортируются)
     */
    public void sortChilds(Comparator<NODE> comparator) {
        if (_childs != null) {
            Collections.sort(_childs, comparator);
        }
    }

    //////

    /**
     * Флаг раскрытого узла. По умолчанию узел раскрыт.
     * Это поле чисто информационное
     */
    public boolean isExpanded() {
        return !_collapsed;
    }

    /**
     * Установить флаг раскрытого для данного узла
     */
    public void setExpanded(boolean expanded) {
        _collapsed = !expanded;
    }

    /**
     * Установить expanded флаг для себя и всех дочерних узлов
     */
    public void setExpandedDown(boolean flag) {
        setExpanded(flag);
        if (_childs != null) {
            for (NODE n : _childs) {
                n.setExpandedDown(flag);
            }
        }
    }

    /**
     * Установить expanded флаг для всей цепочки родителей. Для себя не устанавливается
     */
    public void setExpandedUp(boolean flag) {
        TreeNode cur = _parent;
        while (cur != null) {
            cur.setExpanded(flag);
            cur = cur._parent;
        }
    }

}
                                 