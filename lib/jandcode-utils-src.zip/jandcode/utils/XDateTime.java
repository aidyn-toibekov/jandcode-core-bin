package jandcode.utils;

import java.util.*;

/**
 * Дата и время. Без учета timezone. Неизменяемая.
 */
public class XDateTime {

    protected static final int HOUR_IN_DAY = 24;
    protected static final int MIN_IN_HOUR = 60;
    protected static final int SEC_IN_MIN = 60;
    protected static final int MSEC_IN_SEC = 1000;
    protected static final int MSEC_IN_MIN = MSEC_IN_SEC * SEC_IN_MIN;
    protected static final int MSEC_IN_HOUR = MSEC_IN_MIN * MIN_IN_HOUR;
    protected static final int MSEC_IN_DAY = MSEC_IN_HOUR * HOUR_IN_DAY;

    protected static TimeZone TZ_DEFAULT = TimeZone.getDefault();

    protected int jdn;
    protected int time;

    //////

    protected static void decodeJulianDay(DecodedDateTime ddt, int jdn) {
        int a = jdn + 32044;
        int b = (4 * a + 3) / 146097;
        int c = a - (146097 * b) / 4;
        int d = (4 * c + 3) / 1461;
        int e = c - (1461 * d) / 4;
        int m = (5 * e + 2) / 153;

        ddt.day = e - (153 * m + 2) / 5 + 1;
        ddt.month = m + 3 - 12 * (m / 10);
        ddt.year = 100 * b + d - 4800 + m / 10;
        ddt.dow = jdn % 7 + 1;
    }

    protected static int encodeJulianDay(int year, int month, int day) {
        int a = (14 - month) / 12;
        int y = year + 4800 - a;
        int m = month + 12 * a - 3;
        return day + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045;
    }

    protected static int encodeJulianDay(DecodedDateTime ddt) {
        return encodeJulianDay(ddt.year, ddt.month, ddt.day);
    }

    protected static long julianToMsec(int jdn) {
        return (((long) jdn) - 2440587 - 1) * MSEC_IN_DAY;  // -1 : компенсация за 0.5
    }

    protected static int msecToJulian(long msec) {
        return (int) ((msec / MSEC_IN_DAY) + 2440587 + 1);
    }

    protected static void decodeTime(DecodedDateTime ddt, int time) {
        ddt.msec = (time % MSEC_IN_SEC);
        time = time / MSEC_IN_SEC;
        ddt.sec = time % SEC_IN_MIN;
        time = time / SEC_IN_MIN;
        ddt.min = time % MIN_IN_HOUR;
        time = time / MIN_IN_HOUR;
        ddt.hour = time;
    }

    protected static int encodeTime(int hour, int min, int sec, int msec) {
        return msec + sec * MSEC_IN_SEC + min * MSEC_IN_MIN + hour * MSEC_IN_HOUR;
    }

    protected static TimeZone getCurrentTimeZone() {
        return TZ_DEFAULT;
    }

    ////// const

    /**
     * Текущее время
     */
    public XDateTime() {
        long msec = System.currentTimeMillis();  // utc
        msec = msec + getCurrentTimeZone().getRawOffset(); // local
        this.jdn = XDateTime.msecToJulian(msec);
        this.time = (int) (msec % MSEC_IN_DAY);
    }

    private XDateTime(int jdn, int time) {
        this.jdn = jdn;
        this.time = time;
    }

    public XDateTime(Date date) {
        long msec = date.getTime();
        msec = msec + getCurrentTimeZone().getRawOffset(); // local
        this.jdn = XDateTime.msecToJulian(msec);
        this.time = (int) (msec % MSEC_IN_DAY);
    }

    public XDateTime(int year, int month, int day) {
        this.jdn = encodeJulianDay(year, month, day);
    }

    public XDateTime(int year, int month, int day, int hour, int min, int sec) {
        this.jdn = encodeJulianDay(year, month, day);
        this.time = encodeTime(hour, min, sec, 0);
    }

    public XDateTime(int year, int month, int day, int hour, int min, int sec, int msec) {
        this.jdn = encodeJulianDay(year, month, day);
        this.time = encodeTime(hour, min, sec, msec);
    }

    public XDateTime(long msecInUtc) {
        this.jdn = XDateTime.msecToJulian(msecInUtc);
        this.time = (int) (msecInUtc % MSEC_IN_DAY);
    }

    ////// static

    public static XDateTime today() {
        XDateTime res = new XDateTime();
        res.time = 0;
        return res;
    }

    //////

    public int hashCode() {
        long value = (((long) jdn) << 32) | time;
        return (int) (value ^ (value >>> 32));
    }

    public boolean equals(Object obj) {
        if (obj instanceof XDateTime) {
            XDateTime d = (XDateTime) obj;
            return d.jdn == jdn && d.time == time;
        }
        return false;
    }

    //////

    public DecodedDateTime decode() {
        DecodedDateTime res = new DecodedDateTime();
        decodeJulianDay(res, jdn);
        if (time != 0) {
            decodeTime(res, time);
        }
        return res;
    }

    public XDateTime clearTime() {
        return new XDateTime(jdn, 0);
    }

    public XDateTime clearMSec() {
        if (time != 0) {
            time = time / MSEC_IN_SEC * MSEC_IN_SEC;
        }
        return new XDateTime(jdn, time);
    }

    public Date toJavaDate() {
        return new Date(julianToMsec(jdn) + time - getCurrentTimeZone().getRawOffset());
    }

    public Date toJavaDate(TimeZone tz) {
        return new Date(julianToMsec(jdn) + time - tz.getRawOffset());
    }

    public long getUtcTime() {
        return julianToMsec(jdn) + time;
    }

}
