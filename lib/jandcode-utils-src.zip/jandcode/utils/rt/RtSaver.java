package jandcode.utils.rt;

import jandcode.utils.rt.impl.*;

/**
 * Запись rt в xml
 */
public class RtSaver extends RtXmlSaverImpl {

    public RtSaver(Rt rt) {
        setRoot((RtImpl) rt);
    }

    public RtSaver(Rt rt, boolean expanded) {
        setRoot((RtImpl) rt);
        setExpanded(expanded);
    }

}
