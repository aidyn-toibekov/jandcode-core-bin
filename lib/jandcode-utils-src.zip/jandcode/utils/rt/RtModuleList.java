package jandcode.utils.rt;

import jandcode.utils.*;

/**
 * Список объектов RtModule
 */
public class RtModuleList extends ListNamed<RtModule> {

    /**
     * Получить список зависимых модулей начиная с fromModule
     *
     * @param fromModule с какого модуля начать
     * @return список модулей, от которых прямо или косвенно зависит fromModule
     */
    public ListNamed<RtModule> getModulesDependsFrom(String fromModule) {
        ListNamed<RtModule> res = new ListNamed<RtModule>();
        internal_getModulesDependsFrom(get(fromModule), res);
        return res;
    }

    protected void internal_getModulesDependsFrom(RtModule m, ListNamed<RtModule> res) {
        for (String depend : m.getDepend()) {
            RtModule m1 = get(depend);
            internal_getModulesDependsFrom(m1, res);
        }
        if (res.find(m.getName()) == null) {
            res.add(m);
        }
    }

}
