package jandcode.utils.rt;

import jandcode.utils.*;
import jandcode.utils.io.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Rt.
 */
public interface Rt extends INamed, IValueNamedSet, IVariantNamed, IVariantNamedDefault {

    /**
     * Имя атрибута в котором хранится текст узла, загруженного из xml
     */
    public static final String TEXT = "text"; //NON-NLS

    /**
     * Имя атрибута в котором хранится коментарий узла, загруженного из xml
     */
    public static final String COMMENT = "comment"; //NON-NLS

    /**
     * Имя атрибута в котором хранится путь до предка узла
     */
    public static final String PARENT = "parent"; //NON-NLS

    /**
     * Имя узла, которое заменяется на порядковый номер во владельце
     */
    public static final String NONAME = "i"; //NON-NLS

    /**
     * Префикс имени узла, которое является уникальным-безымянным
     */
    public static final String NONAME_PREFIX = "#";

    /**
     * Разделитель элементов пути (char)
     */
    public static final char PATH_DELIM = '/';

    /**
     * Разделитель элементов пути (string)
     */
    public static final String PATH_DELIM_S = "/";

    /**
     * Разделитель между путем и атрибутом в пути (char)
     */
    public static final char ATTR_DELIM = ':';

    /**
     * Разделитель между путем и атрибутом в пути (string)
     */
    public static final String ATTR_DELIM_S = ":";

    /**
     * Проверка на совпадение имени.
     */
    boolean hasName(String name);

    ////// attrs

    /**
     * Имеется ли собственный атрибут, установленный непосредственно в объекте
     *
     * @param name
     * @return
     */
    boolean hasSelfAttr(String name);

    /**
     * Получить все значения всех атрибутов
     *
     * @return
     */
    Collection<IRtAttr> getAttrs();

    /**
     * Получить все значения только собственных атрибутов
     *
     * @return
     */
    Collection<IRtAttr> getSelfAttrs();

    ////// childs

    /**
     * Имеются ли собственные дети
     */
    boolean hasSelfChilds();

    /**
     * Имеется ли собственный ребенок с указанным именем
     */
    boolean hasSelfChild(String name);

    /**
     * Искать дочерний по пути
     *
     * @param path       путь
     * @param autoCreate true - если не найден - создать узел с указанным ключем.
     * @return null, если не найден
     */
    Rt findChild(String path, boolean autoCreate);

    /**
     * Искать дочерний по пути
     *
     * @param path путь
     * @return null, если не найден
     */
    Rt findChild(String path);

    /**
     * Получить дочерний по пути
     *
     * @param path путь
     * @return ошибка, если не найден
     */
    Rt getChild(String path);

    /**
     * Список дочерних
     */
    Collection<Rt> getChilds();

    /**
     * Список собственных дочерних
     */
    Collection<Rt> getSelfChilds();

    /**
     * Удалить собственного ребенка (первый элемент пути)
     */
    void removeChild(String path);

    //////

    /**
     * Корневой элемент
     */
    Rt getRoot();

    /**
     * Ключ узла начиная с корня. Например 'table/Abonent/field/name/input'.
     */
    String getPath();

    /**
     * Ключ узла начиная с узла fromOwner. Например 'field/name/input' начиная с
     * 'table/Abonent'.
     */
    String getPath(Rt fromOwner);

    /**
     * Кому принадлежит
     */
    Rt getOwner();

    //////

    /**
     * Создание легкого клона узла, с которым можно делать все что угодно.
     */
    Rt cloneRt();

    /**
     * Создать новый пустой объект. Он виртуально является корнем (не имеет владельца
     * и ключа).
     * Привязан к root.
     *
     * @param name имя
     * @return новый экземпляр
     */
    Rt createRt(String name);

    /**
     * Создать новый пустой объект, унаследованный от parent.
     * Он виртуально является корнем (не имеет владельца и ключа).
     * Привязан к root.
     *
     * @param name   имя
     * @param parent предок, должен существовать
     * @return новый экземпляр
     */
    Rt createRt(String name, String parent);

    //////

    /**
     * Создание загрузчика
     */
    LoadFrom load();

    /**
     * Создание записывальщика нераскрытой rt
     */
    SaveTo save();

    /**
     * Создание записывальщика rt
     */
    SaveTo save(boolean expanded);

}
