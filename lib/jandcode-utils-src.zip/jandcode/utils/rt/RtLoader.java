package jandcode.utils.rt;

import jandcode.utils.rt.impl.*;

/**
 * Загрузчик rt из xml
 */
public class RtLoader extends RtXmlLoaderImpl {

    public RtLoader(Rt rt) {
        setRoot((RtImpl) rt);
    }

}
