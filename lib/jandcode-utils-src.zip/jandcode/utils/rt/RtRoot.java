package jandcode.utils.rt;

import jandcode.utils.rt.impl.*;

/**
 * Корневой rt
 */
public class RtRoot extends RtRootImpl {
}
