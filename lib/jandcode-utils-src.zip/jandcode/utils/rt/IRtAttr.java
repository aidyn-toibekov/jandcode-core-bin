package jandcode.utils.rt;

import jandcode.utils.*;
import jandcode.utils.variant.*;

/**
 * Атрибут Rt
 */
public interface IRtAttr extends INamed, IValue {
}
