package jandcode.utils.rt;

/**
 * Плагин загрузки rt
 */
public interface IRtPlugin {

    /**
     * Вызывается при создании экземпляра плагина через x-plugin
     *
     * @param loader     текущий загрузчик
     * @param sys        узел x-plugin
     * @param pluginPath путь, в котором лежит файл с объявлением плагина
     * @throws Exception
     */
    void handleCreatePlugin(IRtLoader loader, Rt sys, String pluginPath) throws Exception;

    /**
     * Обработать подстановку #{var}. Если не обрабатывается, возвращается null.
     *
     * @param loader текущий загрузчик
     * @param var    имя переменной
     * @return значение переменной или null, если не обработана
     */
    String handleMacroVar(IRtLoader loader, String var) throws Exception;

    /**
     * Обработать системный атрибут.
     *
     * @param loader текущий загрузчик
     * @param x      для какого объекта
     * @param name   имя атрибута (включая префикс 'x-')
     * @param value  значение атрибута
     * @return true, если обработан
     */
    boolean handleSysAttr(IRtLoader loader, Rt x, String name, String value) throws Exception;

    /**
     * Обработка системных детей 'x-XXX'
     *
     * @param loader текущий загрузчик
     * @param x      внутри какого узла встретилось
     * @param sys    системный узел
     * @return true, если обработан
     */
    boolean handleSysChild(IRtLoader loader, Rt x, Rt sys) throws Exception;


    /**
     * Выполняется после полной загрузки
     *
     * @param loader текущий загрузчик
     * @param root   корневой узел
     */
    void handleAfterLoad(IRtLoader loader, Rt root) throws Exception;

    /**
     * Обработка x-include для плагина
     *
     * @param loader текущий загрузчик
     * @param x      внутри какого узла встретилось
     * @param sys    системный узел x-include
     */
    void handleInclude(IRtLoader loader, Rt x, Rt sys) throws Exception;

}
