package jandcode.utils.rt;

import jandcode.utils.*;

import java.util.*;

/**
 * Представление узла <module/>
 */
public class RtModule extends Named {

    protected List<String> depend = new ArrayList<String>();
    protected String path;

    public List<String> getDepend() {
        return depend;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
