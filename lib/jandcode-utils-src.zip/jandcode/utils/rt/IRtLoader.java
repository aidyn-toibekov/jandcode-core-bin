package jandcode.utils.rt;

import java.util.*;

/**
 * Интерфейс загрузчика для обработчиков
 */
public interface IRtLoader {

    /**
     * Включает в dest rt-путь rtpath, доступный к моменту выполнения
     *
     * @param dest   куда
     * @param rtpath что
     */
    void includeRtPath(Rt dest, String rtpath) throws Exception;

    /**
     * Стандартный include.
     *
     * @param dest      куда
     * @param path      путь файла (может быть с '*')
     * @param recursive рекурсивно, если '*' в пути
     * @param required  путь должен существовать
     */
    void includePath(Rt dest, String path, boolean recursive, boolean required) throws Exception;

    /**
     * Список зарегистрированных к моменту вызова плагинов {@link IRtPlugin},
     * которые реализуют интерфейс clazz.
     *
     * @param clazz проверяемый интерфейс
     * @return список плагинов, всегда не null
     */
    <A> List<A> plugins(Class<A> clazz);

    /**
     * Установить для указанного узла x-root=value
     */
    void setXRoot(Rt x, boolean value);

    /**
     * Возвращает абсолютный путь
     *
     * @param path для какого относительного. Если он абсолютный, не меняется
     */
    String getAbsPath(String path);

}
