package jandcode.utils.rt.impl;

import jandcode.utils.rt.*;

/**
 * Атрибут rt
 */
public class RtAttrImpl implements IRtAttr {
    String name;
    Object value;

    public RtAttrImpl(String name, Object value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public Object getValue() {
        return value;
    }

    public String toString() {
        return value == null ? "" : value.toString();
    }

}
