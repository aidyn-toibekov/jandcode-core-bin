package jandcode.utils.rt.impl;

import jandcode.utils.*;
import jandcode.utils.rt.*;

/**
 * Для представления раскрытого значения parent
 */
public class RtParentValue {

    private String value;

    public RtParentValue(String value) {
        if (!UtString.empty(value) && !value.startsWith(Rt.PATH_DELIM_S)) {
            value = Rt.PATH_DELIM_S + value;
        }
        this.value = value;
    }

    public String toString() {
        return value;
    }
}
