package jandcode.utils.rt.impl;


import jandcode.utils.*;
import jandcode.utils.io.*;
import jandcode.utils.rt.*;
import org.joda.time.*;

import java.text.*;
import java.util.*;

public class RtImpl extends Named implements Rt {

    protected static List<RtImpl> EMPTY_CHILDS = Collections.unmodifiableList(new ArrayList<RtImpl>());
    protected static List<RtAttrImpl> EMPTY_ATTRS = Collections.unmodifiableList(new ArrayList<RtAttrImpl>());

    protected HashMapNoCase<RtAttrImpl> _attrs;
    protected LinkedHashMapNoCase<RtImpl> _childs;
    protected List<RtImpl> _parents;
    protected RtImpl _owner;
    protected RtRootImpl _root;
    protected RtImpl _rootVirtual;

    //////

    public List<RtImpl> getParents() {
        if (_parents != null) {
            return _parents;
        }
        //
        List<RtImpl> parents = new ArrayList<RtImpl>();
        String hiddenParent = null;
        if (_owner != null) {
            List<RtImpl> ownParents = _owner.getParents();
            if (!ownParents.isEmpty()) {
                for (RtImpl ownParent : ownParents) {
                    RtImpl p = ownParent.internalFindChild(name, false);
                    if (p != null) {
                        parents.add(p);
                        if (hiddenParent == null) {
                            hiddenParent = p.getParentAttr();
                        }
                    }
                }
            }
        }
        String parentAttr = getParentAttr();
        if (parentAttr == null) {
            parentAttr = hiddenParent;
        }
        if (parentAttr != null) {
            RtImpl selfParent = null;
            if (_rootVirtual != null && _rootVirtual != this) {
                selfParent = _rootVirtual.internalFindChild(parentAttr, false);
            }
            if (selfParent == null) {
                selfParent = _root.internalFindChild(parentAttr, false);
            }
            if (selfParent == null) {
                throw new RuntimeException(MessageFormat.format(UtLang.t("Не найден предок [{0}] для [{1}]"), parentAttr, getPath()));
            }
            parents.add(selfParent);
            List<RtImpl> directParents = selfParent.getParents();
            if (!directParents.isEmpty()) {
                parents.addAll(directParents);
            }
        }

        if (parents.size() == 0) {
            _parents = EMPTY_CHILDS;
        } else {
            _parents = parents;
        }

        //
        return _parents;
    }

    protected String getParentAttr() {
        String res = null;
        if (_attrs != null && _attrs.containsKey(PARENT)) {
            res = _attrs.get(PARENT).toString();
        }
        return res;
    }

    //////


    public boolean hasName(String name) {
        return this.name != null && this.name.equalsIgnoreCase(name);
    }

    public boolean hasSelfAttr(String name) {
        return _attrs != null && _attrs.containsKey(name);
    }

    public void setValue(String name, Object value) {
        int a = name.indexOf(ATTR_DELIM);
        if (a != -1) {
            // вариант - путь:атрибут
            String path = name.substring(0, a);
            name = name.substring(a + 1);
            Rt x = findChild(path, true);
            x.setValue(name, value);
        } else {
            // вариант - атрибут
            if (_attrs == null) {
                _attrs = new HashMapNoCase<RtAttrImpl>();
            }
            if (value == null) {
                _attrs.remove(name);
            } else {
                if (PARENT.equalsIgnoreCase(name)) {
                    if (!(value instanceof RtParentValue)) {
                        value = _root.getParentExpander().expand(getPath(), UtString.toString(value));
                    }
                    _parents = null;
                }
                _attrs.put(name, new RtAttrImpl(name, value));
            }
        }
    }

    public Object getValue(String name) {
        int a = name.indexOf(ATTR_DELIM);
        if (a != -1) {
            // вариант - путь:атрибут
            String path = name.substring(0, a);
            name = name.substring(a + 1);
            Rt x = findChild(path, false);
            if (x == null) {
                return null;
            } else {
                return x.getValue(name);
            }
        } else {
            if (_attrs != null) {
                if (_attrs.containsKey(name)) {
                    return _attrs.get(name).getValue();
                }
            }
            List<RtImpl> parents = getParents();
            if (!parents.isEmpty()) {
                for (RtImpl it : parents) {
                    if (it._attrs != null) {
                        if (it._attrs.containsKey(name)) {
                            return it._attrs.get(name).getValue();
                        }
                    }
                }
            }
            return null;
        }
    }


    public Collection<IRtAttr> getSelfAttrs() {
        if (_attrs == null) {
            return (Collection) EMPTY_ATTRS;
        }
        return (Collection) _attrs.values();
    }

    public Collection<IRtAttr> getAttrs() {
        HashMapNoCase<IRtAttr> res = new HashMapNoCase<IRtAttr>();
        if (_attrs != null) {
            res.putAll(_attrs);
        }
        List<RtImpl> parents = getParents();
        if (!parents.isEmpty()) {
            for (RtImpl it : parents) {
                if (it._attrs != null) {
                    for (RtAttrImpl attr : it._attrs.values()) {
                        String k = attr.getName();
                        if (!res.containsKey(k)) {
                            res.put(k, attr);
                        }
                    }
                }
            }
        }
        return res.values();
    }

    //////

    protected RtImpl addNewChild(String name, RtImpl basedOn) {
        if (_childs == null) {
            _childs = new LinkedHashMapNoCase<RtImpl>();
        }
        RtImpl x = new RtImpl();
        if (NONAME.equalsIgnoreCase(name)) {
            name = Rt.NONAME_PREFIX + Integer.toString(_childs.size());
        }
        x.name = name.intern();
        x._owner = this;
        x._root = _root;
        x._rootVirtual = _rootVirtual;
        if (basedOn != null) {
            x._parents = new ArrayList<RtImpl>();
            x._parents.add(basedOn);
            x._parents.addAll(basedOn.getParents());
        }
        _childs.put(name, x);
        return x;
    }

    public boolean hasSelfChilds() {
        return _childs != null && _childs.size() > 0;
    }

    public boolean hasSelfChild(String name) {
        return _childs != null && _childs.containsKey(name);
    }

    protected RtImpl internalFindSelfChild(String name) {
        if (_childs == null) {
            return null;
        }
        return _childs.get(name);
    }

    /**
     * Поиск и создание собственных узлов
     */
    protected RtImpl internalFindChild(String path, boolean autoCreate) {
        // для пустого пути возвращаем себя
        if (path == null || path.length() == 0) {
            return this;
        }
        // проверяем наличие разделителя
        int a = path.indexOf(PATH_DELIM);
        RtImpl cur;
        if (!autoCreate) {
            // если не требуется автосоздание
            if (a == -1) {
                // если в пути нет '/', значит только для себя
                RtImpl w = null;
                if (_childs != null) {
                    w = _childs.get(path);
                }
                if (w != null) {
                    // нашли у себя
                    return w;
                }

                // у себя не нашли, ищем в предках
                List<RtImpl> parents = getParents();
                if (!parents.isEmpty()) {
                    for (RtImpl parent : parents) {
                        if (parent._childs != null) {
                            w = parent._childs.get(path);
                            if (w != null) {
                                // есть такой в parent, воссоздаем у себя
                                w = addNewChild(path, w);
                                // возвращаем созданный у себя
                                return w;
                            }
                        }
                    }
                }

                // нит ничего
                return null;
            } else {
                // есть в пути '/' пойдем по пути
                String ar[] = path.split(PATH_DELIM_S);
                cur = this;
                for (String s : ar) {
                    cur = cur.internalFindChild(s, false);
                    if (cur == null) {
                        return null;
                    }
                }
                return cur;
            }
        } else {
            // требуется автосоздание - создаем не задумываясь
            if (a == -1) {
                // точки нет, создаем себе
                if (_childs == null) {
                    _childs = new LinkedHashMapNoCase<RtImpl>();
                }
                cur = _childs.get(path);
                if (cur == null) {
                    cur = addNewChild(path, null);
                }
                return cur;
            } else {
                // есть в пути '/' пойдем по пути
                String ar[] = path.split(PATH_DELIM_S);
                cur = this;
                for (String s : ar) {
                    if (cur._childs == null) {
                        cur._childs = new LinkedHashMapNoCase<RtImpl>();
                    }
                    RtImpl cur2 = cur._childs.get(s);
                    if (cur2 == null) {
                        cur2 = cur.addNewChild(s, null);
                    }
                    cur = cur2;
                }
                return cur;
            }
        }
    }

    public Rt findChild(String path, boolean autoCreate) {
        return internalFindChild(path, autoCreate);
    }

    public Rt findChild(String path) {
        return internalFindChild(path, false);
    }

    public Rt getChild(String path) {
        Rt res = findChild(path, false);
        if (res == null) {
            throw new RuntimeException(MessageFormat.format(UtLang.t("Не найден дочерний [{0}] для [{1}]"), path, getPath()));
        }
        return res;
    }

    public Collection<Rt> getSelfChilds() {
        if (_childs == null) {
            return (Collection) EMPTY_CHILDS;
        }
        return (Collection) _childs.values();
    }

    public Collection<Rt> getChilds() {
        ArrayList<Rt> res = new ArrayList<Rt>();
        LinkedHashMap<String, String> names = new LinkedHashMap<String, String>();
        // собираем имена дочерних в правильном порядке из parents
        List<RtImpl> parents = getParents();
        if (!parents.isEmpty()) {
            for (int i = parents.size() - 1; i >= 0; i--) {  // в обратном порядке
                RtImpl parent = parents.get(i);
                if (parent._childs != null) {
                    for (RtImpl x : parent._childs.values()) {
                        String nm = x.name.toLowerCase();
                        if (!names.containsKey(nm)) {
                            names.put(nm, x.name);
                        }
                    }
                }
            }
        }
        // собираем имена дочерних в правильном порядке из себя
        if (_childs != null) {
            for (RtImpl x : _childs.values()) {
                String nm = x.name.toLowerCase();
                if (!names.containsKey(nm)) {
                    names.put(nm, x.name);
                }
            }
        }

        // ищем (возможно досоздаем)
        for (String name : names.values()) {
            res.add(internalFindChild(name, false));
        }
        //
        return res;
    }

    public void removeChild(String path) {
        if (UtString.empty(path)) {
            return;
        }
        if (_childs == null) {
            return;
        }
        int a = path.indexOf(PATH_DELIM);
        if (a != -1) {
            path = path.substring(0, a);
        }
        if (_childs.containsKey(path)) {
            _childs.remove(path);
        }
    }

    public Rt getRoot() {
        return _root;
    }

    public String getPath() {
        return getPath(null);
    }

    public String getPath(Rt fromOwner) {
        StringBuilder sb = new StringBuilder();
        internal_getPath(sb, this, fromOwner);
        return sb.toString();
    }

    private void internal_getPath(StringBuilder sb, RtImpl x, Rt fromOwner) {
        if (x._owner != null && x != fromOwner) {
            internal_getPath(sb, x._owner, fromOwner);
        } else {
            return;
        }
        if (sb.length() > 0) {
            sb.append(PATH_DELIM);
        }
        sb.append(x.name);
    }

    public Rt getOwner() {
        return _owner;
    }

    //////

    public String toString() {
        return "{" + getPath() + "}";
    }

    public Rt cloneRt() {
        getParents();
        RtImpl x = new RtImpl();
        x.name = name;
        x._owner = _owner;
        x._root = _root;
        x._rootVirtual = _rootVirtual;
        //
        x._parents = new ArrayList<RtImpl>();
        x._parents.add(this);
        if (_parents != null) {
            x._parents.addAll(_parents);
        }
        //
        return x;
    }

    public Rt createRt(String name) {
        RtImpl x = new RtImpl();
        x.setName(name);
        x._root = _root;
        x._rootVirtual = this;
        //
        x._parents = EMPTY_CHILDS;
        //
        return x;
    }

    public Rt createRt(String name, String parent) {
        RtImpl p = (RtImpl) _root.getChild(parent);
        RtImpl x = new RtImpl();
        x.setName(name);
        x._root = _root;
        x._rootVirtual = this;
        //
        x._parents = new ArrayList<RtImpl>();
        x._parents.add(p);
        //
        return x;
    }

    /**
     * Для очень специфических целей, что бы не сломать все остальное
     */
    public void setRootVirtual(Rt rootVirtual) {
        this._rootVirtual = (RtImpl) rootVirtual;
    }

    ////// IVariantNamed


    public int getDataType(String name) {
        return DataType.getDataType(getValue(name));
    }

    public int getValueInt(String name) {
        return UtCnv.toInt(getValue(name));
    }

    public long getValueLong(String name) {
        return UtCnv.toLong(getValue(name));
    }

    public double getValueDouble(String name) {
        return UtCnv.toDouble(getValue(name));
    }

    public DateTime getValueDateTime(String name) {
        return UtCnv.toDateTime(getValue(name));
    }

    public String getValueString(String name) {
        return UtCnv.toString(getValue(name));
    }

    public boolean getValueBoolean(String name) {
        return UtCnv.toBoolean(getValue(name));
    }

    public boolean isValueNull(String name) {
        return getValue(name) == null;
    }

    ////// IVariantNamedDefault

    public int getValueInt(String name, int defValue) {
        return UtCnv.toInt(getValue(name), defValue);
    }

    public long getValueLong(String name, long defValue) {
        return UtCnv.toLong(getValue(name), defValue);
    }

    public double getValueDouble(String name, double defValue) {
        return UtCnv.toDouble(getValue(name), defValue);
    }

    public DateTime getValueDateTime(String name, DateTime defValue) {
        return UtCnv.toDateTime(getValue(name), defValue);
    }

    public String getValueString(String name, String defValue) {
        return UtCnv.toString(getValue(name), defValue);
    }

    public boolean getValueBoolean(String name, boolean defValue) {
        return UtCnv.toBoolean(getValue(name), defValue);
    }

    //////


    public LoadFrom load() {
        return new LoadFrom(new RtLoader(this));
    }

    public SaveTo save() {
        return new SaveTo(new RtSaver(this));
    }

    public SaveTo save(boolean expanded) {
        return new SaveTo(new RtSaver(this, expanded));
    }

    //////

    public void resetParents() {
        _parents = null;
        if (_childs != null) {
            for (RtImpl rt : _childs.values()) {
                rt.resetParents();
            }
        }
    }

}
