package jandcode.utils.rt.impl;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.impl.*;
import jandcode.utils.io.*;
import jandcode.utils.rt.*;
import org.apache.commons.logging.*;
import org.apache.commons.vfs2.*;
import org.xml.sax.*;
import org.xml.sax.ext.*;

import javax.xml.parsers.*;
import java.io.*;
import java.text.*;
import java.util.*;

/**
 * Реализация загрузки rt из XML
 */
public class RtXmlLoaderImpl extends DefaultHandler2 implements ILoader, IRtLoader {

    protected static Log log = LogFactory.getLog(RtXmlLoaderImpl.class);

    public static final String SYS_PREFIX = "x-"; //NON-NLS

    protected RtImpl _root;
    private StringBuilder _buffer;
    protected StackList<RtImpl> _stack;
    private SubstVarParser _expander = new Expander();
    private Reader _reader;
    private boolean isRootLoader = true;
    private HashSet<String> includedFiles;
    private ListNamed<Plugin> plugins;

    class Expander extends SubstVarParser {
        Expander() {
            startVar1 = '#';
        }

        public String onSubstVar(String v) {
            try {
                return handleMacroVar(v);
            } catch (Exception e) {
                throw new XErrorWrap(e);
            }
        }
    }

    class Plugin extends Named {
        // зависимости (имена плагинов)
        List<String> depend = new ArrayList<String>();
        // экземпляр плагина. Создается в момент обработки x-plugin
        IRtPlugin inst;

        public void addDepend(String name) {
            depend.add(name);
        }

        public void setInst(IRtPlugin inst) {
            this.inst = inst;
        }

        public IRtPlugin getInst() {
            return inst;
        }

    }

    public RtXmlLoaderImpl() {
    }

    public RtXmlLoaderImpl(RtXmlLoaderImpl parent, RtImpl root) {
        if (root != null) {
            this._root = root;
        } else {
            this._root = parent._root;
        }
        this.isRootLoader = false;
        this.includedFiles = parent.getIncludedFiles();
        this.plugins = parent.getPlugins();
    }

    //////

    /**
     * Куда грузить. Не очищается!
     */
    public void setRoot(RtImpl root) {
        _root = root;
    }

    public ListNamed<Plugin> getPlugins() {
        if (plugins == null) {
            plugins = new ListNamed<Plugin>();
            plugins.setNotFoundMessage("Плагин [{0}] не найден");
        }
        return plugins;
    }

    //////

    public LoadFrom load() {
        return new LoadFrom(this);
    }

    public void loadFrom(Reader reader) throws Exception {
        _reader = reader;
        _buffer = new StringBuilder();
        _stack = new StackList<RtImpl>();
        //

        String fn = UtLoad.getFilename(reader);
        if (!UtString.empty(fn)) {
            if (log.isInfoEnabled()) {
                log.info(String.format("load: %s", fn)); //NON-NLS
            }
        }
        ((RtRootImpl) _root.getRoot()).getSourceHolder().startSource(fn);
        try {
            XMLReader xreader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
            xreader.setContentHandler(this);
            xreader.setProperty("http://xml.org/sax/properties/lexical-handler", this); //NON-NLS
            try {
                xreader.parse(UtLoad.getInputSource(reader));
            } catch (Exception e) {
                String s = null;
                RtImpl n = _stack.last();
                if (n != null) {
                    s = n.getPath();
                }
                if (s == null) {
                    throw new XErrorMark(e, "path = " + s);
                } else {
                    throw new RuntimeException(e);
                }
            }
        } finally {
            ((RtRootImpl) _root.getRoot()).getSourceHolder().stopSource();
        }
        //
        if (isRootLoader) {
            for (Plugin p : getPlugins()) {
                p.getInst().handleAfterLoad(this, _root);
            }
        }
    }

    //////

    public void characters(char ch[], int start, int length) throws SAXException {
        _buffer.append(ch, start, length);
    }

    public void startElement(String uri, String localName, String qName,
            Attributes attributes) throws SAXException {
        RtImpl cur;
        boolean sysNode = false;
        if (_stack.size() == 0) {
            cur = _root;
        } else {
            assignValue();
            if (qName.startsWith(SYS_PREFIX)) {
                // для 'x-XXX' детей не добавляем дочерний
                cur = (RtImpl) _root.createRt(qName);
                cur.setName(qName);
                sysNode = true;
            } else {
                cur = _stack.last().internalFindChild(qName, true);
                ((RtRootImpl) _root.getRoot()).getSourceHolder().markNode(cur);
            }
        }
        _stack.add(cur);

        int cnt = attributes.getLength();
        if (cnt > 0) {
            HashMap<String, String> attrs = new HashMap<String, String>();
            for (int i = 0; i < cnt; i++) {
                String an = attributes.getQName(i);
                String av = onPrepareTextValue(attributes.getValue(i));
                if ("name".equals(an) && !sysNode) { //NON-NLS
                    // создаем дочерний и делаем его активным
                    _stack.pop();
                    cur = cur.internalFindChild(av, true);
                    _stack.add(cur);
                } else if (an.startsWith(SYS_PREFIX) && !sysNode) {
                    handleSysAttr(cur, an, av);
                } else {
                    attrs.put(an, av);
                }
            }
            for (Map.Entry<String, String> at : attrs.entrySet()) {
                cur.setValue(at.getKey(), at.getValue());
            }
        }
    }

    public void endElement(String uri, String localName, String qName)
            throws SAXException {
        assignValue();
        RtImpl last = _stack.pop();
        if (qName.startsWith(SYS_PREFIX)) {
            // обработка системного ребенка
            handleSysChild(_stack.last(), last);
        }
    }

    protected void assignValue() {
        if (_buffer.length() == 0) {
            return;
        }
        String s;
        s = _buffer.toString().replaceAll("\r", "");
        s = UtString.normalizeIndent(s);
        if (s.length() > 0) {
            onAssignValue(s);
        }
        _buffer.setLength(0);
    }

    public void comment(char ch[], int start, int length) throws SAXException {
        StringBuilder sb = new StringBuilder();
        sb.append(ch, start, length);
        String s = sb.toString().trim();
        if (_stack.size() > 1 && sb.length() > 0 && sb.charAt(0) == '@') {
            s = s.substring(1);
            s = UtString.normalizeIndent(s);
            s = onPrepareTextValue(s);
            if (s.length() > 0) {
                _stack.last().setValue(Rt.COMMENT, s);
            }
        }
    }

    //////

    /**
     * Срабатывает при присвоении значения
     */
    protected void onAssignValue(String s) {
        s = onPrepareTextValue(s);
        _stack.last().setValue(Rt.TEXT, s);
    }

    /**
     * Срабатывает перед присвоением текста в качестве значения. Что возвратится, то и присвоится.
     */
    protected String onPrepareTextValue(String value) {
        if (value == null) {
            return "";
        }
        if (value.indexOf('#') != -1) {  // ускоряем процесс
            _expander.loadFrom(value);
            return _expander.getResult();
        } else {
            return value;
        }
    }


    //////

    public String handleMacroVar(String v) throws Exception {
        if (v.equals("path")) {
            return getVarPath();
        } else if (v.startsWith("pathup:")) { //NON-NLS
            return getVarPathUp(UtString.removePrefix(v, "pathup:")); //NON-NLS
        } else if (v.startsWith("pathprop:")) { //NON-NLS
            return getVarPathProp(UtString.removePrefix(v, "pathprop:")); //NON-NLS
        } else if (v.startsWith("rt:")) { //NON-NLS
            return getVarRt(UtString.removePrefix(v, "rt:")); //NON-NLS
        } else {
            String s;
            //
            for (Plugin p : getPlugins()) {
                s = p.getInst().handleMacroVar(this, v);
                if (s != null) {
                    return s;
                }
            }
            //
            s = System.getProperty(v);
            if (s == null) {
                return "";
            }
            return s;
        }
    }

    /**
     * Обработка системных атрибутов 'x-XXX'
     *
     * @param cur   для какого узла
     * @param name  имя атрибута (вместе с 'x-')
     * @param value
     */
    protected void handleSysAttr(RtImpl cur, String name, String value) {
        if ("x-root".equals(name)) { //NON-NLS
            boolean v = UtCnv.toBoolean(value);
            setXRoot(cur, v);
        } else {
            //
            for (Plugin p : getPlugins()) {
                try {
                    if (p.getInst().handleSysAttr(this, cur, name, value)) {
                        return;
                    }
                } catch (Exception e) {
                    throw new XErrorWrap(e);
                }
            }
            //
            throw new RuntimeException(MessageFormat.format("Unknown system attr \\\"{0}\\\"", name));
        }
    }

    /**
     * Обработка системных детей 'x-XXX'
     *
     * @param cur внутри какого узла встретилось
     * @param sys системный узел
     */
    protected void handleSysChild(RtImpl cur, RtImpl sys) {
        String nm = sys.getName();
        try {
            if ("x-include".equals(nm)) { //NON-NLS
                handleInclude(cur, sys);
            } else if ("x-parentexpander".equals(nm)) { //NON-NLS
                handleParentExpander(cur, sys);
            } else if ("x-attr".equals(nm)) { //NON-NLS
                handleAttr(cur, sys);
            } else if ("x-module".equals(nm)) { //NON-NLS
                handleModule(sys);
            } else if ("x-plugin".equals(nm)) { //NON-NLS
                handlePlugin(sys);
            } else {
                //
                for (Plugin p : getPlugins()) {
                    if (p.getInst().handleSysChild(this, cur, sys)) {
                        return;
                    }
                }
                //
                throw new RuntimeException(MessageFormat.format("Unknown system child \\\"{0}\\\"", nm));
            }
        } catch (Exception e) {
            String scur = cur.getPath();
            if (scur.length() > 0) {
                scur = scur + Rt.PATH_DELIM;
            }
            scur = scur + sys.getName();
            throw new XErrorMark(e, "x-rtpath = " + scur);
        }
    }


    //////

    /**
     * Имя загружаемого в loader файла
     */
    protected String getReaderFileName(Reader rdr) {
        String fn = UtLoad.getFilename(rdr);
        if (UtString.empty(fn)) {
            fn = UtFile.getWorkdir().getAbsolutePath() + "/DUMMY.rt"; //NON-NLS
        }
        return fn;
    }

    /**
     * Значение 'path'
     */
    protected String getVarPath() {
        String fn = getReaderFileName(_reader);
        return UtFile.path(UtFile.vfsPathToLocalPath(fn));
    }

    /**
     * Значение 'pathup:FN'
     */
    protected String getVarPathUp(String fn) {
        String cp = getVarPath();
        String ff = UtFile.findFileUp(fn, cp);
        if (ff == null) {
            return cp;
        }
        return UtFile.path(ff);
    }

    /**
     * Значение 'pathprop:FN'
     */
    protected String getVarPathProp(String propName) {
        return UtFile.getPathprop(propName, getVarPath());
    }

    /**
     * Значение 'rt:FN'
     */
    protected String getVarRt(String propName) {
        return _root.getValueString(propName);
    }

    protected void handleInclude(RtImpl cur, RtImpl sys) throws Exception {
        //
        String rtpath = sys.getValueString("rtpath"); //NON-NLS
        String module = sys.getValueString("module"); //NON-NLS
        String plugin = sys.getValueString("plugin"); //NON-NLS
        if (!UtString.empty(rtpath)) {
            includeRtPath(cur, rtpath);
        } else if (!UtString.empty(module)) {
            String modulePath = "res:" + module.replace('.', '/') + "/module.rt"; //NON-NLS NON-NLS
            includePath(cur, modulePath, false, true);
        } else if (!UtString.empty(plugin)) {
            includePlugin(cur, sys, plugin);
        } else {
            String pt = sys.getValueString("path");
            if (UtString.empty(pt)) {
                throw new RuntimeException("node \"x-include\" not have value in attr \"path\" or \"rtpath\"");
            }
            boolean recursive = sys.getValueBoolean("recursive"); //NON-NLS
            boolean req = sys.getValueBoolean("required", true); //NON-NLS
            includePath(cur, pt, recursive, req);
        }
    }

    private void includePlugin(RtImpl dest, RtImpl sys, String plugin) throws Exception {
        Plugin p = getPlugins().get(plugin);
        String key = dest.getPath() + "~@~" + p.getName();
        if (getIncludedFiles().contains(key)) {
            return;  // уже грузили этот плагин в этот узел
        }
        getIncludedFiles().add(key);
        //
        if (p.depend.size() > 0) {
            for (String dep : p.depend) {
                includePlugin(dest, sys, dep);
            }
        }
        //
        p.getInst().handleInclude(this, dest, sys);

    }

    protected void handleParentExpander(RtImpl cur, RtImpl sys) {
        String path = sys.getValueString("path");
        String parentValue = sys.getValueString("parentvalue"); //NON-NLS
        String replace = sys.getValueString("replace");
        ((RtRootImpl) cur.getRoot()).getParentExpander().addRule(path, parentValue, replace);
    }

    protected void handleAttr(RtImpl cur, RtImpl sys) {
        cur.setValue(sys.getValueString("name"), sys.getValue(Rt.TEXT)); //NON-NLS
    }

    private void handleModule(RtImpl sys) throws Exception {
        String moduleName = sys.getValueString("name"); //NON-NLS
        if (UtString.empty(moduleName)) {
            throw new XError("x-module not have attribute [name]");
        }
        // зависимости
        Rt depends = sys.findChild("depend");
        if (depends != null) {
            for (Rt depend : depends.getChilds()) {
                Rt includeNode = _root.createRt("x-include"); //NON-NLS
                includeNode.setValue("module", depend.getName()); //NON-NLS
                handleInclude(_root, (RtImpl) includeNode);
            }
        }
        // маркируем модуль
        Rt moduleMark = _root.findChild("module/" + moduleName, true); //NON-NLS
        String path = getVarPath();
        log.info(MessageFormat.format("found module [{0}] path=[{1}]", moduleName, path));
        moduleMark.setValue("path", getVarPath());
        // обработчики запускаем
        for (Plugin p : getPlugins()) {
            p.getInst().handleSysChild(this, _root, sys);
        }
        // сохраняем узел модуля, возможно обработчики его поправили
        UtRt.joinSelf(moduleMark, sys);
        // удаляем атрибут name, он не нужен
        moduleMark.setValue("name", null); //NON-NLS
    }

    private void handlePlugin(RtImpl sys) throws Exception {
        String pluginName = sys.getValueString("name"); //NON-NLS
        if (UtString.empty(pluginName)) {
            pluginName = "noname-plugin-" + getPlugins().size();
        }
        String pluginClassName = sys.getValueString("class", RtPluginIncludePath.class.getName()); //NON-NLS
        if (getPlugins().find(pluginName) != null) {
            throw new XError("Plugin {0} already defined");
        }
        Plugin plugin = new Plugin();
        plugin.setName(pluginName);
        getPlugins().add(plugin);
        plugin.setInst((IRtPlugin) UtClass.createInst(pluginClassName));
        // зависимости
        Rt depends = sys.findChild("depend");
        if (depends != null) {
            for (Rt depend : depends.getChilds()) {
                plugin.addDepend(depend.getName());
            }
        }
        //
        plugin.getInst().handleCreatePlugin(this, sys, getVarPath());
    }

    ////// IRtLoader

    public void includeRtPath(Rt dest, String rtpath) throws Exception {
        Rt mix = null;
        RtImpl cur = (RtImpl) dest;
        if (cur._rootVirtual != null) {
            mix = cur._rootVirtual.findChild(rtpath);
        }
        if (mix == null) {
            mix = cur.getRoot().getChild(rtpath);
        }
        UtRt.joinSelf(cur, mix);
    }

    public void includePath(Rt dest, String path, boolean recursive, boolean required) throws Exception {
        path = getAbsPath(path);

        if (log.isInfoEnabled()) {
            log.info(String.format("include path=%s, recursive=%s, required=%s", path, recursive, required)); //NON-NLS
        }

        if (path.indexOf('*') == -1 && path.indexOf('?') == -1) {
            // one file
            FileObject fo = UtFile.getFileObject(path);
            if (!fo.exists()) {
                if (required) {
                    throw new RuntimeException(MessageFormat.format(UtLang.t("Не найден файл \\\"{0}\\\""), path));
                } else {
                    return;
                }
            }
            try {
                includeOneFile(dest, fo);
            } catch (Exception e) {
                throw new XErrorMark(e, fo.toString());
            }
        } else {
            //
            DirScannerVfs sc = new DirScannerVfs();
            sc.setRecursive(recursive);
            sc.setRootPath(path);
            sc.scan();
            //
            ArrayList<FileObject> lst = sc.getFiles();
            if (required && lst.size() == 0) {
                throw new RuntimeException(MessageFormat.format(UtLang.t("Не найдены файлы по маске \\\"{0}\\\""), path));
            }
            for (FileObject f : sc.getFiles()) {
                try {
                    includeOneFile(dest, f);
                } catch (Exception e) {
                    throw new XErrorMark(e, f.toString());
                }
            }
        }
    }

    public <A> List<A> plugins(Class<A> clazz) {
        List<A> res = new ArrayList<A>();
        if (plugins != null) {
            for (Plugin p : plugins) {
                if (clazz.isAssignableFrom(p.getInst().getClass())) {
                    res.add((A) p.getInst());
                }
            }
        }
        return res;
    }

    //////

    public HashSet<String> getIncludedFiles() {
        if (includedFiles == null) {
            includedFiles = new HashSet<String>();
        }
        return includedFiles;
    }

    /**
     * Включение одного файла. Если файл уже загружался, то вызов игнорируется
     *
     * @param dest куда
     * @param f    откуда
     */
    protected void includeOneFile(Rt dest, FileObject f) throws Exception {
        String key = dest.getPath() + "@" + f.toString();
        if (getIncludedFiles().contains(key)) {
            return;  // уже грузили этот файл в этот узел
        }
        getIncludedFiles().add(key);
        RtXmlLoaderImpl ldr = new RtXmlLoaderImpl(this, (RtImpl) dest);
        UtLoad.fromFileObject(ldr, f);
    }

    public void setXRoot(Rt x, boolean value) {
        RtImpl cur = (RtImpl) x;
        if (value) {
            cur._rootVirtual = cur;
        } else {
            cur._rootVirtual = null;
        }
    }

    public String getAbsPath(String path) {
        if (!UtFile.isAbsolute(path)) {
            path = UtFile.join(getVarPath(), path);
        }
        return path;
    }

}