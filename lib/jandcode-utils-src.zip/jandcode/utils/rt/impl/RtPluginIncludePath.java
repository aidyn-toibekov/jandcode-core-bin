package jandcode.utils.rt.impl;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

/**
 * Системный плугин по умолчанию. Используется для плагинов,
 * которые просто включают один файл
 */
public class RtPluginIncludePath extends RtPluginAdapter {

    private String path;

    public void handleCreatePlugin(IRtLoader loader, Rt sys, String pluginPath) throws Exception {
        path = sys.getValueString("path");
        if (UtString.empty(path)) {
            throw new XError("Не определен атрибут path");
        }
        path = loader.getAbsPath(path);
    }

    public void handleInclude(IRtLoader loader, Rt x, Rt sys) throws Exception {
        loader.includePath(x, path, false, true);
    }

}
