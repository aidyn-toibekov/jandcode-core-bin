package jandcode.utils.rt.impl;

import jandcode.utils.rt.*;

/**
 * Корневой Rt. Только такие экземпляры можно создавать через new.
 */
public class RtRootImpl extends RtImpl {

    private RtParentExpander _parentExpander;
    private RtSourceHolder _sourceHolder;

    public RtRootImpl() {
        name = "root"; //NON-NLS
        _root = this;
        _parentExpander = new RtParentExpander();
        _sourceHolder = new RtSourceHolderImpl();
    }

    /**
     * Раскрывальщик атрибутов 'parent'
     */
    public RtParentExpander getParentExpander() {
        return _parentExpander;
    }

    public Rt cloneRt() {
        throw new RuntimeException("Unsupported cloneRt for root node");
    }

    /**
     * Хранилище источников узлов.
     */
    public RtSourceHolder getSourceHolder() {
        return _sourceHolder;
    }

}
