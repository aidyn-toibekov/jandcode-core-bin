package jandcode.utils.rt.impl;

import jandcode.utils.*;
import jandcode.utils.io.*;
import jandcode.utils.rt.*;

/**
 * Запись RtImpl в xml.
 */
public class RtXmlSaverImpl extends XmlSaver {

    private RtImpl _root;
    private boolean _expanded = false;

    public void setRoot(RtImpl root) {
        _root = root;
    }

    public boolean isExpanded() {
        return _expanded;
    }

    public void setExpanded(boolean expanded) {
        _expanded = expanded;
    }

    protected void onSaveXml() throws Exception {
        saveInternal(_root);
    }

    private void saveInternal(RtImpl node) throws Exception {
        saveNode(node);
    }

    private void saveNode(RtImpl node) throws Exception {
        String nodeName = node.getName();

        if (nodeName.startsWith(Rt.NONAME_PREFIX)) {
            nodeName = Rt.NONAME;
        }

        startNode(nodeName);

        String textAttr = null;
        LinkedHashMapNoCase<IRtAttr> attrs = new LinkedHashMapNoCase<IRtAttr>();
        if (node._attrs != null) {
            for (RtAttrImpl attr : node._attrs.values()) {
                attrs.put(attr.getName(), attr);
            }
        }
        if (_expanded) {
            for (IRtAttr attr : node.getAttrs()) {
                attrs.put(attr.getName(), attr);
            }
        }
        if (attrs != null) {
            Object parentAttr = attrs.get(Rt.PARENT);
            if (parentAttr != null) {
                writeAttr(Rt.PARENT, parentAttr.toString());
            }
            for (IRtAttr attr : attrs.values()) {
                String v = UtCnv.toString(attr.getValue());
                if (Rt.TEXT.equals(attr.getName())) {
                    textAttr = v;
                } else if (Rt.COMMENT.equals(attr.getName())) {
                    // пропускаем
                } else if (Rt.PARENT.equals(attr.getName())) {
                    // пропускаем, записали первым
                } else {
                    writeAttr(attr.getName(), v);
                }
            }
        }

        if (node.hasSelfAttr(Rt.COMMENT)) {
            String s = UtCnv.toString(node.getValue(Rt.COMMENT));
            if (!UtString.empty(s)) {
                prepareWriteText();
                getIndentWriter().indentInc();
                writer.write("\n<!--@ \n");
                getIndentWriter().indentInc();
                writeQuoteNodeValue(s);
                getIndentWriter().indentDec();
                writer.write("\n-->\n");
                getIndentWriter().indentDec();
            }
        }

        if (textAttr != null) {
            prepareWriteText();
            getIndentWriter().indentInc();
            writeQuoteNodeValue(textAttr);
            writer.write("\n");
            getIndentWriter().indentDec();
        }

        if (!_expanded) {
            if (node._childs != null) {
                for (RtImpl n : node._childs.values()) {
                    saveNode(n);
                }
            }
        } else {
            for (Rt n : node.getChilds()) {
                saveNode((RtImpl) n);
            }
        }

        stopNode();

    }

}