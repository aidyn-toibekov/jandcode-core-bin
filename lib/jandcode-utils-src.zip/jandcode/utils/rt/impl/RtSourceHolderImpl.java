package jandcode.utils.rt.impl;

import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

public class RtSourceHolderImpl implements RtSourceHolder {

    private SourceItem cur;
    private StackList<SourceItem> stack = new StackList<SourceItem>();
    private HashMap<String, SourceItem> bySource = new HashMap<String, SourceItem>();
    private HashMap<Rt, NodeItem> byNode = new HashMap<Rt, NodeItem>();

    public class SourceItem {
        String src;
        HashSet<Rt> nodes = new HashSet<Rt>();
    }

    public class NodeItem {
        Rt node;
        HashSet<String> srcs = new HashSet<String>();
    }

    public HashMap<String, SourceItem> getBySource() {
        return bySource;
    }

    public HashMap<Rt, NodeItem> getByNode() {
        return byNode;
    }

    public void startSource(Object source) {
        String s = source.toString();
        SourceItem a = bySource.get(s);
        if (a == null) {
            a = new SourceItem();
            a.src = s;
            bySource.put(s, a);
        } else {
            if (stack.contains(a)) {
                throw new RuntimeException(UtLang.t("Рекурсивная загрузка из: {0}", s));
            }
        }
        cur = a;
        stack.add(a);
    }

    public void stopSource() {
        stack.pop();
        cur = stack.last();
    }

    public void markNode(Rt node) {
        if (cur == null) {
            return;
        }
        cur.nodes.add(node);
        NodeItem a = byNode.get(node);
        if (a == null) {
            a = new NodeItem();
            a.node = node;
            a.srcs.add(cur.src);
            byNode.put(node, a);
        }
        a.srcs.add(cur.src);
    }

    public void clear() {
        byNode.clear();
        bySource.clear();
        stack.clear();
        cur = null;
    }

    public List<String> getSources(Rt node) {
        List<String> res = new ArrayList<String>();
        NodeItem a = byNode.get(node);
        if (a != null) {
            res.addAll(a.srcs);
        }
        return res;
    }

}
