package jandcode.utils.rt.impl;

import jandcode.utils.rt.*;

import java.util.*;

/**
 * Хранилище источников, откуда было получены узлы rt.
 */
public interface RtSourceHolder {

    /**
     * Начать работу источника.
     *
     * @param source
     */
    void startSource(Object source);

    /**
     * Закончить работу источника
     */
    void stopSource();

    /**
     * Пометить узел текущим источником.
     *
     * @param node
     */
    void markNode(Rt node);

    /**
     * Получить список источников, из которых загрузился узел
     *
     * @param node проверяемый узел
     * @return список идентификаторов источников. Всегда не null.
     */
    List<String> getSources(Rt node);

    /**
     * Очистить хранилище
     */
    void clear();

}
