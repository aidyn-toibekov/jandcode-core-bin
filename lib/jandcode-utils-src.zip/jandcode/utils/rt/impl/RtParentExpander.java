package jandcode.utils.rt.impl;

import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.utils.vdir.*;

import java.util.*;
import java.util.regex.*;

/**
 * Раскрытие сокращенного пути в атрибуте 'parent' на
 * реальный путь.
 */
public class RtParentExpander {

    private LinkedHashMap<String, Rule> items = new LinkedHashMap<String, Rule>();

    class Rule {
        Pattern patternPath;
        LinkedHashMap<Pattern, String> replacer = new LinkedHashMap<Pattern, String>();
    }

    /**
     * Определить правило замены.
     * Например, правило для замены строк вида 'name' на 'field/name' в полях
     * домена:<pre>{@code
     * addRule(".*domain/(.*?)/field/(.*?)","^(\\w*)$","field/$1");
     * }</pre>
     *
     * @param patternRtPath      маска для пути
     * @param patternParentValue маска для значения атрибута parent
     * @param replace            на что заменять
     */
    public void addRule(String patternRtPath, String patternParentValue, String replace) {
        Rule r = items.get(patternRtPath);
        if (r == null) {
            r = new Rule();
            r.patternPath = Pattern.compile(patternRtPath, Pattern.CASE_INSENSITIVE);
            items.put(patternRtPath, r);
        }
        Pattern z = Pattern.compile(patternParentValue, Pattern.CASE_INSENSITIVE);
        r.replacer.put(z, replace);
    }

    /**
     * Обработать значение rtPath.
     * Если parentValue без точки и правила не найдены,
     * то считаем результат как rtPath(last part)+'.'+parentValue.
     *
     * @param rtPath      для кого
     * @param parentValue значение атрибута parent
     * @return замененное значение parent или оригинальное, если правила не найдены
     */
    public RtParentValue expand(String rtPath, String parentValue) {
        if (UtString.empty(parentValue)) {
            return new RtParentValue("");
        }
        if (parentValue.startsWith(Rt.PATH_DELIM_S)) {
            return new RtParentValue(VDir.normalize(parentValue)); // начинается с '/', не обрабатываем
        }
        parentValue = VDir.normalize(parentValue);
        if (UtString.empty(rtPath)) {
            return new RtParentValue(parentValue);
        }
        for (Rule rule : items.values()) {
            Matcher m = rule.patternPath.matcher(rtPath);
            if (m.matches()) {
                for (Map.Entry<Pattern, String> en : rule.replacer.entrySet()) {
                    m = en.getKey().matcher(parentValue);
                    if (m.matches()) {
                        return new RtParentValue(m.replaceAll(en.getValue()));
                    }
                }
                break;
            }
        }
        // не найдено
        int a = parentValue.indexOf(Rt.PATH_DELIM);
        if (a != -1) {
            return new RtParentValue(parentValue);  // есть разделитель
        }
        a = rtPath.lastIndexOf(Rt.PATH_DELIM);
        if (a == -1) {
            return new RtParentValue(parentValue);
        } else {
            int b = rtPath.lastIndexOf(Rt.PATH_DELIM, a - 1) + 1;
            return new RtParentValue(rtPath.substring(b, a) + Rt.PATH_DELIM + parentValue);
        }
    }

}
