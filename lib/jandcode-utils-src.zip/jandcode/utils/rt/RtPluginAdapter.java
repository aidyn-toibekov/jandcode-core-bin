package jandcode.utils.rt;

public class RtPluginAdapter implements IRtPlugin {

    public void handleCreatePlugin(IRtLoader loader, Rt sys, String pluginPath) throws Exception {
    }

    public String handleMacroVar(IRtLoader loader, String var) {
        return null;
    }

    public boolean handleSysAttr(IRtLoader loader, Rt x, String name, String value) throws Exception {
        return false;
    }

    public boolean handleSysChild(IRtLoader loader, Rt x, Rt sys) throws Exception {
        return false;
    }

    public void handleAfterLoad(IRtLoader loader, Rt root) throws Exception {
    }

    public void handleInclude(IRtLoader loader, Rt x, Rt sys) throws Exception {
    }
}
