package jandcode.utils;

import java.util.*;

/**
 * LinkedHashMap, где ключи регистронезависимые строки
 */
public class LinkedHashMapNoCase<TYPE> extends LinkedHashMap<String, TYPE> {

    public TYPE get(Object key) {
        key = ((String) key).toLowerCase();
        return super.get(key);
    }

    public TYPE put(String key, TYPE value) {
        key = key.toLowerCase().intern();
        return super.put(key, value);
    }

    public TYPE remove(Object key) {
        key = ((String) key).toLowerCase();
        return super.remove(key);
    }

    public boolean containsKey(Object key) {
        key = ((String) key).toLowerCase();
        return super.containsKey(key);
    }
}
