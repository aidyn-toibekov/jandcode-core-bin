package jandcode.utils.error;

/**
 * Для обработки ошибок в массовых опреациях
 */
public interface ErrorCallback {

    /**
     * Вызывается при ошибке
     *
     * @param e ошибка
     * @return вернуть true, если нужно продолжить
     */
    boolean onErrorCallback(Throwable e);

}
