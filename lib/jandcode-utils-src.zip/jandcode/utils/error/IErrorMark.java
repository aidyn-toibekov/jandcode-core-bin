package jandcode.utils.error;

/**
 * Интерфейс - маркер для пометки ошибок, которые являются маркерами
 */
public interface IErrorMark {
}
