package jandcode.utils.test;


import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.utils.rt.impl.*;

import java.util.*;

/**
 * Расширение тестов для работы с Rt.
 */
public class TestExtRt extends TestExt {

    public class ScanInfo {
        public int countChilds;
        public int countAttrs;

        public String toString() {
            return "attrs=" + countAttrs + ", childs=" + countChilds; //NON-NLS NON-NLS
        }
    }

    /**
     * Установить атрибут __p списком parent
     */
    public void assignParent(Rt x1) {
        RtImpl x = (RtImpl) x1;
        String z = x.getParents().toString();
        x.setValue("__p", z); //NON-NLS
        if (x.hasSelfChilds()) {
            for (Rt rt : x.getSelfChilds()) {
                assignParent((RtImpl) rt);
            }
        }
    }

    /**
     * Создать список ключей всех узлов
     */
    public void createKeyList(List<String> lst, Rt x) {
        lst.add(x.getPath());
        for (Rt x1 : x.getSelfChilds()) {
            createKeyList(lst, x1);
        }
    }

    /**
     * Сканирование на предмет получение информации о времени сканирования
     */
    public ScanInfo scan(Rt x) {
        ScanInfo res = new ScanInfo();
        internal_scan(res, x);
        return res;
    }

    protected void internal_scan(ScanInfo res, Rt x) {
        for (IRtAttr attr : x.getAttrs()) {
            res.countAttrs++;
        }
        Collection<Rt> childs = x.getChilds();
        for (Rt child : childs) {
            res.countChilds++;
            internal_scan(res, child);
        }
    }

    /**
     * Устанавиливает path для модулей как просто имя файла. Что бы сравнивать независимо от
     * расположения модулей
     */
    public void setModulePathAsFilename(Rt root) {
        Rt ch = root.findChild("module");
        if (ch != null) {
            for (Rt c : ch.getChilds()) {
                String s = c.getValueString("path");
                if (!UtString.empty(s)) {
                    c.setValue("path", UtFile.filename(s));
                }
            }
        }
    }

}
