package jandcode.utils.test;

/**
 * Расширение функционала тестов для {@link UtilsTestCase}
 */
public abstract class TestExt {

    /**
     * Тест, в рамках которого выполняется
     */
    public UtilsTestCase test;

    /**
     * Выполняется в {@link UtilsTestCase#setUp()}
     */
    public void setUp() throws Exception {
    }

    /**
     * Выполняется в {@link UtilsTestCase#tearDown()}
     */
    public void tearDown() throws Exception {
    }

}
