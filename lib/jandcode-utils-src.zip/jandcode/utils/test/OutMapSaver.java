package jandcode.utils.test;

import jandcode.utils.io.*;

import java.io.*;
import java.util.*;

/**
 * Вывод map в приличном виде для отладки
 */
public class OutMapSaver implements ISaver {

    private Map map;
    private IndentWriter wr;

    public OutMapSaver(Map map) {
        this.map = map;
    }

    public SaveTo save() {
        return new SaveTo(this);
    }

    public void saveTo(Writer writer) throws Exception {
        wr = new IndentWriter(writer);
        if (map == null) {
            wr.write("[]");
            return;
        }
        outMap(map);
    }

    protected void out(Object s) throws IOException {
        if (s == null) wr.write("<NULL>"); //NON-NLS
        else wr.write(s.toString());
    }

    protected void outMap(Map map) throws IOException {
        for (Object key : map.keySet()) {
            out(key);
            out(": ");
            Object v = map.get(key);
            if (v instanceof Map) {
                out("{");
                wr.indentInc();
                out("\n");
                outMap((Map) v);
                wr.indentDec();
                out("}\n");
            } else if (v instanceof List) {
                out("[");
                wr.indentInc();
                out("\n");
                for (Object it : ((List) v)) {
                    if (it instanceof Map) {
                        out("{");
                        wr.indentInc();
                        out("\n");
                        outMap((Map) it);
                        wr.indentDec();
                        out("}\n");
                    } else {
                        out(it);
                    }
                }
                wr.indentDec();
                out("]\n");
            } else {
                out(v);
                out("\n");
            }
        }
    }

}
