package jandcode.utils.test;

import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.logging.*;
import org.hamcrest.Matcher;
import org.junit.*;
import org.junit.internal.*;
import org.junit.rules.*;
import org.junit.runners.model.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

/**
 * Предок для тестов
 */
public abstract class UtilsTestCase {

    /**
     * Текущее имя тестового метода
     */
    @Rule
    public TestName testName = new TestName();

    /**
     * Если true - то логирование включается в setUp методе.
     * Иначе - логирование отключается в setUp.
     */
    public boolean logSetUp = false;

    /**
     * Номер выполняемого теста
     */
    public static int testNum = 0;

    static {
        UtLog.logOff();
    }

    /**
     * Вызывается при неудачном тесте - показывает ошибку
     */
    class FailedListener extends TestWatchman {
        public void failed(Throwable e, FrameworkMethod method) {
            showError(e);
        }
    }

    @Rule
    public FailedListener failedListener = new FailedListener();


    //////

    @Before
    public void setUp() throws Exception {
        testNum++;
        if (logSetUp) {
            logOn();
        } else {
            logOff();
        }
        extSetUp();
    }

    protected void extSetUp() throws Exception {
        for (TestExt ext : _exts.values()) {
            ext.setUp();
        }
    }

    @After
    public void tearDown() throws Exception {
        extTearDown();
    }

    protected void extTearDown() throws Exception {
        for (TestExt ext : _exts.values()) {
            ext.tearDown();
        }
    }

    //////

    /**
     * Заменяет
     * '#' на имя тестового класса
     * '%' - на имя тестового метода
     * '&' - на имя пакета тестового класса
     */
    public String replaceTestName(String s) {
        return s.replace("#", getClass().getSimpleName())
                .replace("%", getTestName())
                .replace("&", getClass().getPackage().getName());
    }

    //////

    /**
     * Возвращает каталог, в котором лежит скомпилированные класс теста
     */
    public String getTestPath() {
        String fn = getTestFile(getClass().getSimpleName() + ".class"); //NON-NLS
        File f = new File(fn);
        return f.getParentFile().getAbsolutePath();
    }

    /**
     * Возвращает полное имя файла по относительному, относительно физического
     * расположения класса TestCase.
     */
    public String getTestFile(String filename) {
        filename = replaceTestName(filename);
        URL u = getClass().getResource(filename);
        if (u == null) {
            throw new RuntimeException(String.format("Test file [%s] not found for class [%s]", //NON-NLS
                    filename, getClass().getName()));
        }
        return u.getFile();
    }

    /**
     * Имя текущего тестового метода
     */
    public String getTestName() {
        String s = testName.getMethodName();
        if (s == null) {
            s = "NONAME"; //NON-NLS
        }
        return s;
    }

    //////

    /**
     * Сравнение src с указанной маской pattern (regex). Должно совпадать.
     */
    public void match(String src, String pattern) {
        Pattern p = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
        String s = src.trim();
        java.util.regex.Matcher m = p.matcher(s);
        if (!m.matches()) {
            assertEquals(pattern, "not found: " + pattern, s); //NON-NLS
        }
    }

    /**
     * Сравнение src с указанной маской pattern (regex). Не должно совпадать.
     */
    public void notMatch(String src, String pattern) {
        Pattern p = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
        String s = src.trim();
        java.util.regex.Matcher m = p.matcher(s);

        if (m.matches()) {
            assertEquals(pattern, "found: " + pattern, s); //NON-NLS
        }
    }

    ////// timer

    private StopWatch _stopWatch;

    /**
     * Начать засекать время
     */
    public void startTimer(String msg) {
        if (_stopWatch == null) {
            _stopWatch = new StopWatch(true, true);
        }
        _stopWatch.start(msg);
    }

    /**
     * Начать засекать время
     */
    public void startTimer() {
        startTimer(null);
    }

    /**
     * Закончить засекать время и напечатать результат
     */
    public long stopTimer(long count) {
        if (_stopWatch == null) {
            return 0;
        }
        return _stopWatch.stop(count);
    }

    /**
     * Закончить засекать время и напечатать результат
     */
    public long stopTimer() {
        return stopTimer(0);
    }

    ////// logging

    /**
     * Отключение логирования
     */
    public void logOff() throws Exception {
        UtLog.logOff();
    }

    /**
     * Включение логирования для выполняемого метода.
     */
    public void logOn() throws Exception {
        UtLog.logOn();
    }

    /**
     * Вывод лога от имени текущего тестового класса
     */
    public void log(Object message) {
        Log lg = LogFactory.getLog(getClass());
        lg.info(message);
    }

    ////// outs

    /**
     * Вывод разделителя
     *
     * @param delimChar символ разделителя
     * @param msg       сообщение в разделителе
     */
    public void delim(String msg, String delimChar) {
        System.out.println(UtString.delim(msg, delimChar, 76));
    }

    /**
     * Вывод разделителя
     *
     * @param msg сообщение в разделителе
     */
    public void delim(String msg) {
        delim(msg, "~");
    }

    /**
     * Вывести map на консоль в удобочитаемом виде
     */
    public void outMap(Map m) {
        OutMapSaver sv = new OutMapSaver(m);
        String s = sv.save().toString();
        System.out.println(s);
    }

    ////// exts

    private LinkedHashMap<Class, TestExt> _exts = new LinkedHashMap<Class, TestExt>();

    /**
     * Создать и зарегистрировать расширение теста
     */
    public <A extends TestExt> A createExt(Class<A> cls) {
        A ext = (A) UtClass.createInst(cls);
        ext.test = this;
        _exts.put(cls, ext);
        return ext;
    }

    /**
     * Получить расширению по классу. Если его нет, создается и регистрируется.
     */
    public <A extends TestExt> A getExt(Class<A> cls) {
        A res = (A) _exts.get(cls);
        if (res == null) {
            res = createExt(cls);
        }
        return res;
    }

    ////// errors

    /**
     * Показать ошибку в удобном виде
     */
    public void showError(Throwable e) {
        ErrorInfo ei = UtError.createErrorInfo(e);
        delim("ERROR", "="); //NON-NLS
        System.out.println(ei.getText());
        String s = ei.getTextErrorSource();
        if (!UtString.empty(s)) {
            delim("source", "-"); //NON-NLS
            System.out.println(s);
        }
        delim("filtered stack", "-"); //NON-NLS
        System.out.println(ei.getTextStack(true));
        delim("", "=");
    }

    ////// shell

    /**
     * При значении true - тесты выполняются из командной строки либо
     * выполняется не первый тест. Для организации интерактивности в отдельных
     * тестах
     */
    public boolean isBatchMode() {
        String a = System.getProperty("jandcode.batchtest");
        if ("true".equals(a)) { //NON-NLS
            return true;  // в батнике
        }
        if (testNum > 1) {
            return true;  // не первый тест
        }
        return false;
    }

    /**
     * Открыть указанный файл в shell (например .xls или .html).
     * Для организации комфортного просмотра результата генерации файлов.
     * Работает только в режиме запуска одного теста. В случае выполнения
     * в командной строке либо не первого теста - вызов игнорируется.
     *
     * @param filename
     */
    public void shellOpen(String filename) throws Exception {
        if (isBatchMode()) {
            return; // работает только в режиме запуска одного теста
        }
        filename = UtFile.abs(filename);
        boolean osWindows = (File.separatorChar == '\\');
        if (osWindows) {
            filename = filename.replace("/", "\\");
            Runtime.getRuntime().exec("cmd.exe /c start " + filename); //NON-NLS
        }
        // ignore
    }

    ////// assert (std from junit)

    public void assertArrayEquals(byte[] expecteds, byte[] actuals) {
        Assert.assertArrayEquals(expecteds, actuals);
    }

    public void assertArrayEquals(char[] expecteds, char[] actuals) {
        Assert.assertArrayEquals(expecteds, actuals);
    }

    public void assertArrayEquals(double[] expecteds, double[] actuals, double delta) {
        Assert.assertArrayEquals(expecteds, actuals, delta);
    }

    public void assertArrayEquals(float[] expecteds, float[] actuals, float delta) {
        Assert.assertArrayEquals(expecteds, actuals, delta);
    }

    public void assertArrayEquals(int[] expecteds, int[] actuals) {
        Assert.assertArrayEquals(expecteds, actuals);
    }

    public void assertArrayEquals(long[] expecteds, long[] actuals) {
        Assert.assertArrayEquals(expecteds, actuals);
    }

    public void assertArrayEquals(Object[] expecteds, Object[] actuals) {
        Assert.assertArrayEquals(expecteds, actuals);
    }

    public void assertArrayEquals(short[] expecteds, short[] actuals) {
        Assert.assertArrayEquals(expecteds, actuals);
    }

    public void assertArrayEquals(String message, byte[] expecteds, byte[] actuals) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals);
    }

    public void assertArrayEquals(String message, char[] expecteds, char[] actuals) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals);
    }

    public void assertArrayEquals(String message, double[] expecteds, double[] actuals, double delta) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals, delta);
    }

    public void assertArrayEquals(String message, float[] expecteds, float[] actuals, float delta) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals, delta);
    }

    public void assertArrayEquals(String message, int[] expecteds, int[] actuals) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals);
    }

    public void assertArrayEquals(String message, long[] expecteds, long[] actuals) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals);
    }

    public void assertArrayEquals(String message, Object[] expecteds, Object[] actuals) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals);
    }

    public void assertArrayEquals(String message, short[] expecteds, short[] actuals) throws ArrayComparisonFailure {
        Assert.assertArrayEquals(message, expecteds, actuals);
    }

    public void assertEquals(double expected, double actual, double delta) {
        Assert.assertEquals(expected, actual, delta);
    }

    public void assertEquals(long expected, long actual) {
        Assert.assertEquals(expected, actual);
    }

    public void assertEquals(Object expected, Object actual) {
        Assert.assertEquals(expected, actual);
    }

    public void assertEquals(String message, double expected, double actual, double delta) {
        Assert.assertEquals(message, expected, actual, delta);
    }

    public void assertEquals(String message, long expected, long actual) {
        Assert.assertEquals(message, expected, actual);
    }

    public void assertEquals(String message, Object expected, Object actual) {
        Assert.assertEquals(message, expected, actual);
    }

    public void assertFalse(boolean condition) {
        Assert.assertFalse(condition);
    }

    public void assertFalse(String message, boolean condition) {
        Assert.assertFalse(message, condition);
    }

    public void assertNotNull(String message, Object object) {
        Assert.assertNotNull(message, object);
    }

    public void assertNotNull(Object object) {
        Assert.assertNotNull(object);
    }

    public void assertNotSame(String message, Object unexpected, Object actual) {
        Assert.assertNotSame(message, unexpected, actual);
    }

    public void assertNotSame(Object unexpected, Object actual) {
        Assert.assertNotSame(unexpected, actual);
    }

    public void assertNull(String message, Object object) {
        Assert.assertNull(message, object);
    }

    public void assertNull(Object object) {
        Assert.assertNull(object);
    }

    public void assertSame(Object expected, Object actual) {
        Assert.assertSame(expected, actual);
    }

    public void assertSame(String message, Object expected, Object actual) {
        Assert.assertSame(message, expected, actual);
    }

    public <T> void assertThat(T actual, Matcher<T> matcher) {
        Assert.assertThat(actual, matcher);
    }

    public <T> void assertThat(String reason, T actual, Matcher<T> matcher) {
        Assert.assertThat(reason, actual, matcher);
    }

    public void assertTrue(boolean condition) {
        Assert.assertTrue(condition);
    }

    public void assertTrue(String message, boolean condition) {
        Assert.assertTrue(message, condition);
    }

    public void fail() {
        Assert.fail();
    }

    public void fail(String message) {
        Assert.fail(message);
    }

    //////

}
