package jandcode.utils.test;

import jandcode.utils.*;

import java.lang.management.*;

/**
 * Простой секундомер.
 * Вызываем start(), потом stop(). Смотрим результат на консоле
 */
public class StopWatch {

    private boolean showMemory = false;
    private StackList<Item> stack = new StackList<Item>();
    private String lastMessage = "";
    private boolean autoPrint = true;

    public class Item {
        String message;
        long t1;
        long time;
        long count;

        long mem_init;
        long mem_used;
        long mem_committed;
        long mem_max;
    }

    public StopWatch() {
    }

    /**
     * Отслеживать и показывать расход памяти
     */
    public StopWatch(boolean showMemory, boolean autoPrint) {
        this.showMemory = showMemory;
        this.autoPrint = autoPrint;
    }

    /**
     * Запустить.
     *
     * @param message сообщение
     */
    public void start(String message) {
        Item it = new Item();
        it.t1 = System.currentTimeMillis();
        it.message = message;
        //
        if (showMemory) {
            MemoryMXBean m = ManagementFactory.getMemoryMXBean();
            MemoryUsage mu = m.getHeapMemoryUsage();
            it.mem_committed = mu.getCommitted();
            it.mem_init = mu.getInit();
            it.mem_max = mu.getMax();
            it.mem_used = mu.getUsed();
        }
        //
        stack.push(it);
    }

    /**
     * Запустить
     */
    public void start() {
        start(null);
    }

    /**
     * Остановить
     *
     * @param count сколько элементов было обработано (для показа items in sec)
     * @return время в ms
     */
    public long stop(long count) {
        if (stack.isEmpty()) {
            return 0;
        }
        Item it = stack.pop();
        it.time = System.currentTimeMillis() - it.t1;
        it.count = count;
        lastMessage = createMessage(it);
        if (autoPrint) {
            System.out.println(lastMessage);
        }
        return it.time;
    }

    /**
     * Остановить
     *
     * @return время в ms
     */
    public long stop() {
        return stop(0);
    }

    //////

    protected String createMessage(Item it) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Выполнено за %.3f сек.", it.time / 1000.0)); //NON-NLS
        if (it.count > 0 && it.time > 0) {
            double insec = (double) it.count / it.time * 1000.0;
            sb.append(String.format(" (~%.0f в сек, всего %d)", insec, it.count)); //NON-NLS
        }
        if (!UtString.empty(it.message)) {
            sb.append(" : ").append(it.message);
        }
        //
        if (showMemory) {
            MemoryMXBean m = ManagementFactory.getMemoryMXBean();
            MemoryUsage mu = m.getHeapMemoryUsage();
            long mem_committed = mu.getCommitted() - it.mem_committed;
            long mem_init = mu.getInit() - it.mem_init;
            long mem_max = mu.getMax() - it.mem_max;
            long mem_used = mu.getUsed() - it.mem_used;
            sb.append(String.format(" (memory: %,d  init: %,d  max: %,d  used: %,d)",
                    mem_committed, mem_init, mem_max, mem_used));
        }
        //
        return sb.toString();
    }

    /**
     * Последнее после stop сообщений
     */
    public String getLastMessage() {
        return lastMessage;
    }

    //////
}
