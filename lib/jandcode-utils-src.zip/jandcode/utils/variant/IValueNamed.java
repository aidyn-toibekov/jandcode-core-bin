package jandcode.utils.variant;

/**
 * Значение по ключу
 */
public interface IValueNamed {

    Object getValue(String name);

}
