package jandcode.utils.variant;

/**
 * Установка значения по ключу
 */
public interface IValueNamedSet {

    void setValue(String name, Object value);

}
