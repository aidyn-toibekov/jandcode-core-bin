package jandcode.utils.variant;

import org.joda.time.*;

/**
 * Типизированное значение
 */
public interface IVariant extends IValue {

    int getDataType();

    int getValueInt();

    long getValueLong();

    double getValueDouble();

    DateTime getValueDateTime();

    String getValueString();

    boolean getValueBoolean();

    boolean isValueNull();

}
