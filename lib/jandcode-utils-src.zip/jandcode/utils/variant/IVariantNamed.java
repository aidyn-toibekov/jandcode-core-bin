package jandcode.utils.variant;

import org.joda.time.*;

/**
 * Типизированное значение по ключу
 */
public interface IVariantNamed extends IValueNamed {

    int getDataType(String name);

    int getValueInt(String name);

    long getValueLong(String name);

    double getValueDouble(String name);

    DateTime getValueDateTime(String name);

    String getValueString(String name);

    boolean getValueBoolean(String name);

    boolean isValueNull(String name);

}
