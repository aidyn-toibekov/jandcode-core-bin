package jandcode.utils.variant;

/**
 * Установка значения по ключу
 */
public interface IValueIndexedSet {

    void setValue(int index, Object value);

}
