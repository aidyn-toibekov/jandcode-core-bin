package jandcode.utils.variant;

import org.joda.time.*;

/**
 * Типизированное значение по ключу со значением по умолчанию.
 */
public interface IVariantNamedDefault extends IValueNamed {

    int getValueInt(String name, int defValue);

    long getValueLong(String name, long defValue);

    double getValueDouble(String name, double defValue);

    DateTime getValueDateTime(String name, DateTime defValue);

    String getValueString(String name, String defValue);

    boolean getValueBoolean(String name, boolean defValue);

}
