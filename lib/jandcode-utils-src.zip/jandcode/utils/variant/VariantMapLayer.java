package jandcode.utils.variant;

import java.util.*;

/**
 * "Слоеный пирог" из объектов {@link VariantMap} с прозрачным доступом.
 * Допустим имеем 3 объекта Map:
 * <pre>
 * def m1 = [a:1,b:2,c:3]
 * def m2 = [a:11]
 * def m3 = [b:22,d:4]
 * </pre>
 * Добавляем их в {@link VariantMapLayer}:
 * <pre>
 * VariantMapLayer mm = new VariantMapLayer()
 * mm.push(m1);
 * mm.push(m2);
 * mm.push(m3);
 * </pre>
 * Теперь:
 * <pre>
 * mm.get("a")   // 11
 * mm.get("b")   // 22
 * mm.get("c")   // 3
 * mm.get("d")   // 4
 * </pre>
 * Слой может быть добавлен (методом {@link VariantMapLayer#push(java.lang.String, java.util.Map)})
 * и удален (методом {@link VariantMapLayer#pop()}).
 * Вся запись ведется на слой, который добавлен последним.
 * <p/>
 * Все чтение ведется с последнего слоя и до первого. Возвращается первый существующий элемент.
 * Соответственно, если на слое установить значение, то оно перекроет значения на нижележащих
 * слоях.
 * <p/>
 * Каждый слой имеет имя.
 * Несколько слоев могут иметь одинаковые имена.
 * Слой можно получить по имени и далее работать с ним как с {@link VariantMapLayer},
 * если считать полученный слой верхним. Поиск слоя по имени ведется начиная с верхнего
 * до первого слоя с искомым именем.
 */
public class VariantMapLayer extends VariantMapWrap {

    private Layer head = new Layer();

    /**
     * Слой
     */
    public class Layer {
        VariantMap map = new VariantMap();
        Layer parent;
        String name = "";
        private VariantMapLayer asLayerMap;

        /**
         * Получить слой как объект LayerMap
         *
         * @return
         */
        public VariantMapLayer getAsVariantMapLayer() {
            if (asLayerMap == null) {
                asLayerMap = new VariantMapLayer();
                asLayerMap.head = this;
            }
            return asLayerMap;
        }

        /**
         * Имя слоя
         */
        public String getName() {
            return name == null ? "" : name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean hasName(String name) {
            if (name == null) return false;
            return this.name.equals(name);
        }

        /**
         * Предыдущий слой (связанный список)
         */
        public Layer getParent() {
            return parent;
        }

        public void setParent(Layer parent) {
            this.parent = parent;
        }

        /**
         * Личная map на этом слое
         */
        public VariantMap getMap() {
            return map;
        }

        /**
         * Установить личную map на слое
         */
        public void setMap(VariantMap map) {
            this.map = map;
        }
    }


    //////

    /**
     * Сделать новый слой
     *
     * @param name имя слоя. Может отсутсвовать
     * @param map  данные слоя. Может быть null
     */
    public Layer push(String name, Map map) {
        Layer z = new Layer();
        z.name = name;
        z.parent = head;
        head = z;
        if (map != null) {
            z.map.putAll(map);
        }
        return z;
    }

    /**
     * Сделать новый слой
     */
    public Layer push() {
        return push("", null);
    }

    /**
     * Убрать верхний слой
     */
    public void pop() {
        if (head.parent != null) {
            head = head.parent;
        }
    }

    /**
     * Найти слой по имени и возвратить новую VariantMapLayer начиная с найденого слоя.
     *
     * @param name имя слоя, как было указано при push()
     * @return null, если не найден
     */
    public VariantMapLayer findLayer(String name) {
        if (name == null || name.length() == 0) {
            return null;
        }
        Layer z = head;
        while (z != null) {
            if (z.hasName(name)) {
                return z.getAsVariantMapLayer();
            }
            z = z.parent;
        }
        return null;
    }

    /**
     * Найти слой по имени и возвратить новую VariantMapLayer начиная с найденого слоя.
     *
     * @param name имя слоя, как было указано при push()
     * @return ошибка, если не найден
     */
    public VariantMapLayer layer(String name) {
        VariantMapLayer z = findLayer(name);
        if (z == null) {
            throw new RuntimeException("Not found layer [" + name + "] in LayerMap");
        }
        return z;
    }

    /**
     * Формирует новый VariantMap с данным, как они выглядят через LayeredMap
     *
     * @return новый экземпляр Map
     */
    public VariantMap cloneMap() {
        VariantMap res = new VariantMap();
        Layer z = head;
        while (z != null) {
            for (String key : z.map.keySet()) {
                if (!res.containsKey(key)) {
                    res.put(key, z.map.get(key));
                }
            }
            z = z.parent;
        }
        return res;
    }

    /**
     * Возвращает список всех слоев.
     * В списке первым идет последний добавленных слой.
     */
    public ArrayList<Layer> getLayers() {
        ArrayList<Layer> res = new ArrayList<Layer>();
        Layer z = head;
        while (z != null) {
            res.add(z);
            z = z.parent;
        }
        return res;
    }

    /**
     * Синоним для getLayers()
     *
     * @return
     */
    public ArrayList<Layer> layers() {
        return getLayers();
    }

    /**
     * Возвращает верхний слой
     */
    public Layer getHead() {
        return head;
    }

    public void setMap(Map map) {
        throw new UnsupportedOperationException("setMap");
    }

    public Map getMap() {
        throw new UnsupportedOperationException("getMap");
    }

    //////

    public int size() {
        HashMap m = new HashMap();
        Layer z = head;
        while (z != null) {
            m.putAll(z.map);
            z = z.parent;
        }
        return m.size();
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public boolean containsKey(Object key) {
        Layer z = head;
        while (z != null) {
            if (z.map.containsKey(key)) {
                return true;
            }
            z = z.parent;
        }
        return false;
    }

    public boolean containsValue(Object value) {
        Layer z = head;
        while (z != null) {
            if (z.map.containsValue(value)) {
                return true;
            }
            z = z.parent;
        }
        return false;
    }

    public Object get(Object key) {
        Layer z = head;
        while (z != null) {
            if (z.map.containsKey(key)) {
                return z.map.get(key);
            }
            z = z.parent;
        }
        return null;
    }

    public Object put(String key, Object value) {
        return head.map.put(key, value);
    }

    public Object remove(Object key) {
        return head.map.remove(key);
    }

    public void putAll(Map m) {
        head.map.putAll(m);
    }

    public void clear() {
        head.map.clear();
    }

    public Set keySet() {
        LinkedHashSet res = new LinkedHashSet();
        Layer z = head;
        while (z != null) {
            for (Object key : z.map.keySet()) {
                res.add(key);
            }
            z = z.parent;
        }
        return res;
    }

    public Collection values() {
        ArrayList res = new ArrayList();
        Set keys = keySet();
        for (Object key : keys) {
            res.add(get(key));
        }
        return res;
    }

    public Set entrySet() {
        LinkedHashMap res0 = new LinkedHashMap();
        LinkedHashSet res = new LinkedHashSet();
        Layer z = head;
        while (z != null) {
            for (Object ent : z.map.entrySet()) {
                Entry ent0 = (Entry) ent;
                if (!res0.containsKey(ent0.getKey())) {
                    res0.put(ent0.getKey(), "");
                    res.add(ent0);
                }
            }
            z = z.parent;
        }
        return res;
    }

    /////

}
