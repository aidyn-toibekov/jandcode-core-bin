package jandcode.utils.variant;

/**
 * Значение по ключу
 */
public interface IValueIndexed {

    Object getValue(int index);

}
