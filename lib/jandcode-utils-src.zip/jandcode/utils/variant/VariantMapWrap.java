package jandcode.utils.variant;

import jandcode.utils.*;
import org.joda.time.*;

import java.util.*;

/**
 * Враппер для Map с доступом IVariantNamed.
 * Ключ - строка, значение - объект.
 */
public class VariantMapWrap implements IVariantMap {

    protected Map _map;

    public VariantMapWrap() {
    }

    public VariantMapWrap(Map map) {
        _map = map;
    }

    public Map getMap() {
        return _map;
    }

    public void setMap(Map map) {
        _map = map;
    }

    //////

    public Object getValue(String name) {
        return get(name);
    }

    public void setValue(String name, Object value) {
        put(name, value);
    }

    public Object get(String name, Object defValue) {
        Object v = get(name);
        if (v == null) {
            return defValue;
        }
        return v;
    }

    public int getDataType(String name) {
        return DataType.getDataType(get(name));
    }

    public int getValueInt(String name) {
        return UtCnv.toInt(getValue(name));
    }

    public long getValueLong(String name) {
        return UtCnv.toLong(getValue(name));
    }

    public double getValueDouble(String name) {
        return UtCnv.toDouble(getValue(name));
    }

    public DateTime getValueDateTime(String name) {
        return UtCnv.toDateTime(getValue(name));
    }

    public String getValueString(String name) {
        return UtCnv.toString(getValue(name));
    }

    public boolean getValueBoolean(String name) {
        return UtCnv.toBoolean(getValue(name));
    }

    public boolean isValueNull(String name) {
        return getValue(name) == null;
    }

    //////

    public int getValueInt(String name, int defValue) {
        return UtCnv.toInt(getValue(name), defValue);
    }

    public long getValueLong(String name, long defValue) {
        return UtCnv.toLong(getValue(name), defValue);
    }

    public double getValueDouble(String name, double defValue) {
        return UtCnv.toDouble(getValue(name), defValue);
    }

    public DateTime getValueDateTime(String name, DateTime defValue) {
        return UtCnv.toDateTime(getValue(name), defValue);
    }

    public String getValueString(String name, String defValue) {
        return UtCnv.toString(getValue(name), defValue);
    }

    public boolean getValueBoolean(String name, boolean defValue) {
        return UtCnv.toBoolean(getValue(name), defValue);
    }

    ////// map

    public int size() {
        return getMap().size();
    }

    public boolean isEmpty() {
        return getMap().isEmpty();
    }

    public boolean containsKey(Object key) {
        return getMap().containsKey(key);
    }

    public boolean containsValue(Object value) {
        return getMap().containsValue(value);
    }

    public Object get(Object key) {
        return getMap().get(key);
    }

    public Object put(String key, Object value) {
        return getMap().put(key, value);
    }

    public Object remove(Object key) {
        return getMap().remove(key);
    }

    public void putAll(Map m) {
        getMap().putAll(m);
    }

    public void clear() {
        getMap().clear();
    }

    public Set keySet() {
        return getMap().keySet();
    }

    public Collection values() {
        return getMap().values();
    }

    public Set entrySet() {
        return getMap().entrySet();
    }

    //////

}