package jandcode.utils.variant;

import org.joda.time.*;

/**
 * Типизированное значение по ключу
 */
public interface IVariantIndexed extends IValueIndexed {

    int getDataType(int index);

    int getValueInt(int index);

    long getValueLong(int index);

    double getValueDouble(int index);

    DateTime getValueDateTime(int index);

    String getValueString(int index);

    boolean getValueBoolean(int index);

    boolean isValueNull(int index);

}
