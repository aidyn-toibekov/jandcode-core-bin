package jandcode.utils.variant;

/**
 * Установка значения
 */
public interface IValueSet {

    void setValue(Object value);

}
