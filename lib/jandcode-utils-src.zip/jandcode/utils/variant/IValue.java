package jandcode.utils.variant;

/**
 * Значение
 */
public interface IValue {

    Object getValue();

}
