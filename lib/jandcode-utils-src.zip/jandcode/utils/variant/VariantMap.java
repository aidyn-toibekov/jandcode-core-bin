package jandcode.utils.variant;

import jandcode.utils.*;
import org.joda.time.*;

import java.util.*;

/**
 * Типизированная map
 */
public class VariantMap extends LinkedHashMap<String, Object> implements IVariantMap {

    public Object getValue(String name) {
        return get(name);
    }

    public void setValue(String name, Object value) {
        put(name, value);
    }

    public Object get(String key, Object defValue) {
        Object v = get(key);
        if (v == null) {
            return defValue;
        }
        return v;
    }

    //////

    public int getDataType(String name) {
        return DataType.getDataType(get(name));
    }

    public int getValueInt(String name) {
        return UtCnv.toInt(get(name));
    }

    public long getValueLong(String name) {
        return UtCnv.toLong(get(name));
    }

    public double getValueDouble(String name) {
        return UtCnv.toDouble(get(name));
    }

    public DateTime getValueDateTime(String name) {
        return UtCnv.toDateTime(get(name));
    }

    public String getValueString(String name) {
        return UtCnv.toString(get(name));
    }

    public boolean getValueBoolean(String name) {
        return UtCnv.toBoolean(get(name));
    }

    public boolean isValueNull(String name) {
        return get(name) == null;
    }

    //////

    public int getValueInt(String name, int defValue) {
        return UtCnv.toInt(get(name), defValue);
    }

    public long getValueLong(String name, long defValue) {
        return UtCnv.toLong(get(name), defValue);
    }

    public double getValueDouble(String name, double defValue) {
        return UtCnv.toDouble(get(name), defValue);
    }

    public DateTime getValueDateTime(String name, DateTime defValue) {
        return UtCnv.toDateTime(get(name), defValue);
    }

    public String getValueString(String name, String defValue) {
        return UtCnv.toString(get(name), defValue);
    }

    public boolean getValueBoolean(String name, boolean defValue) {
        return UtCnv.toBoolean(get(name), defValue);
    }

    //////

}
