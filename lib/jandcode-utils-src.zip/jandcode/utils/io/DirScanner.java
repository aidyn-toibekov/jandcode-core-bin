package jandcode.utils.io;

import jandcode.utils.*;

import java.util.*;

/**
 * Абстрактный сканер файлов.
 * Настроен по умолчанию для игнорирования каталогов .svn, CVS, .bzr, .hg остальные файлы и
 * каталоги принимает.
 */
public abstract class DirScanner<FILE, DIR> {

    private ArrayList<String> _excludeDir = new ArrayList<String>();
    private ArrayList<String> _excludeFile = new ArrayList<String>();
    private ArrayList<String> _includeDir = new ArrayList<String>();
    private ArrayList<String> _includeFile = new ArrayList<String>();
    protected ArrayList _files = new ArrayList();
    protected ArrayList _dirs = new ArrayList();
    protected boolean _recursive = false;
    private String _rootDir = "";

    public DirScanner() {
        getExcludeDir().add(".svn"); //NON-NLS
        getExcludeDir().add(".bzr"); //NON-NLS
        getExcludeDir().add("CVS"); //NON-NLS
        getExcludeDir().add(".hg"); //NON-NLS
    }

    /**
     * Список масок для исключаемых каталогов.
     *
     * @return список
     */
    public ArrayList<String> getExcludeDir() {
        return _excludeDir;
    }

    /**
     * Список масок для исключаемых файлов
     *
     * @return список
     */
    public ArrayList<String> getExcludeFile() {
        return _excludeFile;
    }

    /**
     * Список включаемых кататалогов. Если список пустой, то включаются все каталоги
     *
     * @return список
     */
    public ArrayList<String> getIncludeDir() {
        return _includeDir;
    }

    /**
     * Список включаемых файлов. Если список пустой, то включаются все файлы
     *
     * @return список
     */
    public ArrayList<String> getIncludeFile() {
        return _includeFile;
    }

    /**
     * Признак рекурсивного обхода каталогов. По умолчанию - false.
     *
     * @return true, если каталоги обходятся рекурсивно. false - сканируется только
     *         выбранный каталог
     */
    public boolean isRecursive() {
        return _recursive;
    }

    /**
     * Признак рекурсивного обхода каталогов
     *
     * @param recursive true, если каталоги обходятся рекурсивно. false - сканируется только
     *                  выбранный каталог
     */
    public void setRecursive(boolean recursive) {
        _recursive = recursive;
    }

    /**
     * Список файлов, заполняется при сканировании (метод scan)
     *
     * @return список файлов.
     */
    public ArrayList<FILE> getFiles() {
        return _files;
    }

    /**
     * Список каталогов, заполняется при сканировании (метод scan)
     *
     * @return список каталогов.
     */
    public ArrayList<DIR> getDirs() {
        return _dirs;
    }

    /**
     * Каталог, с которого начнется сканирование
     *
     * @return каталог
     */
    public String getRootDir() {
        return _rootDir;
    }

    /**
     * Каталог с которого начнется сканирование. Без маски!
     *
     * @param rootDir каталог
     */
    public void setRootDir(String rootDir) {
        _rootDir = rootDir;
    }

    /**
     * Каталог с которого начнется сканирование, включая маску.
     * Строка разделяется на путь и маску, путь становиться rootDir, а маска добавляется
     * в getIncludeFile(). Перед этим getIncludeFile() очищается.
     *
     * @param path каталог с маской
     */
    public void setRootPath(String path) {
        setRootDir(UtFile.path(path));
        getIncludeFile().clear();
        getIncludeFile().add(UtFile.filename(path));
    }

    /**
     * Запуск сканирования. Сканируется каталог getRootDir.
     */
    public void scan() {
        getDirs().clear();
        getFiles().clear();
    }

    /**
     * Обработка одного каталога.
     *
     * @param name       имя каталога
     * @param fileobject объект, представляющий каталог
     * @return true, если нужен. В этом случае он помещается в массив getDirs()
     */
    protected boolean doHandleDirectory(String name, Object fileobject) {
        for (String mask : getExcludeDir()) {
            if (UtFile.wildcardMatchOnSystem(name, mask)) {
                return false;
            }
        }

        boolean accept = false;
        if (getIncludeDir().size() == 0) {
            accept = true;
        } else {
            for (String mask : getIncludeDir()) {
                if (UtFile.wildcardMatchOnSystem(name, mask)) {
                    accept = true;
                    break;
                }
            }
        }
        if (accept) {
            _dirs.add(fileobject);
        }
        return accept && _recursive;
    }

    /**
     * Обработка одного файла. Если нужен, то помещается в getFiles()
     *
     * @param name       имя файла
     * @param fileobject объект, представляющий файл
     */
    protected void doHandleFile(String name, Object fileobject) {
        for (String mask : getExcludeFile()) {
            if (UtFile.wildcardMatchOnSystem(name, mask)) {
                return;
            }
        }

        boolean accept = false;
        if (getIncludeFile().size() == 0) {
            accept = true;
        } else {
            for (String mask : getIncludeFile()) {
                if (UtFile.wildcardMatchOnSystem(name, mask)) {
                    accept = true;
                    break;
                }
            }
        }
        if (accept) {
            _files.add(fileobject);
        }
    }

}
