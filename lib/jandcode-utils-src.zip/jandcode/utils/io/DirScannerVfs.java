package jandcode.utils.io;

import jandcode.utils.*;
import org.apache.commons.vfs2.*;

import java.util.*;

/**
 * Получение списка файлов и каталогов в виртуальной файловой системе.
 * Настроен по умолчанию для игнорирования каталогов .svn, .bzr, .hg и CVS, остальные файлы и
 * каталоги принимает.
 */
public class DirScannerVfs extends DirScanner<FileObject, FileObject> {

    class CompFiles implements Comparator<FileObject> {

        public int compare(FileObject o1, FileObject o2) {
            return o1.getName().getBaseName().compareToIgnoreCase(o2.getName().getBaseName());
        }
    }

    private void scanDir(FileObject dir) throws Exception {
        FileObject[] lst = dir.getChildren();
        Arrays.sort(lst, new CompFiles());
        if (lst == null) {
            return;
        }
        for (FileObject file : lst) {
            if (file.getType() == FileType.FILE) {
                doHandleFile(file.getName().getBaseName(), file);
            }
        }
        for (FileObject file : lst) {
            if (file.getType() == FileType.FOLDER) {
                if (doHandleDirectory(file.getName().getBaseName(), file)) {
                    scanDir(file);
                }
            }
        }
    }

    /**
     * Запуск сканирования. Сканируется каталог getRootDir.
     */
    public void scan() {
        super.scan();
        FileObject root = UtFile.getFileObject(getRootDir());
        try {
            scanDir(root);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
