package jandcode.utils.io;

import java.io.*;
import java.util.*;

/**
 * Получение списка файлов и каталогов.
 * Настроен по умолчанию для игнорирования каталогов .svn, .bzr, .hg и CVS, остальные файлы и
 * каталоги принимает.
 */
public class DirScannerLocal extends DirScanner<File, File> {

    class CompFiles implements Comparator<File> {

        public int compare(File o1, File o2) {
            return o1.getName().compareToIgnoreCase(o2.getName());
        }
    }

    private void scanDir(File dir) {
        File[] lst = dir.listFiles();
        if (lst == null) {
            return;
        }
        Arrays.sort(lst, new CompFiles());
        for (File file : lst) {
            if (!file.isDirectory()) {
                doHandleFile(file.getName(), file);
            }
        }
        for (File file : lst) {
            if (file.isDirectory()) {
                if (doHandleDirectory(file.getName(), file)) {
                    scanDir(file);
                }
            }
        }
    }

    /**
     * Запуск сканирования. Сканируется каталог getRootDir.
     */
    public void scan() {
        super.scan();
        File root = new File(getRootDir());
        scanDir(root);
    }

}
