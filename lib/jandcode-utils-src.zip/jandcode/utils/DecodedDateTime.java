package jandcode.utils;

/**
 * Разобранная на запчасти дата
 */
public class DecodedDateTime {

    public int year;
    public int month;
    public int day;
    public int hour;
    public int min;
    public int sec;
    public int msec;
    public int dow;

    /**
     * В iso-формат
     */
    public String toString() {
        return String.format("%04d-%02d-%02dT%02d:%02d:%02d.%03d", year, month, day, hour, min, sec, msec); //NON-NLS
    }

}
