package jandcode.utils;

/**
 * Поименнованный объект, которому можно установить имя
 */
public interface INamedSet extends INamed {

    public void setName(String name);

}
