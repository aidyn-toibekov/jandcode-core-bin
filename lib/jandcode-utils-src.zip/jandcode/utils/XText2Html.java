package jandcode.utils;

import jandcode.utils.io.*;

/**
 * Конвертор текста в формате XText в HTML
 */
public class XText2Html extends TextParserStr {

    /**
     * Текущее состояние: нет состояния
     */
    private static int STATE_NONE = 0;
    /**
     * Текущее состояние: параграф
     */
    private static int STATE_PARAGRAF = 1;
    /**
     * Текущее состояние: список
     */
    private static int STATE_LIST = 2;
    /**
     * Текущее состояние: таблица
     */
    private static int STATE_TABLE = 3;

    /**
     * Результат конвертации
     */
    private StringBuilder _result = new StringBuilder();

    /**
     * Текущее состояние
     */
    private int _state = STATE_NONE;


    /**
     * Элемент стека вложенных списков
     */
    class ListStackItem {
        /**
         * Тип списка
         */
        char type = '*';
        /**
         * Позиция первого элемента списка на этом уровне (номер колонки)
         */
        int pos = 0;

        /**
         * Открывающий тег для списка
         */
        String startTag() {
            if (type == '#') {
                return "<ol>"; //NON-NLS
            } else {
                return "<ul>"; //NON-NLS
            }
        }

        /**
         * Закрывающий тег для списка
         */
        String stopTag() {
            if (type == '#') {
                return "</ol>"; //NON-NLS
            } else {
                return "</ul>"; //NON-NLS
            }
        }
    }

    /**
     * Стек вложенных списков
     */
    private StackList<ListStackItem> _listStack = new StackList<ListStackItem>();

    /**
     * Реализация парзера
     */
    protected void onParse() throws Exception {
        _listStack.clear();
        _state = STATE_NONE;
        while (last != EOF) {
            nextStr();
            handleStr();
        }
        handleEmpty();
    }

    /**
     * Результат конвертации
     */
    public String getResult() {
        return _result.toString();
    }


    /**
     * Обработка строки
     */
    private void handleStr() throws Exception {
        if (getStr().length() == 0) {
            if (_state == STATE_NONE) {
                return;  // ненужная пустая строка
            } else {
                handleEmpty();
            }
        } else {
            char startChar = getStr().charAt(0);
            if (startChar == '*' || startChar == '#') {
                handleListItem();
            } else if (startChar == '=') {
                handleOneLineTag();
            } else if (startChar == ';') {
                // ignore (comment)
            } else if (startChar == '|') {
                handleTable();
            } else if (startChar == '<' && getStr().length() > 1 && getStr().charAt(1) == '<') {
                handleMultiLineTag();
            } else {
                handleParagraf();
            }
        }
    }

    private void closeParagraf() {
        if (_state == STATE_PARAGRAF) {
            _result.append("\n</p>"); //NON-NLS
            _state = STATE_NONE;
        }
    }

    private void closeList() {
        if (_state == STATE_LIST) {
            for (int i = _listStack.size() - 1; i >= 0; i--) {
                _result.append("\n</li>"); //NON-NLS
                _result.append("\n");
                _result.append(_listStack.get(i).stopTag());
            }
            _listStack.clear();
            _state = STATE_NONE;
        }
    }

    private void closeTable() {
        if (_state == STATE_TABLE) {
            _result.append("\n</table>"); //NON-NLS
            _state = STATE_NONE;
        }
    }

    private void handleEmpty() {
        closeParagraf();
        closeList();
        closeTable();
    }

    private void handleParagraf() {
        String delimiter = "\n";
        int curpos = getSpaces().length();

        if (_state == STATE_LIST) {
            // если строка начинается в неправильном месте для элемента списка, то список закрываем
            if (curpos <= _listStack.last().pos) {
                closeList();
            }
        }
        if (_state == STATE_NONE) {
            _result.append("\n<p>"); //NON-NLS
            delimiter = "";
            _state = STATE_PARAGRAF;
        }
        _result.append(delimiter);
        _result.append(replaceHighlight(getStr()));
    }

    private void handleMultiLineTag() throws Exception {
        handleEmpty();

        int curPos = getSpaces().length();
        // убираем <<
        String outStr = getStr().substring(2).trim();
        // ищем первый пробел
        String attrStr = "";
        String tagName = outStr.toLowerCase();
        int a = outStr.indexOf(' ');

        if (a != -1) {
            tagName = outStr.substring(0, a).toLowerCase();
            attrStr = outStr.substring(a + 1).trim();
        }

        boolean isEscape = false;
        if (tagName.equals("pre") || tagName.equals("code")) { //NON-NLS NON-NLS
            isEscape = true;
            tagName = "pre"; //NON-NLS
        }


        if (tagName.length() > 0) {
            _result.append("\n<");
            _result.append(tagName);
            if (attrStr.length() > 0) {
                _result.append(" ");
                _result.append(attrStr);
            }
            _result.append(">");
            if (isEscape) {
                _result.append("<![CDATA["); //NON-NLS
            }
        }

        // далее выводим строки сами...
        boolean firstStr = true;
        while (last != EOF) {
            nextStr();
            if (getStr().equals(">>") && getSpaces().length() == curPos) {
                break;
            }
            if (!firstStr) {
                _result.append("\n");
            } else {
                firstStr = false;
            }
            int nsp = getSpaces().length();
            while (nsp > curPos) {
                _result.append(' ');
                nsp--;
            }

            _result.append(getStr());
        }

        // и закрывает тег
        if (tagName.length() > 0) {
            if (isEscape) {
                _result.append(" ");  // иначе, если последний символ ']', tagsoup его неправильно распознает
                _result.append("]]>");
            }
            _result.append("\n");
            _result.append("</");
            _result.append(tagName);
            _result.append(">");
        }
    }

    /**
     * Открываем список
     */
    private void openList(char type) {
        ListStackItem it;
        it = new ListStackItem();
        it.type = type;
        it.pos = getSpaces().length();
        _listStack.add(it);
        _result.append("\n");
        _result.append(it.startTag());
    }

    private void handleListItem() {
        closeParagraf();

        if (_state == STATE_NONE) {
            _state = STATE_LIST;
        }

        ListStackItem it;
        char type = getStr().charAt(0);
        String outStr = getStr().substring(1).trim();

        int curpos = getSpaces().length();

        // закрываем все ненужные уровни
        for (int i = _listStack.size() - 1; i >= 0; i--) {
            if (_listStack.get(i).pos > curpos) {
                _result.append("\n</li>"); //NON-NLS
                _result.append("\n");
                _result.append(_listStack.get(i).stopTag());
                _listStack.pop();
            } else {
                break;
            }
        }


        if (_listStack.size() == 0) { // первый элемент
            openList(type);
        } else {
            if (curpos > _listStack.last().pos) {
                openList(type);
            } else {
                _result.append("\n</li>"); //NON-NLS
            }
        }
        _result.append("\n<li>"); //NON-NLS
        _result.append(replaceHighlight(outStr));
    }

    private String replaceHighlight(String s) {
        s = replaceLinkBlock(s);
        s = replaceHighlightBlock(s, "__", "<b>", "</b>"); //NON-NLS NON-NLS
        s = replaceHighlightBlock(s, "~~", "<i>", "</i>"); //NON-NLS NON-NLS
        s = replaceHighlightBlock(s, "``", "<tt>", "</tt>"); //NON-NLS NON-NLS
        return s;
    }

    private String replaceLinkBlock(String s) {
        while (true) {
            int a = s.indexOf("[[");
            if (a == -1) {
                break;
            }
            int b = s.indexOf("]]", a + 2);
            if (b == -1) {
                break;
            }
            String linkRef = s.substring(a + 2, b);
            String linkTitle = linkRef;
            int c = linkRef.indexOf('|');
            if (c != -1) {
                linkTitle = linkRef.substring(c + 1);
                linkRef = linkRef.substring(0, c);
            }
            if (linkRef.length() == 0) {
                linkRef = linkTitle;
            }
            if (linkTitle.length() == 0) {
                linkTitle = linkRef;
            }
            String linkRes = "<a href=\"" + linkRef + "\">" + linkTitle + "</a>"; //NON-NLS NON-NLS
            s = s.substring(0, a) + linkRes + s.substring(b + 2);
        }
        return s;
    }

    private String replaceHighlightBlock(String s, String tag, String startTag, String endTag) {
        while (true) {
            int a = s.indexOf(tag);
            if (a == -1) {
                break;
            }
            int b = s.indexOf(tag, a + tag.length());
            if (b == -1) {
                break;
            }
            s = s.substring(0, a) + startTag + s.substring(a + tag.length(), b) + endTag + s.substring(b + tag.length());
        }
        return s;
    }

    /**
     * Однострочный тег
     */
    private void handleOneLineTag() {
        handleEmpty();

        // убираем =
        String outStr = getStr().substring(1).trim();
        // ищем первый пробел
        int a = outStr.indexOf(' ');
        if (a == -1) {
            // нет пробелов - просто тег
            _result.append("\n<");
            _result.append(outStr);
            _result.append("/>");
        } else {
            String attrStr = "";
            String tagName = outStr.substring(0, a);
            outStr = outStr.substring(a + 1).trim();

            a = outStr.indexOf('|');
            if (a != -1) {
                attrStr = outStr.substring(0, a).trim();
                outStr = outStr.substring(a + 1).trim();
            }
            _result.append("\n<");
            _result.append(tagName);
            if (attrStr.length() > 0) {
                _result.append(" ");
                _result.append(attrStr);
            }
            _result.append(">");
            _result.append(outStr);
            _result.append("</");
            _result.append(tagName);
            _result.append(">");
        }
    }

    /**
     * Таблица
     */
    private void handleTable() {
        if (_state != STATE_TABLE) {
            handleEmpty();
            _result.append("\n<table>"); //NON-NLS
        }
        _state = STATE_TABLE;
        boolean isHead = false;
        if (getStr().length() > 1 && getStr().substring(0, 2).equals("||")) {
            isHead = true;
            setStr(getStr().substring(2));
        } else {
            setStr(getStr().substring(1));
        }
        String[] ar = getStr().split("\\|");
        _result.append("<tr>"); //NON-NLS
        for (String col : ar) {
            if (isHead) {
                _result.append("<th>"); //NON-NLS
            } else {
                _result.append("<td>"); //NON-NLS
            }
            _result.append(replaceHighlight(col));
            if (isHead) {
                _result.append("</th>\n"); //NON-NLS
            } else {
                _result.append("</td>\n"); //NON-NLS
            }
        }
        _result.append("</tr>\n"); //NON-NLS
    }


}