package jandcode.utils.easyxml;

import jandcode.utils.*;
import jandcode.utils.io.*;
import jandcode.utils.variant.*;
import org.xml.sax.*;
import org.xml.sax.ext.*;

import javax.xml.parsers.*;
import java.io.*;

/**
 * Загрузка EasyXml из xml.
 */
public class EasyXmlLoader extends DefaultHandler2 implements ILoader {

    protected EasyXml root;
    private boolean trimSpace = true;
    private boolean trimSpaceEnd = false;
    private String commentNodeName = null;
    private StringBuilder buffer;
    protected StackList<EasyXml> stack;

    public EasyXmlLoader(EasyXml root) {
        this.root = root;
    }

    public LoadFrom load() {
        return new LoadFrom(this);
    }

    public void loadFrom(Reader reader) throws Exception {
        root.clear();
        buffer = new StringBuilder();
        stack = new StackList<EasyXml>();
        //
        XMLReader xreader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
        xreader.setContentHandler(this);
        xreader.setProperty("http://xml.org/sax/properties/lexical-handler", this); //NON-NLS
        xreader.parse(UtLoad.getInputSource(reader));
        //
    }

    //////

    /**
     * Обрезать ли пробелы в тексте. По умолчанию - true
     */
    public boolean isTrimSpace() {
        return trimSpace;
    }

    public void setTrimSpace(boolean trimSpace) {
        this.trimSpace = trimSpace;
    }

    /**
     * Где обрезать пробелы. При значении true - только в конце. По умолчанию false
     */
    public boolean isTrimSpaceEnd() {
        return trimSpaceEnd;
    }

    public void setTrimSpaceEnd(boolean trimSpaceEnd) {
        this.trimSpaceEnd = trimSpaceEnd;
    }

    /**
     * Имя узла для коментариев. Если не установлено (по умолчанию) - комментарии
     * игнорируются.
     */
    public String getCommentNodeName() {
        return commentNodeName;
    }

    public void setCommentNodeName(String commentNodeName) {
        this.commentNodeName = commentNodeName;
    }

//////

    public void startElement(String uri, String localName, String qName,
            Attributes attributes) throws SAXException {
        EasyXml cur;
        if (stack.size() == 0) {
            cur = root;
        } else {
            assignValue();
            cur = stack.last().addChild("");
        }
        stack.add(cur);

        cur.setName(qName);
        int cnt = attributes.getLength();
        if (cnt > 0) {
            IVariantMap m = cur.getAttrs();
            for (int i = 0; i < cnt; i++) {
                m.put(attributes.getQName(i), attributes.getValue(i));
            }
        }
    }

    public void characters(char ch[], int start, int length) throws SAXException {
        buffer.append(ch, start, length);
    }

    public void endElement(String uri, String localName, String qName)
            throws SAXException {
        assignValue();
        stack.pop();
    }

    protected void assignValue() {
        if (buffer.length() == 0) {
            return;
        }
        String s;
        if (trimSpace) {
            if (trimSpaceEnd) {
                s = UtString.trimLast(buffer.toString().replaceAll("\r", ""));
            } else {
                s = buffer.toString().trim().replaceAll("\r", "");
            }
        } else {
            s = buffer.toString().replaceAll("\r", "");
        }
        if (s.length() > 0) {
            if (stack.last().hasChilds()) {
                stack.last().addChild("").setValue(s);
            } else {
                stack.last().setValue(s);
            }
        }
        buffer.setLength(0);
    }

    public void comment(char[] ch, int start, int length) throws SAXException {
        if (UtString.empty(commentNodeName)) {
            return;
        }
        assignValue(); // текст до коментария

        StringBuilder sb = new StringBuilder();
        sb.append(ch, start, length);

        String s;
        if (trimSpace) {
            if (trimSpaceEnd) {
                s = UtString.trimLast(sb.toString().replaceAll("\r", ""));
            } else {
                s = sb.toString().trim().replaceAll("\r", "");
            }
        } else {
            s = sb.toString().replaceAll("\r", "");
        }

        stack.last().addChild(commentNodeName).setValue(s);
    }

}