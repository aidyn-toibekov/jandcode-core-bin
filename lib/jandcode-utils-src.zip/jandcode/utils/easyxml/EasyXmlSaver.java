package jandcode.utils.easyxml;

import jandcode.utils.io.*;
import jandcode.utils.variant.*;

/**
 * Запись EasyXml в xml.
 */
public class EasyXmlSaver extends XmlSaver {

    private EasyXml _root;
    private boolean _saveRootNode = true;
    private String _commentNodeName = null;


    public EasyXmlSaver(EasyXml root) {
        _root = root;
    }

    /**
     * Записывать ли корневой узел. По умолчанию - true.
     */
    public void setSaveRootNode(boolean saveRootNode) {
        _saveRootNode = saveRootNode;
    }

    /**
     * Имя ноды, которая записывается не как нода, а как коментарий.
     * По умолчанию не установлено.
     */
    public void setCommentNodeName(String commentNodeName) {
        _commentNodeName = commentNodeName;
    }

    protected void onSaveXml() throws Exception {
        saveInternal(_root);
    }

    private void saveInternal(EasyXml node) throws Exception {
        saveNode(node, _saveRootNode);
    }

    private void saveNode(EasyXml node, boolean saveSelfTag) throws Exception {
        String nodeName = node.getName();

        if (node != _root && saveSelfTag &&
                (nodeName.length() == 0 && !node.hasChilds() && !node.hasAttrs())) {
            if (isUseIndent()) {
                writeText("\n");
            }
            writeText(node.getValueString());
        } else {

            if (_commentNodeName != null) {
                if (_commentNodeName.equals(nodeName)) {
                    if (isUseIndent()) {
                        writeCustomNode(node.getValueString(), "\n<!--", "\n-->\n");
                    } else {
                        writeCustomNode(node.getValueString(), "<!--", "-->");
                    }
                    return;
                }
            }

            if (saveSelfTag) {

                if (nodeName.length() == 0) {
                    nodeName = "root"; //NON-NLS
                }

                startNode(nodeName);

                if (node.hasAttrs()) {

                    IVariantMap m = node.getAttrs();
                    for (String an : m.keySet()) {
                        writeAttr(an, m.getValueString(an));
                    }

                }

            }


            if (node.hasValue()) {
                writeText(node.getValueString());
            }

            for (EasyXml n : node) {
                saveNode(n, true);
            }

            if (saveSelfTag) {
                stopNode();
            }

        }
    }

}