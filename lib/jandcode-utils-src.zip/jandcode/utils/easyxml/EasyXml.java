package jandcode.utils.easyxml;

import jandcode.utils.*;
import jandcode.utils.easyxml.impl.*;
import jandcode.utils.io.*;
import jandcode.utils.variant.*;
import org.joda.time.*;

import java.text.*;
import java.util.*;

/**
 * Mini-xml.
 * Предназначен в первую очередь для простейших манипуляций с данными xml в памяти,
 * является представленим узла xml. Не поддерживает никаких стандартов XML. Его
 * цель - скорость и минимальные требования к памяти.
 * <p/>
 * Все имена узлов и атрибутов - регистрозависимые.
 * <p/>
 * При поиске узлов используется следующий формат пути: <code>PATH_ITEM[/PATH_ITEM ...]</code>,
 * где <code>PATH_ITEM</code> может принимать значения:
 * <ul>
 * <li>"имя_узла"</li>
 * <li>"имя_узла@имя_атрибута=значение_атрибута"</li>
 * <li>"имя_узла@значение_атрибута_name"</li>
 * <li>"@имя_атрибута" (только последний элемент пути)</li>
 * </ul>
 */
public class EasyXml implements INamedSet, IVariantNamed, IVariantNamedDefault,
        IVariant, IValueSet, IValueNamedSet, Iterable<EasyXml> {

    protected static List<EasyXml> EMPTY_CHILDS = Collections.unmodifiableList(new ArrayList<EasyXml>());

    protected String _name;
    protected Object _value;
    private IVariantMap _attrs;
    private List<EasyXml> _childs;

    ////// name

    /**
     * Имя узла.
     */
    public String getName() {
        return _name == null ? "" : _name;
    }

    public void setName(String name) {
        _name = name.intern();
    }

    /**
     * Имеется ли установленное имя
     */
    public boolean hasName() {
        return _name != null && _name.length() > 0;
    }

    /**
     * Проверка на совпадение имени.
     */
    public boolean hasName(String name) {
        return _name != null && _name.equals(name);
    }

    ////// value

    /**
     * Значение узла.
     */
    public Object getValue() {
        return _value;
    }

    public void setValue(Object value) {
        _value = value;
    }

    /**
     * Есть ли значение. Если значением является пустая строка - то значения нет!
     */
    public boolean hasValue() {
        if (_value == null) {
            return false;
        }
        if (_value instanceof String) {
            return ((String) _value).length() > 0;
        }
        if (_value instanceof CharSequence) {
            String s = _value.toString();
            return s.length() > 0;
        }
        return true;
    }

    ////// attrs

    /**
     * Есть ли атрибуты
     */
    public boolean hasAttrs() {
        return _attrs != null && _attrs.size() > 0;
    }

    /**
     * Очистить атрибуты
     */
    public void clearAttrs() {
        _attrs = null;
    }

    /**
     * Атрибуты
     */
    public IVariantMap getAttrs() {
        if (_attrs == null) {
            _attrs = new VariantMap();
        }
        return _attrs;
    }

    /**
     * Сколько атрибутов
     */
    public int getCountAttrs() {
        if (_attrs == null) {
            return 0;
        }
        return _attrs.size();
    }

    ////// childs

    private void checkChilds() {
        if (_childs == null) {
            _childs = new ArrayList<EasyXml>();
        }
    }

    /**
     * Очистить дочерние
     */
    public void clearChilds() {
        _childs = null;
    }

    /**
     * Есть ли дочерние
     */
    public boolean hasChilds() {
        return _childs != null && _childs.size() > 0;
    }

    /**
     * Сколько дочерних
     */
    public int getCountChilds() {
        if (_childs == null) {
            return 0;
        }
        return _childs.size();
    }

    /**
     * Получить дочерний узел по индексу
     */
    public EasyXml getChild(int index) {
        return _childs.get(index);
    }

    /**
     * Получить дочерний узел по пути
     */
    public EasyXml getChild(String path) {
        EasyXml p = findChild(path);
        if (p == null) {
            throw new RuntimeException(MessageFormat.format(UtLang.t("Дочерний элемент не найден: {0}"), path));
        }
        return p;
    }

    /**
     * Итератор по дочерним узлам
     */
    public Iterable<EasyXml> getChilds() {
        return _childs;
    }

    public Iterator<EasyXml> iterator() {
        if (_childs == null) {
            return EMPTY_CHILDS.iterator();
        }
        return _childs.iterator();
    }

    ////// add childs

    /**
     * Добавить дочерний узел
     */
    public void addChild(EasyXml child) {
        checkChilds();
        _childs.add(child);
    }

    /**
     * Создать и добавить дочерний узел с указанным именем
     */
    public EasyXml addChild(String name) {
        EasyXml r = new EasyXml();
        r.setName(name);
        addChild(r);
        return r;
    }

    /**
     * Создать и добавить дочерний узел с указанным именем и значением атрибута name
     */
    public EasyXml addChild(String name, String nameAttrValue) {
        EasyXml r = new EasyXml();
        r.setName(name);
        r.getAttrs().put("name", nameAttrValue); //NON-NLS
        addChild(r);
        return r;
    }

    /**
     * Добавить дочерний по информации в EasyXmlPathItem
     */
    protected EasyXml internalAddChild(EasyXmlPathItem pi) {
        EasyXml x = new EasyXml();
        x.setName(pi.getName());
        if (pi.getAttrName().length() > 0) {
            x.getAttrs().put(pi.getAttrName(), pi.getAttrValue());
        }
        addChild(x);
        return x;
    }

    ////// remove child

    /**
     * Удалить дочерний, если он есть
     */
    public void removeChild(EasyXml x) {
        if (_childs == null) {
            return;
        }
        _childs.remove(x);
    }

    /**
     * Удалить дочерний, если есть. Удаляется последний элемент пути.
     */
    public void removeChild(String path) {
        if (_childs == null) {
            return;
        }
        EasyXmlPath p = new EasyXmlPath(path);
        if (p.getItems().size() == 0) {
            return;
        }
        EasyXml n;
        if (p.getItems().size() == 1) {
            n = internalFindChild(p, false);
            if (n != null) {
                removeChild(n);
            }
        } else {
            EasyXmlPathItem last = p.getItems().remove(p.getItems().size() - 1);
            n = internalFindChild(p, false);
            if (n != null) {
                EasyXml n2 = n.internalFindSelfChild(last);
                if (n2 != null) {
                    n.removeChild(n2);
                }
            }
        }
    }

    /**
     * Удалить дочерний по индексу
     */
    public void removeChild(int index) {
        if (_childs == null) {
            return;
        }
        _childs.remove(index);
    }

    ////// find

    /**
     * Поиск дочернего по пути
     *
     * @param path путь
     * @return узел или null, если не найден
     */
    public EasyXml findChild(String path) {
        return findChild(path, false);
    }

    /**
     * Поиск дочернего по пути
     *
     * @param path             путь
     * @param createIfNotExist true - создавать не существующие
     * @return узел или null, если не найден
     */
    public EasyXml findChild(String path, boolean createIfNotExist) {
        EasyXmlPath pt = new EasyXmlPath(path);
        return internalFindChild(pt, createIfNotExist);
    }

    /**
     * Проверка - существует ли объект по указанному пути.
     */
    public boolean hasChild(String path) {
        return findChild(path, false) != null;
    }

    /**
     * Поиск дочернего по пути
     *
     * @param path             путь
     * @param createIfNotExist true - добавлять, если не найден
     * @return null, если не найден
     */
    protected EasyXml internalFindChild(EasyXmlPath path, boolean createIfNotExist) {
        EasyXml cur = this;
        for (EasyXmlPathItem pi : path.getItems()) {
            EasyXml found = cur.internalFindSelfChild(pi);
            if (found == null) {
                if (!createIfNotExist) {
                    return null;
                }
                found = cur.internalAddChild(pi);
            }
            cur = found;
        }
        return cur;
    }

    /**
     * Найти собственный дочерний по информации EasyXmlPathItem
     *
     * @return null, если не найден
     */
    protected EasyXml internalFindSelfChild(EasyXmlPathItem p) {
        if (_childs != null) {
            if (p.getAttrName().length() > 0) {
                for (EasyXml x : _childs) {
                    if (x.hasName(p.getName())) {
                        String av = "";
                        if (x.hasAttrs()) {
                            av = x.getAttrs().getValueString(p.getAttrName());
                        }
                        if (av.equals(p.getAttrValue())) {
                            return x;
                        }
                    }
                }
            } else {
                for (EasyXml x : _childs) {
                    if (x.hasName(p.getName())) {
                        return x;
                    }
                }
            }
        }
        return null;
    }

    ////// misc

    /**
     * Очистка все данных, кроме имени.
     */
    public void clear() {
        clearAttrs();
        clearChilds();
    }

    /**
     * Объединенеие узлов. В текущем рекурсивно досоздаются узлы и атрибуты из node,
     * которые не существуют и модифицируются существующие.
     */
    public void join(EasyXml node) {
        if (node.hasValue()) {
            setValue(node.getValue());
        }
        if (node.hasAttrs()) {
            for (Map.Entry<String, Object> a : node.getAttrs().entrySet()) {
                getAttrs().put(a.getKey(), a.getValue());
            }
        }
        if (node.hasChilds()) {
            for (EasyXml ch : node) {
                if (ch.hasAttrs()) {
                    String nm = ch.getAttrs().getValueString("name"); //NON-NLS
                    if (nm.length() != 0) {
                        EasyXml nn = findChild(ch.getName() + "@" + nm, true);
                        nn.join(ch);
                        continue;
                    }
                }
                EasyXml nn = findChild(ch.getName(), true);
                nn.join(ch);
            }
        }
    }

    /**
     * Заменить все на данные из node
     */
    public void assign(EasyXml node) {
        clear();
        internal_assign(node);
    }

    protected void internal_assign(EasyXml node) {
        if (node.hasValue()) {
            setValue(node.getValue());
        }
        if (node.hasAttrs()) {
            for (Map.Entry<String, Object> a : node.getAttrs().entrySet()) {
                getAttrs().put(a.getKey(), a.getValue());
            }
        }
        if (node.hasChilds()) {
            for (EasyXml ch : node) {
                EasyXml nn = addChild(ch.getName());
                nn.internal_assign(ch);
            }
        }
    }

    //////

    /**
     * Получить значение по пути. Если путь указывает на узел, возвращается его
     * значение. Если на атрибут - значение атрибута. Если путь не существует,
     * возвращается null.
     */
    public Object getValue(String path) {
        EasyXmlPath p = new EasyXmlPath(path);
        EasyXml n = internalFindChild(p, false);
        if (n == null) {
            return null;
        }
        if (p.hasAttrName()) {
            if (n.hasAttrs()) {
                return n.getAttrs().get(p.getAttrName());
            } else {
                return null;
            }
        } else {
            return n.getValue();
        }
    }

    /**
     * Установить значение по пути. Если путь указывает на узел, устанавливает его
     * значение. Если на атрибут - устанавливает значение атрибута. Если путь не существует,
     * то он создается.
     */
    public void setValue(String path, Object value) {
        EasyXmlPath p = new EasyXmlPath(path);
        EasyXml n = internalFindChild(p, true);
        if (p.hasAttrName()) {
            n.getAttrs().put(p.getAttrName(), value);
        } else {
            n.setValue(value);
        }
    }

    ////// IVariant

    public int getDataType() {
        return DataType.getDataType(getValue());
    }

    public int getValueInt() {
        return UtCnv.toInt(getValue());
    }

    public long getValueLong() {
        return UtCnv.toLong(getValue());
    }

    public double getValueDouble() {
        return UtCnv.toDouble(getValue());
    }

    public DateTime getValueDateTime() {
        return UtCnv.toDateTime(getValue());
    }

    public String getValueString() {
        return UtCnv.toString(getValue());
    }

    public boolean getValueBoolean() {
        return UtCnv.toBoolean(getValue());
    }

    public boolean isValueNull() {
        return getValue() == null;
    }

    ////// IVariantNamed

    public int getDataType(String name) {
        return DataType.getDataType(getValue(name));
    }

    public int getValueInt(String name) {
        return UtCnv.toInt(getValue(name));
    }

    public long getValueLong(String name) {
        return UtCnv.toLong(getValue(name));
    }

    public double getValueDouble(String name) {
        return UtCnv.toDouble(getValue(name));
    }

    public DateTime getValueDateTime(String name) {
        return UtCnv.toDateTime(getValue(name));
    }

    public String getValueString(String name) {
        return UtCnv.toString(getValue(name));
    }

    public boolean getValueBoolean(String name) {
        return UtCnv.toBoolean(getValue(name));
    }

    public boolean isValueNull(String name) {
        return getValue(name) == null;
    }

    ////// IVariantNamedDefault

    public int getValueInt(String name, int defValue) {
        return UtCnv.toInt(getValue(name), defValue);
    }

    public long getValueLong(String name, long defValue) {
        return UtCnv.toLong(getValue(name), defValue);
    }

    public double getValueDouble(String name, double defValue) {
        return UtCnv.toDouble(getValue(name), defValue);
    }

    public DateTime getValueDateTime(String name, DateTime defValue) {
        return UtCnv.toDateTime(getValue(name), defValue);
    }

    public String getValueString(String name, String defValue) {
        return UtCnv.toString(getValue(name), defValue);
    }

    public boolean getValueBoolean(String name, boolean defValue) {
        return UtCnv.toBoolean(getValue(name), defValue);
    }

    //////

    public LoadFrom load() {
        return new LoadFrom(new EasyXmlLoader(this));
    }

    public SaveTo save() {
        return new SaveTo(new EasyXmlSaver(this));
    }

    ////// for groovy

    /**
     * Аналогично {@link EasyXml#getValue(String)}
     */
    public Object get(String path) {
        return getValue(path);
    }

    /**
     * Аналогично {@link EasyXml#setValue(String, Object)}
     */
    public void set(String path, Object value) {
        setValue(path, value);
    }


}
