package jandcode.utils.easyxml.impl;

import jandcode.utils.*;

/**
 * Элемент пути EasyXml. Формат строки пути может быть следующий:
 * <ul>
 * <li>"имя_узла"</li>
 * <li>"имя_узла@имя_атрибута=значение_атрибута"</li>
 * <li>"имя_узла@значение_атрибута_name"</li>
 * </ul>
 */
public class EasyXmlPathItem {

    private String _name = "";
    private String _attrName = "";
    private String _attrValue = "";

    public EasyXmlPathItem() {
    }

    /**
     * Создать объект и разобрать путь
     *
     * @param pathpart Элемент пути
     */
    public EasyXmlPathItem(String pathpart) {
        doParse(pathpart);
    }

    /**
     * Разобрать строку с элементом пути
     *
     * @param pathpart Элемент пути
     */
    private void doParse(String pathpart) {

        if (pathpart.length() == 0) {
            throw new RuntimeException(UtLang.t("Элемент пути пустой"));
        }

        int n = pathpart.indexOf(EasyXmlPath.DELIMITER_ATTR);
        if (n == -1) {
            // путь без атрибутов вообще
            _name = pathpart;
        } else if (n == 0) {
            // только атрибут
            throw new RuntimeException(UtLang.t("Имя узла не указано"));
        } else {
            _name = pathpart.substring(0, n);
            String s = pathpart.substring(n + 1);
            int n1 = s.indexOf(EasyXmlPath.DELIMITER_VALUE);
            if (n1 != -1) {
                // присутствует знак =, есть имя атрибута
                _attrName = s.substring(0, n1);
                _attrValue = s.substring(n1 + 1);
            } else {
                _attrName = EasyXmlPath.DEFAULT_ATTR_NAME;
                _attrValue = s;
            }
        }

    }

    /**
     * Имя узла
     */
    public String getName() {
        return _name;
    }

    /**
     * Имя атрибута
     */
    public String getAttrName() {
        return _attrName;
    }

    /**
     * Значение атрибута
     */
    public String getAttrValue() {
        return _attrValue;
    }

    /**
     * Проверка, что элемент пути является определением атрибута
     */
    public boolean isAttr() {
        return _name.length() == 0 && _attrName.length() != 0;
    }

    /**
     * Строковое представление элемента пути
     */
    public String toString() {
        String s = _name;
        if (_attrName.length() > 0) {
            if (!_attrName.equals(EasyXmlPath.DEFAULT_ATTR_NAME)) {
                s = s + EasyXmlPath.DELIMITER_ATTR + _attrName;
                if (_attrValue.length() > 0) {
                    s = s + EasyXmlPath.DELIMITER_VALUE + _attrValue;
                }
            } else {
                s = s + EasyXmlPath.DELIMITER_ATTR + _attrValue;
            }
        }
        return s;
    }

}