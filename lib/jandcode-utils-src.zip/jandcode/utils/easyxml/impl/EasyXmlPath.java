package jandcode.utils.easyxml.impl;

import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Путь EasyXml
 */
public class EasyXmlPath {

    public static final String DELIMITER_ATTR = "@";
    public static final String DELIMITER_VALUE = "=";
    public static final String DELIMITER_NODE = "/";
    public static final String DEFAULT_ATTR_NAME = "name"; //NON-NLS

    private ArrayList<EasyXmlPathItem> _items = new ArrayList<EasyXmlPathItem>();
    private String _attrName;

    public EasyXmlPath(String path) {
        doParse(path);
    }

    /**
     * Разбор пути
     *
     * @param path Путь
     */
    protected void doParse(String path) {
        try {
            if (path != null && path.length() > 0) {
                String[] ar = path.split(DELIMITER_NODE);
                for (int i = 0; i < ar.length; i++) {
                    String s = ar[i];
                    if (s.startsWith(DELIMITER_ATTR)) {
                        if (i != ar.length - 1) {
                            throw new RuntimeException(UtLang.t("Атрибут {0} должен быть последним в пути", _attrName));
                        }
                        if (s.length() < 2) {
                            throw new RuntimeException(UtLang.t("Имя атрибута не указано"));
                        }
                        _attrName = s.substring(1);
                    } else {
                        _items.add(new EasyXmlPathItem(s));
                    }
                }
            }
        } catch (Exception e) {
            throw new XErrorMark(e, "path [" + path + "]");
        }
    }

    /**
     * Элементы пути
     */
    public ArrayList<EasyXmlPathItem> getItems() {
        return _items;
    }

    /**
     * Имя атрибута в пути
     */
    public String getAttrName() {
        return _attrName == null ? "" : _attrName;
    }

    public void setAttrName(String attrName) {
        _attrName = attrName;
    }

    /**
     * Есть ли атрибут в пути
     */
    public boolean hasAttrName() {
        return _attrName != null && _attrName.length() > 0;
    }

    /**
     * Перевод в строку
     *
     * @param index       Начиная с узла
     * @param includeAttr Включать ли атрибут
     * @return Путь
     */
    public String toString(int index, boolean includeAttr) {
        StringBuilder sb = new StringBuilder();
        for (int i = index; i < _items.size(); i++) {
            if (i != index) {
                sb.append(DELIMITER_NODE);
            }
            sb.append(_items.get(i).toString());
        }
        if (hasAttrName()) {
            if (sb.length() > 0) {
                sb.append(DELIMITER_NODE);
            }
            sb.append(DELIMITER_ATTR);
            sb.append(getAttrName());
        }
        return sb.toString();
    }

    public String toString() {
        return toString(0, true);
    }

}