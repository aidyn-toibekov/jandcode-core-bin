package jandcode.utils;

/**
 * Поименнованный объект
 */
public interface INamed {

    String getName();

}
