package jandcode.wax.auth.action;

import jandcode.auth.*;
import jandcode.dbm.*;
import jandcode.wax.auth.utils.*;
import jandcode.web.*;

public class AuthAction extends WebAction {

    public void login() throws Exception {
        IUserInfo ui = (IUserInfo) getApp().service(ModelService.class).getModel().daoinvoke("WaxAuth_User", "auth/login",
                getParams().getValueString("name"), getParams().getValueString("passwd"));
        getApp().service(AuthService.class).setCurrentUser(ui);
        getSession().put(AuthFilter.SESSION_KEY_USERINFO, ui);
        getRequest().getOutWriter().write("ok");
    }

    public void logout() throws Exception {
        getApp().service(AuthService.class).setCurrentUser(null);
        getSession().put(AuthFilter.SESSION_KEY_USERINFO, null);
        getRequest().getOutWriter().write("ok");
    }

}
