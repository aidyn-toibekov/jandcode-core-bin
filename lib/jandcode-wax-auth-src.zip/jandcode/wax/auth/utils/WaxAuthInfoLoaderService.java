package jandcode.wax.auth.utils;

import jandcode.app.*;
import jandcode.auth.*;
import jandcode.dbm.*;
import org.apache.commons.logging.*;

import java.util.*;

public class WaxAuthInfoLoaderService extends CompRt implements IAppStartup {

    protected static Log log = LogFactory.getLog(WaxAuthInfoLoaderService.class);


    public void appStartup(Object appInstance) throws Exception {
        reloadAuthInfo();
    }

    public void reloadAuthInfo() throws Exception {
        AuthService svc = getApp().service(AuthService.class);
        log.info("reload roles");
        Collection<IRole> roles = (Collection<IRole>) getApp().service(ModelService.class).getModel().daoinvoke("WaxAuth_User", "auth/loadAllRoles");
        log.info("loaded " + roles.size() + " roles");
        svc.updateRoles(roles);
    }
}
