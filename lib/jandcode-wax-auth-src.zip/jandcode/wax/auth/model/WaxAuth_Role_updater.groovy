package jandcode.wax.auth.model

import jandcode.auth.*
import jandcode.dbm.dao.*
import jandcode.dbm.data.*
import jandcode.utils.*
import jandcode.wax.auth.utils.*

import jandcode.wax.core.model.WaxUpdaterDao

class WaxAuth_Role_updater extends WaxUpdaterDao {

    protected void deletePriv(long roleId) {
        ut.execSql("delete from WaxAuth_Role_Priv where role_id=:id", roleId)
    }

    protected void updatePriv(long roleId, String privsNames) {
        deletePriv(roleId)
        //
        def svc = app.service(AuthService)
        def privs = privsNames.split(",")
        for (pname in privs) {
            if (UtString.empty(pname)) continue;
            if (svc.getPrivs().find(pname) == null) continue;
            ut.insertRec("WaxAuth_Role_Priv", [role_id: roleId, priv_code: pname.toLowerCase()])
        }
        // перегружаем все роли
        svc.service(WaxAuthInfoLoaderService).reloadAuthInfo()
    }

    @DaoMethod
    long ins(DataRecord rec) {
        rec = ut.createRecord("WaxAuth_Role.edit", rec);
        //
        ut.validateRecord(rec, "ins");
        ut.checkErrors();
        //
        long id = ut.insertRec(ut.getTableName(), rec);
        updatePriv(id, rec.getValueString("privs"))
        return id
    }

    @DaoMethod
    void upd(DataRecord rec) {
        rec = ut.createRecord("WaxAuth_Role.edit", rec);
        //
        ut.validateRecord(rec, "upd");
        ut.checkErrors();
        //
        ut.updateRec(ut.getTableName(), rec);
        updatePriv(rec.getValueLong("id"), rec.getValueString("privs"))
    }

    @DaoMethod
    void del(long id) {
        onValidateDel(id);
        ut.checkErrors();
        //
        deletePriv(id)
        ut.deleteRec(ut.getTableName(), id);
    }

}
