package jandcode.wax.auth.model

import jandcode.dbm.dao.*
import jandcode.dbm.data.*
import jandcode.utils.*

import jandcode.wax.core.model.WaxListDao

class WaxAuth_User_list extends WaxListDao {

    @DaoMethod
    public DataStore load() throws Exception {
        DataStore t = ut.createStore();
        ut.loadSql(t, """
            select ${UtString.join(ut.fieldList(ut.tableName, "passwd"), ",")}
            from ${ut.tableName}
            where id>10
            order by id
        """);
        return t;
    }

    @DaoMethod
    DataRecord loadRec(long id) {
        DataRecord t = ut.createRecord();
        ut.loadSqlRec(t, """
            select ${UtString.join(ut.fieldList(ut.tableName, "passwd"), ",")} from ${ut.tableName} where id=:id
        """, id);
        return t;
    }


}
