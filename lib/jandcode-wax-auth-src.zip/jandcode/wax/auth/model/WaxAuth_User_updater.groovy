package jandcode.wax.auth.model

import jandcode.auth.*
import jandcode.dbm.dao.*
import jandcode.dbm.data.*
import jandcode.utils.*
import jandcode.utils.error.*

import jandcode.wax.core.model.WaxDao

class WaxAuth_User_updater extends WaxDao {

    protected void validatePassword(DataRecord t) {
        String p1 = t.getValueString("passwd");
        String p2 = t.getValueString("passwd2");
        //
        if (UtString.empty(p1)) {
            ut.getErrors().addError("Пароль не введен", "passwd");
            return;
        }
        if (p1 != p2) {
            ut.getErrors().addError("Пароли не совпадают", "passwd");
        }
    }

    protected void deleteRole(long userId) {
        ut.execSql("delete from WaxAuth_Role_User where user_id=:id", userId)
    }

    protected void updateRole(long userId, String roleIds) {
        deleteRole(userId)
        //
        def roles = roleIds.split(",")
        for (rid in roles) {
            def rid_num = UtCnv.toLong(rid)
            if (rid_num == 0) continue;
            ut.insertRec("WaxAuth_Role_User", [role_id: rid_num, user_id: userId])
        }
    }

    @DaoMethod
    public long ins(DataRecord data) throws Exception {
        DataRecord t = ut.createRecord("WaxAuth_User.edit", data);
        //
        ut.validateRecord(t, "ins");
        validatePassword(t)
        ut.checkErrors();
        //
        t.setValue("passwd", UtString.md5Str(data.getValueString("passwd")));
        long id = ut.insertRec(ut.getTableName(), t);
        updateRole(id, t.getValueString("roles"))
        return id
    }

    /**
     * Обновление всего, кроме пароля
     */
    @DaoMethod
    public void upd(DataRecord data) throws Exception {
        DataRecord t = ut.createRecord("WaxAuth_User.edit", data);
        //
        ut.validateRecord(t, "upd");
        ut.checkErrors();
        //
        ut.updateRec(ut.getTableName(), t, null, ['passwd', 'passwd2', 'roles']);
        updateRole(t.getValueLong("id"), t.getValueString("roles"))
    }

    /**
     * Вместо удаления делаем locked=true
     */
    @DaoMethod
    public void del(long id) throws Exception {
        //
        if (id < 11) throw new XError("Системного пользователя удалить нельзя");
        //
        ut.validateDelRef(ut.getTableName(), id);
        ut.checkErrors();
        //
        deleteRole(id)
        ut.deleteRec(ut.getTableName(), id);
    }

    /**
     * Обновить собственные данные. Для не админа.
     */
    @DaoMethod
    @Deprecated //todo пометить поля в таблице, которые пользователь может править сам или вообще это убрать
    public void updSelf(DataRecord data) throws Exception {
        DataRecord t = ut.createRecord(ut.getTableName(), data);
        ut.validateField(t, 'fullname')
        ut.checkErrors()
        ut.updateRec(ut.getTableName(), t, ['fullname']);
    }

    /**
     * Обновление пароля (из админки, не требуется старый пароль)
     */
    @DaoMethod
    public void updPasswd(DataRecord data) throws Exception {
        validatePassword(data);
        ut.checkErrors();
        //
        ut.updateRec(ut.getTableName(), [id: data.getValueLong("id"), passwd: UtString.md5Str(data.getValueString("passwd"))]);
    }

    //////

    @DaoMethod
    DataRecord loadRec(long id) {
        DataRecord t = ut.createRecord();
        ut.loadSqlRec(t, """
            select ${UtString.join(ut.fieldList(ut.tableName, "passwd"), ",")} from ${ut.tableName} where id=:id
        """, id);
        return t;
    }

    /**
     * Грузит дерево ролей с галочками для пользователя
     */
    @DaoMethod
    public DataTreeNode loadRoles(long userId) throws Exception {
        DataStore t = ut.createStore("WaxAuth_User.roletree");
        ut.loadSql(t, "select id, name as text, 0 as checked from WaxAuth_Role")
        if (userId > 0) {
            DataStore rp = ut.loadSql("select * from WaxAuth_Role_User where user_id=:id", userId)
            def tidx = UtData.createIndex(t, "id")
            for (r in rp) {
                def roleId = r.getValueString("role_id")
                def a1 = tidx.get(roleId)
                if (a1 != null) {
                    a1["checked"] = true
                }
            }
        }
        return UtData.createTreeIdParent(t, "id", "parent")
    }

    /**
     * Установить значение произвольного атрибута пользователя
     * @param userId пользователь
     * @param name имя атрибута
     * @param value если null, атрибут удаляется
     */
    @DaoMethod
    public void setUserAttr(long userId, String name, String value) {
        if (value == null) {
            ut.execSql("""
                delete from WaxAuth_UserAttrs
                where user_id=:id and name=:name
            """, [id: userId, name: name])
            return
        }
        DataStore curRec = ut.loadSql("""
            select id from WaxAuth_UserAttrs
            where user_id=:id and name=:name
        """, [id: userId, name: name])
        if (curRec.size() == 0) {
            // новое свойство
            ut.insertRec("WaxAuth_UserAttrs", [user_id: userId, name: name, value: value])
        } else {
            // существующее
            ut.updateRec("WaxAuth_UserAttrs", [id: curRec.getCurRec().getValue("id"), value: value])
        }
        def curUser = app.service(AuthService).getCurrentUser()
        if (curUser.id == userId) {
            curUser.getAttrs().put(name, value);
        }
    }

    /**
     * Установить значение произвольного атрибута пользователя
     * @param userId
     * @param name
     * @param value
     */
    @DaoMethod
    public String getUserAttr(long userId, String name) {
        DataStore curRec = ut.loadSql("""
            select id from WaxAuth_UserAttrs
            where user_id=:id and name=:name
        """, [id: userId, name: name])
        return curRec.getCurRec().getValueString("value")
    }

}
