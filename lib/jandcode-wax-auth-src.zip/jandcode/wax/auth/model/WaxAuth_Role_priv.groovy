package jandcode.wax.auth.model

import jandcode.auth.*
import jandcode.dbm.dao.*
import jandcode.dbm.data.*
import jandcode.utils.*

import jandcode.wax.core.model.WaxDao

/**
 * Привелегии роли
 */
class WaxAuth_Role_priv extends WaxDao {

    protected DataStore loadPrivs() {
        DataStore t = ut.createStore("WaxAuth_Role.privtree");
        def privs = app.service(AuthService).getPrivs();
        for (p in privs) {
            def exp = UtString.empty(p.parentName)
            t.add([id: p.name, parent: p.parentName, text: p.title, checked: false, expanded: exp])
        }
        return t
    }

    /**
     * Грузит пустое дерево привелегий
     */
    @DaoMethod
    public DataTreeNode loadEmptyTree() throws Exception {
        DataStore t = loadPrivs()
        return UtData.createTreeIdParent(t, "id", "parent")
    }

    /**
     * Грузит дерево привелегий с галочками для роли
     */
    @DaoMethod
    public DataTreeNode loadForRole(long roleId) throws Exception {
        DataStore t = loadPrivs()
        if (roleId > 0) {
            DataStore rp = ut.loadSql("select * from WaxAuth_Role_Priv where role_id=:id", roleId)
            def tidx = UtData.createIndex(t, "id")
            for (r in rp) {
                def privName = r.getValueString("priv_code")
                def a1 = tidx.get(privName)
                if (a1 != null) {
                    a1["checked"] = true
                }
            }
        }
        return UtData.createTreeIdParent(t, "id", "parent")
    }

}
