Ext.define('Jc.input.String', {
    extend: 'Ext.form.Text',
    requires: ['Jc.layout.Jctextfield'],
    componentLayout: 'jctextfield',

    /**
     * Имя поля из store
     */
    dataIndex: null,

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
    }

});
