/**
 * Ввод многоязыкового строкового поля
 */
Ext.define('Jc.input.Langstring', {
    extend: 'Jc.input.Cbfrm',

    constructor: function(config) {
        var th = this;
        var cfg = Ext.apply({
            directInput: true,
            triggerCls: 'jc-langstring-trigger',
            matchFieldWidth: false
        }, config);
        //
        var model = Jc.dbm.DataBinder.getModel(this);
        cfg.triggerWidth = model.langs.length * 14 + 10;  //todo это приблизительно и зависит от css...

        this.callParent([cfg]);
        //
        th.langMarkerBaseId = Ext.id() + "-";
        //
        th.on("render", function() {
            var trEl = this.triggerEl.elements[0];
            var b = '<div class="jc-langmarker-wrap">';
            Ext.each(model.langs, function(lang) {
                var cls = 'jc-langmarker';
                if (lang == model.lang) {
                    cls += ' jc-langmarker-valuecurrent';
                }
                b += Jc.format('<span id="{2}" class="{0}">{1}</span>', cls, lang, th.langMarkerBaseId + lang);
            });
            b += '</div>';
            trEl.dom.innerHTML = b;
            //
            this._updateLangMarkers(this.getValue());
        });
    },

    onCreateFrame: function() {
        var th = this;
        return Ext.create("Jc.input.Langstring__frame", {
            inputCfg: {jsclass: "String", width: th.getWidth()}
        });
    },

    onCollapse: function() {
        this.callParent(arguments);
        var fv = this.picker.getValue();
        this.setValue(fv);
    },

    /**
     * В качестве значения: {ru:'a',en:'b'...}
     */
    setValue: function(v) {
        if (!v) {
            this._value = {}
        } else if (Ext.isString(v)) {
            var model = Jc.dbm.DataBinder.getModel(this);
            this._value = {};
            this._value[model.lang] = v;
        } else {
            this._value = Ext.apply({}, v);
        }
        //
        var vv = Jc.lang.getCurLangValue(this._value, this);
        var s = vv.value;
        if (!s) s = "";
        //
        this.setRawValue(s);
        this.fireEvent("change", this, s, null);
        //
        this._updateLangMarkers(this._value);
    },

    getValue: function() {
        if (this._value == null) {
            this._value = {};
        }
        var model = Jc.dbm.DataBinder.getModel(this);
        this._value[model.lang] = this.getRawValue();
        var v = Ext.apply({}, this._value);
        return v;
    },

    _updateLangMarkers: function(v) {
        if (!this.rendered) {
            return;
        }
        var th = this;
        var cls = "jc-langmarker-valueexists";
        var model = Jc.dbm.DataBinder.getModel(this);
        Ext.each(model.langs, function(lang) {
            var z = v[lang];
            var el = Ext.fly(th.langMarkerBaseId + lang);
            if (!z) {
                el.removeCls(cls);
            } else {
                el.addCls(cls);
            }
        });
    },

    dataToControl: function() {
        var th = this;
        if (!th.dataIndex) return;
        //
        var v = Jc.lang.getLangDataFromRec(th, th.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.lang.setLangDataToRec(this, this.dataIndex, v);
    }

});

//////

/**
 * Фрейм для ввода значений многоязыкового поля.
 */
Ext.define('Jc.input.Langstring__frame', {
    extend: 'Jc.Frame',

    /**
     * Конфигурация input
     */
    inputCfg: null,

    onInit: function() {
        var th = this;
        th.model = Jc.dbm.DataBinder.getModel(th.pickerField);
        var b = th.createBuilder();
        Ext.apply(th, {
            layout: {type: 'jctable', columns: 2},
            title: "Значения для языков"
        });
        th.inputs = [];
        th.items = [];
        Ext.each(th.model.langs, function(lang) {
            var cfg = Ext.apply(th.inputCfg, {lang: lang});
            var lab = b.label(lang);
            var inp = b.input(null, cfg);
            th.inputs.push(inp);
            th.items.push(lab, inp);
        });

    },

    onSetChoiceValue: function(v, inpText) {
        var th = this;
        Ext.each(th.inputs, function(inp) {
            inp.setValue(v[inp.lang]);
        });
    },

    getValue: function() {
        var v = {};
        Ext.each(this.inputs, function(inp) {
            v[inp.lang] = inp.getValue();
        });
        return v;
    }


});