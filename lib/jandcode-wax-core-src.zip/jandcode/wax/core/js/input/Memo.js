Ext.define('Jc.input.Memo', {
    extend: 'Ext.form.TextArea',
    requires: ['Jc.layout.Jctextarea'],
    componentLayout: 'jctextareafield',

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
    }

});
