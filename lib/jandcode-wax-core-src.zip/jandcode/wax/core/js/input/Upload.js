/**
 * upload поле
 */
Ext.define('Jc.input.Upload', {
    extend: 'Ext.form.field.File',

    isUploadSupport: true,

    dataIndex: null,
    buttonText: '',

    _fieldForUpload: null,
    _idFile: null,

    constructor: function(config) {
        var th = this;
        var cfg = Ext.apply({
            enableKeyEvents: true
        }, config);
        //
        this.callParent([cfg]);
        //
        this.on('keydown', function(t, e) {
            if (e.getKey() == e.DELETE) {
                th._idFile = null;
                th._fieldForUpload = null;
                th.reset();
            }
        });
        //
        this.on('change', function() {
            this._fieldForUpload = this.extractFileInput();
        });
    },

    initComponent: function() {
        this.buttonConfig = {
            iconCls: Jc.iconCls("folder")
        };
        this.callParent(arguments);
    },

    dataToControl: function() {
    },

    controlToData: function() {
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, this._idFile);
    },

    //////

    /**
     * Собирает все поля upload и добавляет в массив arr элементы вида:
     * {owner: this, inp: INPUTFIELDDOM}
     */
    grabUploadFields: function(arr) {
        if (!this._fieldForUpload) return; // выбора не было
        var res = {
            owner: this,
            inp: this._fieldForUpload
        };
        arr.push(res);
    },

    uploadOk: function(inp) {
        if (this._fieldForUpload == null) return;
        this._fieldForUpload = null;
        this.inputEl.dom.value = UtLang.t("Загружен: {0}", this.inputEl.dom.value);
        this._idFile = inp.json.id;
    },

    extractFileInput: function() {
        var fileInput = this.button.fileInputEl.dom;
        var me = this;
        if (me.rendered) {
            me.button.reset(true);
            me.fileInputEl = me.button.fileInputEl;
        }
        return fileInput;
    }

});
