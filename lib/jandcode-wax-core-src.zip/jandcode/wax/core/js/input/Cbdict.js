Ext.define('Jc.input.Cbdict', {
    extend: 'Ext.form.field.ComboBox',

    requires: ['Jc.layout.Jctriggerfield'],
    componentLayout: 'jctriggerfield',

    constructor: function(config) {
        var th = this;
        var cfg = Ext.apply({
            queryMode: 'local',
            valueField: 'id',
            editable: false,
            enableKeyEvents: true
        }, config);
        //
        if (!cfg.dict) {
            var f = Jc.dbm.DataBinder.getField(cfg, cfg.dataIndex);
            if (!f || !f.dict) {
                throw new Error("field not have dict");
            }
            cfg.dict = f.dict;
        }
        //
        var model = Jc.dbm.DataBinder.getModel(cfg);
        if (!model) {
            throw new Error("dbm model not defined");
        }
        cfg.store = model.dict(cfg.dict);
        //
        if (!cfg.displayField) {
            // если явно поле для отображения не указано, берем из словаря поле по умолчанию
            cfg.displayField = cfg.store.domain.getDictDefaultField();
        }
        //
        this.callParent([cfg]);
        //
        this.on('keydown', function(t, e) {
            if (e.getKey() == e.DELETE) {
                th.clearValue();
            }
        });
    },

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
        // обновляем словарь в store, откуда поле редактируем
        var fs = Jc.dbm.DataBinder.getJcStore(this);
        if (fs) {
            var r = this.findRecordByValue(this.getValue());
            if (r) {
                fs.updateDict(this.dict, r);
            }
        }
    },

    /**
     * Текущая запись в словаре
     */
    getCurRec: function() {
        var fs = Jc.dbm.DataBinder.getJcStore(this);
        if (fs) {
            return this.findRecordByValue(this.getValue());
        }
        return null;
    }

});
