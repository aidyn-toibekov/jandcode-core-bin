Ext.define('Jc.input.Int', {
    extend: 'Jc.input.Number',

    initComponent: function() {
        this.allowDecimals = false;
        this.callParent(arguments);
    }

});
