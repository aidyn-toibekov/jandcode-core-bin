Ext.define('Jc.input.Date', {
    extend: 'Ext.form.field.Date',
    requires: ['Jc.layout.Jctriggerfield'],
    componentLayout: 'jctriggerfield',

    constructor: function(config) {
        var cfg = Ext.apply({
        }, config);
        this.onInitConfig(cfg);
        this.callParent([cfg]);
    },

    onInitConfig: function(cfg) {
        Ext.applyIf(cfg, {
            format: Jc.ini.dateFormat
        });
    },

    setValue: function(v) {
        if (v && Ext.isDate(v)) {
            if (Jc.isDateEmpty(v)) {
                v = null;
            }
        }
        return this.callParent([v]);
    },

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
    }

});
