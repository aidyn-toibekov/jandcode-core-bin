/**
 * combobox для выбора данных из произвольного store
 */
Ext.define('Jc.input.Cbstore', {
    extend: 'Ext.form.field.ComboBox',

    requires: ['Jc.layout.Jctriggerfield'],
    componentLayout: 'jctriggerfield',

    constructor: function(config) {
        var th = this;
        var cfg = Ext.apply({
            queryMode: 'local',
            valueField: 'id',
            editable: false,
            enableKeyEvents: true
        }, config);
        //
        if (!cfg.displayField) {
            // если явно поле для отображения не указано, берем 2-е поле из домена
            cfg.displayField = cfg.store.domain.fields[1].name;
        }
        //
        this.callParent([cfg]);
        //
        this.on('keydown', function(t, e) {
            if (e.getKey() == e.DELETE) {
                th.clearValue();
            }
        });
    },

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
    },

    /**
     * Текущая запись в словаре
     */
    getCurRec: function() {
        var fs = Jc.dbm.DataBinder.getJcStore(this);
        if (fs) {
            return this.findRecordByValue(this.getValue());
        }
        return null;
    }

});
