Ext.define('Jc.input.Number', {
    extend: 'Ext.form.field.Number',
    requires: ['Jc.layout.Jctriggerfield'],
    componentLayout: 'jctriggerfield',

    initComponent: function() {
        this.hideTrigger = true;
        this.callParent(arguments);
    },

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
    }

});
