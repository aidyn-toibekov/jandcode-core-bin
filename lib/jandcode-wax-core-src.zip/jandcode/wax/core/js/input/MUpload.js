/**
 * Мульти-upload файлов
 */
Ext.define('Jc.input.MUpload', {
    extend: 'Jc.control.Grid',
    requires: ['Jc.jquery.Plupload'],

    isUploadSupport: true,

    _onOkUploadCallback: null,
    _onErrorUploadCallback: null,
    _cnt: 0,

    initComponent: function() {
        var th = this;
        //
        if (!th.height) {
            th.height = 120;
        }
        th.hideHeaders = true;
        //
        var dm = Jc.createDomain("sys", {
            fields: [
                {name: "id"},
                {name: "file"},
                {name: "stat"}
            ]
        });
        var store = th.store = dm.createStore({});
        //
        var b = Jc.app.createBuilder(store);
        th.columns = [
            b.column('file', {title: 'Файл', jsclass: 'Icontext', icon: 'false', flex: 1,
                onTextCell: function(v) {
                    return v.name;
                },
                onIconCell: function(v) {
                    if (v.status != plupload.DONE) {
                        return "false";
                    } else {
                        return "true";
                    }
                }
            }),
            b.column('stat', {title: 'Размер', width: 85, onRenderCell: function(v, m, r) {
                v = r.get('file');
                if (v.status == plupload.UPLOADING) {
                    return v.percent + "%"
                } else {
                    return plupload.formatSize(v.size);
                }
            }})
        ];
        //
        th.tbar = [
            th.b_add = b.button({text: 'Добавить файлы', icon: 'ins', href: '#', target: '_self', handler: function() {
            }}),
            b.action({text: 'Удалить файл', icon: 'del', onExec: function() {
                var r = th.getCurRec();
                if (!r) return;
                th.uploader.removeFile(r.get('file'));
                th.store.remove(r);
            }})
        ];
        //
        this.callParent();
        //
        th.on('afterrender', function() {
            th.initUploader();
        });
    },

    initUploader: function() {
        var th = this;
        //
        var uploader = th.uploader = new plupload.Uploader({
            runtimes: 'gears,html5,flash,silverlight,html4',
            browse_button: th.b_add.getActionEl().id,
            container: th.id,
            url: Jc.url('dbm/upload'),
            multipart_params: {},
            file_data_name: 'fileitem',
            flash_swf_url: Jc.url('js/jquery/plupload/plupload.flash.swf'),
            silverlight_xap_url: Jc.url('js/jquery/plupload/plupload.silverlight.xap')
        });
        //
        uploader.init();
        //
        uploader.bind('FilesAdded', function(up, files) {
            $.each(files, function(i, file) {
                var r = th.store.add({id: file.id, file: file});
            });
            up.refresh(); // Reposition Flash/Silverlight
        });
        //multipart_params
        uploader.bind('BeforeUpload', function(up, file) {
            uploader.settings.multipart_params['fileitem_name'] = Ext.encode({name: file.name});
        });
        //
        uploader.bind('FileUploaded', function(up, file, resp) {
            var json = Ext.decode(resp.response);
            if (json.success) {
                file.dbm_id = json.id;
            } else {
                Jc.error(new Jc.Error({err: json, type: 'json'}));
            }
        });
        //
        uploader.bind('UploadComplete', function(up, files) {
            if (th._onOkUploadCallback) {
                th._onOkUploadCallback();
            }
        });
        //
        uploader.bind('Error', function(up, err) {
            if (th._onErrorUploadCallback) {
                th._onErrorUploadCallback(err);
            }
        });
        //
        uploader.bind('UploadProgress', function(up, file) {
            var r = th.store.getById(file.id);
            if (!r) return;
            th.setCurRec(r);
            th._cnt++;
            r.set('stat', th._cnt);
        });
    },

    controlToData: function() {
        var s = '';
        Ext.each(this.uploader.files, function(f) {
            if (f.dbm_id) {
                if (s != '') {
                    s += ',';
                }
                s += f.dbm_id;
            }
        });
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, s);
    },

    ////// dbm upload interface

    /**
     * Собирает все поля upload и добавляет в массив arr элементы вида:
     * {owner: this, inp: INPUTFIELDDOM}
     */
    grabUploadFields: function(arr) {
        var th = this;
        //
        var need = false;
        Ext.each(th.uploader.files, function(f) {
            if (f.status != plupload.DONE) {
                need = true;
                return false;
            }
        });
        if (!need) return;
        //
        var res = {
            owner: this,
            handler: function(config) {
                th._onOkUploadCallback = config.onOk;
                th._onErrorUploadCallback = config.onError;
                th.uploader.start();
            }
        };
        arr.push(res);
    }

});
