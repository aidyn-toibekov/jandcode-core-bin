Ext.define('Jc.input.Password', {
    extend: 'Jc.input.String',

    initComponent: function() {
        this.inputType = 'password';
        //
        this.callParent(arguments);
    }

});
 