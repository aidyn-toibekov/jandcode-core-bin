Ext.define('Jc.input.Checkbox', {
    extend: 'Ext.form.field.Checkbox',

    constructor: function(config) {
        if (config) {
            if (config.value !== undefined) {
                config.checked = config.value;
            }
        }
        this.callParent(arguments);
    },

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        v = Jc.toBoolean(v);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
    }

});
