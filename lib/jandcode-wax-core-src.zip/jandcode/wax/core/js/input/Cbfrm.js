/**
 * Выбор из произвольной формы
 *
 * Что для этого нужно:
 *
 * у Cbfrm перекрыть методы:
 *  onGetDisplayText(v) -> для v нужно вернуть текст, который будет показан в поле
 *  onCreateFrame() -> создать фрейм, который будет выпадать
 *      у этого фрейма перекрыть методы:
 *          onSetChoiceValue(v, inpText) -> ориентировать компоненты на отображение значения v
 *                                 (например установить позицию в гриде)
 *      у этого фрейма в какой то момент (например на двойном щелчке на гриде)
 *      вызвать метод choice(v), где v - выбранное значение
 *
 * Если для фрейма (или для компонента Cbfrm) установить свойство pickerAlign=null (или pickerAlign='c-c'),
 * то всплывающее окно будет распологаться по центру экрана.
 * Используется для достаточно больших окон, размер которых превышает половину экрана.
 *
 * Если для фрейма не установлена ширина, то она выбирается как размер input
 *
 * Если для фрейма не установлена высота, и ее нельзя определеить автоматом, она выставляется
 * в пол экрана. Для центрированного вывода - в экран. С небольшими границами.
 */
Ext.define('Jc.input.Cbfrm', {
    extend: 'Ext.form.field.Picker',

    /**
     * Имя поля из store
     */
    dataIndex: null,

    /**
     * Имя словаря, откуда будут браться значения для displayText.
     * Если не указан, берется из поля.
     */
    dict: null,

    /**
     * Поле словаря для отображения. Если не указано, используется поле по умолчанию
     * из словаря.
     */
    dictfield: null,

    /**
     * Очищать значение при нажатии DEL
     */
    clearOnDel: true,

    /**
     * При true поле ввода ведет себя как обычное поле ввода
     */
    directInput: false,

    /**
     * Выпадающий фрейм. Либо имя фрейма (класс или путь),
     * либо конфигурация для Jc.showFrame. Если не задано, то фрейм
     * создается в onCreateFrame
     */
    frame: null,

    ///
    _value: null,
    _lastInpText: '',
    _defaultFrameTitle: 'Выбор значения',

    constructor: function(config) {
        var th = this;
        var cfg = Ext.apply({
            enableKeyEvents: true,
            matchFieldWidth: true    //! без true по умолчанию плывет все
        }, config);
        //
        this.callParent([cfg]);
        //
        this.on('keydown', function(t, e) {
            if (!th.directInput) {
                if (th.clearOnDel) {
                    if (e.getKey() == e.DELETE) {
                        th.setValue(null);
                        return;
                    }
                }
                if (e.isSpecialKey()) {
                    e.stopEvent();
                    return;
                }
            }
        });
        //
        this.on('keypress', function(t, e) {
            if (!th.directInput) {
                if (!th.isExpanded) {
                    var c = String.fromCharCode(e.getCharCode());
                    th._lastInpText = th._lastInpText + c;
                    e.stopEvent();
                    th.expand();
                }
            }
        });
        //
    },

    expand: function() {
        var th = this;
        if (th.frame && !th.picker) {
            var sfc = th.getShowFrameConfig();
            sfc.onShowFrame = function(f, showConfig) {
                th.picker = f;
                th.createPicker();
                Jc.input.Cbfrm.superclass.expand.call(th);
            };
            Jc.showFrame(sfc);
            return;
        }
        Jc.input.Cbfrm.superclass.expand.call(th);
    },

    onExpand: function() {
        this.picker.toFront();
        var inpText = this._lastInpText;
        this._lastInpText = '';
        this.picker.setChoiceValue(this.getValue(), inpText);
        this.setEditable(false);
    },

    onCollapse: function() {
        this.callParent(arguments);
        this.setEditable(true);
    },

    dataToControl: function() {
        if (!this.dataIndex) return;
        //
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    },

    controlToData: function() {
        var v = this.getValue();
        Jc.dbm.DataBinder.setFieldValue(this, this.dataIndex, v);
    },

    getValue: function() {
        return this._value;
    },

    setValue: function(v) {
        var oldValue = this._value;
        this._value = v;
        if (oldValue != this._value) {
            this.setRawValue(this.getDisplayText(v));
            this.fireEvent("change", this, this._value, oldValue);
        }
    },

    getDisplayText: function(v) {
        if (!v) {
            return "";
        }
        return this.onGetDisplayText(v);
    },

    onGetDisplayText: function(v) {
        var th = this;
        if (th.getDict()) {
            return th.getDictValue(v);
        }
        return v;
    },

    getDictValue: function(v) {
        var th = this;
        if (!th.tempStore) {
            th.tempStore = Jc.createStore("id");
            th.tempStore.domain.fields[0].dict = th.getDict();
            th.tempStore.add({});
        }
        th.tempStore.getCurRec().set("id", v);
        th.tempStore.getCurRec().resolveDicts();
        return th.tempStore.getCurRec().getDictValue("id", th.dictfield);
    },

    /**
     * Словарь, используемый для показа значения в input
     */
    getDict: function() {
        if (this.dict) return this.dict;
        var field = Jc.dbm.DataBinder.getField(this, this.dataIndex);
        if (!field) return null;
        return field.dict;
    },

    createPicker: function() {
        var th = this;
        var f = th.onCreateFrame();
        if (!f) {
            Jc.error(UtLang.t("onCreateFrame должен возвращать frame"));
        }
        Ext.apply(f, {
            enableKeyEvents: true,
            pickerField: th,
            renderTo: Ext.getBody(),
            floating: true,
            hidden: true,
            focusOnToFront: true,
            closable: false,
            border: true,
            header: true
        });

        if (!f.title) {
            f.title = th._defaultFrameTitle;
        }

        f.tools = [
            {
                type: 'minimize',
                tooltip: 'Скрыть',
                handler: function(event, toolEl, panel) {
                    th.collapse();
                }
            }
        ];

        // свойства из content (или фрейма)
        var cf = f.getContentControl();
        if (cf.pickerAlign !== undefined) {
            th.pickerAlign = cf.pickerAlign;
        }

        // size
        if (f.width) {
            f.minWidth = f.width;
            delete f.width;
        }
        if (!f.height) {
            if (Jc.isFitLayout(f)) {
                var bs = Ext.getBody().getViewSize();
                f.height = bs.height - 20 * 2;
                if (!(!this.pickerAlign || this.pickerAlign == "c-c")) {
                    f.height = f.height / 2;
                }
            }
        }

        // надо...
        f.ownerCt = th.ownerCt;

        // toolbar из фрейма
        var tb = [
        ];
        if (f.toolbar) {
            tb.push(f.toolbar);
            f.toolbar = null;
        }

        // если toolbar есть, ставим ее
        var tbCtrl;
        if (tb.length > 0) {
            tbCtrl = Ext.create("Ext.toolbar.Toolbar", {
                dock: 'top',
                cls: 'jc-cbfrm-toolbar',
                items: tb
            });
            f.addDocked(tbCtrl);
        }

        f.on("choice", function(frame, value, text) {
            th.collapse();
            th.setValue(value);
        });

        f.on("keydown", function(t, e) {
            if (e.getKey() == e.ESC) {
                th.collapse();
            }
        });

        f.on("render", function() {
            f.getKeyMap().on(27, function() {
                th.collapse();
            });
        });

        f.on("toolbarchange", function(fr) {
            if (tbCtrl) {
                tbCtrl.removeAll();
                if (fr.toolbar) {
                    tbCtrl.add(fr.toolbar);
                }
            } else {
                if (fr.toolbar) {
                    tbCtrl = Ext.create("Ext.toolbar.Toolbar", {
                        dock: 'top',
                        cls: 'jc-cbfrm-toolbar',
                        items: fr.toolbar
                    });
                    f.addDocked(tbCtrl);
                }
            }
            fr.toolbar = null;
        });

        f.on("titlechange", function(fr, newTitle) {
            if (!newTitle) {
                fr.setTitle(th._defaultFrameTitle);
            }
        });

        return f;
    },

    onCreateFrame: function() {
        if (this.frame) {
            if (!this.picker) {
                Jc.error("picker not created!");
            }
            return this.picker;
        } else {
            // по умолчанию создается примитивный фрейм для ручного ввода id...
            var f = Ext.create("Jc.Frame", {
                layout: {type: 'jctable', columns: 1},
                items: [
                    {xtype: 'label', text: UtLang.t("onCreateFrame не переопределен, введите значение:")},
                    {xtype: 'textfield', itemId: "inp1",
                        enableKeyEvents: true,
                        listeners: {
                            keydown: function(t, e) {
                                if (e.getKey() == e.ENTER) {
                                    f.choice(t.getValue());
                                }
                            }
                        }
                    }
                ],
                onSetChoiceValue: function(v, inpText) {
                    var inp = this.getComponent("inp1");
                    inp.setValue(v);
                }
            });
            return f;
        }
    },

    /**
     * Возвращает конфигурацию для Jc.showFrame, если фрейм задан в свойстве frame
     */
    getShowFrameConfig: function() {
        var th = this;
        var cfg = {
            local: {
                pickerField: th  // для gf-фреймов ссылка для onInit
            }
        };
        if (Ext.isString(th.frame)) {
            cfg.frame = th.frame;
        } else {
            Ext.apply(th.frame);
        }
        return cfg;
    },

    fixPickerSize: function(useHalfHeight) {
        var comp = this.picker;
        //
        var w = comp.getWidth();
        var h = comp.getHeight();
        //
        var bs = Ext.getBody().getViewSize();
        // границы по x и y
        var spX = 20;
        var spY = 20;

        bs.width = bs.width - spX * 2;
        bs.height = bs.height - spY * 2;

        var needFix = false;
        if (w > bs.width) {
            w = bs.width;
            needFix = true;
        }
        if (h > bs.height) {
            if (useHalfHeight) {
                h = bs.height / 2;
            } else {
                h = bs.height;
            }
            needFix = true;
        }

        if (needFix) {
            if (comp.minWidth > w) {
                comp.minWidth = w;
            }
            if (comp.minHeight > h) {
                comp.minHeight = h;
            }
            comp.setWidth(w);
            comp.setHeight(h);
        }

        return needFix;
    },

    doAlign: function() {
        if (!this.pickerAlign || this.pickerAlign == "c-c") {
            this.fixPickerSize(false);
            this.picker.alignTo(Ext.getBody(), "c-c");
            return;
        }
        this.fixPickerSize(true);
        this.callParent(arguments);
    },

    getZIndexForDom: function(z) {
        while (z && z.nodeName != "BODY" && z.nodeName != 'body') {
            var r = z.style.zIndex;
            if (r) return r;
            z = z.parentNode;
        }
        return 0;
    },

    collapseIf: function(e) {
        var tzi = this.getZIndexForDom(e.getTarget());
        var mytzi = this.getZIndexForDom(this.picker.getEl().dom);
        if (tzi < mytzi) {
            this.callParent(arguments);
        }
    },


    triggerBlur: function() {
        // иммено так!
        if (!this.isExpanded) {
            this.callParent(arguments);
        }
    },

    mimicBlur: function(e) {
        // иммено так!
        if (!this.isExpanded) {
            this.callParent(arguments);
        }
    }

});
