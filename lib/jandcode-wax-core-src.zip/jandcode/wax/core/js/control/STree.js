/**
 * STree. Расширенное tree с плюшками.
 */
Ext.define("Jc.control.STree", {
    extend: 'Jc.control.Tree',

    mixins: {
        smixingrid: 'Jc.control.SMixinGrid'
    },

    _istree: true,

    initComponent: function() {
        this.mixins.smixingrid._doInit.apply(this);
        this.callParent(arguments);
    }


});