/**
 * Иконка
 */
Ext.define('Jc.control.Icon', {
    extend: 'Ext.Component',

    isFocusable: false,

    autoEl: 'img',

    iconUrl: null,
    iconType: '32',
    icon: null,

    initComponent: function() {
        this.minHeight = parseInt(this.iconType);
        this.minWidth = parseInt(this.iconType);
        this.iconUrl = Jc.iconUrl(this.icon, this.iconType);
        this.callParent(arguments);
    },

    getElConfig: function() {
        var th = this;
        var cfg = th.callParent();
        cfg.src = th.iconUrl;
        return cfg;
    },

    // null out this function, we can't set any html inside the image
    initRenderTpl: Ext.emptyFn,

    setIcon: function(src) {
        var th = this;
        var img = th.el;
        this.iconUrl = Jc.iconUrl(th.icon, th.iconType);
        if (img) {
            img.dom.src = this.iconUrl;
        }
    }

});
