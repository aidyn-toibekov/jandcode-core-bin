/**
 * Предок для грид
 */
Ext.define('Jc.control.Grid', {
    extend: 'Ext.grid.Panel',

    constructor: function(config) {
        var th = this;
        //
        var cfg = Ext.apply({
            autoScroll: true,
            containerScroll: true, //todo хз
            columnLines: true
        }, config);
        //
        if (!cfg.viewConfig) {
            cfg.viewConfig = {};
        }
        if (cfg.viewConfig.stripeRows === undefined) cfg.viewConfig.stripeRows = false;
        if (cfg.viewConfig.loadMask === undefined) cfg.viewConfig.loadMask = false;
        if (cfg.viewConfig.trackOver === undefined) cfg.viewConfig.trackOver = Jc.ini.grid.trackOver;
        //
        this.callParent([cfg]);
        //
        this.on('cellclick', function(v, td_el, colIdx, rec, tr_el, rowIdx, e) {
            var col = th.columns[colIdx];
            if (col.clickCell) {
                col.clickCell(rec, e);
            }
        });
    },

    setCurRec: function(r) {
        this.getSelectionModel().deselectAll(false);
        if (r || r==0) {
            this.getSelectionModel().select(r);
        }
    },

    getCurRec: function() {
        var r = this.getSelectionModel().getSelection();
        if (!r) return null;
        return r[0];
    },

    /**
     * Для store устанавливает такую же текущую запись, как стоит у grid.
     * Возвращает установленную запись.
     */
    syncCurRec: function() {
        var r = this.getCurRec();
        if (!r) return null;
        this.store.setCurRec(r);
        return r;
    },

    ////// direct update. Используется при редактировании гриду через диалоги

    /**
     * Вставить запись из from (store, rec, data)
     */
    insRec: function(from) {
        var data = Jc.dbm.DataBinder.getRecData(from);
        if (!data) return;
        this.store.suspendEvents(true);
        try {
            var recs = this.store.add(data);
            if (recs.length > 0) {
                recs[0].resolveDicts();
            }
        } finally {
            this.store.resumeEvents();
        }
        //this.store.fireEvent('datachanged', this.store);   //todo: 4.2. не факт что события нужны
        //this.store.fireEvent('refresh', this.store);
        this.setCurRec(recs[0]);
    },

    /**
     * Удалить текущую запись.
     */
    delRec: function() {
        var r = this.getCurRec();
        if (!r) return;
        this.store.remove(r);
    },

    /**
     * Изменить текущую запись
     * @param from откуда (store, record, data)
     */
    updRec: function(from) {
        var r = this.getCurRec();
        if (!r) return;
        var data = Jc.dbm.DataBinder.getRecData(from);
        if (!data) return;
        this.store.suspendEvents(true);
        try {
            r.set(data);
            r.resolveDicts();
        } finally {
            this.store.resumeEvents();
        }
        this.setCurRec(r);
        //this.store.fireEvent('datachanged', this.store); //todo: 4.2. не факт что события нужны
        //this.store.fireEvent('refresh', this.store);
    }

    //////

});

