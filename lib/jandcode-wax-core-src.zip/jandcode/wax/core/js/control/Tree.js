/**
 * Дерево
 */
Ext.define('Jc.control.Tree', {
    extend: 'Ext.tree.Panel',

    constructor: function(config) {
        var cfg = Ext.apply({
            useArrows: true,
            animate: false,
            rootVisible: false
        }, config);
        //
        if (!cfg.viewConfig) {
            cfg.viewConfig = {};
        }
        if (cfg.viewConfig.loadMask === undefined) cfg.viewConfig.loadMask = false;
        if (cfg.viewConfig.trackOver === undefined) cfg.viewConfig.trackOver = Jc.ini.grid.trackOver;
        //
        this.callParent([cfg]);
    },

    setCurRec: function(r) {
        if (r.getPath) {
            this.selectPath(r.getPath());
        } else {
            this.getSelectionModel().select(r);
        }
    },

    getCurRec: function() {
        var r = this.getSelectionModel().getSelection();
        if (!r) return null;
        return r[0];
    },

    /**
     * Для store устанавливает такую же текущую запись, как стоит у grid.
     * Возвращает установленную запись.
     */
    syncCurRec: function() {
        var r = this.getCurRec();
        if (!r) return null;
        this.store.setCurRec(r);
        return r;
    }

});
 