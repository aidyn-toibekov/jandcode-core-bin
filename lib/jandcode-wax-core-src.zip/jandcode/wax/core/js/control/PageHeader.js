/**
 * Заголовок с иконкой (или без) для страниц
 */
Ext.define('Jc.control.PageHeader', {
    extend: 'Ext.Component',

    baseCls: 'jc-pageheader',

    renderTpl: [
        '<div class="{baseCls} {baseCls}-{th.iconType}">',
        '  <tpl if="th.icon"><div class="{baseCls}-icon-wrap"><img class="{baseCls}-icon" src="{iconUrl}"></div></tpl>',
        '  <div class="{baseCls}-text">{th.text}</div>',
        '</div>'
    ],

    isFocusable: false,

    /**
     * Тип иконки. Для разных типов можно настраивать разные css: .jc-pageheader-ICONTYPE
     */
    iconType: '32',
    icon: null,
    text: "",

    initComponent: function() {
        var th = this;
        th.minHeight = parseInt(this.iconType);
        th.minWidth = parseInt(this.iconType) + 20;
        Ext.applyIf(th.renderSelectors, {
            textEl: '.' + th.baseCls + '-text',
            iconEl: '.' + th.baseCls + '-icon'
        });
        if (th.title) {
            th.text = th.title
        }
        this.callParent(arguments);
    },

    initRenderData: function() {
        var cfg = {
            th: this
        };
        if (this.icon) {
            cfg.iconUrl = Jc.iconUrl(this.icon, this.iconType);
        }
        return Ext.applyIf(this.callParent(), cfg);
    },

    setText: function(s) {
        this.text = s;
        if (this.rendered) {
            this.textEl.dom.innerHTML = s;
        }
    }

});
 