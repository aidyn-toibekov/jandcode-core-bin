/**
 * Панель с поддержкой dataToControl/controlToData
 */
Ext.define('Jc.control.Panel', {
    extend: 'Ext.Panel',

    isFocusable: false,

    dataToControl: function() {
        Jc.dataToControlChilds(this);
    },

    controlToData: function() {
        Jc.controlToDataChilds(this);
    }

});
