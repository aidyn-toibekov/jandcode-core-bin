/**
 * Разделитель для частей формы
 */
Ext.define('Jc.control.Delim', {
    extend: 'Ext.Component',

    isFocusable: false,

    initComponent: function() {
        this.html = '<div class="jc-delim"><div class="jc-delim-title">' + this.title + '</div></div>';
        this.callParent(arguments);
    }

});
