/**
 * Контейнер для группировки компонентов на фрейме.
 * Есть поддержка dataToControl/controlToData
 */
Ext.define('Jc.control.Box', {
    extend: 'Ext.container.Container',

    isFocusable: false,

    dataToControl: function() {
        Jc.dataToControlChilds(this);
    },

    controlToData: function() {
        Jc.controlToDataChilds(this);
    }

});
