/**
 * mixin для SGrid и STree. Общая функциональность.
 *
 * Предназначено для показа store, который грузится из dao c одним параметром - map.
 * На входе подается store полностью настроенное.
 * У store:
 *  daoname, daomethod, daoparams(=MAP!)
 *  filterDomain - имя домена для фильтра. Если нету, берется 'id'
 */
Ext.define("Jc.control.SMixinGrid", {

    /**
     * Если true - то грида может делать refresh записи. В этом случае в dao должен быть
     * реализован метод loadRec
     */
    refreshRec: false,

    /**
     * Если true - то грида делает полный refresh при попытке сделать
     * refresh записи
     */
    refreshStore: false,

    /**
     * store c фильтром. Создается автоматически по свойству filterDomain у store.
     * Используется как средство ввода данных фильтра.
     * Изначально будет содержать данные из store.daoparams
     */
    //filterStore: null,

    /**
     * Показывать toolbar с пагинацией. В этом случае метод load тоже должен
     * поддерживать пагинацию
     */
    paginate: false,

    /**
     * action, которая выполнится по двойному щелчку на записи
     */
    dblclickAction: 'view',

    /**
     * Варианты сортировок. Массив вида:
     * [{name: "name", title: "По имени"},{name: "fullName", title: "По полному имени"}]
     * Свойство name определяет имя сортировки, которое сервер интерпретирует нужным ему образом.
     */
    orderBy: null,

    //////

    /**
     * Инициализация. Вызывается из соответствующего компонента.
     * До initComponent
     * @private
     */
    _doInit: function() {
        var th = this;
        //
        var b = Jc.app.createBuilder({frame: this, store: th.store});
        //
        th._bindStore(b);

        if (Ext.isFunction(th.columns)) {
            th.columns = th.columns(b);
        }
        if (!Ext.isArray(th.columns)) {
            Jc.error('grid: columns is not array');
        }

        // paginate
        if (th.paginate) {
            th.bbar = Ext.create('Ext.toolbar.Paging', {
                store: th.store,
                displayInfo: true
            });
        }

        //
        if (th._istree) {
            th.viewConfig.toggleOnDblClick = false;
            if (th.columns.length > 1) {
                th.rowLines = true;
                th.columnLines = true;
            }
        }

        //
        th.on('itemdblclick', function() {
            if (!th.getCurRec()) return;
            // по двойному клику запускаем action view
            Jc.execAction(th, th.dblclickAction);
        });

        //
        if (th.filterPanel) {
            th._filterToolbar = Ext.create('Jc.control.SGridFilterToolbar', {
                dock: 'top',
                grid: th
            })
        }

        // далее builder настраиваем на filterStore
        b.store = th.filterStore;

        // actions
        var actionsItems = [];
        var a;
        if (th.tbar) {
            if (!Ext.isArray(th.tbar)) {
                Jc.error('grid: tbar not array');
            }
            Ext.Array.push(actionsItems, th.tbar);
            delete th.tbar;
        }
        if (th.actions) {
            a = th.actions;
            if (Ext.isFunction(a)) {
                a = a(b)
            }
            if (!Ext.isArray(a)) {
                Jc.error('grid: actions not array');
            }
            Ext.Array.push(actionsItems, a);
            delete th.actions;
        }

        // sys actions
        var sysActionsItems = [];

        // варианты сортировок
        th._currentOrderBy = null;
        if (th.orderBy) {
            if (!Ext.isArray(th.orderBy)) {
                th.orderBy = [th.orderBy];
            }
            th._currentOrderBy = th.orderBy[0].name;
            if (th.orderBy.length > 1) {
                // несколько вариантов, создаем кнопки
                var ordcfg = {text: th.orderBy[0].title, icon: 'sort', itemId: 'orderBy', menu: []};
                Ext.each(th.orderBy, function(z) {
                    ordcfg.menu.push(b.action({text: z['title'], icon: 'sort', cs: z,
                        onExec: function(a) {
                            var x = Jc.getComponent(th, 'orderBy');
                            x.setText(a.cs.title);
                            th._changeOrderBy(a.cs.name);
                        }
                    }));
                });
                sysActionsItems.push(b.action(ordcfg));
            }
        }

        if (sysActionsItems.length > 0) {
            actionsItems.push('->');
            actionsItems.push(sysActionsItems);
        }

        //
        if (actionsItems.length > 0) {
            th._mainToolbar = Ext.create('Ext.Toolbar', {
                itemId: 'mainToolbar',
                dock: 'top',
                items: actionsItems
            });
        }

        // создаем toolbars
        if (!th.dockedItems) {
            th.dockedItems = [];
        }
        // main toolbar всегда сверху
        if (th._mainToolbar) {
            Ext.Array.insert(th.dockedItems, 0, [th._mainToolbar]);
        }
        // filter toolbar всегда снизу
        if (th._filterToolbar) {
            th.dockedItems.push(th._filterToolbar);
        }
    },

    /**
     * Настройка store
     */
    _bindStore: function(b) {
        var th = this;

        if (!th.store) {
            Jc.error("grid: store not assigned");
        }

        // определяем домен для фильтра
        var filterDomainName = "id";
        if (th.store.filterDomain) {
            filterDomainName = th.store.filterDomain;
        }

        // создаем store для фильтра
        th.filterStore = b.createStore(filterDomainName);
        th.filterStore.add();

        // daoparams из store используем как данные фильтра по умолчанию
        th.defaultFilterData = {};
        if (th.store.daoparams && Ext.isArray(th.store.daoparams) && th.store.daoparams.length > 0) {
            Ext.apply(th.defaultFilterData, th.store.daoparams[0]);
            th.filterStore.getCurRec().set(th.store.daoparams[0]);
        }

        // если есть информация о фильтре - обновляем ее
        th._updateFilterInfo();

        //
        th.store.on("load", function() {
            // обновляем информацию о фильтре после загрузки данных
            th._updateFilterInfo();
        });

        //
        th.store.on("beforeload", function(st, op) {

            // ставим сортировку для фильтра на сервере
            th.filterStore.set("orderBy", th._currentOrderBy);

            // автопараметры передаем через фильтр
            if (!Ext.isEmpty(op.start)) {
                th.filterStore.set("start", op.start);
            }
            if (!Ext.isEmpty(op.limit)) {
                th.filterStore.set("limit", op.limit);
            }
            if (th._istree && !Ext.isEmpty(op.id, true)) {
                th.filterStore.set("node", op.id);
            }

            // формируем параметры
            th.store.daoparams = [th.filterStore.getCurRec().getValues()];
        });
        //

    },

    _updateFilterInfo: function(info) {
        var th = this;
        if (!th._filterToolbar) return;
        //
        if (!info) info = th.store.clientdata.filterText;
        if (!info) info = '';
        //
        th._filterToolbar.updateFilterInfo(info);
    },

    /**
     * Изменить порядок сортировки
     */
    _changeOrderBy: function(orderByName) {
        this._currentOrderBy = orderByName;
        this.reload();
    },

    //////

    controlToData: function() {
        Jc.controlToDataChilds(this);
    },

    dataToControl: function() {
        Jc.dataToControlChilds(this);
    },

    /////

    /**
     * Очистить данные фильтра
     * @param doReload при значении false - не происходит перезагрузка гриды
     */
    clearFilter: function(doReload) {
        this.filterStore.getCurRec().clearValues();
        this.filterStore.getCurRec().set(this.defaultFilterData);
        this.dataToControl();
        if (doReload !== false) {
            this.reload();
        }
    },

    /**
     * Перезагрузка данных в гриде
     */
    reload: function() {
        if (this._istree) {
            this.store.load({node: this.store.root});
        } else {
            this.store.loadPage(1);
        }
    },

    /**
     * Загрузка одной записи с сервера по id.
     * Асинхронная!
     * @param id id загружаемой записи
     * @param onOk callback функция. Параметр - загруженная запись.
     */
    loadRec: function(id, onOk) {
        var th = this;
        if (!th.refreshRec) {
            Jc.error("SGrid не поддерживает refreshRec");
        }
        var refreshStore = th.store.domain.createStore({
            daoname: th.store.daoname,
            daomethod: 'loadRec',
            daoparams: [id]
        });
        refreshStore.load(function(records, operation, ok) {
            if (records.length > 0) {
                if (onOk) {
                    onOk(records[0]);
                }
            } else {
                Jc.error("Не получена запись #" + id);
            }
        });
    },

    /**
     * Вставляет запись в гриду.
     * @param r запись (record или map). Если поддерживается refresh то для id записи
     * загружается новая запись с сервера, иначе добавляется новая запись и туда копируются данные.
     * @param parentNode к какому узлу добавлять, если показываем дерево.
     * Если не указано, то к текущему или корневому, если нет текущего
     */
    insRec: function(r, parentNode) {
        var th = this;
        var store = th.store;
        //
        if (th.refreshStore) {
            th.reload(); //todo как то нужно поставить активную запись?
            return;
        }
        //
        if (th._istree) {
            if (!parentNode) parentNode = th.getCurRec();
            if (!parentNode) parentNode = th.getRootNode();
            if (!parentNode.isLoaded()) {
                // узел не загружен. просто грузим его
                store.load({node: parentNode, callback: function() {
                    var id = Jc.dbm.DataBinder.getRecId(r);
                    if (id) {
                        var cr = store.getById(id);
                        if (cr) {
                            th.setCurRec(cr);
                        }
                    }
                }});
                return; // больше ничего не делаем
            }
        }
        //
        var doChange = function(r) {
            var data = Jc.dbm.DataBinder.getRecData(r);
            if (!data) return;
            //store.suspendEvents();
            try {
                if (!th._istree) {
                    var recs = store.add(data);
                    if (recs.length > 0) {
                        recs[0].resolveDicts();
                    }
                } else {
                    var cr = parentNode.appendChild(data);
                    cr.treeStore = th.store;  //todo а это надо???
                    cr.resolveDicts();
                }
            } finally {
                //store.resumeEvents();
            }
            if (!th._istree) {
                //store.fireEvent('datachanged', store);
                th.setCurRec(recs[0]);
            } else {
                th.setCurRec(cr);
            }
            th.view.refresh();
        };
        //
        if (Ext.isNumber(r) || Ext.isString(r)) {
            //id
            th.loadRec(r, function(rec) {
                doChange(rec);
            });
        } else if (th.refreshRec) {
            // запись и есть поддержка refresh
            var id = Jc.dbm.DataBinder.getRecId(r);
            th.loadRec(id, function(rec) {
                doChange(rec);
            });
        } else {
            doChange(r);
        }
    },

    /**
     * Обновляет запись в гриде.
     * @param r если запись или map - в текущую запись копируются данные данные.
     * если не указано - загружаются новые данные для текущей записи с сервера
     */
    updRec: function(r) {
        var th = this;
        var store = th.store;
        var currec = th.getCurRec();
        if (!currec) {
            return;
        }
        //
        if (th.refreshStore) {
            th.reload(); //todo как то нужно поставить активную запись?
            return;
        }
        //
        var doChange = function(r) {
            var data = Jc.dbm.DataBinder.getRecData(r);
            if (!data) return;
            //store.suspendEvents();
            try {
                currec.set(data);
                currec.resolveDicts();
                th.view.refresh();
            } finally {
                //store.resumeEvents();
            }
            //store.fireEvent('datachanged', store);
        };
        //
        if (!r) {
            th.loadRec(currec.getId(), function(rec) {
                doChange(rec);
            });
        } else if (th.refreshRec) {
            // запись и есть поддержка refresh
            var id = Jc.dbm.DataBinder.getRecId(r);
            th.loadRec(id, function(rec) {
                doChange(rec);
            });
        } else {
            doChange(r);
        }
    },

    /**
     * Удаляет текущую запись в гриде.
     */
    delRec: function() {
        var th = this;
        var store = th.store;
        var r = th.getCurRec();
        if (!r) return;
        //
        if (th.refreshStore) {
            th.reload(); //todo как то нужно поставить активную запись?
            return;
        }
        //
        if (!th._istree) {
            store.remove(r);
        } else {
            var p = r.parentNode;
            if (p) {
                p.removeChild(r);
            }
        }
    }


});