/**
 * Контейнер для использования в качестве единственного компонента на gsp-фрейме.
 */
Ext.define('Jc.control.GspBox', {
    extend: 'Ext.container.Container',

    isFocusable: false,

    /**
     * Ссылка на фрейм.
     */
    frame: null,

    /**
     * Заголовок фрейма. Присвоить в onInit
     */
    title: null,

    /**
     * Toolbar фрейма. Присвоить в onInit
     */
    toolbar: null,

    /**
     * Если установить true, то фрейм получит layout='fit', если false, то auto (скроллинг)
     */
    fit: false,


    initComponent: function() {
        this.onInit();
        this.callParent(arguments);
    },

    /**
     * Вызывается перед initComponent для настройки this. Компонент еще не создан.
     * Метод предназначен для перекрытия.
     */
    onInit: function() {
    },

    dataToControl: function() {
        Jc.dataToControlChilds(this);
    },

    controlToData: function() {
        Jc.controlToDataChilds(this);
    },

    /**
     * Создание Jc.utils.UiBuilder
     * В качестве параметра config может быть передан домен или store.
     * Фрейм сохраняется в builder в свойстве frame
     */
    createBuilder: function(config) {
        var b = Jc.app.createBuilder(config);
        b.frame = this;
        return b;
    },

    /**
     * Перезагрузка содержимого фрейма полностью
     * @param params дополнительные параметры. Будут переданы на сервер. Накладываются
     * на существующие к этому времени параметры фрейма
     */
    reload: function(params) {
        if (params) {
            this.frame.setParams(params);
        }
        this.frame.reloadData();
    }

});
