/**
 * Простая toolbar с фильтром. Выглядет как:
 *
 * [Фильтр] | текст фильтра
 *
 * на нажатие кнопки [Фильтр] показывается окно с фильтром
 */
Ext.define('Jc.control.SGridFilterToolbar', {
    extend: 'Ext.Toolbar',

    /**
     * С какой grid связан
     */
    grid: null,

    initComponent: function() {
        var th = this;
        //
        var b = Jc.app.createBuilder({frame: this});
        //
        th.filterInfo = b.create("Ext.Component", {
            flex: 1,
            html: ""
        });
        //
        th.items = [
            b.action({text: "Фильтр", icon: "find", onExec: th.showFilter}),
            '-',
            ' ',
            th.filterInfo
        ];
        th.callParent();
    },

    /**
     * Показать фильтр
     */
    showFilter: function() {
        var th = this;
        if (!th.grid.filterFrame) return;
        //
        if (Ext.isFunction(th.grid.filterFrame)) {
            Jc.showFrame({frame: 'Jc.control.SGridFilterFrame', shower: "dialog", store: th.grid.filterStore,
                filterFrameBuilder: th.grid.filterFrame, defaultFilterData: th.grid.defaultFilterData,
                onOk: function() {
                    th.grid.reload();
                }
            });
        } else {
            Jc.showFrame({frame: th.grid.filterFrame, shower: "dialog", store: th.grid.filterStore,
                defaultFilterData: th.grid.defaultFilterData,
                onOk: function() {
                    th.grid.reload();
                }
            });
        }
        //
    },

    updateFilterInfo: function(s) {
        this.filterInfo.update(s);
    }

});