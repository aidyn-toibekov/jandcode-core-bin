/**
 * SGrid. Расширенная grid с плюшками.
 */
Ext.define("Jc.control.SGrid", {
    extend: 'Jc.control.Grid',

    mixins: {
        smixingrid: 'Jc.control.SMixinGrid'
    },

    _istree: false,

    initComponent: function() {
        this.mixins.smixingrid._doInit.apply(this);
        this.callParent(arguments);
    },

    insRec: function(r, parentNode) {
        this.mixins.smixingrid.insRec.apply(this, arguments);
    },

    updRec: function(r) {
        this.mixins.smixingrid.updRec.apply(this, arguments);
    },

    delRec: function() {
        this.mixins.smixingrid.delRec.apply(this, arguments);
    }

});