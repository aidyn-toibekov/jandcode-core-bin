/**
 * Метка для поля
 */
Ext.define('Jc.control.Label', {
    extend: 'Ext.form.Label',

    isFocusable: false,

    initComponent: function() {
        this.cellCls = 'cell-label';
        this.callParent(arguments);
    },

    getElConfig: function() {
        var me = this;
        return {
            tag: 'label',
            id: me.id,
            htmlFor: me.forId || '',
            html: me.getText()
        };
    },

    /**
     * Возвращает текст, который будет отображен
     */
    getText: function() {
        var s = this.text;
        if (!s) return '';
        if (s.substr(s.length - 1) != ":") {
            s = s + ":";
        }
        return s;
    },

    setText: function(text) {
        this.text = text;
        if (this.rendered) {
            this.el.dom.innerHTML = this.getText();
        }
        return this;
    }

});
