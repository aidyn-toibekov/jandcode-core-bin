/**
 * Всплывающая форма фильтрации для sgrid
 */
Ext.define('Jc.control.SGridFilterFrame', {
    extend: 'Jc.frame.FilterFrame',

    /**
     * Функция function(b), которая принимает builder фрейма и возвращает
     * массив элементов items для фрейма.
     */
    filterFrameBuilder: null,

    onInit: function() {
        var th = this;
        th.callParent();
        var b = th.createBuilder();
        //
        th.items = [];
        if (th.filterFrameBuilder) {
            th.items = th.filterFrameBuilder(b);
        }
    }

});
 