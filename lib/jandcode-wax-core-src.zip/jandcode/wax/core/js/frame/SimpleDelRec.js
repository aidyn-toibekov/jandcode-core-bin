/**
 * Удаление записи
 */
Ext.define('Jc.frame.SimpleDelRec', {
    extend: 'Jc.frame.CustomDelRec'
});
