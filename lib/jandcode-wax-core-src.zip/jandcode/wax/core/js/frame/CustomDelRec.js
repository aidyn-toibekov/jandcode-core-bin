/**
 * Удаление записи через dao.
 * Вход:
 * recId - удаляемая запись
 */
Ext.define('Jc.frame.CustomDelRec', {
    extend: 'Jc.frame.DomainFrame',

    /**
     * dao-метод для удаления записи.
     * Метод должен имет один параметр: id записи
     */
    daomethod_del: "updater/del",

    title: UtLang.t("Удаление записи"),

    onInit: function() {
        this.callParent();
        var th = this;
        //
        th.layout = {
            type: 'jctable',
            columns: 2
        };
        th.width = 450;
        th.height = 100;
        th.showConfig = {
            ok: {text: Jc.msg.yes},
            cancel: {text: Jc.msg.no}
        };
        //
        var b = th.createBuilder();
        this.items = [
            b.icon("del", {padding: '0 16 0 0'}),
            b.html(UtLang.t("Вы хотите удалить запись?"))
        ]
    },

    onOk: function() {
        this.controlToData();
        this.onSaveData();
    },

    onSaveData: function() {
        var a = Jc.daoinvoke(this.daoname, this.daomethod_del, [this.recId]);
    }

});
