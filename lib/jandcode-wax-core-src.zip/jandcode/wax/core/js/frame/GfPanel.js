/**
 * Панель для отображения gf-фрейма.
 * Используется в сложных фреймах, которые комбинируется из более простых.
 * Например фрейм с tabpanel, на каждой панели которого отдельный фрейм.
 */
Ext.define('Jc.frame.GfPanel', {
    extend: 'Jc.frame.GfFrame',

    /**
     * Конфигурация фрейма такая, как она была бы передана в Jc.showFrame
     */
    frame: null,

    constructor: function(config) {
        var cfg = Ext.apply({
            closable: false
        }, config);
        this.callParent([cfg]);
    },

    initComponent: function() {
        var th = this;
        th.parseParams(th.frame);
        delete th.frame;
        //
        this.callParent(arguments);
        //
        var tbCtrl;
        th.on('toolbarchange', function(fr) {
            if (tbCtrl) {
                tbCtrl.removeAll();
                if (fr.toolbar) {
                    tbCtrl.add(fr.toolbar);
                }
            } else {
                if (fr.toolbar) {
                    tbCtrl = Ext.create("Ext.toolbar.Toolbar", {
                        dock: 'top',
                        cls: 'jc-cbfrm-toolbar',
                        items: fr.toolbar
                    });
                    th.addDocked(tbCtrl);
                }
            }
            fr.toolbar = null;
        });
        //
        th.on('afterrender', function() {
            if (!th.ctrl) {
                th.load();
            }
        });
    }


});