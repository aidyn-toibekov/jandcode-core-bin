/**
 * Простая форма для редактирования записи в столбик.
 */
Ext.define('Jc.frame.SimpleEditRec', {
    extend: 'Jc.frame.CustomEditRec',

    onInit: function() {
        var th = this;
        th.callParent();
        //
        var b = th.createBuilder(th.store);
        //
        this.items = b.inputsEditable();
    }

});
