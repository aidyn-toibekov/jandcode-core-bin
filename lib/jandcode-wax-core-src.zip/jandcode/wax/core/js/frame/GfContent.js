/**
 * Базовый класс для содержимого фреймов gf
 */
Ext.define('Jc.frame.GfContent', {
    extend: 'Ext.container.Container',

    isFocusable: false,

    /**
     * Ссылка на фрейм, которому принадлежит content
     */
    frame: null,

    /**
     * Заголовок фрейма. Присвоить в onInit
     */
    title: null,

    /**
     * Toolbar фрейма. Присвоить в onInit
     */
    toolbar: null,

    /**
     * Если установить true, то фрейм получит layout='fit', если false,
     * то layout='auto' (скроллинг).
     * Если явно не установлен, определяется автоматически по layout содержимого
     * (для fit, vbox, border - выбирается fit=true)
     */
    fit: null,

    /**
     * При значении true content уведобляет фрейм, что сам собирается разбиратся с
     * padding. Фрейм в этом случае свой стандартный padding отключает. Используется
     * с содержимым во весь фрейм (например дерево в окне tools)
     */
    nopadding: false,

    initComponent: function() {
        this.initAttrs();
        this.onInit();
        this.callParent(arguments);
    },

    /**
     * Инициализация разделяемых атрибутов. Текст метода генерируется сервером
     * после отработки контроллера.
     */
    initAttrs: function() {
    },

    /**
     * Вызывается перед initComponent для настройки this. Компонент еще не создан.
     * Метод предназначен для перекрытия.
     */
    onInit: function() {
    },

    /**
     * Делегирует вызов фрейму
     */
    dataToControl: function() {
        if (this.__dc_) {
            Jc.dataToControlChilds(this);
        } else {
            this.__dc_ = true;
            try {
                this.frame.dataToControl();
            } finally {
                this.__dc_ = false;
            }
        }
    },

    /**
     * Делегирует вызов фрейму
     */
    controlToData: function() {
        if (this.__dc_) {
            Jc.controlToDataChilds(this);
        } else {
            this.__dc_ = true;
            try {
                this.frame.controlToData();
            } finally {
                this.__dc_ = false;
            }
        }
    },

    /**
     * Создание Jc.utils.UiBuilder
     * В качестве параметра config может быть передан домен или store.
     * Фрейм сохраняется в builder в свойстве frame
     */
    createBuilder: function(config) {
        var b = Jc.app.createBuilder(config);
        b.frame = this;
        return b;
    },

    /**
     * Перезагрузка содержимого фрейма полностью
     */
    reload: function() {
        this.frame.reloadContent();
    },

    /**
     * Перезагрузка содержимого фрейма полностью
     */
    load: function() {
        this.frame.reloadContent();
    },

    /**
     * Конвертация json в формате dbm в переменную js
     */
    jsonToVar: function(json) {
        return Jc.createFromDbmJson(json);
    },

    /**
     * Реакция на ok
     */
    onOk: function() {
    },

    choice: function(value, text) {
        return this.frame.choice(value, text);
    },

    /**
     * Реакция на setChoiceValue
     */
    onSetChoiceValue: function(value, inpText) {
    },

    /**
     * Сменить заголовок фрейма
     */
    setTitle: function(s) {
        if (this.frame) {
            this.frame.setTitle(s);
        }
    }

});