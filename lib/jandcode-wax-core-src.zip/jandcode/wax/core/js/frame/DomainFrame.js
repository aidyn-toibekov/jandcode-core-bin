/**
 * Фрейм, имеющий привязку к домену.
 */
Ext.define('Jc.frame.DomainFrame', {
    extend: 'Jc.Frame',

    /**
     * Домен. Можно присвоить как домен, так и имя домена.
     * Если будет имя домена - то домен будет создан автоматически в onInit
     * и присвоен этому свойству.
     */
    domain: null,

    /**
     * Имя dao по умолчанию. Если не указано, используется имя домена.
     */
    daoname: null,

    /**
     * Имя домена. Если не указан домен и есть domainName, то это имя
     * используется для создания домена. Свойство удяляется после распознования домена.
     */
    //domainName: null,

    /**
     * dbm-модель. Если не указана, берется модель по умолчанию (если домен указан
     * как строка), либо из домена (если домен указан явно)
     */
    //model: null,

    onInit: function() {
        this.callParent();
        if (!this.domain && !this.domainName) {
            this.domain = this._defaultDomain; // _defaultDomain передается из createDomainFrame
        }
        if (!this.domain) {
            this.domain = this.domainName;
        }
        delete this.domainName;
        if (Ext.isString(this.domain)) {
            if (!this.model) {
                this.model = Jc.model;
            }
            this.domain = Jc.createDomain(this.domain);
        }
        if (!this.domain) {
            throw new Error(UtLang.t("Для фрейма не назначен домен"));
        }
        if (!(this.domain instanceof Jc.dbm.Domain)) {
            throw new Error(UtLang.t("Свойство domen должно быть доменом или именем домена"));
        } else {
            if (!this.model) {
                this.model = this.domain.model;
            }
        }
        //
        if (!this.daoname) {
            this.daoname = this.domain.name;
        }
    }

});
