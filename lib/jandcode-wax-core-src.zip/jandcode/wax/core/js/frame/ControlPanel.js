/**
 * Стандартная панель управления. В качестве элементов дерева
 * забирается массив из Jc.app.createControlPanelMenu()
 */
Ext.define('Jc.frame.ControlPanel', {
    extend: 'Jc.Frame',

    onInit: function() {
        this.callParent();
        var th = this;
        Ext.apply(th, {
            title: UtLang.t('Панель управления'),
            layout: 'fit',
            shower: 'tools',
            bodyCls: 'jc-frame-body no-padding'
        });
        // строим дерево
        var m = this.createMenu();
        var treeNodes = [];
        this.menuToTree(treeNodes, m);
        //
        var tree = this.tree = Ext.create('Jc.control.Tree', {
            rootVisible: false,
            animate: false,
            cls: 'x-tree-tools',
            fields: ['text', '_action'],
            border: false,
            bodyBorder: false,
            root: {
                expanded: true,
                children: treeNodes
            },
            listeners: {
                itemclick: function(v, r) {
                    var act = r.get("_action");
                    if (!act) return;
                    act.execute();
                }
            }
        });

        this.items = [
            tree
        ];

        //
    },

    /**
     * Строит обычное меню, которое преобразуется в дерево
     */
    createMenu: function() {
        return Jc.app.createControlPanelMenu();
    },

    /**
     * Преобразование массива menu/action в дерево
     */
    menuToTree: function(res, m, level) {
        if (!level) level = 0;
        var th = this;
        Ext.each(m, function(m1) {
            if (Ext.isString(m1)) return; // строковый элемент
            if (m1 instanceof Ext.Component) return; // компонент какой-то
            var it = {};
            res.push(it);
            if (m1 instanceof Ext.Action) {
                Ext.apply(it, m1.initialConfig);
                it._action = m1;
            } else {
                Ext.apply(it, m1);
            }
            if (m1.menu) {
                // есть дочерние
                delete it.menu;
                it.children = [];
                if (level == 0 && m1.expanded === undefined) {
                    it.expanded = true;
                }
                th.menuToTree(it.children, m1.menu, level + 1);
            } else {
                it.leaf = true;
            }
        });
    }

});
 