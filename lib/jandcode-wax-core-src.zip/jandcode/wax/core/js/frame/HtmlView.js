/**
 * Просмотр чистого html во фрейме
 */
Ext.define('Jc.frame.HtmlView', {
    extend: 'Jc.Frame',

    onInit: function() {
        this.callParent();
        //
        var th = this;
        Ext.apply(this, {
            loader: {
                url: 'xxx',
                params: {},
                renderer: function(a, b) {
                    try {
                        var s = th.prepareText(b.responseText);
                        th.update('<div class="jc-htmltext">' + s + '</div>');
                    } catch(e) {
                        Jc.error(e);
                    }
                }
            },
            listeners: {
                click: {
                    element: 'el',
                    fn: function(ev) {
                        var targ = ev.getTarget();
                        if (!targ) return;
                        if (targ.nodeName == 'A') {
                            var hr = targ.attributes.getNamedItem("href").value;
                            if (hr.indexOf("#") == -1) {
                                ev.preventDefault();
                                th.changeUrl(hr);
                            }
                        }
                    }
                }
            }
        });
        if (this.url) {
            this.loader.url = this.url;
        }
        if (this.params) {
            Ext.apply(this.loader.params, this.params);
        }

        this._urlHistory = [];
        this.actBack = Jc.action({text: UtLang.t("Назад"), icon: 'back', disabled: true, scope: this, onExec: this.back});

        this.toolbar = [
            this.actBack
        ];
    },

    onLoadData: function() {
        this.getLoader().load();
    },

    changeUrl: function(href) {
        var cururl = this.getLoader().url;
        this._urlHistory.push(cururl);
        this.actBack.setDisabled(false);
        var i1 = cururl.lastIndexOf("/");
        cururl = cururl.substr(0, i1 + 1) + href;
        this.getLoader().url = cururl;
        this.reloadData();
    },

    back: function() {
        var url = this._urlHistory.pop();
        if (this._urlHistory.length == 0) {
            this.actBack.setDisabled(true);
        }
        if (url) {
            this.getLoader().url = url;
            this.reloadData();
        }
    },

    prepareText: function(s) {
        var cururl = this.getLoader().url;
        var i1 = cururl.lastIndexOf("/");
        cururl = cururl.substr(0, i1 + 1);
        // картинки
        var s1 = s.replace(/<img\s*?src="(.*?)"/ig, function(s, p1) {
            if (p1.indexOf(':') != -1) {
                return s;
            }
            return '<img src="' + cururl + p1 + '"';
        });
        return s1;
    }

});
 