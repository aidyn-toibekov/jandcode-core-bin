/**
 * Фрейм с контентом gf
 */
Ext.define('Jc.frame.GfFrame', {
    extend: 'Jc.Frame',

    /**
     * url фрейма, откуда брать содержимое
     */
    contentUrl: null,

    /**
     * Параметры для получения содержимого
     */
    contentParams: null,

    /**
     * параметры для перезагрузки content. Содержит имена свойств content,
     * которые нужно использовать для перезагрузки фрейма.
     * Изначально пустое. Формируется контентом.
     */
    contentParamNames: null,

    /**
     * Дополнительные атрибуты контента для его создания.
     * Накладывается на contentConfig, который content себе заказал.
     * Используется для передачи ссылок на локальные переменные.
     */
    contentConfigOverride: null,

    /**
     * Ссылка на контент. Если null - контент еще не был получен.
     */
    ctrl: null,

    onInit: function() {
        this.header = false;
        this.callParent();
    },

    content: function(cls, config) {
        this.contentCls = cls;
        this.contentConfig = config;
    },

    grabProp: function(pname, deleteOrig) {
        if (!Ext.isEmpty(this.ctrl[pname], true)) {
            this[pname] = this.ctrl[pname];
            if (deleteOrig) {
                delete this.ctrl[pname];
            }
        }
    },

    /**
     * Разбираем параметры
     */
    parseParams: function(cfg) {
        var th = this;
        th.contentConfigOverride = {};
        th.contentParams = {};
        if (!cfg) return;
        for (var an in cfg) {
            var av = cfg[an];
            if (Ext.isFunction(av)) {
                th.contentConfigOverride[an] = av;
            } else if (an == "frame") {
                th.contentUrl = av;
            } else if (an == "local") {
                Ext.apply(th.contentConfigOverride, av);
            } else if (an == "params") {
                //ignore
            } else {
                th.contentParams[an] = av;
            }
        }
    },

    /**
     * Возвращает параметры для запроса содержимого. Все преобразовано в json как требуется,
     * учтены локальные переменные.
     */
    getReqParams: function() {
        var th = this;
        // берем то, что было по умолчанию
        var reqParams = Ext.apply({}, th.contentParams);
        // накладываем то что сейчас есть
        if (th.ctrl) {
            Ext.each(th.contentParamNames, function(z) {
                reqParams[z] = th.ctrl[z];
            });
        }
        // преобразуем в json
        for (var pn in reqParams) {
            reqParams[pn] = Jc.dbm.Cnv.toJson(reqParams[pn]);
        }
        return reqParams;
    },

    /**
     * Обновить содержимое фрейма
     * @param s
     */
    updateContent: function(s) {
        var th = this;
        var firstContent = (th.ctrl == null);
        if (!firstContent) {
            th.removeAll();
        }
        //
        th.contentCls = null;
        th.contentConfig = null;
        th.contentParamNames = [];
        var saveTH = window.TH;
        window.TH = th;
        //
        try {
            // препроцессор
            // замена ~id~ на id фрейма
            // замена ~id~X на id-X фрейма (если X буква),
            // например: <div id="~id~form"> заменится на <div id="x-123-form">
            s = s.replace(/~id~(\w)/g, th.id + '-$1');
            s = s.replace(/~id~/g, th.id);
            //
            Jc.evalHtml(s);

            //
            if (th.contentCls) {
                // есть класс контента
                var cfg = Ext.apply({}, th.contentConfig);
                Ext.apply(cfg, th.contentConfigOverride);
                cfg.frame = th;
                var content = th.ctrl = Ext.create(th.contentCls, cfg);
                //
                th.toolbar = content.toolbar;
                th.title = content.title;
                //
                if (firstContent) {

                    if (th.isFitContent(content)) {
                        if (th.body) {
                            th.body.update('');
                        }
                        th.setLayout(Ext.create('Ext.layout.container.Fit'));
                    }

                    if (content.shower) {
                        th.shower = content.shower;
                    }

                    //
                    if (content.nopadding) {
                        th.addBodyCls('no-padding');
                    }

                    // grab prop
                    th.grabProp("width", true);
                    th.grabProp("height", true);
                    th.grabProp("resizable", true);
                }
                //
                th.add(content);
                //
                th.fireEvent("toolbarchange", th);
                if (th.title) {
                    th.setTitle(th.title);
                }
                //
                if (th.rendered) {
                    th.dataToControl();
                    //
                    th.doLayout();
                }
            }

        } catch(e) {
            throw e;

        } finally {
            window.TH = saveTH;
        }
    },

    /**
     * Перегрузка содержимого фрейма.
     * Если передана функция onLoad, то она вызывается с параметром - загруженный текст,
     * иначе содержимое обновляется по полученному тексту.
     */
    reloadContent: function(onLoad) {
        var th = this;
        // собираем параметры
        var reqParams = th.getReqParams();
        //
        Ext.Ajax.request({
            url: th.contentUrl,
            params: {
                gfparams: Ext.encode(reqParams)
            },
            success: function(response, opts) {
                // загрузка прошла удачно
                try {
                    if (onLoad) {
                        onLoad(response.responseText);
                    } else {
                        th.updateContent(response.responseText);
                    }
                } catch(e) {
                    Jc.error(e);
                }
            },
            failure: function(response, opts) {
                Jc.error(response, false);
            }
        });
    },

    reload: function() {
        this.reloadContent();
    },

    load: function() {
        this.reloadContent();
    },

    isFitContent: function(fr) {
        var fit = fr.fit;
        if (fit === true || fit === false) return fit;
        return Jc.isFitLayout(fr);
    },

    onOk: function() {
        return this.ctrl.onOk();
    },

    getContentControl: function() {
        return this.ctrl;
    },

    setChoiceValue: function(value, inpText) {
        this.ctrl.onSetChoiceValue(value, inpText);
    }

});
 