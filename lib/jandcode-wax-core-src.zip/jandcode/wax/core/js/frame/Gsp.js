/**
 * gsp-фрейм. Экземпляр фрейма создается на клиенте, все свое содержимое (включая объекты)
 * получает с серевера по запросу. Имеется возможность перезагружать контент.
 */
Ext.define('Jc.frame.Gsp', {
    extend: 'Jc.Frame',

    DEFAULT_TITLE: UtLang.t('Загрузка...'),

    _onReady: null,
    _controls: null,
    _firstLoad: true, // первая загрузка

    constructor: function(config) {
        this.callParent([config]);
        this.on("beforedestroy", function(th) {
            th._destroyControls();
        });
    },


    onInit: function() {
        this.callParent();
        //
        var th = this;
        Ext.apply(this, {
            cls: 'jc-frame jc-frame-gsp',
            bodyCls: 'jc-frame-body jc-frame-body-gsp',
            layout: null,
            loader: {
                url: 'NONE',
                params: {},
                renderer: function(loader, response, active) {
                    var text = response.responseText;
                    try {
                        var saveTitle = th.title;
                        var saveToolbar = th.toolbar;
                        //
                        th.updateBody(text);
                        //
                        if (saveToolbar != th.toolbar) {
                            th.fireEvent("toolbarchange", th);
                        }
                        if (th.title == th.DEFAULT_TITLE) {
                            th.setTitle(UtLang.t('Нет заголовка'));
                        } else if (saveTitle != th.title) {
                            th.setTitle(th.title);
                        }
                        //
                        th.fireEvent('afterloadframe', th, th._firstLoad);
                    } catch(e) {
                        Jc.error(e);
                    }
                    th._firstLoad = false;
                    return true;
                },
                failure: function(ldr, b, c) {
                    Jc.error(b, false);
                    th.fireEvent('errorloadframe', th, th._firstLoad);
                }
            }
        });
        if (this.url) {
            this.loader.url = this.url;
            delete this.url;
        }
        if (this.params) {
            Ext.apply(this.loader.params, this.params);
            delete this.params
        }
        if (!this.title) {
            this.title = this.DEFAULT_TITLE;
        }
        //
        this.addEvents("afterloadframe");
        this.addEvents("errorloadframe");
    },

    onReady: function(fn) {
        if (!this._onReady) {
            this._onReady = [];
        }
        this._onReady.push(fn);
    },

    /**
     * Создание компонента, который будет использован в качестве control на фрейме
     * @param cls
     * @param config
     */
    content: function(cls, config) {
        var th = this;
        var cfg = Ext.apply({}, config);
        cfg.frame = th;
        var cmp = Ext.create(cls, cfg);
        if (cmp.title) {
            th.title = cmp.title;
        }
        if (cmp.toolbar) {
            th.toolbar = cmp.toolbar;
        }
        if (cmp.fit) {
            th.setLayout(Ext.create('Ext.layout.container.Fit'));
        }
        th.removeAll();
        th.update("");
        th.add(cmp);
    },

    /**
     * Обновить тело панели по данным строки s
     * @param s
     */
    updateBody: function(s) {
        var th = this;
        th.removeAll();
        th.update("");
        th._destroyControls();
        //
        //
        var saveTH = window.TH;
        window.TH = th;
        //
        this._onReady = null;
        //
        try {
            // препроцессор
            // замена ~id~ на id фрейма
            // замена ~id~X на id-X фрейма (если X буква),
            // например: <div id="~id~form"> заменится на <div id="x-123-form">
            s = s.replace(/~id~(\w)/g, th.id + '-$1');
            s = s.replace(/~id~/g, th.id);
            //
            th.update(s);

            Jc.evalHtml(s);

            //
            if (th._onReady) {
                for (var i = 0; i < th._onReady.length; i++) {
                    th._onReady[i].apply(th, [th]);
                }
            }

            //
            th.dataToControl();

        } catch(e) {
            throw e;

        } finally {
            this._onReady = null;
            window.TH = saveTH;
        }
    },

    setParams: function(params) {
        Ext.apply(this.getLoader().params, params);
    },

    getParams: function() {
        return this.getLoader().params;
    },

    setUrl: function(url) {
        this.getLoader().url = url;
    },

    onLoadData: function() {
        this.getLoader().load();
    },

    /**
     * Регистрирует контрол для удаления при destroy фрейма.
     * growHeight - высота контрола подгоняется под высоту фрейма
     */
    addControl: function(ctrl) {
        if (!this._controls) {
            this._controls = [];
        }
        if (Ext.isArray(ctrl)) {
            for (var i = 0; i < ctrl.length; i++) {
                this.addControl(ctrl[i]);
            }
            return;
        }
        this._controls.push(ctrl);
        if (ctrl.rendered) {
            if (ctrl.growHeight) {
                this.doGrowHeight(ctrl);
            }
        }
        return ctrl;
    },

    doGrowHeight: function(ctrl) {
        var fs = this.ownerCt.getHeight();
        var cy = ctrl.getPosition()[1];
        var nh = fs - cy - 10;
        if (nh < 100) nh = 100;
        ctrl.setHeight(nh);
    },

    _destroyControls: function() {
        if (!this._controls || this._controls.length == 0) {
            return;
        }
        for (var i = 0; i < this._controls.length; i++) {
            var cc = this._controls[i];
            if (!cc.ownerCt) {
                Ext.destroy(cc);
            }
        }
        this._controls = null;
    },

    dataToControl: function() {
        if (this._controls && this._controls.length != 0) {
            for (var i = 0; i < this._controls.length; i++) {
                var cc = this._controls[i];
                if (cc.dataToControl) {
                    cc.dataToControl();
                } else {
                    Jc.dataToControlChilds(cc);
                }
            }
        }
        this.callParent();
    },

    controlToData: function() {
        if (this._controls && this._controls.length != 0) {
            for (var i = 0; i < this._controls.length; i++) {
                var cc = this._controls[i];
                if (cc.controlToData) {
                    cc.controlToData();
                } else {
                    Jc.controlToDataChilds(cc);
                }
            }
        }
        this.callParent();
    }


});
 