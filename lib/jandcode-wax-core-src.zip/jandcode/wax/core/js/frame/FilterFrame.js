/**
 * Предок для фреймов ввода значений для фильтров.
 *
 */
Ext.define('Jc.frame.FilterFrame', {
    extend: 'Jc.Frame',

    /**
     * Это store, которую требуется редактировать. Ее передадут.
     */
    store: null,

    /**
     * Данные для фильтра по умолчанию при сбросе
     */
    defaultFilterData: null,

    /**
     * Сбросить данные
     */
    resetData: function() {
        var th = this;
        var d = {};
        Ext.apply(d, th.defaultFilterData);
        th.onResetData(d);
        th.store.removeAll();
        th.store.add(d);
        th.dataToControl();
    },

    /**
     * Отреагировать на сброс данных. Может значения по умолчанию поставить
     * @param data куда посавить значения по умолчанию.
     */
    onResetData: function(data) {
    },

    onOk: function() {
        this.controlToData();
    },

    onInit: function() {
        this.callParent();
        var th = this;
        var b = th.createBuilder();
        th.layout = b.layout("table");
        th.title = "Фильтр";
        th.toolbar = [
            b.action({text: "Сброс", icon: "clear", onExec: th.resetData})
        ];
    }

});