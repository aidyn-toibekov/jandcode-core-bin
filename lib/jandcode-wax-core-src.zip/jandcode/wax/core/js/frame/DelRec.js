/**
 * Удаление записи из базы указанным dao.
 */
Ext.define('Jc.frame.DelRec', {
    extend: 'Jc.Frame',

    /**
     * Домен. Если указан и не указано daoname, то daoname=domain/updater
     */
    domain: null,

    /**
     * Имя dao для выполнения
     */
    daoname: null,

    /**
     * Метод для удаления записи. По умолчанию - 'del'
     */
    daomethod: "del",

    /**
     * Удаляемая запись
     */
    recId: null,

    /**
     * Если указано, то используется вместо recId
     */
    daoparams: null,


    onInit: function() {
        this.callParent();
        var th = this;
        var b = th.createBuilder();
        //
        Ext.apply(th, {
            title: UtLang.t("Удаление записи"),
            layout: b.layout("table"),
            width: 450,
            height: 100,
            shower: "dialog"
        });
        //
        if (!th.daoname) {
            if (th.domain) {
                th.daoname = th.domain + '/updater';
            }
        }
        //
        if (!th.daomethod) {
            th.daomethod = 'del';
        }
        //
        th.showConfig = {
            ok: {text: Jc.msg.yes},
            cancel: {text: Jc.msg.no}
        };
        //
        this.items = [
            b.icon("del", {padding: '0 16 0 0'}),
            b.html(UtLang.t("Вы хотите удалить запись?"))
        ]
    },

    onOk: function() {
        try {
            if (!this.recId && !this.daoparams) {
                Jc.error('Не указан recId или daoparams');
            }
            var dp = this.daoparams;
            if (!dp) {
                dp = [this.recId];
            }
            Jc.daoinvoke(this.daoname, this.daomethod, dp);
        } catch(e) {
            // Про ошибке в onOk показываем ошибку, окно закрываем по любому
            Jc.error(e, false);
            this.closeFrame();
            return false;  // отключаем механизм закрытия через onOk
        }
    }

});
