/**
 * Настраиваемый редактор таблицы.
 * Если явно не указан title, берется title из домена.
 * Для редактирования записи используется фрейм домена "editRec".
 */
Ext.define('Jc.frame.CustomEditList', {
    extend: 'Jc.frame.DomainFrame',

    /**
     * dao-метод для загрузки данных списка
     */
    daomethod_load: "list/load",

    /**
     * Параметры dao-метода. Если не указан, игнорируется
     */
    daoparams_load: null,

    /**
     * dao-метод для загрузки одной записи списка для refresh после редактирования.
     * В качестве параметра будет передан id записи.
     */
    daomethod_loadRec: "list/loadRec",

    /**
     * Если true, то после радактирования запись будет загружена с сервера, иначе
     * запись будет взята из формы редактирования без дополнительного запроса на сервер.
     */
    refreshRec: false,

    /**
     * Иконка для заголовка
     */
    headerIсon: "dict",

    onInit: function() {
        this.callParent();
        var th = this;
        // создаем store
        var store = th.store = th.domain.createStore();
        var b = th.createBuilder(store);
        //
        Ext.apply(th, {
            layout: {type: 'vbox', align: 'stretch'}
        });
        if (!th.title) th.title = store.domain.title;
        //
        var gridConfig = {
            flex: 1,
            columns: th.createGridColumns(b),
            tbar: th.createGridToolbar(b)
        };
        var grid = th.grid = b.grid(gridConfig);
        //
        th.items = [
            b.pageheader(th.title, th.headerIсon),
            grid
        ];
    },

    onLoadData: function() {
        this.store.daoload(this.daoname, this.daomethod_load, this.daoparams_load);
    },

    /**
     * Создание колонок для гриды. Возвращает массив колонок. Можно перекрыть.
     * @param b UIBuilder
     */
    createGridColumns: function(b) {
        return b.columnsVisible();
    },

    /**
     * Создание toolbar для гриды. Возвращает массив action. Можно перекрыть.
     * @param b UIBuilder
     */
    createGridToolbar: function(b) {
        return [
            b.actionIns({onExec: this.act_ins}),
            b.actionUpd({onExec: this.act_upd}),
            b.actionDel({onExec: this.act_del})
        ]
    },

    /**
     * action: ins
     */
    act_ins: function() {
        var th = this;
        var recData = {};
        th.onIns(recData);
        var f = th.domain.createDomainFrame("editRec", {recData: recData});
        f.showDialog({onOk: function() {
            if (th.refreshRec) {
                var rec = th.model.daoinvoke(th.daoname, th.daomethod_loadRec, [f.recId]);
                th.grid.insRec(rec);
            } else {
                th.grid.insRec(f);
            }
        }});
    },

    /**
     * Вызывается при добавлении записи.
     * @param data данные записи по умолчанию для формы вставки записи.
     */
    onIns: function(data) {
    },

    /**
     * action: upd
     */
    act_upd: function() {
        var th = this;
        var r = th.grid.getCurRec();
        if (!r) return;
        var f = th.domain.createDomainFrame("editRec", {recId: r.getId()});
        f.showDialog({onOk: function() {
            if (th.refreshRec) {
                var rec = th.model.daoinvoke(th.daoname, th.daomethod_loadRec, [f.recId]);
                th.grid.updRec(rec);
            } else {
                th.grid.updRec(f);
            }
        }});
    },

    /**
     * action: del
     */
    act_del: function() {
        var th = this;
        var r = th.grid.getCurRec();
        if (!r) return;
        var f = th.domain.createDomainFrame("delRec", {recId: r.getId()});
        f.showDialog({onOk: function() {
            th.grid.delRec();
        }});
    }

});

