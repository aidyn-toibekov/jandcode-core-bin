/**
 * Простой редактор для простой таблицы.
 */
Ext.define('Jc.frame.SimpleEditList', {
    extend: 'Jc.frame.CustomEditList'
});
