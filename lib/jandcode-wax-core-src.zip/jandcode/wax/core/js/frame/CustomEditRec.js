/**
 * Редактирование записи через dao.
 * Вход:
 * mode = ins|upd
 * recData = {} данные для записи по умолчанию.
 * recId!=0 - редактируемая запись, нужно загрузить. Помещается в recData.id.
 *            При вставке после выполнения в recId - id добавленной записи.
 *
 * Выход:
 * store - собственно запись. После вставки в поле id - id добавленной записи.
 *
 */
Ext.define('Jc.frame.CustomEditRec', {
    extend: 'Jc.frame.DomainFrame',

    /**
     * dao-метод для загрузки записи
     */
    daomethod_loadRec: "updater/loadRec",

    /**
     * dao-метод для добавления записи.
     * Метод должен имет один параметр: store.
     * Метод должен возвращать id добавленной записи.
     */
    daomethod_ins: "updater/ins",

    /**
     * dao-метод для изменения записи.
     * Метод должен имет один параметр: store.
     */
    daomethod_upd: "updater/upd",

    /**
     * Режим ins/upd/CUSTOM. В зависимости от режима выбирается метод "daomethod_MODE"
     * для модификации записи. Если такого метода нет (например mode="insSub"), то тогда
     * подразумевается метод "updater/MODE".
     */
    mode: null,

    title: UtLang.t("Редактирование записи"),

    onInit: function() {
        this.callParent();
        var th = this;
        //        
        th.layout = {
            type: 'jctable',
            columns: 2
        };
        //
        if (!th.recData) {
            th.recData = {};
        }
        if (th.recId) {
            th.recData.id = th.recId;
            if (!th.mode) {
                th.mode = "upd";
            }
        }
        if (!th.mode) {
            th.mode = "ins";
        }
        //
        if (th.isIns()) {
            th.title = UtLang.t("Новая запись");
        }
        // создаем store
        this.store = this.domain.createStore();
        th.onCreateStore();
        // загружаем данные сразу, что бы при формировании интерфейса
        // данные можно можно было использовать
        th.loadData();
    },

    /**
     * Вызывается после создания store и перед загрузкой данных.
     * Можно перекрыть для создания дополнительных store, если это необходимо.
     */
    onCreateStore: function() {
    },

    /**
     * Возвращает true, если режим "добавление записи"
     */
    isIns: function() {
        return this.mode.substr(0, 3) == "ins";
    },

    onLoadData: function() {
        if (!this.isIns()) {
            this.store.daoload(this.daoname, this.daomethod_loadRec, [this.recId]);
        } else {
            this.store.add(this.recData);
        }
    },

    onOk: function() {
        this.controlToData();
        this.onSaveData();
    },

    onSaveData: function() {
        var mn = this["daomethod_" + this.mode];
        if (!mn) {
            mn = "updater/" + this.mode;
        }
        var a = Jc.daoinvoke(this.daoname, mn, [this.store]);
        if (this.isIns()) {
            this.recId = a;
            this.store.getCurRec().set("id", this.recId);
        }
    }

});
