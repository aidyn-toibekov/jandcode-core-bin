/**
 * Колонка для показа данных многоязыкового поля.
 */
Ext.define('Jc.column.TreeLangstring', {
    extend: 'Jc.column.Tree',


    onRenderCell: function(value) {
        var th = this;
        //
        var model = Jc.dbm.DataBinder.getModel(th.args.record);
        var data = Jc.lang.getLangDataFromRec(th.args.record, th.dataIndex);
        var v = Jc.lang.getLangValue(data, th.args.record);
        //
        var s = v.value;
        if (!s) s = "";
        //
        var b = '<div class="jc-langmarker-wrap">';
        Ext.each(model.langs, function(lang) {
            var cls = 'jc-langmarker';
            if (data[lang]) {
                cls += ' jc-langmarker-valueexists';
            }
            if (lang == v.lang) {
                cls += ' jc-langmarker-valuecurrent';
            }
            b += Jc.format('<span class="{0}">{1}</span>', cls, lang);
        });
        b += '</div>';

        return b + s;
    }


});
