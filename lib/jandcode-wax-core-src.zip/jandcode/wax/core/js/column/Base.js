/**
 * Предок для колонок гриды.
 * Для имени поля используется стандартное extjs имя поля dataIndex.
 */
Ext.define('Jc.column.Base', {
    extend: 'Ext.grid.column.Column',

    /**
     * Функция, которая вызывается после onRenderCell. В качестве значения (первого
     * параметра) получает то, что было создано в onRenderCell
     * @param config
     */
    //onAfterRenderCell: null,

    constructor: function(config) {
        var cfg = Ext.apply({
            sortable: Jc.ini.grid.columnSortable,
            menuDisabled: !Jc.ini.grid.columnMenu
        }, config);
        this.onInitConfig(cfg);
        this.callParent([cfg]);
    },

    initComponent: function() {
        var th = this;
        th.args = {};
        this.renderer = function(value, metaData, record, rowIndex, colIndex, store, view) {
            var res;
            var saveArgs = th.args;
            // все аргументы будут доступны через this.args на время выполнения onRenderCell
            th.args = {
                value: value,
                meta: metaData,
                record: record,
                rowIndex: rowIndex,
                colIndex: colIndex,
                store: store,
                view: view
            };
            try {
                res = th.onRenderCell.apply(th, arguments);
                if (th.onAfterRenderCell) {
                    th.args.value = res;
                    var args2 = Array.prototype.slice.call(arguments);
                    args2[0] = res;
                    res = th.onAfterRenderCell.apply(th, args2);
                }
            } finally {
                th.args = saveArgs;
            }
            return res;
        };
        //
        this.callParent(arguments);
    },

    //////

    /**
     * Инициализация cfg в конструкторе
     */
    onInitConfig: function(cfg) {
    },

    /**
     * Для перекрытия. Вернуть текст для отрисовки в гриде.
     * Параметры соответсвуют renderer. this = колонка
     */
    onRenderCell: function(value, metaData, record, rowIndex, colIndex, store, view) {
        return value;
    },

    /**
     * Вызывается гридой Jc.control.Grid при щелчке на ячейке
     * @param rec запись
     * @param e событие
     */
    onClickCell: function(rec, e) {
    },

    /////

    clickCell: function(rec, e) {
        this.onClickCell(rec, e);
    }

    ////// args

});
