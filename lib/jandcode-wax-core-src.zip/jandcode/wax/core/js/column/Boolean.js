Ext.define('Jc.column.Boolean', {
    extend: 'Jc.column.Base',

    /**
     * Иконка для значения true
     */
    icon_true: "true",

    /**
     * Иконка для значения false
     */
    icon_false: "false",

    onRenderCell: function(value) {
        var v = Jc.toBoolean(value);
        var ic = this.icon_true;
        if (!v) ic = this.icon_false;
        ic = Jc.iconUrl(ic);
        return '<img src="' + ic + '">';
    }
});
