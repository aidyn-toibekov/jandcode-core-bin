/**
 * Колонка для показа наличия данных многоязыкового поля.
 * Например может использоваться для поля "мемо".
 */
Ext.define('Jc.column.Langflag', {
    extend: 'Jc.column.Base',

    /**
     * Имена иконок для есть/нет значение
     */
    iconTrue: 'truegray',
    iconFalse: 'false',

    onRenderCell: function(value) {
        var th = this;
        //
        var model = Jc.dbm.DataBinder.getModel(th.args.record);
        var data = Jc.lang.getLangDataFromRec(th.args.record, th.dataIndex);
        var v = Jc.lang.getLangValue(data, th.args.record);
        //
        var ic = th.iconFalse;
        var b = '<div class="jc-langmarker-wrap">';
        Ext.each(model.langs, function(lang) {
            var cls = 'jc-langmarker';
            if (data[lang]) {
                cls += ' jc-langmarker-valueexists';
                ic = th.iconTrue;
            }
            b += Jc.format('<span class="{0}">{1}</span>', cls, lang);
        });
        b += '</div>';
        var s = Jc.format('<img class="x-grid-cell-icon" src="{0}">', Jc.iconUrl(ic));
        return b + s;
    }


});
