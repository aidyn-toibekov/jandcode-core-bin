Ext.define('Jc.column.Dict', {
    extend: 'Jc.column.Base',

    /**
     * Имя словаря
     */
    dict: null,

    /**
     * Поле словаря для отображения
     */
    dictfield: null,

    onRenderCell: function(value) {
        var dictname = this.getDict();
        if (!dictname) return "";
        var store = Jc.dbm.DataBinder.getJcStore(this.args);
        if (!store) return "";
        var v = store.dictdata.getValue(dictname, value, this.dictfield);
        return v;
    },

    getDict: function() {
        if (this.dict) return this.dict;
        var field = Jc.dbm.DataBinder.getField(this.args, this.dataIndex);
        if (!field) return null;
        return field.dict;
    }

});
