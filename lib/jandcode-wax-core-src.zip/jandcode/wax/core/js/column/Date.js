Ext.define('Jc.column.Date', {
    extend: 'Jc.column.Datetime',

    onInitConfig: function(cfg) {
        Ext.applyIf(cfg, {
            format: Jc.ini.dateFormat
        });
    }

});
