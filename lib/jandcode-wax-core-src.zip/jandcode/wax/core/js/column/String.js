Ext.define('Jc.column.String', {
    extend: 'Jc.column.Base',
    onRenderCell: function(value) {
        return value;
    }
});
