Ext.define('Jc.column.Number', {
    extend: 'Jc.column.Base',
    onRenderCell: function(value) {
        return value; //todo
    }
});
