Ext.define('Jc.column.Datetime', {
    extend: 'Jc.column.Base',

    onInitConfig: function(cfg) {
        Ext.applyIf(cfg, {
            format: Jc.ini.datetimeFormat
        });
    },

    onRenderCell: function(value) {
        return Jc.dateToText(value, this.format);
    }

});
