Ext.define('Jc.column.Icontext', {
    extend: 'Jc.column.Base',

    icon: 'show',
    bold: false,
    atag: false,

    onRenderCell: function(value) {
        var ic = this.onIconCell.apply(this, arguments);
        var txt = this.onTextCell.apply(this, arguments);
        if (!txt) txt = "";
        var s = Jc.format('<img class="x-grid-cell-icon" src="{0}">', Jc.iconUrl(ic));
        if (this.bold) {
            s += '<b>';
        }
        if (this.atag) {
            s += '<a href="#">';
        }
        s += txt;
        if (this.atag) {
            s += '</a>';
        }
        if (this.bold) {
            s += '</b>';
        }
        return s;
    },

    /**
     * Возвращает имя иконки для использования в onRenderCell
     */
    onIconCell: function(value, metaData, record, rowIndex, colIndex, store, view) {
        return this.icon;
    },

    /**
     * Возвращает текст для использования в onRenderCell
     */
    onTextCell: function(value, metaData, record, rowIndex, colIndex, store, view) {
        return value;
    }

});
