/**
 * Это модель extjs. Фактически это класс для представления записи в store.
 * В контексте wax я рассматриваю этот класс как подобие jandcode.dbm.data.IDataRecord
 *
 * Запись имеет ссылку на store. Это Jc.dbm.Store (или Jc.dbm.TreeStore).
 * Соответсвенно имеется ссылка на домен: store.domain
 *
 */
Ext.define('Jc.dbm.ExtModel', {
    extend: 'Ext.data.Model',

    constructor: function(data, id, raw, convertedData) {
        this.callParent(arguments);
        // для свободных данных (без объявления полей)
        Ext.applyIf(this.data, data);
        Ext.applyIf(this.data, raw);
    },

    /**
     * Получение словарного значения для поля
     * @param fieldName для какого поля (его значение используется как ключ)
     * @param dictFieldName словарное поле. Если не указано, используется поле по
     * умолчанию для словаря, указанного для поля.
     */
    getDictValue: function(fieldName, dictFieldName) {
        var store = this.treeStore || this.store;
        return store.dictdata.getValue(store.domain.f(fieldName).dict, this.get(fieldName), dictFieldName);
    },

    /**
     * Возвращает все значения из записи в виде map. Фактически копия свойства data.
     */
    getValues: function() {
        var th = this;
        var r = {};
        if (th.data) {
            Ext.apply(r, th.data);
        }
        return r;
    },

    /**
     * Установить значение полей за раз.
     * @param data может быть объектом/записью/store(берется getCurRec)
     */
    setValues: function(data) {
        if (data instanceof Jc.dbm.Store) {
            data = data.getCurRec().data;
        } else if (data instanceof Ext.data.Model) {
            data = data.data;
        }
        this.set(data);
    },

    /**
     * Очистить все значения в записи
     */
    clearValues: function() {
        var d1 = {};
        for (var key in this.data) {
            d1[key] = null;
        }
        this.set(d1);
    },

    /**
     * Получить значение поля. Синоним для get
     */
    getValue: function(fieldName) {
        return this.get(fieldName);
    },

    /**
     * Установить значение поля. Синоним для set
     */
    setValue: function(fieldName, value) {
        return this.set(fieldName, value);
    },

    /**
     * Загрузка данных для словарей, которые используются в этой записи
     * @param force true - перезагрузить словари, даже если значения закешированы
     */
    resolveDicts: function(force) {
        var store = this.treeStore || this.store;
        return store.dictdata.resolveDictRec(this, force, store);
    },

    /**
     * Обновить конкретный словарь. см: Jc.dbm.DictData#updateDict
     */
    updateDict: function(dictname, data) {
        var store = this.treeStore || this.store;
        store.dictdata.updateDict(dictname, data);
    }

});
 