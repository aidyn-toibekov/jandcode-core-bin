/**
 * Объект для получения информации и данных в условиях тотального отсутствия
 * прямых указаний...
 */
Ext.define('Jc.dbm.DataBinder', {

    singleton: true,

    /**
     * У объекта bind вызывает метод getDataBinds (если он есть). Для каждого
     * элемента полученного массива (если он есть) вызывается функция bindMeth,
     * где первым параметром элемент пассива, а остальные - args.
     *
     * Используется для возможности предоставить bind-объекту свои внутренние объекты,
     * где тоже можно искать bind-данные. Например UiBuilder предоставляет свой frame
     * как дополнительное место для поиска bind-данных.
     */
    _scanBinders: function(bind, bindMeth, args) {
        if (bind.getDataBinds) {
            var a = bind.getDataBinds();
            if (a) {
                var args2 = [null];
                if (args) {
                    args2.concat(args);
                }
                for (var i = 0; i < a.length; i++) {
                    if (!a[i]) continue;
                    args2[0] = a[i];
                    var b = bindMeth.apply(this, args2);
                    if (b != null) return b;
                }
            }
        }
        return null;
    },

    getField: function(bind, name) {
        if (!bind) return null;
        var domain = this.getDomain(bind);
        if (!domain) return null;
        return domain.findField(name);
    },

    isDomain: function(z) {
        return z instanceof Jc.dbm.Domain;
    },

    isStore: function(z) {
        return z instanceof Ext.data.AbstractStore;
    },

    isJcStore: function(z) {
        return z instanceof Jc.dbm.Store || z instanceof Jc.dbm.TreeStore;
    },

    getModel: function(bind) {
        if (!bind) return Jc.model;
        if (bind instanceof Jc.dbm.Model) return bind;
        var model = bind.model;
        if (model instanceof Jc.dbm.Model) return model;
        var domain = this.getDomain(bind);
        if (!domain) return Jc.model;
        return domain.model;
    },

    getDomain: function(bind) {
        if (!bind) return null;
        if (this.isDomain(bind)) return bind;
        if (this.isDomain(bind.domain)) return bind.domain;
        if (Ext.isString(bind.domain)) return Jc.model.getDomain(bind.domain);
        var store = this.getStore(bind);
        if (store) {
            if (this.isDomain(store.domain)) return store.domain;
        }
        //
        return this._scanBinders(bind, this.getDomain);
    },

    getStore: function(bind) {
        if (!bind) return null;
        if (bind instanceof Ext.data.NodeStore) {
            bind = bind.treeStore;
        }
        if (this.isStore(bind)) return bind;
        if (this.isStore(bind.jcstore)) return this.getStore(bind.jcstore);
        if (this.isStore(bind.store)) return this.getStore(bind.store);
        return this._scanBinders(bind, this.getStore);
    },

    getJcStore: function(bind) {
        if (!bind) return null;
        var store = this.getStore(bind);
        if (!store) return null;
        if (this.isJcStore(store)) return store;
        return null;
    },

    getRec: function(bind) {
        if (bind instanceof Ext.data.Model) return bind;
        var store = this.getJcStore(bind);
        if (!store) return null;
        return store.getCurRec();
    },

    getRecData: function(bind) {
        var rec = this.getRec(bind);
        if (rec) return rec.data;
        return bind;
    },

    getRecId: function(bind) {
        var rec = this.getRec(bind);
        if (rec) return rec.getId();
        rec = this.getRecData(bind);
        if (rec) return rec.id;
        return null;
    },

    getFieldValue: function(bind, fieldName) {
        var rec = this.getRec(bind);
        if (!rec) return null;
        return rec.get(fieldName);
    },

    setFieldValue: function(bind, fieldName, value) {
        var rec = this.getRec(bind);
        if (!rec) return null;
        rec.set(fieldName, value);
    }

});
 