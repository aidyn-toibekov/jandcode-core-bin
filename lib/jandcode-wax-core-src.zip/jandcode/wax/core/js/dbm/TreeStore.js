/**
 *
 */
Ext.define('Jc.dbm.TreeStore', {
    extend: 'Ext.data.TreeStore',

    daoname: null,
    daomethod: null,
    daoparams: null,
    daoloaded: false,

    clientdata: null,

    /**
     * Текущая запись. Для тех, кто рассматривает store как запись.
     */
    _curRec: null,

    constructor: function(config) {
        var cfg = Ext.apply({
            autoLoad: false,
            defaultRootProperty: "data",
            proxy: {
                type: 'dao',
                store: this
            },
            root: {
                text: 'ROOT',
                id: 0,
                expanded: true
            }
        }, config);
        if (cfg.fields) {
            throw new Error('For Jc.dbm.Store "fields" not valid config');
        }
        if (cfg.data) {
            cfg.root.data = cfg.data;
            delete cfg.data;
        }
        this.callParent([cfg]);
        this.dictdata = new Jc.dbm.DictData(this.domain.model);
        this.clientdata = {};
    },

    /**
     * hack ставим ссылку на treeStore для каждой записи
     */
    fillNode: function(node, records) {
        var ln = records ? records.length : 0, i = 0;
        for (; i < ln; i++) {
            records[i].treeStore = this;
        }
        return this.callParent(arguments);
    },

    ////// currec

    /**
     * Возвращает "текущую запись". Это виртуальная запись, которая при пустом store
     * на чтение всегда дает null, а при записи - создает новую пустую запись.
     * Если store не пустой и явно текущая запись не установлена, то возвращается
     * первая запись.
     */
    getCurRec: function() {
        var r = this._curRec;
        if (!r) {
            if (this.count() == 0) {
                r = Ext.create("Jc.dbm.FirstProxyRecord", this, null);
            } else {
                r = this.getAt(0);
            }
        }
        return r;
    },

    /**
     * Установить текущую запись, которая будет возвращаена через getCurRec().
     * @param rec номер записи или запись
     */
    setCurRec: function(rec) {
        if (Ext.isNumber(rec)) {
            this._curRec = this.getAt(rec);
        } else {
            this._curRec = rec;
        }
    },

    ////// extensions

    /**
     * Количество записей. Синоним для count(). Для совместимости с jandcode.dbm.data.DataStore
     */
    size: function() {
        return this.count();
    },

    /**
     * Загрузка данных для словарей, которые используются в этом store
     */
    resolveDicts: function() {
        return this.dictdata.resolveDictStore(this);
    },

    /**
     * Загрузить результат dao в это store. Синхронно.
     */
    daoload: function(daoname, daomethod, daoparams) {
        return this.domain.model._daoload_store(this, daoname, daomethod, daoparams);
    },

    onProxyLoad: function(operation) {
        var rawData;
        try {
            // проверяем на предмет прицепленны dictdata
            rawData = this.proxy.reader.rawData;
        } catch(e) {
        }
        if (rawData) {
            this.dictdata.update(rawData.dictdata);
            this.domain.model._checkCacheInfo(rawData);
            if (rawData.clientdata) {
                Ext.apply(this.clientdata, rawData.clientdata);
            }
        }
        return this.callParent(arguments);
    },

    /**
     * Стандартная загрузка extjs с уточнением параметром для proxy
     * @param config
     */
//    load: function(config) {
//        this.domain.model._prepare_load_store(this, config);
//        return this.callParent(arguments);
//    },

    //////

    /**
     * Аналог store.each
     * Перебор всех записей. Включая все дочерние дочерних.
     * @param fn функция вызываемая для каждой записи
     */
    each: function(fn) {
        this.getRootNode().cascadeBy(fn);
    }

});
