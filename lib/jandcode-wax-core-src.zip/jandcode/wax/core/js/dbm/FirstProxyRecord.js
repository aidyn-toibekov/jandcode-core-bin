/**
 * proxy для записи из store, полученной через getCurRec().
 * Если записей в store нет, то на чтение дает null, на запись - создает первую запись
 */
Ext.define('Jc.dbm.FirstProxyRecord', {

    constructor: function(store, rec) {
        this.store = store;
        this.rec = rec;
    },

    _createRec: function() {
        if (this.rec == null) {
            if (this.store.count() == 0) {
                this.store.add({});
            }
            this.rec = this.store.getAt(0);
        }
    },

    get: function(fieldName) {
        if (!this.rec) return null;
        return this.rec.get.apply(this.rec, arguments);
    },

    set: function(fieldName, value) {
        this._createRec();
        return this.rec.set.apply(this.rec, arguments);
    },

    getDictValue: function(fieldName, dictFieldName) {
        if (!this.rec) return null;
        return this.rec.getDictValue.apply(this.rec, arguments);
    },

    getValues: function() {
        if (!this.rec) return {};
        return this.rec.getValues.apply(this.rec, arguments);
    },

    getValue: function(fieldName) {
        return this.get(fieldName);
    },

    /**
     * Очистить все значения в записи
     */
    clearValues: function() {
        if (!this.rec) return;
        return this.rec.clearValues.apply(this.rec, arguments);
    },

    setValue: function(fieldName, value) {
        return this.set(fieldName, value);
    },

    resolveDicts: function() {
        if (!this.rec) return false;
        return this.rec.resolveDicts.apply(this.rec, arguments);
    }

});
 