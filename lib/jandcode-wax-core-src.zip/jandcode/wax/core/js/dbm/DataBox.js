/**
 * DataBox. Все свойства (кроме явно в классе указанных) - значимые значения.
 */
Ext.define('Jc.dbm.DataBox', {

    model: null,
    daoname: null,
    daomethod: null,
    daoparams: null,
    daoloaded: false,

    constructor: function(config) {
        Ext.apply(this, config);
    },

    /**
     * Загрузить результат dao в это store.
     */
    daoload: function(daoname, daomethod, daoparams) {
        if (arguments.length > 0) {
            this.daoname = daoname;
            this.daomethod = daomethod;
            this.daoparams = daoparams;
        }
        this.daoloaded = false;
        this.model._daoload(this, this.daoname, this.daomethod, this.daoparams);
        this.daoloaded = true;
    }

});
