/**
 * Конвертор типов данных в/из dao совместимые
 */
Ext.define('Jc.dbm.Cnv', {

    singleton: true,

    /**
     * Конвертация объекта javascript в формат параметров dao
     */
    toJson: function(v) {
        var res = {
            type: 'null',
            value: null
        };
        if (v === undefined || v === null) {
            return res;

        } else if (Ext.isBoolean(v)) {
            res.type = 'boolean';
            res.value = v;

        } else if (Ext.isNumber(v)) {
            res.type = 'number';
            res.value = v;

        } else if (Ext.isString(v)) {
            res.type = 'string';
            res.value = v;

        } else if (Ext.isArray(v)) {
            res.type = 'list';
            res.value = v;

        } else if (Ext.isDate(v)) {
            res.type = 'date';
            res.value = Ext.Date.format(v, Jc.ini.datetimeFormatServer);

        } else if (v instanceof Ext.data.AbstractStore) {
            res.type = 'datastore';
            res.value = this._storeToJson(v);

        } else if (v instanceof Ext.data.Model) {
            res.type = 'datarec';
            res.value = this._recToJson(v);

        } else if (v instanceof Jc.dbm.DataBox) {
            res.type = 'databox';
            res.value = this._databoxToJson(v);

        } else {
            res.type = 'map';
            res.value = v;
        }
        return res;
    },

    /**
     * Конвертация значения, полученного как результат работы dao, в javascript объект
     */
    fromJson: function(v, model) {
        if (v.type == 'datastore') {
            return this._jsonToStore(v.value, model);

        } else if (v.type == 'datatreestore') {
            return this._jsonToTreeStore(v.value, model);

        } else if (v.type == 'datarec') {
            return this._jsonToStore(v.value, model);

        } else if (v.type == 'databox') {
            return this._jsonToDatabox(v.value, model);

        } else if (v.type == 'datatree') {
            throw new Error(UtLang.t("По данным datatree нельзя создать store, можно только загрузить в существующий"));

        } else {
            return v.value;
        }
    },

    /**
     * Загрузка значения, полученного как результат работы dao, в javascript объект
     * @param to куда
     * @param v что (json)
     * @param model модель
     */
    loadJson: function(to, v, model) {
        if (to instanceof Jc.dbm.Store) {
            to.suspendEvents();
            try {
                to.removeAll();
                if (v.type == 'datastore' || v.type == 'datatree' || v.type == 'datarec') {
                    to.dictdata.update(v.value['dictdata']);
                    to.add(v.value['data']);
                    if (v.value.clientdata) {
                        Ext.apply(to.clientdata, v.value.clientdata);
                    }

                } else if (v.type == 'map') {
                    to.add(v.value);

                } else {
                    throw new Error("unsupported type: " + v.type);
                }
            } finally {
                to.resumeEvents();
                to.fireEvent('load', to, to.getRange(), true);
                to.fireEvent('datachanged', to);
                to.fireEvent('refresh', to);
            }

        } else if (to instanceof Jc.dbm.ExtModel) {
            if (v.type == 'datastore' || v.type == 'datarec') {
                to.store.dictdata.update(v.value['dictdata']);
                to.set(v.value['data'][0]); // только первую запись берем

            } else if (v.type == 'map') {
                to.set(v.value);

            } else {
                throw new Error("unsupported type: " + v.type);
            }

        } else if (to instanceof Jc.dbm.DataBox) {
            if (v.type == 'databox') {
                this._loadDatabox(to, v.value, model);

            } else {
                throw new Error("unsupported type: " + v.type);
            }

        } else {
            throw new Error("unsupported type");
        }
    },

    //////

    //todo + динамические store
    _storeToJson: function(store) {
        var res = {
            struct: {
                name: store.domain.name
            },
            data: this._storeToArray(store)
        };
        if (store.clientdata) {
            res.clientdata = {};
            Ext.apply(res.clientdata, store.clientdata);
        }
        return res;
    },

    _storeToArray: function(store) {
        var th = this;
        var arr = [];
        store.each(function(rec) {
            arr.push(rec.getValues());
        });
        return arr;
    },

    _recToJson: function(rec) {
        var res = {
            struct: {
                name: rec.store.domain.name
            },
            data: [rec.getValues()]
        };
        if (rec.clientdata) {
            res.clientdata = {};
            Ext.apply(res.clientdata, rec.clientdata);
        }
        return res;
    },

    _databoxToJson: function(v) {
        var res = {};
        for (var key in v) {
            var vv = v[key];
            if (Ext.isFunction(vv)) continue;
            if (key.indexOf("$") != -1
              || key == 'config'
              || key == 'superclass'
              || key == 'model'
              || key == 'daoname'
              || key == 'daomethod'
              || key == 'daoparams'
              || key == 'daoloaded'
              ) continue;
            res[key] = this.toJson(vv);
        }
        return res;
    },

    //////

    _jsonToStore: function(data, model) {
        var cfg = data['struct'];
        var dn = cfg['name'];
        if (dn != "sys") cfg = null;
        var domain = model.createDomain(dn, cfg);
        var t = domain.createStore();
        t.dictdata.update(data['dictdata']);
        t.add(data['data']);
        if (data.clientdata) {
            Ext.apply(t.clientdata, data.clientdata);
        }
        if (data.instdata) {
            for (var idpn in data.instdata) {
                t[idpn] = this.fromJson(data.instdata[idpn], model);
            }
        }
        if (t.clientdata.total) {
            t.totalCount = t.clientdata.total;
        }
        return t;
    },

    _jsonToTreeStore: function(data, model) {
        var cfg = data['struct'];
        var dn = cfg['name'];
        if (dn != "sys") cfg = null;
        var domain = model.createDomain(dn, cfg);
        var storeCfg = {};
        if (data['data']) {
            storeCfg.data = data['data'];
        }
        if (data.instdata) {
            for (var idpn in data.instdata) {
                storeCfg[idpn] = this.fromJson(data.instdata[idpn], model);
            }
        }
        var t = domain.createTreeStore(storeCfg);
        t.dictdata.update(data['dictdata']);
        if (data.clientdata) {
            Ext.apply(t.clientdata, data.clientdata);
        }
        if (t.clientdata.total) {
            t.totalCount = t.clientdata.total;
        }
        return t;
    },

    _jsonToDatabox: function(v, model) {
        var res = new Jc.dbm.DataBox();
        for (var key in v) {
            res[key] = this.fromJson(v[key], model);
        }
        return res;
    },

    //////

    _loadDatabox: function(to, v, model) {
        for (var nm in v) {
            var v1 = v[nm];
            var cv = to[nm];
            if (!cv) {
                // нет такого поля в DataBox
                to[nm] = this.fromJson(v1, model);
            } else {
                // есть такое поле в DataBox
                if (cv instanceof Jc.dbm.Store || cv instanceof Jc.dbm.DataBox ||
                  cv instanceof Ext.data.Model) {
                    this.loadJson(cv, v1, model)
                } else {
                    v[nm] = this.fromJson(v1, model);
                }
            }
        }
    }


});
