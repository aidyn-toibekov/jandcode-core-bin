/**
 * Словарные данные, прикрепленные к store.
 *
 * Каждый store имеет такой объект. В нем храним данные словарей, которые
 * задействованы в store. Т.е. тут хранится не полный набор словарных данных,
 * а только те, чьи значения используются в качестве значений полей.
 */
Ext.define('Jc.dbm.DictData', {

    /**
     * Собственно данные словарей. Формат:
     * {
     *      dict: {                   // имя словаря (lowercase)
     *          key: {                // значение id
     *              field:            // имя словарного поля
     *                  value         // значение словарного поля
     *          }
     *      }
     *  }
     */
    data: null,

    /**
     * Модель
     */
    model: null,

    constructor: function(model) {
        this.data = {};
        this.model = model;
    },

    /**
     * Получить значение из словаря. Для не найденных возвращается пустая строка
     * @param dictname словарь
     * @param dictkey ключ
     * @param dictfield поле
     */
    getValue: function(dictname, dictkey, dictfield) {
        var d2 = this.getValues(dictname, dictkey);
        if (!d2) return "";
        if (!dictfield) {
            // словарное поле не указано, берем по умолчанию
            var dm = this.model.getDomain(dictname);
            if (!dm.dict) return ""; // это не словарь
            dictfield = dm.dict.defaultField;
        }
        var d3 = d2[dictfield];
        if (!d3) return "";
        return d3;
    },

    /**
     * Возвращает объект со значениями или null, если нет словаря или нет ключа в словаре
     * @param dictname для какого словаря
     * @param dictkey для какого ключа
     */
    getValues: function(dictname, dictkey) {
        if (!dictname) return null; // нет имени словаря
        dictname = dictname.toLowerCase();
        var d1 = this.data[dictname];
        if (!d1) return null;
        var d2 = d1[dictkey];
        if (!d2) return null;
        return d2;
    },

    /**
     * Обновить данные. dictdata соответствует по формату this.data
     */
    update: function(dictdata) {
        if (!dictdata) return;
        //
        for (var dictname in dictdata) {
            var dd = dictdata[dictname];
            var dn = dictname.toLowerCase();
            var cdd = this.data[dn];
            if (!cdd) {
                cdd = {};
                this.data[dn] = cdd;
            }
            for (var keyname in dd) {
                var kitem = dd[keyname];
                var kdd = cdd[keyname];
                if (!kdd) {
                    kdd = {};
                    cdd[keyname] = kdd;
                }
                for (var fn in kitem) {
                    kdd[fn] = kitem[fn];
                }
            }
        }
    },

    /**
     * Обновить конкретный словарь
     * @param dictname имя словаря
     * @param data данные:
     *  rec - id записи используется как ключ, поля как dictfield
     *  store - добавляются все записи. id записи используется как ключ, поля как dictfield
     *  map - свойство id используется как ключ, остальные свойства как значения
     */
    updateDict: function(dictname, data) {
        var dd = {};
        var d = {};
        var d1;
        dd[dictname.toLowerCase()] = d;
        if (data instanceof Jc.dbm.ExtModel) {
            d1 = data.getValues();
            d[data.get("id")] = d1;
        } else if (data instanceof Jc.dbm.Store) {
            data.each(function(rec) {
                d1 = data.getValues();
                d[rec.get("id")] = d1;
            });
        } else {
            d[data['id']] = data;
        }
        this.update(dd);
    },

    /**
     * Загрузка данных для словарей, которые используются в записи.
     * Если словарных полей нет, запрос не делается.
     * Возвращает true, если был запрос на resolve.
     * @param rec для какой запис
     * @param force запрос на обновление делается в любом случае, даже если данные для словаря
     *              есть (обновление словарных данных)
     * @param store какое store использовать. Если не указана, берется store из записи
     */
    resolveDictRec: function(rec, force, store) {
        if (!store) store = rec.store;
        var ff = [];
        // ищем все поля со словарями
        Ext.each(store.domain.fields, function(f) {
            if (f.dict) ff.push(f);
        });
        if (ff.length == 0) return false; // нет словарей
        // собираем структуру для запроса
        var p = {};
        var needQuery = false;
        for (var i = 0; i < ff.length; i++) {
            var f = ff[i];
            var vv = rec.get(f.name);
            if (!vv) continue; // нет значения
            if (!force) {
                var curValues = this.getValues(f.dict, vv);
                if (curValues) continue; // такой ключ есть
            }
            var p1 = p[f.dict];
            if (!p1) {
                needQuery = true;
                p1 = [];
                p[f.dict] = p1;
            }
            p1.push(vv);
        }
        if (needQuery) {
            // выполняем запрос
            var r = this.model.daoinvoke("dict.utils", "default/resolveDicts", [p]);
            // обновляем словари
            this.update(r);
        }
        return needQuery;
    },

    /**
     * Загрузка данных для словарей, которые используются в store.
     * Если словарных полей нет, запрос не делается.
     * Возвращает true, если был запрос на resolve.
     * @param store для какого store
     * @param force запрос на обновление делается в любом случае, даже если данные для словаря
     *              есть (обновление словарных данных)
     */
    resolveDictStore: function(store, force) {
        var th = this;
        var ff = [];
        // ищем все поля со словарями
        Ext.each(store.domain.fields, function(f) {
            if (f.dict) ff.push(f);
        });
        if (ff.length == 0) return false; // нет словарей
        // собираем структуру для запроса
        var p = {};
        var needQuery = false;
        store.each(function(rec) {
            for (var i = 0; i < ff.length; i++) {
                var f = ff[i];
                var vv = rec.get(f.name);
                if (!vv) continue; // нет значения
                if (!force) {
                    var curValues = th.getValues(f.dict, vv);
                    if (curValues) continue; // такой ключ есть
                }
                var p1 = p[f.dict];
                if (!p1) {
                    needQuery = true;
                    p1 = [];
                    p[f.dict] = p1;
                }
                p1.push(vv);
            }
        });
        if (needQuery) {
            // выполняем запрос
            var r = this.model.daoinvoke("dict.utils", "default/resolveDicts", [p]);
            // обновляем словари
            this.update(r);
        }
        return needQuery;
    }


});
 