/**
 * Поле. Аналог jandcode.dbm.Field.
 *
 * Нужно иметь ввиду, что по некоторым особенностям extjs поля имеют регистрозависимое имя.
 * Соотвественно в коде js это нужно учитывать и писать имена полей так же, как они описаны
 * в описании домана!
 */
Ext.define('Jc.dbm.Field', {

    name: '',

    /**
     * Домен-владелец
     */
    owner: null,

    /**
     * Какой модели принадлежит
     */
    model: null,

    title: null,

    titleShort: null,

    visible: true,

    editable: true,

    size: 0,

    dict: null,

    datatype: 'string',

    /**
     * Свойства колонки гриды по умолчанию
     */
    column: null,

    /**
     * Свойства поля ввода по умолчанию
     */
    input: null,

    /**
     * Свойства datalabel по умолчанию
     */
    datalabel: null,

    constructor: function(config) {
        Ext.merge(this, config);
        this._initUiInfo("column");
        this._initUiInfo("input");
        this._initUiInfo("datalabel");
    },

    _initUiInfo: function(name) {
        if (!this[name]) {
            this[name] = {};
        }
        if (!this[name].jsclass) {
            this[name].jsclass = "String";
        }
    },

    getTitle: function() {
        if (!this.title) return '';
        return this.title;
    },

    getTitleShort: function() {
        if (!this.titleShort) return this.getTitle();
        return this.titleShort;
    }

});
