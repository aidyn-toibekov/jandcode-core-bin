/**
 * Домен. Аналог jandcode.dbm.Domain
 */
Ext.define('Jc.dbm.Domain', {

    title: null,

    fields: null,

    constructor: function(config) {
        var th = this;
        Ext.merge(this, config);
        this.fields = [];
        this._fieldsByName = {};
        if (config.fields) {
            Ext.Array.each(config.fields, function(z) {
                th.addField(z);
            });
        }
    },

    addField: function(config) {
        var f = new Jc.dbm.Field(config);
        f.owner = this;
        f.model = this.model;
        //
        var nm = f.name;
        this.fields.push(f);
        this._fieldsByName[nm] = f;
    },

    /**
     * Поле по имени. Возвращает null, если поле не найдено.
     */
    findField: function(name) {
        return this._fieldsByName[name];
    },

    /**
     * Поле по имени. Генерит ошибку, если поле не найдено.
     */
    f: function(name) {
        var it = this.findField(name);
        if (it) return it;
        throw new Error('Not found field: ' + name);
    },

    /**
     * extjs модель для домена.
     */
    _getExtModelClass: function() {
        return this.model._getExtModelClassForDomain(this);
    },

    /**
     * Создать store для домена
     */
    createStore: function(config) {
        var cfg = Ext.apply({}, config);
        cfg.domain = this;
        cfg.model = this._getExtModelClass();
        return Ext.create("Jc.dbm.Store", cfg);
    },

    /**
     * Создать treestore для домена
     */
    createTreeStore: function(config) {
        var cfg = Ext.apply({}, config);
        cfg.domain = this;
        cfg.model = this._getExtModelClass();
        return Ext.create("Jc.dbm.TreeStore", cfg);
    },

    /**
     * Возвращает имя поля словаря по умолчанию, если этот домен описывает словарь
     */
    getDictDefaultField: function() {
        if (!this.dict) return null;
        return this.dict.defaultField;
    },

    /**
     * Создать фрейм для домена
     * @param frameName имя фрейма, описанного в rt 'js/frame/NAME'
     * @param frameConfig конфигурация фрейма
     */
    createDomainFrame: function(frameName, frameConfig) {
        return Jc.app.createBuilder(this).createDomainFrame(frameName, frameConfig);
    }

});
