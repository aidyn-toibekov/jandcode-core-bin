/**
 * Модель. Скромный аналог jandcode.dbm.Model
 */
Ext.define('Jc.dbm.Model', {

    /**
     * Имя модели
     */
    name: 'default',

    /**
     * Список языков, поддерживаемых моделью (базой).
     * Формат: ['ru','en']. Заголовки языков можно взять из Jc.app.ini.langs
     *
     */
    langs: null,

    /**
     * Текущий язык модели. Должен быть в списке языков поддерживаемых интерфейсом.
     */
    lang: "ru",

    // структуры доменов в формате: 'domainName' : {DOMAINSTRUCT}
    _domainStructs: null,

    // кешированные домены, полученые через getDomain
    _domains: null,

    // кешированные словари в формате: 'domainname' : STORE
    _dicts: null,

    // кешированные extjs модели в формате: 'hash-domain-struct' : EXTMODEL-CLASS
    _extmodels: null,

    // версия кеша
    _cacheVersion: 0,

    constructor: function(config) {
        Ext.apply(this, config);
        this._domainStructs = {};
        this._domains = {};
        this._dicts = {};
        this._extmodels = {};
        this.langs = ["ru"];
    },

    /**
     * Получение структуры домена. Если структура домена уже была получена, то
     * возвращается закешированная структура, иначе делается запрос на сервер.
     * @param domainName имя домена
     */
    _getDomainStruct: function(domainName) {
        var nm = domainName.toLowerCase();
        var st = this._domainStructs[nm];
        if (!st) {
            var data = Jc.requestJson({
                url: Jc.baseUrl + 'dbm/domain?_=' + domainName, //url только для наглядности!
                params: {
                    model: this.name,
                    domain: domainName,
                    cacheinfo: this._cacheVersion
                }
            });
            st = data['struct'];
            this._domainStructs[nm] = st;
            this._checkCacheInfo(data);
        }
        return st;
    },

    /**
     * Возвращает класс модели extjs для домена. Модель формируется на основе
     * структуры домена. Т.е. разные домены с одинаковой структурой будут
     * иметь одинаковые модели extjs
     */
    _getExtModelClassForDomain: function(domain) {
        var key = "";
        var i, f;
        for (i = 0; i < domain.fields.length; i++) {
            f = domain.fields[i];
            var sf = f.name + ":" + f.datatype + ";";
            key += sf;
        }
        var extm = this._extmodels[key];
        if (extm) return extm;
        // модели еще нет, формируем
        var cfg = {
            extend: "Jc.dbm.ExtModel",
            fields: []
        };
        for (i = 0; i < domain.fields.length; i++) {
            f = domain.fields[i];
            var ff = {
                name: f.name,
                type: Jc.dbm.Dbm.datatypeToExtType(f.datatype),
                useNull: true,
                defaultValue: null
            };
            cfg.fields.push(ff);
        }
        // создаем класс и кешируем его
        var mname = "Jc.dbm.EXTMODEL_" + Ext.id();
        extm = Ext.define(mname, cfg);
        this._extmodels[key] = extm;
        //
        return extm;
    },

    /**
     * Создание нового экземпляра домена
     * @param domainName имя домена
     * @param domainAdditionalConfig дополнительный config для домена. Тут можно,
     * например, добавить дополнительные поля:
     *
     *      var d = Jc.createDomain("id", {
     *          fields: [
     *              {name:'f1', datatype: 'string'},
     *              {name:'f2', datatype: 'int', visible: false}
     *          ]
     *      });
     */
    createDomain: function(domainName, domainAdditionalConfig) {
        var dd = Ext.apply({model: this}, this._getDomainStruct(domainName));
        var dom = Ext.create('Jc.dbm.Domain', dd);
        //
        if (domainAdditionalConfig) {
            var cfg = Ext.apply({}, domainAdditionalConfig);
            if (cfg.fields) {
                Ext.Array.each(cfg.fields, function(z) {
                    dom.addField(z);
                });
                delete cfg.fields;
            }
            Ext.apply(dom, cfg);
        }
        //
        return dom;
    },

    /**
     * Получить кешированный экземпляр домена
     * @param domainName
     */
    getDomain: function(domainName) {
        var nm = domainName.toLowerCase();
        var st = this._domains[nm];
        if (!st) {
            st = this.createDomain(domainName);
            this._domains[nm] = st;
        }
        return st;
    },

    /**
     * Создать store для домена
     * @param domainName имя домена
     * @param storeConfig конфигурация для store
     */
    createStore: function(domainName, storeConfig) {
        var domain = this.createDomain(domainName);
        return domain.createStore(storeConfig);
    },

    /**
     * Создать treestore для домена
     * @param domainName имя домена
     * @param storeConfig конфигурация для store
     */
    createTreeStore: function(domainName, storeConfig) {
        var domain = this.createDomain(domainName);
        return domain.createTreeStore(storeConfig);
    },

    /**
     * Создать databox
     */
    createDataBox: function(config) {
        var cfg = Ext.apply({
            model: this
        }, config);
        return Ext.create("Jc.dbm.DataBox", cfg);
    },

    /**
     * Создание объекта из dbm json. См. Jc.dbm.Cnv.fromJson
     * @param json
     */
    createFromDbmJson: function(json) {
        return Jc.dbm.Cnv.fromJson(json, this);
    },

    //////

    /**
     * Массив параметров преобразует в json для использования в daoinvoke
     * @param daoparams обычный массив данных
     */
    daoparamsToJson: function(daoparams) {
        var dp = [];
        if (daoparams) {
            for (var i = 0; i < daoparams.length; i++) {
                dp.push(Jc.dbm.Cnv.toJson(daoparams[i]));
            }
        }
        return Ext.encode(dp);
    },

    /**
     * Выполнение dao. Возвращает нетипизированный результат (то, что пришло).
     */
    _daoinvoke: function(daoname, daomethod, daoparams) {
        if (Ext.isObject(daoname)) {
            daomethod = daoname.daomethod;
            daoparams = daoname.daoparams;
            daoname = daoname.daoname;
        }
        if (!daoparams) {
            daoparams = [];
        }
        if (!Ext.isArray(daoparams)) {
            throw new Error("daoparams must be array");
        }
        var dpjson = this.daoparamsToJson(daoparams);
        var res = Jc.requestJson({
            url: Jc.baseUrl + 'dbm/daoinvoke?_=' + daoname + "|" + daomethod, //url только для наглядности!
            params: {
                model: this.name,
                daoname: daoname,
                daomethod: daomethod,
                daoparams: dpjson,
                cacheinfo: this._cacheVersion
            }
        });
        this._checkCacheInfo(res);
        return res;
    },


    /**
     * Выполнение dao. Возвращает типизированный результат
     */
    daoinvoke: function(daoname, daomethod, daoparams) {
        var res = this._daoinvoke(daoname, daomethod, daoparams);
        return Jc.dbm.Cnv.fromJson(res, this);
    },

    /**
     * Выполнение dao. Возвращает отрендеренный результат (используется метод DbmAction.daorender).
     * Синхронный метод!
     */
    daorender: function(daoname, daomethod, daoparams, rendertype) {
        if (!daoparams) {
            daoparams = [];
        }
        if (!rendertype) {
            rendertype = "html";
        }
        if (!Ext.isArray(daoparams)) {
            throw new Error("daoparams must be array");
        }
        var dpjson = this.daoparamsToJson(daoparams);
        var res = Jc.requestText({
            url: Jc.baseUrl + 'dbm/daorender?_=' + daoname + "|" + daomethod, //url только для наглядности!
            params: {
                model: this.name,
                daoname: daoname,
                daomethod: daomethod,
                daoparams: dpjson,
                rendertype: rendertype
            }
        });
        return res;
    },

    /**
     * Выполнение dao через Jc.requestDownload.
     * Используется метод DbmAction.daorender.
     * Асинхронный метод!
     */
    daodownload: function(daoname, daomethod, daoparams, rendertype) {
        if (!daoparams) {
            daoparams = [];
        }
        if (!rendertype) {
            rendertype = "bin";
        }
        if (!Ext.isArray(daoparams)) {
            throw new Error("daoparams must be array");
        }
        var dpjson = this.daoparamsToJson(daoparams);
        Jc.requestDownload({
            url: Jc.baseUrl + 'dbm/daorender?_=' + daoname + "|" + daomethod, //url только для наглядности!
            params: {
                model: this.name,
                daoname: daoname,
                daomethod: daomethod,
                daoparams: dpjson,
                rendertype: rendertype
            }
        });
    },

    /**
     * Загрузка результата dao в существующий объект. Превый параметры - куда,
     * остальные - параметры dao
     */
    _daoload: function(to, daoname, daomethod, daoparams) {
        var res = this._daoinvoke(daoname, daomethod, daoparams);
        Jc.dbm.Cnv.loadJson(to, res, this);
    },


    /**
     * Загрузить результат dao в store. Синхронно.
     * Используется как утилитный метод для store и treestore
     */
    _daoload_store: function(store, daoname, daomethod, daoparams) {
        if (daoname) store.daoname = daoname;
        if (daomethod) store.daomethod = daomethod;
        if (daoparams) store.daoparams = daoparams;
        if (!store.daoname) {
            if (store.domain) {
                store.daoname = store.domain.name;
            }
        }
        if (!store.daoname) {
            throw new Error(UtLang.t("daoname не назначен"));
        }
        if (!store.daomethod) {
            throw new Error(UtLang.t("daomethod не назначен"));
        }
        store.daoloaded = false;
        this._daoload(store, store.daoname, store.daomethod, store.daoparams);
        store.daoloaded = true;
    },

    /**
     * Подготовка к стандартной загрузке extjs с уточнением параметром для proxy
     * Используется как утилитный метод для store и treestore
     */
//    _prepare_load_store: function(store, config) {
//        if (!store.daoname) {
//            if (store.domain) {
//                store.daoname = store.domain.name;
//            }
//        }
//        if (!store.daoname) {
//            throw new Error(UtLang.t("daoname не назначен"));
//        }
//        if (!store.daomethod) {
//            throw new Error(UtLang.t("daomethod не назначен"));
//        }
//        var px = store.getProxy();
//        if (px && px._prepareParams) {
//            px._prepareParams(store);
//        }
//    },

    /**
     * Возвращает store с кешированными данными словаря. Работает только для обычных
     * словарей (не resolve)
     * @param name имя словаря
     * @param autoLoad по умолчанию true - загружать сразу
     */
    dict: function(name, autoLoad) {
        name = name.toLowerCase();
        var st = this._dicts[name];
        if (!st) {
            var domain = this.getDomain(name);
            if (!domain.dict) throw new Error(UtLang.t("Домен не является словарем: {0}", name));
            if (domain.dict.resolve) throw new Error(UtLang.t("Домен является resolve-словарем: {0}", name));
            //
            var dictDomain = domain.dict.domain;
            if (!dictDomain) dictDomain = name;
            dictDomain = this.getDomain(dictDomain);
            //
            st = dictDomain.createStore();
            st.name = name;
            st.daoname = "dict.utils";
            st.daomethod = "default/getData";
            st.daoparams = [name];
            this._dicts[name] = st;
        }
        if (autoLoad === undefined || autoLoad === true) {
            if (!st.daoloaded) st.daoload();
        }
        return st;
    },

    /**
     * Создать фрейм для домена
     * @param domainOrNameDomain домен или имя домена
     * @param frameName имя фрейма, описанного в rt 'js/frame/NAME'
     * @param frameConfig конфигурация фрейма
     */
    createDomainFrame: function(domainOrNameDomain, frameName, frameConfig) {
        var domain = domainOrNameDomain;
        if (Ext.isString(domain)) {
            domain = this.createDomain(domain);
        }
        return domain.createDomainFrame(frameName, frameConfig);
    },

    ////// cache

    _checkCacheInfo: function(data) {
        if (!data) return;
        var ci = data["cacheinfo"];
        if (!ci) return;
        if (ci["version"]) this._cacheVersion = ci["version"];
        if (ci["dataNames"]) {
            Ext.each(ci["dataNames"], function(z) {
                if (Ext.isString(z)) {
                    var dn = z.toLowerCase();
                    var st = this._dicts[dn];
                    if (st) {
                        st.daoloaded = false; // ставим флаг не загруженного
                    }
                }
            }, this);
        }
    }

});
