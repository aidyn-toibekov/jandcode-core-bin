/**
 * ExtJs proxy для загрузки данных в store стандартным способом:
 *
 * var store = Jc.createStore("WaxTest_Tab1", {
 *      daoname: 'WaxTest_Tab1',
 *      daomethod: 'default/list',
 *      daoparams: []
 * });
 * store.load();
 */
Ext.define('Jc.dbm.DaoProxy', {
    extend: 'Ext.data.proxy.Ajax',
    alias: 'proxy.dao',

    actionMethods: {
        create: 'POST',
        read: 'POST',
        update: 'POST',
        destroy: 'POST'
    },

    constructor: function(config) {
        var cfg = Ext.apply({
            url: Jc.baseUrl + 'NONE',
            reader: {
                type: 'json',
                root: 'data',
                successProperty: 'success'
            }
        }, config);
        if (!cfg.extraParams) {
            cfg.extraParams = {};
        }
        if (!cfg.params) {
            cfg.params = {};
        }
        //
        this.callParent([cfg]);
        //
        this.on("exception", function(a, b, c) {
            var jsonData;
            try {
                jsonData = Ext.decode(b.responseText);
            } catch(e) {
                Jc.error(e);
            }
            Jc.showError(new Jc.Error({err: jsonData, type: 'json'}));
        });
    },

    buildRequest: function() {
        var a = this.callParent(arguments);
        var store = this.store;
        if (store) {
            a.url = Jc.baseUrl + 'dbm/loadstore?_=' + store.daoname + "|" + store.daomethod;
            a.params.daoname = store.daoname;
            a.params.daomethod = store.daomethod;
            a.params.daoparams = store.domain.model.daoparamsToJson(store.daoparams);
            a.params.model = store.domain.model.name;
        }
        return a;
    }//,

//    /**
//     * Подготовить параметры перед вызовом. Вызывается из store.load
//     */
//    _prepareParams: function(store) {
//    }

});
 