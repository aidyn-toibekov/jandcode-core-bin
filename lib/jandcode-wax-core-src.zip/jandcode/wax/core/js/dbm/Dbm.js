/**
 * Глобальные объекты для dbm
 */
Ext.define('Jc.dbm.Dbm', {

    singleton: true,
    requires: [
        'Jc.dbm.Field',
        'Jc.dbm.Domain',
        'Jc.dbm.Model',
        'Jc.dbm.Store',
        'Jc.dbm.DataBox',
        'Jc.dbm.DictData',
        'Jc.dbm.ExtModel',
        'Jc.dbm.Cnv',
        'Jc.dbm.DataBinder'
    ],

    /**
     * Зарегистрированные модели
     */
    models: {},

    /**
     * Соответствие между типом jandcode и типом extjs
     */
    datatypes: {
        'boolean': 'boolean',
        'date': 'jcdate',
        'datetime': 'jcdate',
        'double': 'float',
        'int': 'int',
        'long': 'int'
    },

    constructor: function(config) {
        Ext.apply(this, config);
        Ext.apply(Ext.data.Types, {
            // тип данных - date (с корректным преобразованием)
            JCDATE: {
                convert: function(v) {
                    if (!v) {
                        return null;
                    }
                    if (Ext.isDate(v)) {
                        return v;
                    }
                    var parsed = Ext.Date.parse(v, 'c');
                    return parsed ? new Date(parsed) : null;
                },
                sortType: Ext.data.SortTypes.asDate,
                type: 'jcdate'
            }
        });
        this._addModel('default');
    },

    /**
     * Зарегистрировать модель с указанным именем. Вызывается автоматически.
     */
    _addModel: function(name) {
        var m = Ext.create("Jc.dbm.Model", {name: name});
        this.models[name] = m;
        return m;
    },

    /**
     * Получить модель по имени.
     * @param name имя модели. По умолчанию 'default'
     */
    getModel: function(name) {
        if (!name) name = 'default';
        var m = this.models[name];
        if (!m) throw new Error("Model not found: " + name);
        return m;
    },

    /**
     * Для типа данных jandcode возвращает тип данных extjs
     */
    datatypeToExtType: function(t) {
        var a = this.datatypes[t];
        if (!a) return "auto";
        return a;
    }

}, function() {
    // aliases
    Jc.model = Jc.dbm.Dbm.getModel();
    Jc.createDomain = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "createDomain");
    Jc.createStore = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "createStore");
    Jc.createTreeStore = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "createTreeStore");
    Jc.daoinvoke = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "daoinvoke");
    Jc.daorender = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "daorender");
    Jc.daodownload = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "daodownload");
    Jc.createDataBox = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "createDataBox");
    Jc.createDomainFrame = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "createDomainFrame");
    Jc.createFromDbmJson = Ext.Function.alias(Jc.dbm.Dbm.getModel(), "createFromDbmJson");
});
