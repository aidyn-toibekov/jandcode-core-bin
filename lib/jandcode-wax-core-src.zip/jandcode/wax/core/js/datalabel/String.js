Ext.define('Jc.datalabel.String', {
    extend: 'Ext.Component',

    isFocusable: false,

    autoEl: 'span',

    cellCls: 'cell-datalabel',
    cls: 'jc-datalabel',

    getElConfig: function() {
        var th = this;
        var cfg = th.callParent();
        cfg.html = th.getValue();
        return cfg;
    },

    /**
     * Возвращает html текст, который будет отображен
     */
    getValue: function() {
        var s = this.value;
        if (!s) return '';
        return s;
    },

    setValue: function(value) {
        this.value = value;
        if (this.rendered) {
            this.el.dom.innerHTML = this.getValue();
        }
        return this;
    },

    dataToControl: function() {
        if (!this.dataIndex) return;
        var v = Jc.dbm.DataBinder.getFieldValue(this, this.dataIndex);
        this.setValue(v);
    }

});
