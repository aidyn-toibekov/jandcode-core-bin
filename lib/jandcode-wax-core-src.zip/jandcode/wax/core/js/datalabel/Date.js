Ext.define('Jc.datalabel.Date', {
    extend: 'Jc.datalabel.Datetime',

    format: Jc.ini.dateFormat

});
