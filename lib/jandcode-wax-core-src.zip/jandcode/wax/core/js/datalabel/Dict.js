Ext.define('Jc.datalabel.Dict', {
    extend: 'Jc.datalabel.String',

    dictfield: null,


    getValue: function() {
        var dictname = this.getDict();
        if (!dictname) return "";
        //
        var store = Jc.dbm.DataBinder.getJcStore(this);
        if (!store) return "";
        //
        var v = store.dictdata.getValue(dictname, this.value, this.dictfield);
        return v;
    },

    getDict: function() {
        if (this.dict) return this.dict;
        var field = Jc.dbm.DataBinder.getField(this, this.dataIndex);
        if (!field) return null;
        return field.dict;
    }


});
