Ext.define('Jc.datalabel.Datetime', {
    extend: 'Jc.datalabel.String',

    format: Jc.ini.datetimeFormat,

    getValue: function() {
        var v = this.value;
        return Jc.dateToText(v, this.format);
    }

});
