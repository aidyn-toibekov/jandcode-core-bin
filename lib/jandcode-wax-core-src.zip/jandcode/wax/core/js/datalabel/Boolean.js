Ext.define('Jc.datalabel.Boolean', {
    extend: 'Jc.datalabel.String',

    cellCls: 'cell-datalabel-icon',

    getValue: function() {
        var v = Jc.toBoolean(this.value);
        var ic = "true";
        if (!v) ic = "false";
        ic = Jc.iconUrl(ic);
        return '<img src="' + ic + '">';
    }

});
