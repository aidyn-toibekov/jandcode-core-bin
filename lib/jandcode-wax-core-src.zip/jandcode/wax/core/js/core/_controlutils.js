/**
 * Подогнать размер окна под размер экрана
 */
Jc.fixWindowSize = function(win) {
    var bs = Ext.getBody().getViewSize();
    bs.width -= 40;
    bs.height -= 40;
    var sz = win.getSize();
    //
    if (sz.width > bs.width || sz.height > bs.height ||
      (win.minWidth && sz.width < win.minWidth) ||
      (win.minHeight && sz.height < win.minHeight) ||
      (win.maxWidth && sz.width > win.maxWidth) ||
      (win.maxHeight && sz.height > win.maxHeight)
      ) {
        var w = sz.width;
        if (win.minWidth && w < win.minWidth) w = win.minWidth;
        if (win.maxWidth && w > win.maxWidth) w = win.maxWidth;
        if (w > bs.width) w = bs.width;
        var h = sz.height;
        if (win.minHeight && h < win.minHeight) h = win.minHeight;
        if (win.maxHeight && h < win.maxHeight) h = win.maxHeight;
        if (h > bs.height) h = bs.height;
        win.setSize(w, h);
        win.center();
    }
};

/**
 * Выполнить функцию для каждого дочернего у компонента own.
 * Если функция func возвращает false, обследование прекращается.
 */
Jc.eachChild = function(own, func, ignoreDocked) {
    var res;
    var th = this;
    if (!own) return;
    //
    if (own.items) {
        Ext.each(own.items.items, function(z) {
            res = func(z);
            if (res === false) return false;
            res = th.eachChild(z, func, ignoreDocked);
            if (res === false) return false;
        });
    }
    if (res === false) return false;
    //
    if (own.menu && own.menu.items) {
        Ext.each(own.menu.items.items, function(z) {
            res = func(z);
            if (res === false) return false;
            res = th.eachChild(z, func, ignoreDocked);
            if (res === false) return false;
        });
    }
    if (res === false) return false;
    //
    if (!ignoreDocked && own.dockedItems) {
        Ext.each(own.dockedItems.items, function(z) {
            res = func(z);
            if (res === false) return false;
            res = th.eachChild(z, func, ignoreDocked);
            if (res === false) return false;
        });
    }
    if (res === false) return false;
};

/**
 * Выполнить функцию funcName для каждого дочернего у компонента own.
 * Если такая функция есть, она вызывается, если нет, обследуются
 * дочерние.
 */
Jc.eachChildCall = function(own, funcName, ignoreDocked) {
    var th = this;
    if (!own) return;
    if (own.items) {
        Ext.each(own.items.items, function(z) {
            var func = z[funcName];
            if (func) {
                func.call(z);
            } else {
                Jc.eachChildCall(z, funcName, ignoreDocked);
            }
        });
    }
    if (own.menu && own.menu.items) {
        Ext.each(own.menu.items.items, function(z) {
            var func = z[funcName];
            if (func) {
                func.call(z);
            } else {
                Jc.eachChildCall(z, funcName, ignoreDocked);
            }
        });
    }
    if (!ignoreDocked && own.dockedItems) {
        Ext.each(own.dockedItems.items, function(z) {
            var func = z[funcName];
            if (func) {
                func.call(z);
            } else {
                Jc.eachChildCall(z, funcName, ignoreDocked);
            }
        });
    }
};

Jc.controlToDataChilds = function(own) {
    Jc.eachChildCall(own, "controlToData");
};

Jc.dataToControlChilds = function(own) {
    Jc.eachChildCall(own, "dataToControl");
};

/**
 * Найти компонент с указанным itemId включая все вложенные.
 * @param itemId itemId
 */
Jc.getComponent = function(own, itemId) {
    var res;
    Jc.eachChild(own, function(z) {
        if (z.itemId == itemId) {
            res = z;
            return false;
        }
        if (z.getComponent) {
            res = z.getComponent(itemId);
        }
        if (res) return false;
        //
        if (z.menu && z.menu.getComponent) {
            res = z.menu.getComponent(itemId);
        }
        if (res) return false;
    });
    return res;
};

/**
 * Поиск компонента вверх. Работает почти как Component.up, только заточен для
 * поиска компонентов из action
 * @param from с кого начинать
 * @param queryStr что искать
 */
Jc.findComponentUp = function(from, queryStr, useFrom) {
    if (useFrom) {
        if (Ext.ComponentQuery.is(from, queryStr)) {
            return from;
        }
    }
    var res;
    if (from.ownerCt) {
        res = Jc.findComponentUp(from.ownerCt, queryStr, true);
        if (res) return res;
    }
    if (from.ownerItem) {
        res = Jc.findComponentUp(from.ownerItem, queryStr, true);
        if (res) return res;
    }
    if (from.ownerButton) {
        res = Jc.findComponentUp(from.ownerButton, queryStr, true);
        if (res) return res;
    }
};

/**
 * Возвращает true, если у компонента установлен layout, которые требует
 * полного заполнения и соответсвенно информации и размере comp.
 * @param comp
 */
Jc.isFitLayout = function(comp) {
    if (!comp.getLayout) return false;
    var fit = false;
    var lay = comp.getLayout();
    if (lay instanceof Ext.layout.container.VBox) {
        fit = true;
    } else if (lay instanceof Ext.layout.container.Fit) {
        fit = true;
    } else if (lay instanceof Ext.layout.container.Border) {
        fit = true;
    }
    return fit;
};
