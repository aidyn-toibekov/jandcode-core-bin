/**
 * Синхронный запрос
 */
Jc._request = function(config) {
    var cfg = Ext.apply({
    }, config);
    cfg.async = false;

    cfg.callback = function(opt, success, response) {
        cfg.success = success;
        cfg.response = response;
    };

    Ext.Ajax.request(cfg);

    if (!cfg.success) {
        Jc.error(cfg.response);
    }

    return cfg;
};

/**
 * Синхронный запрос текста
 */
Jc.requestText = function(config) {
    var res = Jc._request(config);
    return res.response.responseText;
};

/**
 * Синхронный запрос json данных
 */
Jc.requestJson = function(config) {
    var res = Jc._request(config);
    var jsonData;
    try {
        jsonData = Ext.decode(res.response.responseText);
    } catch(e) {
        Jc.error(e);
    }
    if (jsonData.success === false || jsonData.success === "false") {
        Jc.error(new Jc.Error({err: jsonData, type: 'json'}));
    }
    return jsonData;
};

/**
 * Выполняет upload полей
 * @param upfs список полей, полученных через grabUploadFields
 * @param config.onOk что выполнить после окончания
 */
Jc.requestUpload = function(upfs, config) {
    var cfg = Ext.apply({}, config);
    var idx = 0;
    Jc.app.showWait();
    var func = function() {
        if (idx >= upfs.length) {
            Jc.app.hideWait();
            if (cfg.onOk) {
                cfg.onOk();
            }
            return;
        }
        var upl = upfs[idx];
        //

        if (upl.handler) {
            // компонент сам умеет и хочет делать upload. подчиняемся...
            upl.handler({
                onOk: function() {
                    idx++;
                    func();
                },
                onError: function(err) {
                    idx = 10000000;
                    Jc.error(err);
                }
            })
        } else {
            // компонент предоставляет input, в котором выбран файл. это мы умеем и сами...
            var formSpec = {
                tag: 'form',
                action: Jc.url("dbm/upload?_="),
                enctype: 'multipart/form-data',
                method: "POST",
                target: '_self',
                style: 'display:none'
            };

            var formEl = Ext.DomHelper.append(Ext.getBody(), formSpec);
            upl.inp.name = "fileitem";
            formEl.appendChild(upl.inp);
            var pp = {name: upl.inp.value};
            Ext.DomHelper.append(formEl, {tag: 'textarea', name: "fileitem_name", html: Ext.encode(pp)});

            Ext.Ajax.request({
                form: formEl,
                callback: function(opt, suc, resp) {
                    var json = Ext.decode(resp.responseText);
                    if (json.success) {
                        upl.json = json;
                        upl.owner.uploadOk(upl);
                        idx++;
                        func();
                    } else {
                        idx = 10000000;
                        Jc.error(new Jc.Error({err: json, type: 'json'}));
                    }
                }
            });

        }


    };
    func();
};

Jc.requestDownload = function(cfg) {
    var frm;
    var frmID = "Jc.requestDownload._form";

    // берем или создаем временную форму
    frm = Ext.get(frmID);
    if (!frm) {
        frm = Ext.DomHelper.append(Ext.getBody(), {
            tag: 'form',
            name: frmID,
            id: frmID,
            style: "display:none;",
            method: 'post',
            target: '_blank'
        }, true);
    }

    // чистим форму
    frm.update("");

    // устанавливаем url запроса
    frm.set({action: Jc.url(cfg.url)});

    // параметры post-запроса
    if (cfg.params) {
        for (var p in cfg.params) {
            var v = cfg.params[p];
            if (Ext.isString(v)) {
                // by SDV 23.05.2011 todo: надо маскировать "<" и ">", а не "'" и "\"
                // v = String.escape(v);
            }
            Ext.DomHelper.append(frm, {tag: 'textarea', name: p, html: v});
        }
    }

    // кнопка submit
    Ext.DomHelper.append(frm, {tag: 'input', id: frmID + '_s', type: 'submit', name: frmID + '_s'});

    // выполняем
    document.forms[frmID].submit();
};

// общий hook для всех запросов
Jc._beforeRequest = function(ob, cfg) {
    if (cfg.url) {
        cfg.url = Jc.url(cfg.url);
    }
};

Ext.Ajax.on('beforerequest', Jc._beforeRequest, Jc);
