/**
 * action для jc.
 */
Ext.define("Jc.Action", {
    extend: "Ext.Action",

    /**
     * Метод onExec является обработчиком события, если определен.
     */
    //onExec: null

    /**
     * Метод onBeforeExec выполняется перед onExec.
     * Если возвращает false, onExec не выполняется.
     */
    //onBeforeExec: null

    constructor: function(config) {
        var cfg = Ext.apply({
        }, config);
        //
        if (cfg.items) {
            if (!cfg.menu) {
                cfg.menu = cfg.items;
                delete cfg.items;
            }
        }
        //
        if (!cfg.menu) {
            cfg.handler = Jc.actionHandler;
        }
        Jc.adaptIcon(cfg);
        //
        this.callParent([cfg]);
    },

    /**
     * Выполнить action
     */
    execute: function() {
        this.initialConfig.handler.call(this.initialConfig.scope || Ext.global, this.initialConfig);
    },

    /**
     * Выполняется перед onBeforeexec и onExec как метод Action.
     * Если метод возвращает false, то выполнение прерывается
     * @param act компонент, который вызвал действие. Обычно это кнопка
     */
    prepareExec: function(act) {
    }

});

/**
 * action, которая знает про гриду, внутри которой она работает
 */
Ext.define("Jc.ActionGrid", {
    extend: 'Jc.Action',
    prepareExec: function(act) {
        act.grid = null;
        //
        var grid = Jc.findComponentUp(act, 'grid');
        if (!grid) {
            grid = Jc.findComponentUp(act, 'treepanel');
            if (!grid) {
                return; // action не в гриде, ограничений нет
            }
            console.info("found tree",grid);
        }
        //
        act.grid = grid;
    }
});

/**
 * action, которая выполняется только если в гриде есть выделенная запись.
 */
Ext.define("Jc.ActionRec", {
    extend: 'Jc.Action',
    prepareExec: function(act) {
        act.grid = null;
        act.rec = null;
        act.recId = null;
        //
        var grid = Jc.findComponentUp(act, 'grid');
        if (!grid) {
            grid = Jc.findComponentUp(act, 'treepanel');
            if (!grid) {
                return; // action не в гриде, ограничений нет
            }
            console.info("found tree",grid);
        }
        //
        var rec = grid.getCurRec();
        if (!rec) return false;
        //
        act.grid = grid;
        act.rec = rec;
        act.recId = rec.get('id');
    }
});


/**
 * Кнопка
 */
Ext.define('Jc.Button', {
    extend: 'Ext.Button',

    initComponent: function() {
        Jc.adaptIcon(this);
        if (!this.handler) {
            this.handler = Jc.actionHandler; //todo проверить на кнопку+меню и она сама onexec
        }
        this.callParent(arguments);
    }
});

/**
 * Адаптация конфигурации к иконке (icon->iconCls)
 */
Jc.adaptIcon = function(opt) {
    if (opt.icon && opt.icon.indexOf('/') == -1) {
        opt.iconCls = opt.icon;
        delete opt.icon;
    }
    if (opt.iconCls) {
        opt.iconCls = Jc.iconCls(opt.iconCls);
    }
};

/**
 * Создает и возвращает объект Jc.Action
 */
Jc.action = function(options) {
    return Ext.create("Jc.Action", options);
};

/**
 * Универсальный обработчик action.
 * onExec - функция-обработчик (либо текст скрипта)
 * onBeforeExec - функция-обработчик, выполняется перед onExec.
 *      Если возвращает false, onExec не выполняется
 * scope - пространство имен, где выполнить onExec
 * При ошибке - показывается ошибка.
 */
Jc.actionHandler = function(act) {
    // скрываем все открытые меню
    Ext.menu.Manager.hideAll();
    try {
        var res;

        if (act.baseAction && act.baseAction.prepareExec) {
            res = act.baseAction.prepareExec.call(act.baseAction, act);
            if (res === false) {
                return;
            }
        }

        if (act.onBeforeExec) {
            res = act.onBeforeExec.apply(act.scope || Ext.global, arguments);
            if (res === false) {
                return;
            }
        }
        if (act.onExec) {
            if (Ext.isString(act.onExec)) {
                Jc.eval(act.onExec);
            } else {
                act.onExec.apply(act.scope || Ext.global, arguments);
            }
        }
    } catch(e) {
        Jc.error(e);
    }
};

/**
 * menu. Возвращает адаптированный объект определения меню, которое имеет дочерние объекты
 * и может сам быть кнопкой с onExec.
 */
Jc.menu = function(options) {
    var opt = Ext.apply({
    }, options);
    if (opt.items) {
        opt.menu = {items: opt.items};
        delete opt.items;
    }
    if (opt.onExec || opt.frame) {
        // меню, которое как кнопка
        Ext.applyIf(opt, {
            handler: Jc.actionHandler,
            xtype: 'splitbutton'
        });
    }
    Jc.adaptIcon(opt);
    return opt;
};

/**
 * Возвращает объект Ext.Button для кнопки на панели инструментов (без текста и с tooltip),
 * сделанной из Jc.Action
 */
Jc.toolbutton = function(act) {
    var res = Ext.create("Ext.button.Button", act);
    res.setText('');
    res.setTooltip(act.getText());
    return res;
};

/**
 * Информация о щелчке по <a>
 * @param e событие
 * @return action:xxx, recId: xxx
 */
Jc.clickRefRec = function(e) {
    var a = e.getTarget('a');
    if (!a) return null;
    var act = Ext.fly(a).getAttribute("data-action");
    if (!act) return null;
    var rec = Ext.fly(a).up(".data-rec");
    if (!rec) return null;
    var recId = Ext.fly(rec).getAttribute("data-recId");
    var res = {
        recId: recId,
        action: act
    };
    return res;
};

/**
 * Найти и выполнить action с указанным itemId
 * @param frame контейнер, откуда искать action. Может быть и не фреймом, а гридой например
 * @param itemId itemId
 */
Jc.execAction = function(frame, itemId) {
    var act = Jc.getComponent(frame, itemId);
    if (act) {
        if (act.handler) {
            act.handler.call(frame, act);
        }
    }
};

