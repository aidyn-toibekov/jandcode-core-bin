/**
 * Объект - ошибка
 */
Ext.define('Jc.Error', {

    /**
     * Оригинальная ошибка
     */
    err: null,

    /**
     * Признак "обработано"
     */
    handled: false,

    /**
     * Тип err, например 'json'
     */
    type: null,

    constructor: function(config) {
        if (config) {
            Ext.apply(this, config);
        }
    },

    /**
     * Превращает ошибку в текст сообщения
     */
    toMsg: function(devMode) {
        var e = this.err;
        var m = "";
        var s;
        if (this.type == 'json') {
            s = '';
            Ext.each(e.errors, function(z) {
                s = Jc.appendUL(s, z.text);
            });
            if (s == '') {
                s = 'Error:' + e;
            }
            return s;
        } else if (e instanceof Error) {
            return "" + e.message;
        } else if (e.statusText == "communication failure") {
            return Jc.format("Ответ от сервера не получен ({0})", e.statusText);
        } else if (e.status && e.statusText) {
            // response
            s = e.responseText;
            if (s) {
                // есть текст
                var s1 = s.substr(0, Jc.ERROR_AJAX_PREFIX.length);
                if (s1 == Jc.ERROR_AJAX_PREFIX) {
                    m = s.substring(Jc.ERROR_AJAX_PREFIX.length);
                } else {
                    var rr = s.match(/<body.*?>((\n|\r|.)*?)<\/body>/);
                    if (rr) s = rr[1];
                    if (!devMode) {
                        rr = s.match(/<div class="error-text">((\n|\r|.)*?)<\/div>/);
                        if (rr) {
                            m = rr[1];
                        } else {
                            m = "" + e.status + ": " + e.statusText;
                        }
                    } else {
                        m = s;
                    }
                }
                //
            }
//            var ar = m.split("\n");
//            var m1 = "";
//            for (var i = 0; i < ar.length; i++) {
//                m1 = Jc.appendUL(m1, ar[i]);
//            }
            return m;
        } else if (Ext.isString(e)) {
            return e;
        }
        return "" + e;
    },

    /**
     * Разбивка на ошибки по полям
     */
    toMsgByFields: function() {
        var e = this.err;
        var res = {};
        if (this.type == 'json') {
            Ext.each(e.errors, function(z) {
                var fn = z.field;
                var s = res[fn];
                if (s === undefined) {
                    s = '';
                    res[fn] = s;
                }
                if (s.length > 0) {
                    s += '<br>';
                }
                s += z.text + ' ';
                res[fn] = s;
            });
        }
        return res;
    }

});

/**
 * Создает объект Jc.Error из err, если err не Jc.Error.
 * Возвращает или новый объект Jc.Error или err, если err это Jc.Error
 */
Jc.errorCreate = function(err) {
    var e = err;
    if (!(err instanceof Jc.Error)) {
        e = new Jc.Error({err: err});
    }
    return e;
};

/**
 * Метод вызывается в catch для регистрации/показа ошибки.
 * Автоматически отправляет дальше (throw) вариант ошибки Jc.Error
 */
Jc.error = function(err, doThrow) {
    if (Jc.app && Jc.app.hideWaitForce) {
        Jc.app.hideWaitForce();
    }
    var e = Jc.errorCreate(err);
    if (!e.handled) {
        console.error("Jc.error:", e.err);
        e.handled = true;
        Jc.showError(e);
    }
    if (doThrow || doThrow === undefined) {
        throw e;
    }
};

