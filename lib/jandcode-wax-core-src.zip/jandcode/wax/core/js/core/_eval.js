/**
 * Выполнение js скрипта из строки
 * @param script текст скрипта
 */
Jc.eval = function(script) {
    if (window.execScript) {
        return window.execScript(script);
    } else {
        return window.eval(script);
    }
};

/**
 * Разделение html на части, которые можно выполнить
 *
 * @param htmltext текст html
 * @return массив объектов: {type: (jstext,jsref,cssref), text: TEXT}.
 */
Jc._evalSplitHtml = function(htmltext) {
    var result = [];
    if (!htmltext || htmltext.length == 0) {
        return result;
    }

    var re = /(?:<scr[i]pt([^>]*)?>)((\n|\r|.)*?)(?:<\/scr[i]pt>)/ig,
      srcRe = /\ssrc=([\'\"])(.*?)\1/i,
      typeRe = /\stype=([\'\"])(.*?)\1/i,
      match = null,
      attrs,
      srcMatch,
      typeMatch,
      reLink = /(?:<link([^>]*)?\/>)/ig,
      hrefRe = /\shref=([\'\"])(.*?)\1/i
      ;

    var src, sc1, sc2;

    while ((match = re.exec(htmltext))) {
        attrs = match[1];
        srcMatch = attrs ? attrs.match(srcRe) : false;
        if (srcMatch && srcMatch[2]) {
            src = srcMatch[2];
            var type = "";
            typeMatch = attrs.match(typeRe);
            if (typeMatch && typeMatch[2]) {
                type = typeMatch[2];
            }
            sc1 = {};
            sc1.type = "jsref";
            sc1.text = src;
            result.push(sc1);
        } else if (match[2] && match[2].length > 0) {
            sc2 = {};
            sc2.type = "jstext";
            sc2.text = " " + match[2];
            result.push(sc2);
        }
    }

    while ((match = reLink.exec(htmltext))) {
        attrs = match[1];
        srcMatch = attrs ? attrs.match(hrefRe) : false;
        if (srcMatch && srcMatch[2]) {
            src = srcMatch[2];
            sc1 = {};
            sc1.type = "cssref";
            sc1.text = src;
            result.push(sc1);
        }
    }

    return result;
};

/**
 * Выполнение html. Текст html анализируется на предмет наличия тегов 'script'
 * которые выполняются
 *
 * @param htmltext текст html
 */
Jc.evalHtml = function(htmltext) {
    var parts = Jc._evalSplitHtml(htmltext);
    for (var i = 0; i < parts.length; i++) {
        var part = parts[i];

        if (part.type == "jsref") {
            // ссылка на скрипт
            // имитируем работу, как если бы он был указан в секции head
            // сначала делаем запрос с проверкой изменения
            var dd = new Date();
            var curd = dd.toGMTString();
            var resp = Ext.Ajax.request({async: false, url: part.text, disableCaching: true,
                headers: {
                    "If-Modified-Since": curd
                }
            });
            if (resp.status == 304) {
                // если 304, то мы не получили текст, теперь получаем
                // разрешаем кеширование, пусть берет из кеша
                resp = Ext.Ajax.request({async: false, url: part.text, disableCaching: false});
            }
            Jc.eval(resp.responseText);
        } else if (part.type == "jstext") {
            Jc.eval(part.text);
        } else if (part.type == "cssref") {
            Ext.core.DomHelper.append(Ext.getBody(), {tag: 'link', rel: "stylesheet", href: part.text});
        }
    }
};
