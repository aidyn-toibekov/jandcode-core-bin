/**
 * Поддержка для многоязыковых приложений и многоязыковых данных
 */

Ext.namespace("UtLang");
Ext.namespace("Jc.lang");

// данные для транслятора
UtLang._tdata = [];

/**
 * Функция перевода
 * @param s строка для перевода
 * @param args аргументы для подстановки {0}, {1} и т.д.
 * @return {*}
 */
UtLang.t = function(s) {
    if (!s) return "";
    var s1 = UtLang._tdata[s];
    if (!s1) s1 = s;
    if (arguments.length > 1) {
        // применяем форматирование
        var args = Array.prototype.slice.call(arguments);
        args[0] = s1;
        s1 = Ext.String.format.apply(null, args);
    }
    return s1;
};

/**
 * Получение данных из структуры типа: {'ru':a, 'en':b, ...}
 * Если для текущего языка есть значение, возвращает оно. Иначе перебираются языки
 * в порядке, в котором они описаны в модели и выбирается первое существующее.
 *
 * @param data данные
 * @param model для какой модели. Если не указано, используется модель по умолчанию
 * @return {*} объект вида {lang:'ru', value: a} или {lang:null, value:null}, если нет
 * значения или его нельзя выявить
 */
Jc.lang.getLangValue = function(data, model) {
    if (!data) return {lang: null, value: null};
    model = Jc.dbm.DataBinder.getModel(model);
    // пробуем значение для текущего языка
    var s = data[model.lang];
    if (s) return {lang: model.lang, value: s};
    // не вышло. Перебираем языки
    Ext.each(model.langs, function(lang) {
        s = data[lang];
        if (s) {
            s = {lang: lang, value: s};
            return false;
        }
    });
    //
    if (!s) {
        return {lang: null, value: null};
    }
    return s;
};

/**
 * Получение данных из структуры типа: {'ru':a, 'en':b, ...}
 * Возвращается значение для текущего языка.
 *
 * @param data данные
 * @param model для какой модели. Если не указано, используется модель по умолчанию
 * @return {*} объект вида {lang:'ru', value: a} или {lang:null, value:null}, если нет
 * значения или его нельзя выявить
 */
Jc.lang.getCurLangValue = function(data, model) {
    if (!data) return {lang: null, value: null};
    model = Jc.dbm.DataBinder.getModel(model);
    // пробуем значение для текущего языка
    var s = data[model.lang];
    if (s) return {lang: model.lang, value: s};
    // нет значения
    return {lang: null, value: null};
};

/**
 * Получение данных вида {'ru':a, 'en':b, ...} из записи. Для получения данных используется
 * список языков из модели записи или модели по умолчанию, если для записи не определена.
 *
 * @param rec запись
 * @param fieldname базовое имя поля. Например 'name'. Тогда будут искаться значения
 * 'name_ru', 'name_en' ...
 */
Jc.lang.getLangDataFromRec = function(rec, fieldname) {
    var r = {};
    var model = Jc.dbm.DataBinder.getModel(rec);
    Ext.each(model.langs, function(lang) {
        r[lang] = Jc.dbm.DataBinder.getFieldValue(rec, fieldname + "_" + lang);
    });
    return r;
};

/**
 * Установка данных вида {'ru':a, 'en':b, ...} в запись.
 * Для установки данных используется список языков из модели записи или
 * модели по умолчанию, если для записи не определена.
 *
 * @param rec запись
 * @param fieldname базовое имя поля. Например 'name'. Тогда будут записываться значения
 * 'name_ru', 'name_en' ...
 * @param data данные в виде {'ru':a, 'en':b, ...}
 */
Jc.lang.setLangDataToRec = function(rec, fieldname, data) {
    if (!data) {
        data = {};
    }
    var model = Jc.dbm.DataBinder.getModel(rec);
    Ext.each(model.langs, function(lang) {
        Jc.dbm.DataBinder.setFieldValue(rec, fieldname + "_" + lang, data[lang]);
    });
};

