/**
 * Подтверждение
 * @param text сообщение
 * @param onYes функция, которая будет вызвана при нажатии на yes
 */
Jc.showYN = function(text, onYes) {
    var w = Ext.create('Ext.Window', {
        title: UtLang.t('Подтверждение'),
        modal: true,
        bodyPadding: 20,
        layout: {
            type: 'jctable',
            columns: 2
        },
        width: 450,
        items: [
            Ext.create("Jc.control.Icon", {
                padding: '0 16 0 0',
                icon: 'question',
                iconType: '32'
            }),
            Ext.create("Ext.Component", {
                html: text
            })
        ],
        buttons: [
            Ext.create('Jc.Button', {
                text: Jc.msg.yes,
                icon: 'ok',
                onExec: function() {
                    if (onYes) {
                        onYes();
                    }
                    w.close();
                }
            }),
            Ext.create('Jc.Button', {
                text: Jc.msg.no,
                icon: 'cancel',
                onExec: function() {
                    w.close();
                }
            })
        ]
    });
    w.show();
};

/**
 * Показ сообщения
 */
Jc.showMsg = function(text) {
    var w = Ext.create('Ext.Window', {
        title: UtLang.t('Сообщение'),
        modal: true,
        bodyPadding: 20,
        layout: {
            type: 'jctable',
            columns: 2
        },
        width: 450,
        items: [
            Ext.create("Jc.control.Icon", {
                padding: '0 16 0 0',
                icon: 'info',
                iconType: '32'
            }),
            Ext.create("Ext.Component", {
                html: text
            })
        ],
        buttons: [
            Ext.create('Jc.Button', {
                text: 'Ok',
                icon: 'ok',
                onExec: function() {
                    w.close();
                }
            })
        ]
    });
    w.show();
};

/**
 * Показ ошибки
 * @param err ошибка
 */
Jc.showError = function(err) {
    if (Jc.app && Jc.app.hideWaitForce) {
        Jc.app.hideWaitForce();
    }
    var devMode = Jc.ini.debug;
    var e = Jc.errorCreate(err);
    var w = Ext.create("Ext.window.Window", {
        x: 30000,
        minWidth: 550,
        maxWidth: 800,
        title: UtLang.t('Ошибка'),
        iconCls: 'icon-error',
        cls: 'jc-errorwindow',
        bodyCls: 'jc-errorwindow-body',
        autoScroll: true,
        maximizable: true,
        modal: true,
        constrain: true,
        buttons: [
            {text: UtLang.t('Закрыть'), iconCls: 'icon-cancel', handler: function() {
                w.close();
            }}
        ]
    });
    w.show();
    var s = e.toMsg(devMode);
    if (!/<div class="error-text">/.test(s)) {
        s = '<div class="error-text">' + s + '</div>';
    }
    // <br>
    s = s.replace(/([\s\S]*?<div class="error-text">)([\s\S]*?)(<\/div>[\s\S]*?)/m, function(a, c1, c2, c3) {
        c2 = c2.replace(/\n\x20\x20\x20\x20/gm, "\n&nbsp;&nbsp;&nbsp;&nbsp;");
        return c1 + c2.replace(/\n/gm, "<br>\n") + c3;
    });
    //
    w.update(s);
    Jc.fixWindowSize(w);
    w.center();
};

