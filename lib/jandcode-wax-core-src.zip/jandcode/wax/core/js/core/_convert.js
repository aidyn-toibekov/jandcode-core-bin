/**
 * Возвращает url с префиксом Jc.baseUrl, если url не абсолютный
 */
Jc.url = function(url) {
    if (url.substr(0, 1) == "/" || url.indexOf(':') != -1) {
        return url;
    }
    return Jc.baseUrl + url;
};

/**
 * Из имени иконки и типа - url иконки
 * @param iconname имя иконки. Если url, то просто возвращается.
 * Префикс 'icon-' отбрасывается.
 * @param type тип иконки (16, 32)
 */
Jc.iconUrl = function(iconname, type) {
    if (iconname.indexOf('/') != -1) {
        return iconname;
    }
    if (iconname.indexOf('icon-') == 0) {
        iconname = iconname.substr(5)
    }
    if (!type) type = "16";
    return Jc.url("images/icon" + type + "/" + iconname + ".png");
};

/**
 * Из имени иконки - класс иконки
 * @param iconname имя иконки. Если префикс 'icon-' - просто возвращается
 */
Jc.iconCls = function(iconname) {
    if (iconname.indexOf('icon-') == 0) {
        return iconname;
    }
    return "icon-" + iconname;
};

/**
 * Конвертация значения в boolean
 */
Jc.toBoolean = function(value) {
    return value === true || value == "true" || value === "1" || value === 1;
};

/**
 * Возвращает текущую дату без времени
 */
Jc.date = function() {
    var d = new Date();
    return Ext.Date.clearTime(d)
};

/**
 * Дату в текст для показа
 */
Jc.dateToText = function(d, format) {
    if (!d) return "";
    if (!Ext.isDate(d)) return "";
    if (Jc.isDateEmpty(d)) return Jc.ini.dateEmptyText;
    if (!format) format = Jc.ini.dateFormat;
    return Ext.Date.format(d, format);
};

/**
 * Возвращает true, если d - пустая дата. Или не дата.
 * В конкретном проекте возможно перекрытие этой функции, если в нем
 * пустые даты определяются другим способом.
 */
Jc.isDateEmpty = function(d) {
    if (!d) return true;
    if (!Ext.isDate(d)) return true;
    var y = d.getFullYear();
    if (y >= 3333) return true;
    if (y <= 1901) return true;
    return false;
};

/**
 * Как Ext.String.format, первым параметром может быть массив строк,
 * который объединяется в одну.
 */
Jc.format = function() {
    var args = Array.prototype.slice.call(arguments);
    if (Ext.isArray(args[0])) {
        args[0] = args[0].join('');
    }
    return Ext.String.format.apply(null, args);
};

/**
 * Возвращает класс по имени (по аналогии с Ext.create, только не экземпляр, а класс)
 */
Jc.getClass = function(clsname) {
    var cls = Ext.ClassManager.get(clsname);
    if (!cls) {
        Ext.syncRequire(clsname);
        cls = Ext.ClassManager.get(clsname);
        if (!cls) {
            Jc.error("[Jc.getClass] Cannot create an instance of unrecognized class name / alias: " + clsname);
        }
    }
    return cls;
};

/**
 * Формирование многострочной строки. К src добавляется appendStr и возвращается полученная.
 * Если это не первая строка, то из строки делается <ul>
 */
Jc.appendUL = function(src, appendStr) {
    if (!src) src = "";
    if (src == "") return appendStr;
    if (src.substr(0, 4) == "<ul>") {
        return src.substr(0, src.length - 10) + "<li>" + appendStr + "</li></ul>";
    } else {
        return "<ul><li>" + src + "</li><li>" + appendStr + "</li></ul>";
    }
};

/**
 * Перевод строки в число
 * @param s        строка
 * @param defValue значение по умолчанию, если преобразование не удалось (по умолчанию 0)
 */
Jc.toInt = function(s, defValue) {
    var v;
    if (Ext.isNumber(s)) return s;
    if (!defValue) defValue = 0;
    try {
        v = parseInt(s);
    } catch(e) {
        v = defValue;
    }
    if (isNaN(v)) v = defValue;
    return v;
};


