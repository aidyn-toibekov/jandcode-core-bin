/**
 * Всякие фиксы для extjs
 */

////// 4.2

Ext.define('Jc.patch.AbstractContainer', {
    override: 'Ext.container.AbstractContainer',
    add: function() {
        if (arguments.length == 1 && Ext.isArray(arguments[0])) {
            var args = Ext.Array.flatten(arguments[0]);
            return this.callParent([args]);
        } else {
            return this.callParent(arguments);
        }
    }
});

Ext.define('Jc.patch.DockingContainer', {
    override: 'Ext.container.DockingContainer',
    addDocked: function(items, pos) {
        if (Ext.isArray(items)) {
            items = Ext.Array.flatten(items);
        }
        return this.callParent([items, pos]);
    }
});

/**
 * Для bordersplitter вводим:
 * Если у его элемента (панели) есть splitterBorder: true, то рисуем border.
 * Для: две панели рядом без рамок во весь экран.
 */
Ext.define('Ext.resizer.BorderSplitter_patch1', {
    extend: 'Ext.resizer.BorderSplitter',

    alias: 'widget.bordersplitter',

    beforeRender: function() {
        var th = this;
        var target = th.getCollapseTarget();
        var cd = th.getCollapseDirection();
        if (target && target.splitterBorder) {
            if (th.horizontal) {
                th.cls = 'jc-splitter-horz-border';
            }
            if (th.vertical) {
                th.cls = 'jc-splitter-vert-border';
            }
        }
        th.callParent(arguments);
    }

});

/**
 * Добавляет кнопку "Очистить" в триггер. Появлется только если
 * у триггера стоит showClearButton=true или класс триггера зарегистрирован
 * в Jc.ini.trigger.showClearButton
 */
Ext.define('Jc.patch.Trigger', {
    override: 'Ext.form.field.Trigger',

    isShowClearButton: function() {
        if (this.showClearButton === true) return true;
        if (this.showClearButton === false) return false;
        var a = Jc.ini.trigger.showClearButton;
        for (var i = 0; i < a.length; i++) {
            var c = Jc.getClass(a[i]);
            if (this instanceof c) return true;
        }
        return false;
    },

    beforeRender: function() {
        // patch: showClearButton for any trigger
        if (this.isShowClearButton()) {
            this.trigger1Cls = Ext.baseCSSPrefix + 'form-clear-trigger';
            this.trigger2Cls = this.triggerCls;
            if (!this.trigger2Cls) {
                this.trigger2Cls = Ext.baseCSSPrefix + 'form-trigger';
            }
            this.onTrigger1Click = function() {
                this.setValue(null);
            };
        }
        //
        this.callParent(arguments);
    }

});

//fix: в chrome qtip схлопывается до 40px... взято отсюда:
//http://www.sencha.com/forum/showthread.php?260106
//
delete Ext.tip.Tip.prototype.minWidth;