Ext.namespace("Jc");

/**
 * Базовый url для добавления в начало загружаемых url. Должен заканчиваться '/'
 */
Jc.baseUrl = "/";

/**
 * Префикс для ajax-сообщений об ошибках
 */
Jc.ERROR_AJAX_PREFIX = "ERROR_AJAX:";

/**
 * Пустая функция
 */
Jc.fnEmpty = function() {
};

/**
 * Функция, которая возвращает false
 */
Jc.fnFalse = function() {
    return false;
};

if (!window.console) {
    // имитируем firebug console
    window.console = {
        log: Jc.fnEmpty,
        info: Jc.fnEmpty,
        debug: Jc.fnEmpty,
        error: Jc.fnEmpty,
        assert: Jc.fnEmpty,
        dir: Jc.fnEmpty,
        dirxml: Jc.fnEmpty,
        trace: Jc.fnEmpty,
        group: Jc.fnEmpty,
        groupCollapsed: Jc.fnEmpty,
        groupEnd: Jc.fnEmpty,
        time: Jc.fnEmpty,
        timeEnd: Jc.fnEmpty,
        profile: Jc.fnEmpty,
        profileEnd: Jc.fnEmpty,
        count: Jc.fnEmpty,
        warn: Jc.fnEmpty
    };
}

/**
 * Настройки
 */
Jc.ini = {
    /**
     * Среда выполнения debug/release
     */
    debug: false,

    /**
     * формат даты для клиента
     */
    dateFormat: 'd.m.Y',

    /**
     * формат времени для клиента
     */
    timeFormat: 'H:i',

    /**
     * формат даты и времени для клиента
     */
    datetimeFormat: 'd.m.Y H:i',

    /**
     * формат даты для сервера
     */
    datetimeFormatServer: 'Y-m-d\\TH:i:s',

    /**
     * Текст, на который заменяется пустая дата в datalabel и column.
     * Точнее в функции Jc.dateToText
     */
    dateEmptyText: '...',

    /**
     * Информация о пользователе
     */
    userInfo: {
        id: 0,
        name: 'guest',
        fullName: 'guest',
        guest: true,
        attrs: {}
    },

    /**
     * Прибизительная ширина символа в точках. Очень приблизительная.
     */
    charWidth: 8,

    /**
     * Декларативная ширина input
     */
    inputWidth: {
        large: 350,
        medium: 200,
        small: 100
    },

    /**
     * Свойства приложения
     */
    app: {
        // заголовок
        title: "Wax App",

        // класс темы
        themeClass: "Jc.theme.Ide"
    },

    /**
     * Текущий язык
     */
    lang: "ru",

    /**
     * Список поддерживаемых языков для интерфейса.
     * Языки для модели определяются в модели и являются подмножеством этого списка.
     */
    langs: [
        {name: "ru", title: "Русский"}
    ],

    /**
     * Некоторые глобальные свойства по умолчанию для грид и колонок
     */
    grid: {

        /**
         * sortable для колонок
         */
        columnSortable: false,

        /**
         * Наличие меню в колонках по умолчанию
         */
        columnMenu: false,

        /**
         * Выделение записи под курсором мыши
         */
        trackOver: false

    },

    trigger: {

        /**
         * Список имен классов, для которых по умолчанию показывается кнопка "Очистить",
         * если в экземпляре явно не разрешено или запрещено показывать такую кнопку.
         * Например настройка:
         * Jc.ini.trigger.showClearButton = ['Ext.form.field.Trigger']
         * приведет к показу кнопки "Очистить" во всех триггерах
         */
        showClearButton: []

    },

    /**
     * Настройки для showWait
     */
    showWait: {

        /**
         * Зарегистрированные control для показа сообщения showWait.
         * Если пусто или отсутсвует, то используется старый: 'Подождите...'
         */
        control: {

            /**
             * control по умолчанию. Если не задан, то используется поведение по умолчанию.
             */
            default: ''

        }

    }

};


/**
 * Константы для строк
 */
Jc.msg = {
    ins: "Добавить", //NLS
    upd: "Изменить", //NLS
    del: "Удалить", //NLS
    view: "Просмотр", //NLS
    print: "Печать", //NLS
    delYN: "Вы хотите удалить запись?", //NLS
    yes: "Да", //NLS
    no: "Нет" //NLS
};

/**
 * Создание приложеня
 * @param cls класс приложения
 */
Jc.createApp = function(cls, config) {
    Ext.syncRequire(cls);
    Ext.create(cls, config);
};

