/**
 * Тема ide
 */
Ext.define('Jc.theme.Ide', {
    extend: 'Jc.theme.Base',

    requires: [
        'Jc.shower.TabPanel'
    ],

    toolsRegion: 'west',
    toolsWidth: 275,

    createToolbar: function() {
        return Jc.app.createMainMenu();
    },

    onInit: function() {
        this.callParent();
        var th = this;

        //
        th.topPanel = Ext.createWidget("toolbar", {
            id: "jc-app-top",
            region: 'north',
            items: this.createToolbar()
        });

        //
        th.centerPanel = Ext.createWidget("tabpanel", {
            id: "jc-app-center",
            plain: true,
            tabPosition: 'bottom',
            region: "center",
            tabBar: {
                cls: 'jc-app-tabbar'
            }
        });

        //
        th.toolsPanel = Ext.createWidget("tabpanel", {
            id: "jc-app-tools",
            region: this.toolsRegion,
            width: this.toolsWidth,
            plain: true,
            tabPosition: 'bottom',
            split: true,
            hidden: true,
            tabBar: {
                cls: 'jc-app-tabbar'
            }
        });

        // showers
        th.setShower("main", Ext.create('Jc.shower.TabPanel', {
            tabPanel: th.centerPanel
        }));
        th.setShower("tools", Ext.create('Jc.shower.TabPanel', {
            tabPanel: th.toolsPanel,
            autoHide: true
        }));

        //
        th.viewPort = Ext.createWidget("viewport", {
            id: "jc-app-viewport",
            layout: {
                type: 'border'
            },
            padding: '0 0 10 0',
            items: [th.topPanel, this.centerPanel, this.toolsPanel]
        });

    }

});
 