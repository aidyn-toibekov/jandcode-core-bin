/**
 * Базовая тема
 */
Ext.define('Jc.theme.Base', {

    /**
     * Показывальщики фреймов
     */
    _showers: null,

    /**
     * shower по умолчанию
     */
    defaultShower: "main",

    /**
     * При true включается поддержка истории (для кнопки браузера back)
     */
    historySupport: false,

    /**
     * Глобальная инициализация. Вызывается в момент создания экзепляра
     * приложения (работает вне onReady)
     */
    initGlobal: function() {
        //
        Ext.tip.QuickTipManager.init();
        //
        Ext.Ajax.on('beforerequest', Jc.app.theme.showWait, Jc.app.theme);
        Ext.Ajax.on('requestcomplete', Jc.app.theme.hideWait, Jc.app.theme);
        Ext.Ajax.on('requestexception', Jc.app.theme.hideWait, Jc.app.theme);
    },

    /**
     * Вызывается при инициализации приложения. Работает внутри onReady
     */
    init: function() {
        //
        if (this.historySupport) {
            Ext.DomHelper.append(Ext.getBody(),
              '<form id="history-form" class="x-hide-display">' +
              '<input type="hidden" id="x-history-field" />' +
              '<iframe id="x-history-frame">' +
              '</iframe>' +
              '</form>'
            );
            Ext.History.init();
        }
        //
        this.onInit();
    },

    /**
     * Инициалиазация темы. Тут создаем ui.
     */
    onInit: function() {
        this._showers = {};
        this.setShower("dialog", Ext.create('Jc.shower.Dialog'));
        this.setShower("dialogclose", Ext.create('Jc.shower.Dialogclose'));
        this.setShower("main", Ext.create('Jc.shower.Dialogclose'));
    },

    ////// shower

    /**
     * Установить shower
     * @param name имя
     * @param sh экземпляр
     */
    setShower: function(name, sh) {
        sh.name = name;
        this._showers[name] = sh;
    },

    /**
     * Найти shower по имени
     */
    getShower: function(name) {
        var sh = this._showers[name];
        if (!sh) sh = this._showers[this.defaultShower];
        return sh;
    },

    /**
     * Показать фрейм
     * @param fr экземпляр фрейма Jc.Frame
     */
    showFrame: function(fr, showConfig) {
        var cfg = {
            shower: fr.shower
        };
        Ext.apply(cfg, fr.showConfig);
        Ext.apply(cfg, showConfig);
        var sh = this._showers[cfg.shower];
        if (!sh) sh = this._showers[this.defaultShower];
        fr.shower = sh;
        fr.showConfig = cfg;
        return sh.showFrame(fr, cfg);
    },

    /**
     * Закрыть фрейм
     * @param fr экземпляр фрейма Jc.Frame
     */
    closeFrame: function(fr) {
        var sh;
        if (Ext.isString(fr)) {
            for (var nm in this._showers) {
                sh = this._showers[nm];
                if (sh.closeFrameById(fr)) {
                    return;
                }
            }
        } else {
            sh = fr.shower;
            if (sh && !Ext.isString(sh)) {
                sh.closeFrame(fr);
            }
        }
    },

    /**
     * Активировать фрейм по id, если есть.
     * Возвращает активированный фрейм, если активирован, либо null, если фрейма нет.
     */
    activateFrame: function(id) {
        for (var nm in this._showers) {
            var sh = this._showers[nm];
            var f = sh.activateFrame(id);
            if (f) {
                return f;
            }
        }
        return null;
    },

    ////// wait

    /**
     * Показать окошко 'Подождите'
     * @param control какой control использовать в качестве окошка. Если не указано,
     * то используется стандартное поведение по умолчанию.
     * Указанный control должен быть наследником от Ext.Panel (остальные компоненты
     * ведут себя неадекватно, в частности не показываются в центре экрана почему-то).
     * Кроме того, этот control должет имет css class "jc-showwait-control" для
     * отображения поверх маски экрана.
     * Еще этот control при создании должен бытб hidden.
     *
     * @param force true - принудительная замена текущего showWait на новый
     */
    showWait: function(control, force) {
        //! стандартная маска Ext.LoadMaskView под управлением слоем и часто оказывается под диалогом...
        if (!this._showWaitEl) {
            this._showWaitMaskEl = Ext.core.DomHelper.append(Ext.getBody(), '<div class="x-mask" style="visibility: hidden;"></div>', true);
            this._showWaitEl = Ext.core.DomHelper.append(Ext.getBody(), Jc.format('<div class="x-mask-msg x-mask-msg-default jc-mask-msg jc-showwait-control" style="visibility: hidden;"><div class="x-mask-loading">{0}</div></div>', UtLang.t('Подождите...')), true);
            this._showWaitLevel = 0;
        }
        if (force === true) {
            if (this._showWaitCtrl) {
                this._showWaitCtrl.hide();
                this._showWaitCtrl.destroy();
                this._showWaitCtrl = null;
            }
            if (this._showWaitEl) {
                this._showWaitEl.hide();
            }
        }
        if (this._showWaitLevel == 0 || force === true) {
            this._showWaitMaskEl.show();
            if (!control) {
                control = 'default';
            }
            // определен control
            var cls = Jc.ini.showWait.control[control];
            if (cls) {
                var inst = Ext.create(cls);
                inst.render(Ext.getBody());
                this._showWaitCtrl = inst;
            }
            if (this._showWaitCtrl) {
                this._showWaitCtrl.show();
                this._showWaitCtrl.center();
            } else {
                this._showWaitEl.show();
                this._showWaitEl.center();
            }
        }
        this._showWaitLevel++;
    },

    hideWait: function() {
        if (this._showWaitEl && this._showWaitLevel > 0) {
            this._showWaitLevel--;
            if (this._showWaitLevel == 0) {
                if (this._showWaitCtrl) {
                    this._showWaitCtrl.hide();
                    this._showWaitCtrl.destroy();
                    this._showWaitCtrl = null;
                } else {
                    this._showWaitEl.hide();
                }
                this._showWaitMaskEl.hide();
            }
        }
    },

    hideWaitForce: function() {
        if (this._showWaitEl && this._showWaitLevel != 0) {
            this._showWaitLevel = 1;
            this.hideWait();
        }
    },

    /**
     * Возвращает текущий showWait control или null, если его нет или отображается
     * стандартный по умолчанию.
     */
    getShowWaitControl: function() {
        return this._showWaitCtrl;
    }

});
 