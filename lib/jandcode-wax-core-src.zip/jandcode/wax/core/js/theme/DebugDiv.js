/**
 * Тема в виде отладочных div
 */
Ext.define('Jc.theme.DebugDiv', {
    extend: 'Jc.theme.Base',

    historySupport: true,

    createMainMenu1: function() {
        try {
            return Jc.app.createMainMenu1();
        } catch(e) {
            return [
                {text: "NoMenu1"}
            ]
        }
    },

    createMainMenu2: function() {
        try {
            return Jc.app.createMainMenu2();
        } catch(e) {
            return [
                {text: "NoMenu2"}
            ]
        }
    },

    onInit: function() {
        this.callParent();
        var th = this;

        th.mainMenuToolbar = Ext.create("Ext.toolbar.Toolbar", {
            renderTo: "jc-app-menu1",
            items: th.createMainMenu1()
        });

        th.mainMenuToolbar2 = Ext.create("Ext.toolbar.Toolbar", {
            renderTo: "jc-app-menu2",
            items: th.createMainMenu2()
        });

        // showers
        th.setShower("main", Ext.create('Jc.shower.Div', {
            historySupport: true,
            titleId: "jc-app-content-title",
            toolbarId: "jc-app-content-toolbar",
            bodyId: "jc-app-content-body"
        }));

        th.setShower("tools", Ext.create('Jc.shower.Div', {
            titleId: "jc-app-tools-title",
            toolbarId: "jc-app-tools-toolbar",
            bodyId: "jc-app-tools-body"
        }));

    }

});
 