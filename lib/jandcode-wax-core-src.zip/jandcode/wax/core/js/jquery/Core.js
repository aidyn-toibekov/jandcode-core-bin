Ext.define('Jc.jquery.Core', {
}, function() {
    Jc.eval(Jc.requestText({url: 'js/jquery/jquery-1.8.3.min.js'}));
});
