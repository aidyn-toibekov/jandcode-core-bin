Ext.define('Jc.jquery.Plupload', {
    requires: ['Jc.jquery.Core']
}, function() {
    Jc.eval(Jc.requestText({url: 'js/jquery/plupload/plupload.full.js'}));
});

