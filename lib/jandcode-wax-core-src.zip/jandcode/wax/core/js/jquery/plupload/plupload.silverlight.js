(function(g, b, d, e) {
    var a = {}, h = {};

    function c(o) {
        var n, m = typeof o, j, l, k;
        if (o === e || o === null) {
            return"null"
        }
        if (m === "string") {
            n = "\bb\tt\nn\ff\rr\"\"''\\\\";
            return'"' + o.replace(/([\u0080-\uFFFF\x00-\x1f\"])/g, function(q, p) {
                var i = n.indexOf(p);
                if (i + 1) {
                    return"\\" + n.charAt(i + 1)
                }
                q = p.charCodeAt().toString(16);
                return"\\u" + "0000".substring(q.length) + q
            }) + '"'
        }
        if (m == "object") {
            j = o.length !== e;
            n = "";
            if (j) {
                for (l = 0; l < o.length; l++) {
                    if (n) {
                        n += ","
                    }
                    n += c(o[l])
                }
                n = "[" + n + "]"
            } else {
                for (k in o) {
                    if (o.hasOwnProperty(k)) {
                        if (n) {
                            n += ","
                        }
                        n += c(k) + ":" + c(o[k])
                    }
                }
                n = "{" + n + "}"
            }
            return n
        }
        return"" + o
    }

    function f(r) {
        var u = false, i = null, n = null, j, k, l, t, m, p = 0;
        try {
            try {
                n = new ActiveXObject("AgControl.AgControl");
                if (n.IsVersionSupported(r)) {
                    u = true
                }
                n = null
            } catch(q) {
                var o = navigator.plugins["Silverlight Plug-In"];
                if (o) {
                    j = o.description;
                    if (j === "1.0.30226.2") {
                        j = "2.0.30226.2"
                    }
                    k = j.split(".");
                    while (k.length > 3) {
                        k.pop()
                    }
                    while (k.length < 4) {
                        k.push(0)
                    }
                    l = r.split(".");
                    while (l.length > 4) {
                        l.pop()
                    }
                    do {
                        t = parseInt(l[p], 10);
                        m = parseInt(k[p], 10);
                        p++
                    } while (p < l.length && t === m);
                    if (t <= m && !isNaN(t)) {
                        u = true
                    }
                }
            }
        } catch(s) {
            u = false
        }
        return u
    }

    d.silverlight = {trigger: function(n, k) {
        var m = a[n], l, j;
        if (m) {
            j = d.toArray(arguments).slice(1);
            j[0] = "Silverlight:" + k;
            setTimeout(function() {
                m.trigger.apply(m, j)
            }, 0)
        }
    }};
    d.runtimes.Silverlight = d.addRuntime("silverlight", {getFeatures: function() {
        return{jpgresize: true, pngresize: true, chunks: true, progress: true, multipart: true, multi_selection: true}
    }, init: function(p, q) {
        var o, m = "", n = p.settings.filters, l, k = b.body;
        if (!f("2.0.31005.0") || (g.opera && g.opera.buildNumber)) {
            q({success: false});
            return
        }
        h[p.id] = false;
        a[p.id] = p;
        o = b.createElement("div");
        o.id = p.id + "_silverlight_container";
        d.extend(o.style, {position: "absolute", top: "0px", background: p.settings.shim_bgcolor || "transparent", zIndex: 99999, width: "100px", height: "100px", overflow: "hidden", opacity: p.settings.shim_bgcolor || b.documentMode > 8 ? "" : 0.01});
        o.className = "plupload silverlight";
        if (p.settings.container) {
            k = b.getElementById(p.settings.container);
            if (d.getStyle(k, "position") === "static") {
                k.style.position = "relative"
            }
        }
        k.appendChild(o);
        for (l = 0; l < n.length; l++) {
            m += (m != "" ? "|" : "") + n[l].title + " | *." + n[l].extensions.replace(/,/g, ";*.")
        }
        o.innerHTML = '<object id="' + p.id + '_silverlight" data="data:application/x-silverlight," type="application/x-silverlight-2" style="outline:none;" width="1024" height="1024"><param name="source" value="' + p.settings.silverlight_xap_url + '"/><param name="background" value="Transparent"/><param name="windowless" value="true"/><param name="enablehtmlaccess" value="true"/><param name="initParams" value="id=' + p.id + ",filter=" + m + ",multiselect=" + p.settings.multi_selection + '"/></object>';
        function j() {
            return b.getElementById(p.id + "_silverlight").content.Upload
        }

        p.bind("Silverlight:Init", function() {
            var i, r = {};
            if (h[p.id]) {
                return
            }
            h[p.id] = true;
            p.bind("Silverlight:StartSelectFiles", function(s) {
                i = []
            });
            p.bind("Silverlight:SelectFile", function(s, v, t, u) {
                var w;
                w = d.guid();
                r[w] = v;
                r[v] = w;
                i.push(new d.File(w, t, u))
            });
            p.bind("Silverlight:SelectSuccessful", function() {
                if (i.length) {
                    p.trigger("FilesAdded", i)
                }
            });
            p.bind("Silverlight:UploadChunkError", function(s, v, t, w, u) {
                p.trigger("Error", {code: d.IO_ERROR, message: "IO Error.", details: u, file: s.getFile(r[v])})
            });
            p.bind("Silverlight:UploadFileProgress", function(s, w, t, v) {
                var u = s.getFile(r[w]);
                if (u.status != d.FAILED) {
                    u.size = v;
                    u.loaded = t;
                    s.trigger("UploadProgress", u)
                }
            });
            p.bind("Refresh", function(s) {
                var t, u, v;
                t = b.getElementById(s.settings.browse_button);
                if (t) {
                    u = d.getPos(t, b.getElementById(s.settings.container));
                    v = d.getSize(t);
                    d.extend(b.getElementById(s.id + "_silverlight_container").style, {top: u.y + "px", left: u.x + "px", width: v.w + "px", height: v.h + "px"})
                }
            });
            p.bind("Silverlight:UploadChunkSuccessful", function(s, v, t, y, x) {
                var w, u = s.getFile(r[v]);
                w = {chunk: t, chunks: y, response: x};
                s.trigger("ChunkUploaded", u, w);
                if (u.status != d.FAILED && s.state !== d.STOPPED) {
                    j().UploadNextChunk()
                }
                if (t == y - 1) {
                    u.status = d.DONE;
                    s.trigger("FileUploaded", u, {response: x})
                }
            });
            p.bind("Silverlight:UploadSuccessful", function(s, v, t) {
                var u = s.getFile(r[v]);
                u.status = d.DONE;
                s.trigger("FileUploaded", u, {response: t})
            });
            p.bind("FilesRemoved", function(s, u) {
                var t;
                for (t = 0; t < u.length; t++) {
                    j().RemoveFile(r[u[t].id])
                }
            });
            p.bind("UploadFile", function(s, u) {
                var v = s.settings, t = v.resize || {};
                j().UploadFile(r[u.id], s.settings.url, c({name: u.target_name || u.name, mime: d.mimeTypes[u.name.replace(/^.+\.([^.]+)/, "$1").toLowerCase()] || "application/octet-stream", chunk_size: v.chunk_size, image_width: t.width, image_height: t.height, image_quality: t.quality || 90, multipart: !!v.multipart, multipart_params: v.multipart_params || {}, file_data_name: v.file_data_name, headers: v.headers}))
            });
            p.bind("CancelUpload", function() {
                j().CancelUpload()
            });
            p.bind("Silverlight:MouseEnter", function(s) {
                var t, u;
                t = b.getElementById(p.settings.browse_button);
                u = s.settings.browse_button_hover;
                if (t && u) {
                    d.addClass(t, u)
                }
            });
            p.bind("Silverlight:MouseLeave", function(s) {
                var t, u;
                t = b.getElementById(p.settings.browse_button);
                u = s.settings.browse_button_hover;
                if (t && u) {
                    d.removeClass(t, u)
                }
            });
            p.bind("Silverlight:MouseLeftButtonDown", function(s) {
                var t, u;
                t = b.getElementById(p.settings.browse_button);
                u = s.settings.browse_button_active;
                if (t && u) {
                    d.addClass(t, u);
                    d.addEvent(b.body, "mouseup", function() {
                        d.removeClass(t, u)
                    })
                }
            });
            p.bind("Sliverlight:StartSelectFiles", function(s) {
                var t, u;
                t = b.getElementById(p.settings.browse_button);
                u = s.settings.browse_button_active;
                if (t && u) {
                    d.removeClass(t, u)
                }
            });
            p.bind("DisableBrowse", function(s, t) {
                j().DisableBrowse(t)
            });
            p.bind("Destroy", function(s) {
                var t;
                d.removeAllEvents(b.body, s.id);
                delete h[s.id];
                delete a[s.id];
                t = b.getElementById(s.id + "_silverlight_container");
                if (t) {
                    k.removeChild(t)
                }
            });
            q({success: true})
        })
    }})
})(window, document, plupload);