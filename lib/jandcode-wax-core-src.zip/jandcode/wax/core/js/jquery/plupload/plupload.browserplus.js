(function(a) {
    a.runtimes.BrowserPlus = a.addRuntime("browserplus", {getFeatures: function() {
        return{dragdrop: true, jpgresize: true, pngresize: true, chunks: true, progress: true, multipart: true, multi_selection: true}
    }, init: function(g, i) {
        var e = window.BrowserPlus, h = {}, d = g.settings, c = d.resize;

        function f(n) {
            var m, l, j = [], k, o;
            for (l = 0; l < n.length; l++) {
                k = n[l];
                o = a.guid();
                h[o] = k;
                j.push(new a.File(o, k.name, k.size))
            }
            if (l) {
                g.trigger("FilesAdded", j)
            }
        }

        function b() {
            var j = false;
            g.bind("PostInit", function() {
                var n, l = d.drop_element, p = g.id + "_droptarget", k = document.getElementById(l), m;

                function q(s, r) {
                    e.DragAndDrop.AddDropTarget({id: s}, function(t) {
                        e.DragAndDrop.AttachCallbacks({id: s, hover: function(u) {
                            if (!u && r) {
                                r()
                            }
                        }, drop: function(u) {
                            if (r) {
                                r()
                            }
                            f(u)
                        }}, function() {
                        })
                    })
                }

                function o() {
                    document.getElementById(p).style.top = "-1000px"
                }

                if (k) {
                    if (document.attachEvent && (/MSIE/gi).test(navigator.userAgent)) {
                        n = document.createElement("div");
                        n.setAttribute("id", p);
                        a.extend(n.style, {position: "absolute", top: "-1000px", background: "red", filter: "alpha(opacity=0)", opacity: 0});
                        document.body.appendChild(n);
                        a.addEvent(k, "dragenter", function(s) {
                            var r, t;
                            r = document.getElementById(l);
                            t = a.getPos(r);
                            a.extend(document.getElementById(p).style, {top: t.y + "px", left: t.x + "px", width: r.offsetWidth + "px", height: r.offsetHeight + "px"})
                        });
                        q(p, o)
                    } else {
                        q(l)
                    }
                }
                a.addEvent(document.getElementById(d.browse_button), "click", function(x) {
                    var r = [], t, s, w = d.filters, v, u;
                    x.preventDefault();
                    if (j) {
                        return
                    }
                    no_type_restriction:for (t = 0; t < w.length; t++) {
                        v = w[t].extensions.split(",");
                        for (s = 0; s < v.length; s++) {
                            if (v[s] === "*") {
                                r = [];
                                break no_type_restriction
                            }
                            u = a.mimeTypes[v[s]];
                            if (u && a.inArray(u, r) === -1) {
                                r.push(a.mimeTypes[v[s]])
                            }
                        }
                    }
                    e.FileBrowse.OpenBrowseDialog({mimeTypes: r}, function(y) {
                        if (y.success) {
                            f(y.value)
                        }
                    })
                });
                k = n = null
            });
            g.bind("CancelUpload", function() {
                e.Uploader.cancel({}, function() {
                })
            });
            g.bind("DisableBrowse", function(k, l) {
                j = l
            });
            g.bind("UploadFile", function(n, k) {
                var m = h[k.id], s = {}, l = n.settings.chunk_size, o, p = [];

                function r(t, v) {
                    var u;
                    if (k.status == a.FAILED) {
                        return
                    }
                    s.name = k.target_name || k.name;
                    if (l) {
                        s.chunk = "" + t;
                        s.chunks = "" + v
                    }
                    u = p.shift();
                    e.Uploader.upload({url: n.settings.url, files: {file: u}, cookies: document.cookies, postvars: a.extend(s, n.settings.multipart_params), progressCallback: function(y) {
                        var x, w = 0;
                        o[t] = parseInt(y.filePercent * u.size / 100, 10);
                        for (x = 0; x < o.length; x++) {
                            w += o[x]
                        }
                        k.loaded = w;
                        n.trigger("UploadProgress", k)
                    }}, function(x) {
                        var w, y;
                        if (x.success) {
                            w = x.value.statusCode;
                            if (l) {
                                n.trigger("ChunkUploaded", k, {chunk: t, chunks: v, response: x.value.body, status: w})
                            }
                            if (p.length > 0) {
                                r(++t, v)
                            } else {
                                k.status = a.DONE;
                                n.trigger("FileUploaded", k, {response: x.value.body, status: w});
                                if (w >= 400) {
                                    n.trigger("Error", {code: a.HTTP_ERROR, message: a.translate("HTTP Error."), file: k, status: w})
                                }
                            }
                        } else {
                            n.trigger("Error", {code: a.GENERIC_ERROR, message: a.translate("Generic Error."), file: k, details: x.error})
                        }
                    })
                }

                function q(t) {
                    k.size = t.size;
                    if (l) {
                        e.FileAccess.chunk({file: t, chunkSize: l}, function(w) {
                            if (w.success) {
                                var x = w.value, u = x.length;
                                o = Array(u);
                                for (var v = 0; v < u; v++) {
                                    o[v] = 0;
                                    p.push(x[v])
                                }
                                r(0, u)
                            }
                        })
                    } else {
                        o = Array(1);
                        p.push(t);
                        r(0, 1)
                    }
                }

                if (c && /\.(png|jpg|jpeg)$/i.test(k.name)) {
                    BrowserPlus.ImageAlter.transform({file: m, quality: c.quality || 90, actions: [
                        {scale: {maxwidth: c.width, maxheight: c.height}}
                    ]}, function(t) {
                        if (t.success) {
                            q(t.value.file)
                        }
                    })
                } else {
                    q(m)
                }
            });
            i({success: true})
        }

        if (e) {
            e.init(function(k) {
                var j = [
                    {service: "Uploader", version: "3"},
                    {service: "DragAndDrop", version: "1"},
                    {service: "FileBrowse", version: "1"},
                    {service: "FileAccess", version: "2"}
                ];
                if (c) {
                    j.push({service: "ImageAlter", version: "4"})
                }
                if (k.success) {
                    e.require({services: j}, function(l) {
                        if (l.success) {
                            b()
                        } else {
                            i()
                        }
                    })
                } else {
                    i()
                }
            })
        } else {
            i()
        }
    }})
})(plupload);