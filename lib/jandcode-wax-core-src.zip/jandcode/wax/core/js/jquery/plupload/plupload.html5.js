(function(h, k, j, e) {
    var c = {}, g;

    function m(o, p) {
        var n;
        if ("FileReader" in h) {
            n = new FileReader();
            n.readAsDataURL(o);
            n.onload = function() {
                p(n.result)
            }
        } else {
            return p(o.getAsDataURL())
        }
    }

    function l(o, p) {
        var n;
        if ("FileReader" in h) {
            n = new FileReader();
            n.readAsBinaryString(o);
            n.onload = function() {
                p(n.result)
            }
        } else {
            return p(o.getAsBinary())
        }
    }

    function d(r, p, n, v) {
        var q, o, u, s, t = this;
        m(c[r.id], function(w) {
            q = k.createElement("canvas");
            q.style.display = "none";
            k.body.appendChild(q);
            o = q.getContext("2d");
            u = new Image();
            u.onerror = u.onabort = function() {
                v({success: false})
            };
            u.onload = function() {
                var B, x, z, y, A;
                if (!p.width) {
                    p.width = u.width
                }
                if (!p.height) {
                    p.height = u.height
                }
                s = Math.min(p.width / u.width, p.height / u.height);
                if (s < 1 || (s === 1 && n === "image/jpeg")) {
                    B = Math.round(u.width * s);
                    x = Math.round(u.height * s);
                    q.width = B;
                    q.height = x;
                    o.drawImage(u, 0, 0, B, x);
                    if (n === "image/jpeg") {
                        y = new f(atob(w.substring(w.indexOf("base64,") + 7)));
                        if (y.headers && y.headers.length) {
                            A = new a();
                            if (A.init(y.get("exif")[0])) {
                                A.setExif("PixelXDimension", B);
                                A.setExif("PixelYDimension", x);
                                y.set("exif", A.getBinary());
                                if (t.hasEventListener("ExifData")) {
                                    t.trigger("ExifData", r, A.EXIF())
                                }
                                if (t.hasEventListener("GpsData")) {
                                    t.trigger("GpsData", r, A.GPS())
                                }
                            }
                        }
                        if (p.quality) {
                            try {
                                w = q.toDataURL(n, p.quality / 100)
                            } catch(C) {
                                w = q.toDataURL(n)
                            }
                        }
                    } else {
                        w = q.toDataURL(n)
                    }
                    w = w.substring(w.indexOf("base64,") + 7);
                    w = atob(w);
                    if (y && y.headers && y.headers.length) {
                        w = y.restore(w);
                        y.purge()
                    }
                    q.parentNode.removeChild(q);
                    v({success: true, data: w})
                } else {
                    v({success: false})
                }
            };
            u.src = w
        })
    }

    j.runtimes.Html5 = j.addRuntime("html5", {getFeatures: function() {
        var s, o, r, q, p, n;
        o = r = p = n = false;
        if (h.XMLHttpRequest) {
            s = new XMLHttpRequest();
            r = !!s.upload;
            o = !!(s.sendAsBinary || s.upload)
        }
        if (o) {
            q = !!(s.sendAsBinary || (h.Uint8Array && h.ArrayBuffer));
            p = !!(File && (File.prototype.getAsDataURL || h.FileReader) && q);
            n = !!(File && (File.prototype.mozSlice || File.prototype.webkitSlice || File.prototype.slice))
        }
        g = j.ua.safari && j.ua.windows;
        return{html5: o, dragdrop: (function() {
            var t = k.createElement("div");
            return("draggable" in t) || ("ondragstart" in t && "ondrop" in t)
        }()), jpgresize: p, pngresize: p, multipart: p || !!h.FileReader || !!h.FormData, canSendBinary: q, cantSendBlobInFormData: !!(j.ua.gecko && h.FormData && h.FileReader && !FileReader.prototype.readAsArrayBuffer), progress: r, chunks: n, multi_selection: !(j.ua.safari && j.ua.windows), triggerDialog: (j.ua.gecko && h.FormData || j.ua.webkit)}
    }, init: function(p, r) {
        var n, q;

        function o(w) {
            var u, t, v = [], x, s = {};
            for (t = 0; t < w.length; t++) {
                u = w[t];
                if (s[u.name]) {
                    continue
                }
                s[u.name] = true;
                x = j.guid();
                c[x] = u;
                v.push(new j.File(x, u.fileName || u.name, u.fileSize || u.size))
            }
            if (v.length) {
                p.trigger("FilesAdded", v)
            }
        }

        n = this.getFeatures();
        if (!n.html5) {
            r({success: false});
            return
        }
        p.bind("Init", function(w) {
            var G, F, C = [], v, D, t = w.settings.filters, u, B, s = k.body, E;
            G = k.createElement("div");
            G.id = w.id + "_html5_container";
            j.extend(G.style, {position: "absolute", background: p.settings.shim_bgcolor || "transparent", width: "100px", height: "100px", overflow: "hidden", zIndex: 99999, opacity: p.settings.shim_bgcolor ? "" : 0});
            G.className = "plupload html5";
            if (p.settings.container) {
                s = k.getElementById(p.settings.container);
                if (j.getStyle(s, "position") === "static") {
                    s.style.position = "relative"
                }
            }
            s.appendChild(G);
            no_type_restriction:for (v = 0; v < t.length; v++) {
                u = t[v].extensions.split(/,/);
                for (D = 0; D < u.length; D++) {
                    if (u[D] === "*") {
                        C = [];
                        break no_type_restriction
                    }
                    B = j.mimeTypes[u[D]];
                    if (B && j.inArray(B, C) === -1) {
                        C.push(B)
                    }
                }
            }
            G.innerHTML = '<input id="' + p.id + '_html5"  style="font-size:999px" type="file" accept="' + C.join(",") + '" ' + (p.settings.multi_selection && p.features.multi_selection ? 'multiple="multiple"' : "") + " />";
            G.scrollTop = 100;
            E = k.getElementById(p.id + "_html5");
            if (w.features.triggerDialog) {
                j.extend(E.style, {position: "absolute", width: "100%", height: "100%"})
            } else {
                j.extend(E.style, {cssFloat: "right", styleFloat: "right"})
            }
            E.onchange = function() {
                o(this.files);
                this.value = ""
            };
            F = k.getElementById(w.settings.browse_button);
            if (F) {
                var z = w.settings.browse_button_hover, A = w.settings.browse_button_active, x = w.features.triggerDialog ? F : G;
                if (z) {
                    j.addEvent(x, "mouseover", function() {
                        j.addClass(F, z)
                    }, w.id);
                    j.addEvent(x, "mouseout", function() {
                        j.removeClass(F, z)
                    }, w.id)
                }
                if (A) {
                    j.addEvent(x, "mousedown", function() {
                        j.addClass(F, A)
                    }, w.id);
                    j.addEvent(k.body, "mouseup", function() {
                        j.removeClass(F, A)
                    }, w.id)
                }
                if (w.features.triggerDialog) {
                    j.addEvent(F, "click", function(H) {
                        var y = k.getElementById(w.id + "_html5");
                        if (y && !y.disabled) {
                            y.click()
                        }
                        H.preventDefault()
                    }, w.id)
                }
            }
        });
        p.bind("PostInit", function() {
            var s = k.getElementById(p.settings.drop_element);
            if (s) {
                if (g) {
                    j.addEvent(s, "dragenter", function(w) {
                        var v, t, u;
                        v = k.getElementById(p.id + "_drop");
                        if (!v) {
                            v = k.createElement("input");
                            v.setAttribute("type", "file");
                            v.setAttribute("id", p.id + "_drop");
                            v.setAttribute("multiple", "multiple");
                            j.addEvent(v, "change", function() {
                                o(this.files);
                                j.removeEvent(v, "change", p.id);
                                v.parentNode.removeChild(v)
                            }, p.id);
                            s.appendChild(v)
                        }
                        t = j.getPos(s, k.getElementById(p.settings.container));
                        u = j.getSize(s);
                        if (j.getStyle(s, "position") === "static") {
                            j.extend(s.style, {position: "relative"})
                        }
                        j.extend(v.style, {position: "absolute", display: "block", top: 0, left: 0, width: u.w + "px", height: u.h + "px", opacity: 0})
                    }, p.id);
                    return
                }
                j.addEvent(s, "dragover", function(t) {
                    t.preventDefault()
                }, p.id);
                j.addEvent(s, "drop", function(u) {
                    var t = u.dataTransfer;
                    if (t && t.files) {
                        o(t.files)
                    }
                    u.preventDefault()
                }, p.id)
            }
        });
        p.bind("Refresh", function(s) {
            var t, u, v, x, w;
            t = k.getElementById(p.settings.browse_button);
            if (t) {
                u = j.getPos(t, k.getElementById(s.settings.container));
                v = j.getSize(t);
                x = k.getElementById(p.id + "_html5_container");
                j.extend(x.style, {top: u.y + "px", left: u.x + "px", width: v.w + "px", height: v.h + "px"});
                if (p.features.triggerDialog) {
                    if (j.getStyle(t, "position") === "static") {
                        j.extend(t.style, {position: "relative"})
                    }
                    w = parseInt(j.getStyle(t, "z-index"), 10);
                    if (isNaN(w)) {
                        w = 0
                    }
                    j.extend(t.style, {zIndex: w});
                    j.extend(x.style, {zIndex: w - 1})
                }
            }
        });
        p.bind("DisableBrowse", function(s, u) {
            var t = k.getElementById(s.id + "_html5");
            if (t) {
                t.disabled = u
            }
        });
        p.bind("CancelUpload", function() {
            if (q && q.abort) {
                q.abort()
            }
        });
        p.bind("UploadFile", function(s, u) {
            var v = s.settings, y, t;

            function x(A, D, z) {
                var B;
                if (File.prototype.slice) {
                    try {
                        A.slice();
                        return A.slice(D, z)
                    } catch(C) {
                        return A.slice(D, z - D)
                    }
                } else {
                    if (B = File.prototype.webkitSlice || File.prototype.mozSlice) {
                        return B.call(A, D, z)
                    } else {
                        return null
                    }
                }
            }

            function w(A) {
                var D = 0, C = 0, z = ("FileReader" in h) ? new FileReader : null;

                function B() {
                    var I, M, K, L, H, J, F, E = s.settings.url;

                    function G(V) {
                        var T = 0, N = "----pluploadboundary" + j.guid(), O, P = "--", U = "\r\n", R = "";
                        q = new XMLHttpRequest;
                        if (q.upload) {
                            q.upload.onprogress = function(W) {
                                u.loaded = Math.min(u.size, C + W.loaded - T);
                                s.trigger("UploadProgress", u)
                            }
                        }
                        q.onreadystatechange = function() {
                            var W, Y;
                            if (q.readyState == 4 && s.state !== j.STOPPED) {
                                try {
                                    W = q.status
                                } catch(X) {
                                    W = 0
                                }
                                if (W >= 400) {
                                    s.trigger("Error", {code: j.HTTP_ERROR, message: j.translate("HTTP Error."), file: u, status: W})
                                } else {
                                    if (K) {
                                        Y = {chunk: D, chunks: K, response: q.responseText, status: W};
                                        s.trigger("ChunkUploaded", u, Y);
                                        C += J;
                                        if (Y.cancelled) {
                                            u.status = j.FAILED;
                                            return
                                        }
                                        u.loaded = Math.min(u.size, (D + 1) * H)
                                    } else {
                                        u.loaded = u.size
                                    }
                                    s.trigger("UploadProgress", u);
                                    V = I = O = R = null;
                                    if (!K || ++D >= K) {
                                        u.status = j.DONE;
                                        s.trigger("FileUploaded", u, {response: q.responseText, status: W})
                                    } else {
                                        B()
                                    }
                                }
                            }
                        };
                        if (s.settings.multipart && n.multipart) {
                            L.name = u.target_name || u.name;
                            q.open("post", E, true);
                            j.each(s.settings.headers, function(X, W) {
                                q.setRequestHeader(W, X)
                            });
                            if (typeof(V) !== "string" && !!h.FormData) {
                                O = new FormData();
                                j.each(j.extend(L, s.settings.multipart_params), function(X, W) {
                                    O.append(W, X)
                                });
                                O.append(s.settings.file_data_name, V);
                                q.send(O);
                                return
                            }
                            if (typeof(V) === "string") {
                                q.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + N);
                                j.each(j.extend(L, s.settings.multipart_params), function(X, W) {
                                    R += P + N + U + 'Content-Disposition: form-data; name="' + W + '"' + U + U;
                                    R += unescape(encodeURIComponent(X)) + U
                                });
                                F = j.mimeTypes[u.name.replace(/^.+\.([^.]+)/, "$1").toLowerCase()] || "application/octet-stream";
                                R += P + N + U + 'Content-Disposition: form-data; name="' + s.settings.file_data_name + '"; filename="' + unescape(encodeURIComponent(u.name)) + '"' + U + "Content-Type: " + F + U + U + V + U + P + N + P + U;
                                T = R.length - V.length;
                                V = R;
                                if (q.sendAsBinary) {
                                    q.sendAsBinary(V)
                                } else {
                                    if (n.canSendBinary) {
                                        var S = new Uint8Array(V.length);
                                        for (var Q = 0; Q < V.length; Q++) {
                                            S[Q] = (V.charCodeAt(Q) & 255)
                                        }
                                        q.send(S.buffer)
                                    }
                                }
                                return
                            }
                        }
                        E = j.buildUrl(s.settings.url, j.extend(L, s.settings.multipart_params));
                        q.open("post", E, true);
                        q.setRequestHeader("Content-Type", "application/octet-stream");
                        j.each(s.settings.headers, function(X, W) {
                            q.setRequestHeader(W, X)
                        });
                        q.send(V)
                    }

                    if (u.status == j.DONE || u.status == j.FAILED || s.state == j.STOPPED) {
                        return
                    }
                    L = {name: u.target_name || u.name};
                    if (v.chunk_size && u.size > v.chunk_size && (n.chunks || typeof(A) == "string")) {
                        H = v.chunk_size;
                        K = Math.ceil(u.size / H);
                        J = Math.min(H, u.size - (D * H));
                        if (typeof(A) == "string") {
                            I = A.substring(D * H, D * H + J)
                        } else {
                            I = x(A, D * H, D * H + J)
                        }
                        L.chunk = D;
                        L.chunks = K
                    } else {
                        J = u.size;
                        I = A
                    }
                    if (s.settings.multipart && n.multipart && typeof(I) !== "string" && z && n.cantSendBlobInFormData && n.chunks && s.settings.chunk_size) {
                        z.onload = function() {
                            G(z.result)
                        };
                        z.readAsBinaryString(I)
                    } else {
                        G(I)
                    }
                }

                B()
            }

            y = c[u.id];
            if (n.jpgresize && s.settings.resize && /\.(png|jpg|jpeg)$/i.test(u.name)) {
                d.call(s, u, s.settings.resize, /\.png$/i.test(u.name) ? "image/png" : "image/jpeg", function(z) {
                    if (z.success) {
                        u.size = z.data.length;
                        w(z.data)
                    } else {
                        if (n.chunks) {
                            w(y)
                        } else {
                            l(y, w)
                        }
                    }
                })
            } else {
                if (!n.chunks && n.jpgresize) {
                    l(y, w)
                } else {
                    w(y)
                }
            }
        });
        p.bind("Destroy", function(s) {
            var u, v, t = k.body, w = {inputContainer: s.id + "_html5_container", inputFile: s.id + "_html5", browseButton: s.settings.browse_button, dropElm: s.settings.drop_element};
            for (u in w) {
                v = k.getElementById(w[u]);
                if (v) {
                    j.removeAllEvents(v, s.id)
                }
            }
            j.removeAllEvents(k.body, s.id);
            if (s.settings.container) {
                t = k.getElementById(s.settings.container)
            }
            t.removeChild(k.getElementById(w.inputContainer))
        });
        r({success: true})
    }});
    function b() {
        var q = false, o;

        function r(t, v) {
            var s = q ? 0 : -8 * (v - 1), w = 0, u;
            for (u = 0; u < v; u++) {
                w |= (o.charCodeAt(t + u) << Math.abs(s + u * 8))
            }
            return w
        }

        function n(u, s, t) {
            var t = arguments.length === 3 ? t : o.length - s - 1;
            o = o.substr(0, s) + u + o.substr(t + s)
        }

        function p(t, u, w) {
            var x = "", s = q ? 0 : -8 * (w - 1), v;
            for (v = 0; v < w; v++) {
                x += String.fromCharCode((u >> Math.abs(s + v * 8)) & 255)
            }
            n(x, t, w)
        }

        return{II: function(s) {
            if (s === e) {
                return q
            } else {
                q = s
            }
        }, init: function(s) {
            q = false;
            o = s
        }, SEGMENT: function(s, u, t) {
            switch(arguments.length) {
                case 1:
                    return o.substr(s, o.length - s - 1);
                case 2:
                    return o.substr(s, u);
                case 3:
                    n(t, s, u);
                    break;
                default:
                    return o
            }
        }, BYTE: function(s) {
            return r(s, 1)
        }, SHORT: function(s) {
            return r(s, 2)
        }, LONG: function(s, t) {
            if (t === e) {
                return r(s, 4)
            } else {
                p(s, t, 4)
            }
        }, SLONG: function(s) {
            var t = r(s, 4);
            return(t > 2147483647 ? t - 4294967296 : t)
        }, STRING: function(s, t) {
            var u = "";
            for (t += s; s < t; s++) {
                u += String.fromCharCode(r(s, 1))
            }
            return u
        }}
    }

    function f(s) {
        var u = {65505: {app: "EXIF", name: "APP1", signature: "Exif\0"}, 65506: {app: "ICC", name: "APP2", signature: "ICC_PROFILE\0"}, 65517: {app: "IPTC", name: "APP13", signature: "Photoshop 3.0\0"}}, t = [], r, n, p = e, q = 0, o;
        r = new b();
        r.init(s);
        if (r.SHORT(0) !== 65496) {
            return
        }
        n = 2;
        o = Math.min(1048576, s.length);
        while (n <= o) {
            p = r.SHORT(n);
            if (p >= 65488 && p <= 65495) {
                n += 2;
                continue
            }
            if (p === 65498 || p === 65497) {
                break
            }
            q = r.SHORT(n + 2) + 2;
            if (u[p] && r.STRING(n + 4, u[p].signature.length) === u[p].signature) {
                t.push({hex: p, app: u[p].app.toUpperCase(), name: u[p].name.toUpperCase(), start: n, length: q, segment: r.SEGMENT(n, q)})
            }
            n += q
        }
        r.init(null);
        return{headers: t, restore: function(y) {
            r.init(y);
            var w = new f(y);
            if (!w.headers) {
                return false
            }
            for (var x = w.headers.length; x > 0; x--) {
                var z = w.headers[x - 1];
                r.SEGMENT(z.start, z.length, "")
            }
            w.purge();
            n = r.SHORT(2) == 65504 ? 4 + r.SHORT(4) : 2;
            for (var x = 0, v = t.length; x < v; x++) {
                r.SEGMENT(n, 0, t[x].segment);
                n += t[x].length
            }
            return r.SEGMENT()
        }, get: function(x) {
            var y = [];
            for (var w = 0, v = t.length; w < v; w++) {
                if (t[w].app === x.toUpperCase()) {
                    y.push(t[w].segment)
                }
            }
            return y
        }, set: function(y, x) {
            var z = [];
            if (typeof(x) === "string") {
                z.push(x)
            } else {
                z = x
            }
            for (var w = ii = 0, v = t.length; w < v; w++) {
                if (t[w].app === y.toUpperCase()) {
                    t[w].segment = z[ii];
                    t[w].length = z[ii].length;
                    ii++
                }
                if (ii >= z.length) {
                    break
                }
            }
        }, purge: function() {
            t = [];
            r.init(null)
        }}
    }

    function a() {
        var q, n, o = {}, t;
        q = new b();
        n = {tiff: {274: "Orientation", 34665: "ExifIFDPointer", 34853: "GPSInfoIFDPointer"}, exif: {36864: "ExifVersion", 40961: "ColorSpace", 40962: "PixelXDimension", 40963: "PixelYDimension", 36867: "DateTimeOriginal", 33434: "ExposureTime", 33437: "FNumber", 34855: "ISOSpeedRatings", 37377: "ShutterSpeedValue", 37378: "ApertureValue", 37383: "MeteringMode", 37384: "LightSource", 37385: "Flash", 41986: "ExposureMode", 41987: "WhiteBalance", 41990: "SceneCaptureType", 41988: "DigitalZoomRatio", 41992: "Contrast", 41993: "Saturation", 41994: "Sharpness"}, gps: {0: "GPSVersionID", 1: "GPSLatitudeRef", 2: "GPSLatitude", 3: "GPSLongitudeRef", 4: "GPSLongitude"}};
        t = {ColorSpace: {1: "sRGB", 0: "Uncalibrated"}, MeteringMode: {0: "Unknown", 1: "Average", 2: "CenterWeightedAverage", 3: "Spot", 4: "MultiSpot", 5: "Pattern", 6: "Partial", 255: "Other"}, LightSource: {1: "Daylight", 2: "Fliorescent", 3: "Tungsten", 4: "Flash", 9: "Fine weather", 10: "Cloudy weather", 11: "Shade", 12: "Daylight fluorescent (D 5700 - 7100K)", 13: "Day white fluorescent (N 4600 -5400K)", 14: "Cool white fluorescent (W 3900 - 4500K)", 15: "White fluorescent (WW 3200 - 3700K)", 17: "Standard light A", 18: "Standard light B", 19: "Standard light C", 20: "D55", 21: "D65", 22: "D75", 23: "D50", 24: "ISO studio tungsten", 255: "Other"}, Flash: {0: "Flash did not fire.", 1: "Flash fired.", 5: "Strobe return light not detected.", 7: "Strobe return light detected.", 9: "Flash fired, compulsory flash mode", 13: "Flash fired, compulsory flash mode, return light not detected", 15: "Flash fired, compulsory flash mode, return light detected", 16: "Flash did not fire, compulsory flash mode", 24: "Flash did not fire, auto mode", 25: "Flash fired, auto mode", 29: "Flash fired, auto mode, return light not detected", 31: "Flash fired, auto mode, return light detected", 32: "No flash function", 65: "Flash fired, red-eye reduction mode", 69: "Flash fired, red-eye reduction mode, return light not detected", 71: "Flash fired, red-eye reduction mode, return light detected", 73: "Flash fired, compulsory flash mode, red-eye reduction mode", 77: "Flash fired, compulsory flash mode, red-eye reduction mode, return light not detected", 79: "Flash fired, compulsory flash mode, red-eye reduction mode, return light detected", 89: "Flash fired, auto mode, red-eye reduction mode", 93: "Flash fired, auto mode, return light not detected, red-eye reduction mode", 95: "Flash fired, auto mode, return light detected, red-eye reduction mode"}, ExposureMode: {0: "Auto exposure", 1: "Manual exposure", 2: "Auto bracket"}, WhiteBalance: {0: "Auto white balance", 1: "Manual white balance"}, SceneCaptureType: {0: "Standard", 1: "Landscape", 2: "Portrait", 3: "Night scene"}, Contrast: {0: "Normal", 1: "Soft", 2: "Hard"}, Saturation: {0: "Normal", 1: "Low saturation", 2: "High saturation"}, Sharpness: {0: "Normal", 1: "Soft", 2: "Hard"}, GPSLatitudeRef: {N: "North latitude", S: "South latitude"}, GPSLongitudeRef: {E: "East longitude", W: "West longitude"}};
        function p(u, C) {
            var w = q.SHORT(u), z, F, G, B, A, v, x, D, E = [], y = {};
            for (z = 0; z < w; z++) {
                x = v = u + 12 * z + 2;
                G = C[q.SHORT(x)];
                if (G === e) {
                    continue
                }
                B = q.SHORT(x += 2);
                A = q.LONG(x += 2);
                x += 4;
                E = [];
                switch(B) {
                    case 1:
                    case 7:
                        if (A > 4) {
                            x = q.LONG(x) + o.tiffHeader
                        }
                        for (F = 0; F < A; F++) {
                            E[F] = q.BYTE(x + F)
                        }
                        break;
                    case 2:
                        if (A > 4) {
                            x = q.LONG(x) + o.tiffHeader
                        }
                        y[G] = q.STRING(x, A - 1);
                        continue;
                    case 3:
                        if (A > 2) {
                            x = q.LONG(x) + o.tiffHeader
                        }
                        for (F = 0; F < A; F++) {
                            E[F] = q.SHORT(x + F * 2)
                        }
                        break;
                    case 4:
                        if (A > 1) {
                            x = q.LONG(x) + o.tiffHeader
                        }
                        for (F = 0; F < A; F++) {
                            E[F] = q.LONG(x + F * 4)
                        }
                        break;
                    case 5:
                        x = q.LONG(x) + o.tiffHeader;
                        for (F = 0; F < A; F++) {
                            E[F] = q.LONG(x + F * 4) / q.LONG(x + F * 4 + 4)
                        }
                        break;
                    case 9:
                        x = q.LONG(x) + o.tiffHeader;
                        for (F = 0; F < A; F++) {
                            E[F] = q.SLONG(x + F * 4)
                        }
                        break;
                    case 10:
                        x = q.LONG(x) + o.tiffHeader;
                        for (F = 0; F < A; F++) {
                            E[F] = q.SLONG(x + F * 4) / q.SLONG(x + F * 4 + 4)
                        }
                        break;
                    default:
                        continue
                }
                D = (A == 1 ? E[0] : E);
                if (t.hasOwnProperty(G) && typeof D != "object") {
                    y[G] = t[G][D]
                } else {
                    y[G] = D
                }
            }
            return y
        }

        function s() {
            var v = e, u = o.tiffHeader;
            q.II(q.SHORT(u) == 18761);
            if (q.SHORT(u += 2) !== 42) {
                return false
            }
            o.IFD0 = o.tiffHeader + q.LONG(u += 2);
            v = p(o.IFD0, n.tiff);
            o.exifIFD = ("ExifIFDPointer" in v ? o.tiffHeader + v.ExifIFDPointer : e);
            o.gpsIFD = ("GPSInfoIFDPointer" in v ? o.tiffHeader + v.GPSInfoIFDPointer : e);
            return true
        }

        function r(w, u, z) {
            var B, y, x, A = 0;
            if (typeof(u) === "string") {
                var v = n[w.toLowerCase()];
                for (hex in v) {
                    if (v[hex] === u) {
                        u = hex;
                        break
                    }
                }
            }
            B = o[w.toLowerCase() + "IFD"];
            y = q.SHORT(B);
            for (i = 0; i < y; i++) {
                x = B + 12 * i + 2;
                if (q.SHORT(x) == u) {
                    A = x + 8;
                    break
                }
            }
            if (!A) {
                return false
            }
            q.LONG(A, z);
            return true
        }

        return{init: function(u) {
            o = {tiffHeader: 10};
            if (u === e || !u.length) {
                return false
            }
            q.init(u);
            if (q.SHORT(0) === 65505 && q.STRING(4, 5).toUpperCase() === "EXIF\0") {
                return s()
            }
            return false
        }, EXIF: function() {
            var v;
            v = p(o.exifIFD, n.exif);
            if (v.ExifVersion && j.typeOf(v.ExifVersion) === "array") {
                for (var w = 0, u = ""; w < v.ExifVersion.length; w++) {
                    u += String.fromCharCode(v.ExifVersion[w])
                }
                v.ExifVersion = u
            }
            return v
        }, GPS: function() {
            var u;
            u = p(o.gpsIFD, n.gps);
            if (u.GPSVersionID) {
                u.GPSVersionID = u.GPSVersionID.join(".")
            }
            return u
        }, setExif: function(u, v) {
            if (u !== "PixelXDimension" && u !== "PixelYDimension") {
                return false
            }
            return r("exif", u, v)
        }, getBinary: function() {
            return q.SEGMENT()
        }}
    }
})(window, document, plupload);