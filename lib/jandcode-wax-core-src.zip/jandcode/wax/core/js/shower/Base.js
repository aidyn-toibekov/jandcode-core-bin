/**
 * Предок для shower
 */
Ext.define('Jc.shower.Base', {

    constructor: function(config) {
        Ext.apply(this, config);
        this.onInit();
    },

    onInit: function() {
    },

    /**
     * Показать фрейм
     * @param fr фрейм
     */
    showFrame: function(fr, showConfig) {
    },

    /**
     * Закрыть фрейм
     * @param fr фрейм
     */
    closeFrame: function(fr) {
    },

    /**
     * Закрыть фрейм по id. Возвращает true, если нашел и закрыл
     */
    closeFrameById: function(id) {
        return false;
    },

    /**
     * Активировать фрейм. Возвращает фрейм, если активирован. Иначе - null
     * @param id id фрейма
     */
    activateFrame: function(id) {
        return null;
    },

    /**
     * Получить тип layout фрейма.
     * Возвращает:
     * 'fit' - фрейм имеет такой layout, что требует заполнение родительского окна.
     * К таким относятся: fit, vbox
     * 'nofit' - фрейм имеет такой layout, что он может как то гарантировать свой размер,
     * окно может под него подстраиваться
     * @param fr фрейм
     */
    getFrameLayoutType: function(fr) {
        if (Jc.isFitLayout(fr)) {
            return "fit";
        }
        return "nofit";
    }

});
 