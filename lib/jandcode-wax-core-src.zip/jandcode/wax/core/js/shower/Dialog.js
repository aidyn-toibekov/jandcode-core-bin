/**
 * Показ фреймов в виде диалога
 */
Ext.define('Jc.shower.Dialog', {
    extend: 'Jc.shower.BaseWindow',

    onWinCfg: function(wincfg, fr, showConfig) {
        //wincfg.x = 30000; // если поставить constrain: true, тогда x не сработает!
        wincfg.modal = true;
        wincfg.buttons = this.createButtons(showConfig);
        wincfg.cls = 'jc-dialog';
        wincfg.focusOnToFront = false;
        //todo fix 4.2: если в диалоге cbfrm всплыл и ткнуть в диалог, он становится верхним!!!
        wincfg.onMouseDown = function(e) {
            var preventFocus;

            if (this.floating) {
                if (Ext.fly(e.getTarget()).focusable()) {
                    preventFocus = true;
                }
                //this.toFront(preventFocus);  // убираем toFront!
            }
        };


    },

    ////// buttons

    createButtons: function(cfg) {
        return [this.createButtonOk(cfg), this.createButtonCancel(cfg)];
    },

    createButtonOk: function(cfg) {
        var text = UtLang.t("Ок");
        if (cfg.ok && cfg.ok.text) text = cfg.ok.text;
        return {
            iconCls: 'icon-ok',
            text: text,
            handler: function() {
                var win = this.up("window");
                var fr = win.items.get(0);
                fr.doClose("ok", cfg.onOk);
            }
        };
    },

    createButtonCancel: function(cfg) {
        var text = UtLang.t('Отмена');
        if (cfg.cancel && cfg.cancel.text) text = cfg.cancel.text;
        return {
            iconCls: 'icon-cancel',
            text: text,
            handler: function() {
                var win = this.up("window");
                var fr = win.items.get(0);
                fr.doClose("cancel");
            }
        };
    },

    createButtonClose: function(cfg) {
        var text = UtLang.t('Закрыть');
        if (cfg.cancel && cfg.cancel.text) text = cfg.cancel.text;
        return {
            iconCls: 'icon-cancel',
            text: text,
            handler: function() {
                var win = this.up("window");
                var fr = win.items.get(0);
                fr.doClose("cancel");
            }
        };
    }


});
 