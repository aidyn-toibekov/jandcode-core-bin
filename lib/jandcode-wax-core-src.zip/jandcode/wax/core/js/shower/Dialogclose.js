/**
 *
 */
Ext.define('Jc.shower.Dialogclose', {
    extend: 'Jc.shower.Dialog',

    createButtons: function(cfg) {
        return [this.createButtonClose(cfg)];
    }

});
 