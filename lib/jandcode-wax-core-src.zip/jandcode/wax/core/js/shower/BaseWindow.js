/**
 * Предок для shower-ов в окне
 */
Ext.define('Jc.shower.BaseWindow', {
    extend: 'Jc.shower.Base',

    /**
     * При true - окно будет maximized. showConfig может перекрыть это значение
     */
    maximized: false,

    showFrame: function(fr, showConfig) {
        var th = this;

        fr.header = false;
        //fr.autoScroll = false;

        var wincfg = {
            title: fr.title,
            //autoScroll: true,
            items: [fr],
            listeners: {
                show: function() {
                    fr.fireEvent("activate");
                }
            }
        };
        if (fr.showConfig.maximized === undefined) {
            fr.showConfig.maximized = th.maximized;
        }
        if (fr.showConfig.maximized) {
            wincfg.maximizable = true;
            wincfg.maximized = true;
        }
        var layType = th.getFrameLayoutType(fr);
        if (layType == "fit") {
            // фрейм желает заполнить все что можно. Начальный размер определяется фреймом
            //wincfg.autoScroll = false;
            wincfg.layout = {type: "fit"};
        }
        //wincfg.autoScroll = false;
        wincfg.layout = {type: "fit"};
        //
        if (!wincfg.title) {
            wincfg.title = '';
        }
        //
        if (fr.toolbar) {
            wincfg.tbar = Ext.create("Ext.toolbar.Toolbar", {
                items: fr.toolbar,
                itemId: 'frame-toolbar'
            });
            fr.toolbar = null;
        }
        //
        fr.on("titlechange", function(fr, tit) {
            win.setTitle(tit);
        });
        //
        fr.on("toolbarchange", function(fr) {
            th.createFrameToolbar(win, fr);
        });
        //
        fr.on('afterloadframe', function(fr, firstLoad) {
            th.onAfterLoadFrame(fr, firstLoad);
        });
        //
        fr.on('errorloadframe', function(fr, firstLoad) {
            if (firstLoad) {
                fr.close();
            }
        });
        //
        th.onWinCfg(wincfg, fr, showConfig);
        var win = Ext.create('Ext.window.Window', wincfg);
        win.show();
        if (!(fr instanceof Jc.frame.Gsp)) {
            if (!fr.showConfig.maximized) {
                Jc.fixWindowSize(win);
                win.center();
            }
        }
    },

    createFrameToolbar: function(win, fr) {
        var tb = win.getDockedComponent('frame-toolbar');
        if (!fr.toolbar) {
            if (tb) {
                tb.removeAll();
            }
        } else {
            if (!tb) {
                tb = Ext.create("Ext.toolbar.Toolbar", {
                    dock: 'top',
                    itemId: 'frame-toolbar',
                    items: fr.toolbar
                });
                win.addDocked(tb);
            } else {
                tb.removeAll();
                tb.add(fr.toolbar);
            }
            fr.toolbar = null;
        }
    },

    closeFrame: function(fr) {
        var win = fr.up("window");
        if (win) {
            win.close();
        }
    },

    onAfterLoadFrame: function(fr, firstLoad) {
        if (fr.showConfig.maximized) return;
        //
        var win = fr.up("window");
        if (!win) return;
        if (firstLoad) {
            if (fr.showerWidth) win.setWidth(fr.showerWidth);
            if (fr.showerHeight) win.setHeight(fr.showerHeight);
        }
        Jc.fixWindowSize(win);
        win.center();
    },

    onWinCfg: function(wincfg, fr, showConfig) {
    }

});
 