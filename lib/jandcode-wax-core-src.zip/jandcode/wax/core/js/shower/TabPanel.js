/**
 * Показ фрейма в закладках.
 */
Ext.define('Jc.shower.TabPanel', {

    extend: 'Jc.shower.Base',

    /**
     * Где показываем фреймы
     */
    tabPanel: null,

    /**
     * true - скрываться при удалении последней вкладки
     */
    autoHide: false,

    /**
     * Показывать ли заголовок фрейма на панели инструментов фрейма
     */
    titleOnToolbar: true,

    /**
     * Показывать ли (и обрабатывать) toolbar фрейма
     */
    showToolbar: true,

    /**
     * При значении true toolbar не показывается вообще, если его нет во фрейме
     */
    autoHideToolbar: false,

    /**
     * Показывать ли кнопку "закрыть" на toolbar
     */
    closeButtonOnToolbar: true,

    onInit: function() {
        var th = this;
        //
        if (this.autoHide) {
            this.tabPanel.on("remove", function() {
                if (th.tabPanel.items.getCount() == 0) {
                    th.tabPanel.hide();
                } else {
                    th.tabPanel.setActiveTab(th.tabPanel.items.getCount() - 1);
                }
            });
        }
    },

    showFrame: function(fr, showConfig) {
        var th = this;

        fr.header = false;

        if (th.tabPanel.isHidden()) {
            th.tabPanel.show();
        }

        if (th.showToolbar) {

            if (fr.toolbar || !th.autoHideToolbar) {
                th.createFrameToolbar(fr);
            }
            //
            fr.on("titlechange", function(fr, newTitle) {
                if (th.titleOnToolbar) {
                    var tb = fr.getDockedComponent('frame-toolbar');
                    if (tb) {
                        var t = tb.getComponent('frame-title');
                        if (t) {
                            t.setText(newTitle);
                        }
                    }
                }
            });
            //
            fr.on("toolbarchange", function(fr) {
                var tb = fr.getDockedComponent('frame-toolbar');
                if (tb) {
                    tb.removeAll();
                    tb.add(th.getFrameToolbarItems(fr));
                } else {
                    if (fr.toolbar) {
                        // ны было и появилось
                        th.createFrameToolbar(fr);
                    }
                }
            });
        }

        this.tabPanel.add(fr);
        this.tabPanel.setActiveTab(fr);

        //todo: FIX: 4.2 нет события activate для первого добавляемого фрейма
        if (this.tabPanel.items.getCount() == 1) {
            fr.fireEvent('activate');
        }

    },

    createFrameToolbar: function(fr) {
        var tb = Ext.create("Ext.toolbar.Toolbar", {
            minHeight: 26,  // если не поставить, то тулбар без action с картинкой маленький и fit под ней не работает верно
            dock: 'top',
            cls: 'jc-frametab-toolbar',
            itemId: 'frame-toolbar',
            items: this.getFrameToolbarItems(fr)
        });
        fr.addDocked(tb);
        return tb;
    },

    getFrameToolbarItems: function(fr) {
        var th = this;
        var items = [
        ];
        if (th.titleOnToolbar) {
            items.push(
              {xtype: 'tbtext', text: fr.title, cls: 'jc-frametab-title', itemId: 'frame-title'},
              '->'
            )
        }
        if (fr.toolbar) {
            items.push(fr.toolbar);
            fr.toolbar = null;
        }
        if (fr.closable && th.closeButtonOnToolbar) {
            if (th.titleOnToolbar) {
                items.push('-');
            } else {
                items.push('->');
            }
            items.push({xtype: 'splitbutton', iconCls: 'icon-shower-tab-close', tooltip: UtLang.t('Закрыть'), handler: function() {
                th.closeFrame(fr);
            }, menu: [
                {text: UtLang.t('Закрыть все, кроме этого'), iconCls: 'icon-shower-tab-close', handler: function() {
                    th.closeOtherFrame(fr);
                }},
                {text: UtLang.t('Закрыть все'), iconCls: 'icon-shower-tab-close', handler: function() {
                    th.closeAllFrame();
                }}
            ]});
        }
        return items;
    },

    closeOtherFrame: function(fr) {
        if (!fr) {
            fr = this.tabPanel.getActiveTab();
        }
        var a = [];
        this.tabPanel.items.each(function(z) {
            if (z != fr) a.push(z);
        });
        for (var i = 0; i < a.length; i++) {
            this.tabPanel.remove(a[i]);
        }
    },

    closeAllFrame: function() {
        this.tabPanel.removeAll();
    },

    closeFrame: function(fr) {
        this.tabPanel.remove(fr);
    },

    closeActiveFrame: function() {
        var fr = this.tabPanel.getActiveTab();
        if (fr) {
            this.closeFrame(fr);
        }
    },

    activateFrame: function(id) {
        var f = Ext.getCmp(id);
        if (f && f.ownerCt == this.tabPanel) {
            if (this.tabPanel.isHidden()) {
                this.tabPanel.show();
            }
            this.tabPanel.setActiveTab(f);
            return f;
        }
        return null;
    },

    closeFrameById: function(id) {
        var f = Ext.getCmp(id);
        if (f && f.ownerCt == this.tabPanel) {
            this.closeFrame(f);
            return true;
        }
        return false;
    }


});
 