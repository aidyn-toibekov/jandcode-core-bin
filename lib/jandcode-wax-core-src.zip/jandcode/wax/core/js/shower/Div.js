/**
 * Показ фрейма в div
 */
Ext.define('Jc.shower.Div', {
    extend: 'Jc.shower.Base',

    // id элемента для заголовка
    titleId: null,

    // id элемента для toolbar
    toolbarId: null,

    // id элемента для body
    bodyId: null,

    // при true поддерживается кнопка 'back' для закрытия фрейма
    historySupport: false,

    _stack: null,

    onInit: function() {
        var th = this;
        //
        th.titleEl = Ext.get(th.titleId);
        th.toolbarEl = Ext.get(th.toolbarId);
        th.bodyEl = Ext.get(th.bodyId);
        //
        th._stack = [];
        //
        if (th.historySupport) {
            Ext.History.on('change', function(token) {
                if (th._stack.length < 2) return;
                var fi = th._stack[th._stack.length - 1];
                if (fi.token == token) return; // это текущий
                //
                th.closeFrame(fi.frame);
            });
        }
    },

    showFrame: function(fr, showConfig) {
        var th = this;

        fr.header = false;

        var frInfo = {
            frame: fr,
            title: fr.title,
            toolbar: th.createFrameToolbar(fr),
            token: null
        };

        fr.on("titlechange", function(fr, newTitle) {
            th._updateTitle(newTitle);
        });

        fr.on("toolbarchange", function(fr) {
        });

        if (this._stack.length > 0) {
            // имеется текущий фрейм, убираем его временно
            var fi = this._stack[this._stack.length - 1];
            this._doHideFrame(fi);
        }
        if (th.historySupport) {
            if (this._stack.length > 0) {
                frInfo.token = fr.id;
                Ext.History.add(frInfo.token);
            }
        }

        this._stack.push(frInfo);
        this._updateTitle(frInfo.title);
        frInfo.toolbar.render(this.toolbarEl);
        this._prepareFrameSize(frInfo.frame);
        fr.render(this.bodyEl);
    },

    _doHideFrame: function(frInfo) {
        this._updateTitle("");
        frInfo.toolbar.hide();
        frInfo.frame.hide();
    },

    _doShowFrame: function(frInfo) {
        this._updateTitle(frInfo.title);
        frInfo.toolbar.show();
        this._prepareFrameSize(frInfo.frame);
        frInfo.frame.show();
    },

    _updateTitle: function(s) {
        this.titleEl.dom.innerHTML = s;
    },

    _prepareFrameSize: function(fr) {
        var layType = this.getFrameLayoutType(fr);
        if (layType == "fit") {
            // фрейм желает заполнить все что можно
            var bs = Ext.getBody().getViewSize();
            var newH = bs.height - this.bodyEl.getY() - this.bodyEl.getMargin("b") - 1;
            this.bodyEl.setHeight(newH);
            fr.setHeight(this.bodyEl.getHeight(true));
        } else {
            this.bodyEl.setHeight("auto");
        }
    },

    _findFrameInfo: function(fr) {
        for (var i = 0; i < this._stack.length; i++) {
            var fi = this._stack[i];
            if (fi.frame == fr) {
                return fi;
            }
        }
        return null;
    },

    createFrameToolbar: function(fr) {
        var tb = Ext.create("Ext.toolbar.Toolbar", {
            itemId: 'frame-toolbar',
            items: this.getFrameToolbarItems(fr)
        });
        return tb;
    },

    getFrameToolbarItems: function(fr) {
        var th = this;
        var items = [
            '->'
        ];
        if (fr.toolbar) {
            items.push(fr.toolbar);
            fr.toolbar = null;
        }
        if (fr.closable) {
            items.push('-');
            items.push({xtype: 'button', iconCls: 'icon-shower-tab-close', handler: function() {
                th.closeFrame(fr);
            }});
        }

        return items;
    },

    closeFrame: function(fr) {
        var fi = this._findFrameInfo(fr);
        if (!fi) return;
        if (this._stack.length < 2) {
            return; // ну и последний фрейм не закрываем
        }
        if (this._stack[this._stack.length - 1] != fi) {
            return; // закрыть можно только последний фрейм
        }
        Ext.Array.remove(this._stack, fi);
        this._doHideFrame(fi);
        if (this._stack.length > 0) {
            this._doShowFrame(this._stack[this._stack.length - 1]);
        }
    },

    activateFrame: function(id) {
        //not supported!
    },

    closeFrameById: function(id) {
        //not supported!
    }

});
 