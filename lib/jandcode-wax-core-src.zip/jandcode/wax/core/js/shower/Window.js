/**
 * Показ фреймов в виде обычного окна
 */
Ext.define('Jc.shower.Window', {
    extend: 'Jc.shower.BaseWindow'


});
 