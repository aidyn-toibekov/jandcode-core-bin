/**
 * Утилиты для построения фреймов.
 */
Ext.define('Jc.utils.UiBuilder', {

    /**
     * Какой фрейм строится
     */
    frame: null,

    /**
     * Какой store используется для построения
     */
    store: null,

    constructor: function(config) {
        Ext.apply(this, config);
    },

    getDataBinds: function() {
        return [this.frame];
    },

    ////// bindings

    /**
     * store по умолчанию для этого builder
     */
    getStore: function() {
        return Jc.dbm.DataBinder.getStore(this);
    },

    /**
     * model по умолчанию для этого builder
     */
    getModel: function() {
        return Jc.dbm.DataBinder.getModel(this);
    },

    //////

    /**
     * Создание экземпляра. Если создается для фрейма Gsp, то контролы
     * автоматически регистрируются.
     * @param cls класс или алиас виджета
     * @param config конфиг
     */
    create: function(cls, config) {
        try {
            var ob;
            if (cls.charAt(0) != cls.charAt(0).toUpperCase()) {
                // с маленькой буквы - виджет
                ob = Ext.widget(cls, config);
            } else {
                ob = Ext.create(cls, config);
            }
            if (ob instanceof Ext.Component && this.frame && this.frame instanceof Jc.frame.Gsp) {
                this.frame.addControl(ob);
            }
            return ob;
        } catch(e) {
            Jc.error(UtLang.t("Ошибка при создании экземпляра класса: {0}", cls) + " - " + Jc.errorCreate(e).toMsg())
        }
    },

    /**
     * Панель для организации вложенных панелей
     */
    box: function(config) {
        var cfg = Ext.apply({
            layout: {
                type: 'jctable'
            }
        }, config);
        return this.create("Jc.control.Box", cfg);
    },

    /**
     * Панель для организации информационных панелей с данными
     */
    databox: function(config) {
        var cfg = Ext.apply({
            cls: 'jc-databox',
            border: true,
            layout: {
                type: 'jctable',
                columns: 2
            }
        }, config);
        return this.create("Jc.control.Box", cfg);
    },

    /**
     * Обычная панель для организации вложенных панелей с toolbar и т.д.
     */
    panel: function(config) {
        var cfg = Ext.apply({
        }, config);
        return this.create("Jc.control.Panel", cfg);
    },

    /**
     * Обычная Tab-панель
     */
    tabpanel: function(config) {
        var cfg = Ext.apply({
        }, config);
        return this.create("Ext.tab.Panel", cfg);
    },

    //////

    /**
     * Заколовок для страницы
     * @param text текст
     * @param icon иконка
     * @param config
     */
    pageheader: function(text, icon, config) {
        var cfg = Ext.apply({
            text: text,
            icon: icon
        }, config);
        return this.create("Jc.control.PageHeader", cfg);
    },

    /**
     * Заголовок второго уровня для страницы
     * @param text
     * @param icon
     * @param config
     */
    pageheader2: function(text, icon, config) {
        var cfg = Ext.apply({
            text: text,
            icon: icon,
            iconType: '16'
        }, config);
        return this.create("Jc.control.PageHeader", cfg);
    },

    /**
     * Заколовок для фрейма. По умолчанию получает заголовок фрейма.
     */
    frameheader: function(config) {
        var cfg = Ext.apply({
            text: this.frame.title,
            icon: "docum",
            iconType: 32
        }, config);
        return this.create("Jc.control.PageHeader", cfg);
    },

    //////

    /**
     * Грида
     */
    grid: function(config) {
        var cfg = Ext.apply({
            store: this.getStore()
        }, config);
        return this.create("Jc.control.Grid", cfg);
    },

    //////

    /**
     * Tree
     */
    tree: function(config) {
        var cfg = Ext.apply({
        }, config);
        return this.create("Jc.control.Tree", cfg);
    },

    //////

    /**
     * Полный класс для компонента
     * @param group группа: input, datalabel, column ...
     * @param jsclass либо полный класс, либо имя класса в группе
     */
    _getCompCls: function(group, jsclass) {
        if (!jsclass) jsclass = "String";
        var a = jsclass.indexOf('.');
        if (a == -1) {
            jsclass = 'Jc.' + group + '.' + jsclass;
        }
        return jsclass;
    },

    /**
     * Для вызова такой функций с опциональным первым параметром store.
     * store становится на время вызова активным, остальные параметры - снова передаются
     * в функцию.
     * @param a arguments из вызываемой. Первый параметр должен быть store
     */
    _forStoreCall: function(a) {
        var saveStore = this.store;
        this.store = a[0];
        var args = Array.prototype.slice.call(a, 1);
        try {
            return a.callee.apply(this, args);
        } finally {
            this.store = saveStore;
        }
    },

    /**
     * Создать метку для поля ввода.
     * Первым параметром (до text) можно указать store, тогда оно станет активным на
     * время выполнения метода.
     * @param text текст метки
     * @param config конфигурация
     */
    label: function(text, config) {
        //
        if (Jc.dbm.DataBinder.isStore(text)) {
            return this._forStoreCall(arguments);
        }
        //
        var cfg = Ext.apply({
            text: text
        }, config);
        var ff = Jc.dbm.DataBinder.getField(this, text);
        if (ff) {
            cfg.text = ff.getTitle();
        }
        var z = this.create("Jc.control.Label", cfg);
        return z;
    },

    /**
     * Создать метку для показа данных
     * Первым параметром (до field) можно указать store, тогда оно станет активным на
     * время выполнения метода.
     * @param field имя поля или значение метки
     * @param config конфигурация
     */
    datalabel: function(field, config) {
        //
        if (Jc.dbm.DataBinder.isStore(field)) {
            return this._forStoreCall(arguments);
        }
        //
        var cfg = Ext.apply({
            field: field
        }, config);
        //

        // field
        if (!cfg.dataIndex) {
            if (cfg.field) {
                cfg.dataIndex = cfg.field;
            }
        }

        var ff = Jc.dbm.DataBinder.getField(this, cfg.dataIndex);
        if (!ff) {
            if (cfg.value === undefined && field) {
                cfg.value = field;  // нет поля - значение явное
            }
            delete cfg.dataIndex;
        } else {
            Ext.applyIf(cfg, ff.datalabel);
        }

        //
        cfg.jcstore = this.getStore();

        var jsclass = this._getCompCls('datalabel', cfg.jsclass);
        //
        delete cfg.field;
        return this.create(jsclass, cfg);
    },

    /**
     * Колонка гриды
     * @param field имя поля
     * @param config конфигурация
     */
    column: function(field, config) {
        var cfg = Ext.apply({
            field: field
        }, config);

        // field
        if (!cfg.dataIndex) {
            if (cfg.field) {
                cfg.dataIndex = cfg.field;
            }
        }
        delete cfg.field;

        // title & width для поля домена (если оно есть)
        var ff = Jc.dbm.DataBinder.getField(this, cfg.dataIndex);
        if (ff) {
            Ext.applyIf(cfg, ff.column);
        }

        // строковую ширину преобразуем в число
        cfg.width = Jc.toInt(cfg.width);
        if (cfg.width == 0) delete cfg.width;

        if (ff) {
            if (!cfg.title) {
                cfg.title = ff.getTitleShort();
            }
            if (!cfg.width && !cfg.flex) {
                if (ff.size > 0) {
                    var sz = ff.size;
                    if (cfg.title.length > sz) sz = cfg.title.length;
                    if (sz > 30) sz = 30;
                    cfg.width = sz * Jc.ini.charWidth;
                }
            }
        }

        if (!cfg.flex && !cfg.width) cfg.width = 10 * Jc.ini.charWidth;

        if (cfg.title) {
            cfg.text = cfg.title;
        }

        delete cfg.title;
        //
        var jsclass = this._getCompCls('column', cfg.jsclass);
        //
        return this.create(jsclass, cfg);
    },

    /**
     * Поле ввода.
     * Первым параметром (до field) можно указать store, тогда оно станет активным на
     * время выполнения метода.
     * @param field имя поля
     * @param config конфигурация
     */
    input: function(field, config) {
        //
        if (Jc.dbm.DataBinder.isStore(field)) {
            return this._forStoreCall(arguments);
        }
        //
        var cfg = Ext.apply({
            field: field
        }, config);

        // field
        if (!cfg.dataIndex) {
            if (cfg.field) {
                cfg.dataIndex = cfg.field;
            }
        }
        delete cfg.field;

        // title & width
        var ff = Jc.dbm.DataBinder.getField(this, cfg.dataIndex);
        if (ff) {
            Ext.applyIf(cfg, ff.input);
            //
            if (!cfg.width) {
                if (ff.size > 20) {
                    cfg.width = 'large';
                } else {
                    cfg.width = 'medium';
                }
            }
        }

        //
        if (cfg.width) {
            var w1 = Jc.ini.inputWidth[cfg.width];
            if (w1 !== undefined) {
                cfg.width = w1;
            }
        }

        //
        cfg.jcstore = this.getStore();

        //
        var jsclass = this._getCompCls('input', cfg.jsclass);
        //
        return this.create(jsclass, cfg);
    },

    /**
     * Создать метку и поле ввода
     */
    input2: function(field, configInput, configLabel) {
        //
        if (Jc.dbm.DataBinder.isStore(field)) {
            return this._forStoreCall(arguments);
        }
        //
        return [
            this.label(field, configLabel),
            this.input(field, configInput)
        ]
    },

    /**
     * Создать метку и datalabel
     */
    datalabel2: function(field, configDatalabel, configLabel) {
        //
        if (Jc.dbm.DataBinder.isStore(field)) {
            return this._forStoreCall(arguments);
        }
        //
        return [
            this.label(field, configLabel),
            this.datalabel(field, configDatalabel)
        ]
    },

    /**
     * Разделитель. Линия с текстом
     */
    delim: function(title, config) {
        var cfg = Ext.apply({
            title: title,
            colspan: 2
        }, config);
        return this.create("Jc.control.Delim", cfg);
    },

    ////// action

    /**
     * Создать Jc.Action.
     * Если scope не указан, то по умолчанию берется фрейм (если он указан)
     */
    action: function(config) {
        var cfg = Ext.apply({}, config);
        if (!cfg.scope && this.frame) cfg.scope = this.frame;
        return Jc.action(cfg);
    },

    /**
     * Создать Jc.ActionGrid.
     * Такая action используется в гриде. Знает про свою гриду.
     * Если запись не выделена, вызов игнорируется.
     * В onExec доступны:
     * a.grid - грида
     * Если scope не указан, то по умолчанию берется фрейм (если он указан)
     */
    actionGrid: function(config) {
        var cfg = Ext.apply({}, config);
        if (!cfg.scope && this.frame) cfg.scope = this.frame;
        return Ext.create("Jc.ActionGrid", cfg);
    },

    /**
     * Создать Jc.ActionRec.
     * Такая action используется в гриде. Знает про текущую запись.
     * Если запись не выделена, вызов игнорируется.
     * В onExec доступны:
     * a.grid - грида
     * a.rec - текущая запись
     * a.recId - id текущей записи
     * Если scope не указан, то по умолчанию берется фрейм (если он указан)
     */
    actionRec: function(config) {
        var cfg = Ext.apply({}, config);
        if (!cfg.scope && this.frame) cfg.scope = this.frame;
        return Ext.create("Jc.ActionRec", cfg);
    },

    /**
     * Создать action "Добавить"
     */
    actionIns: function(config) {
        var cfg = Ext.apply({}, config);
        Ext.applyIf(cfg, {text: Jc.msg.ins, icon: "ins"});
        return this.actionGrid(cfg);
    },

    /**
     * Создать action "Изменить"
     */
    actionUpd: function(config) {
        var cfg = Ext.apply({}, config);
        Ext.applyIf(cfg, {text: Jc.msg.upd, icon: "upd"});
        return this.actionRec(cfg);
    },

    /**
     * Создать action "Удалить"
     */
    actionDel: function(config) {
        var cfg = Ext.apply({}, config);
        Ext.applyIf(cfg, {text: Jc.msg.del, icon: "del"});
        return this.actionRec(cfg);
    },

    ////// complex actions

    /**
     * Создать action "Добавить".
     * Показывает фрейм для добавления записи, после этого добавляет запись в гриду.
     * @param config
     * @param config.frame фрейм. see: Jc.showFrame
     * @param config.onBeforeShow(a) - если функция определена, то она вызываается
     * до показа окна для формирования данных по умолчанию (a.recData)
     */
    actionInsFrame: function(config) {
        var cfg = Ext.apply({}, config);
        Ext.applyIf(cfg, {
            text: Jc.msg.ins,
            icon: "ins",
            onExec: function(a) {
                if (!a.recData) {
                    a.recData = {};
                }
                if (a.onBeforeShow) {
                    a.onBeforeShow(a);
                }
                Jc.showFrame({frame: a.frame, recData: a.recData, onOk: function(fr) {
                    a.grid.insRec(fr.store);
                }});
            }
        });
        return this.actionGrid(cfg);
    },

    /**
     * Создать action "Изменить".
     * Показывает фрейм для редактирования записи, после этого изменяет запись в гриде.
     * @param config
     * @param config.frame фрейм. see: Jc.showFrame
     * @param config.onBeforeShow(a) - если функция определена, то она вызываается
     * до показа окна для формирования данных по умолчанию (a.recData)
     */
    actionUpdFrame: function(config) {
        var cfg = Ext.apply({}, config);
        Ext.applyIf(cfg, {
            text: Jc.msg.upd,
            icon: "upd",
            onExec: function(a) {
                if (!a.recData) {
                    a.recData = {};
                }
                if (a.onBeforeShow) {
                    a.onBeforeShow(a);
                }
                Jc.showFrame({frame: a.frame, recId: a.recId, recData: a.recData, onOk: function(fr) {
                    a.grid.updRec(fr.store);
                }});
            }
        });
        return this.actionRec(cfg);
    },

    /**
     * Создать action "Удалить".
     * Показывает окно фрейм для редактирования записи, после этого изменяет запись в гриде.
     * @param config
     * @param config.daoname - каким dao удалять запись
     * @param config.daomethod - каким dao-методом удалять запись. По умолчанию - 'del'
     */
    actionDelFrame: function(config) {
        var cfg = Ext.apply({}, config);
        Ext.applyIf(cfg, {
            text: Jc.msg.del,
            icon: "del",
            onExec: function(a) {
                Jc.showFrame({frame: 'Jc.frame.DelRec', recId: a.recId,
                    daoname: a.daoname, daomethod: a.daomethod,
                    onOk: function(fr) {
                        a.grid.delRec();
                    }
                });
            }
        });
        return this.actionRec(cfg);
    },

    /**
     * Создать action "Просмотр".
     * Показывает фрейм для просмотра записи по id.
     * @param config
     * @param config.frame фрейм. see: Jc.showFrame
     */
    actionViewFrame: function(config) {
        var cfg = Ext.apply({}, config);
        Ext.applyIf(cfg, {
            text: Jc.msg.view,
            icon: "view",
            onExec: function(a) {
                Jc.showFrame({frame: a.frame, recId: a.recId, id: a.frame, replace: true});
            }
        });
        return this.actionRec(cfg);
    },

    ////// domain controls

    /**
     * Создать control для домена
     * @param controlType тип (например frame, grid...)
     * @param controlName имя контрола внутри типа
     * @param config дополнительная конфигурация
     */
    _create_domain_control: function(controlType, controlName, config) {
        var domain = Jc.dbm.DataBinder.getDomain(this);
        if (!domain) {
            throw new Error(UtLang.t("builder не может выявить связанный домен"));
        }
        var ctConfig = domain[controlType];
        if (!ctConfig) {
            throw new Error(UtLang.t("Для домена не определен объект {0}", controlType));
        }
        var cfgFromDomain = ctConfig[controlName];
        if (!cfgFromDomain) {
            throw new Error(UtLang.t("Для домена не определен объект {0}/{1}", controlType, controlName));
        }
        //
        var cfg = Ext.apply({
            _defaultDomain: domain
        }, cfgFromDomain);
        Ext.apply(cfg, config);
        //
        var jsclass = cfg.jsclass;
        if (!jsclass) {
            throw new Error(UtLang.t("В объекте {0}/{1} не определен jsclass", controlType, controlName));
        }
        return Ext.create(jsclass, cfg);
    },

    /**
     * Создать фрейм для домена. Конфигурация по умолчанию
     * берется из domain.frame[frameName]
     */
    createDomainFrame: function(frameName, config) {
        return this._create_domain_control("frame", frameName, config);
    },

    ////// button

    /**
     * Создать кнопку
     * @param actionConfig конфигурация action, на основе которой создается кнопка.
     * Может быть как экземпляром Ext.Action, так и конфигурацией для создания Jc.Action
     */
    button: function(actionConfig) {
        var act;
        if (actionConfig instanceof Ext.Action) {
            act = actionConfig;
        } else {
            act = this.action(actionConfig);
        }
        return this.create("Ext.Button", act);
    },

    ////// icon

    /**
     * Создать иконку.
     * По умолчанию iconType='32'
     * @param iconName имя иконки
     * @param config конфигурация icon
     */
    icon: function(iconName, config) {
        var cfg = Ext.apply({
            icon: iconName,
            iconType: '32'
        }, config);
        return this.create("Jc.control.Icon", cfg);
    },

    ////// html

    /**
     * Создать html-текст
     */
    html: function(text, config) {
        var cfg = Ext.apply({
            html: text
        }, config);
        return this.create("Ext.Component", cfg);
    },

    //////

    /**
     * Создание колонок для гриды. Возвращает массив колонок для полей visible=true.
     */
    columnsVisible: function() {
        var domain = Jc.dbm.DataBinder.getDomain(this);
        var cols = [];
        for (var i = 0; i < domain.fields.length; i++) {
            var f = domain.fields[i];
            if (!f.visible) continue;
            cols.push(this.column(domain.fields[i].name));
        }
        return cols;
    },

    /**
     * Создание полей ввода для формы. Возвращает массив созданный через input2
     * для полей editable=true.
     */
    inputsEditable: function() {
        var domain = Jc.dbm.DataBinder.getDomain(this);
        var items = [];
        for (var i = 0; i < domain.fields.length; i++) {
            var f = domain.fields[i];
            if (!f.editable) continue;
            items.push(this.input2(domain.fields[i].name));
        }
        return items;
    },

    //////

    /**
     * Создание paging-toolbar для пагинации гриды.
     * Пример:
     *
     * b.grid({
     *   columns: [
     *      b.column("id")
     *   ]
     *   bbar: b.paging()
     * })
     *
     * @param config
     */
    paging: function(config) {
        var cfg = Ext.apply({
            store: this.getStore(),
            displayInfo: true
        }, config);
        return this.create("Ext.toolbar.Paging", cfg);
    },

    /**
     * Из объекта th берем свойство name. Если его нет - создаем новое {} и возвращаем его.
     * @param th откуда
     * @param name какое свойства
     */
    getConfig: function(th, name) {
        var a = th[name];
        if (!a) {
            a = {};
            th[name] = a;
        }
        return a;
    },

    /**
     * Из объекта th берем свойство name. Если его нет - создаем новое [] и возвращаем его.
     * @param th откуда
     * @param name какое свойства
     */
    getArray: function(th, name) {
        var a = th[name];
        if (!a) {
            a = [];
            th[name] = a;
        }
        return a;
    },

    /**
     * Создать store
     * @param domainName
     * @param config
     * @return {*}
     */
    createStore: function(domainName, config) {
        return this.getModel().createStore(domainName, config);
    },

    /**
     * Создать tree store
     * @param domainName
     * @param config
     * @return {*}
     */
    createTreeStore: function(domainName, config) {
        return this.getModel().createTreeStore(domainName, config);
    },

    layout: function(name, config) {
        var v;
        var cfg = Ext.apply({}, config);

        if (name == 'autobox') {
            v = {
                type: 'jcauto',
                defaultMargins: {top: 0, right: 0, bottom: 4, left: 0}
            };
            Ext.apply(v, cfg);

        } else if (name == 'hbox') {
            v = {
                type: 'hbox',
                align: 'stretchmax',
                defaultMargins: {top: 0, right: 4, bottom: 0, left: 0}
            };
            Ext.apply(v, cfg);

        } else if (name == 'vbox') {
            v = {
                type: 'vbox',
                align: 'stretch',
                defaultMargins: {top: 0, right: 0, bottom: 4, left: 0}
            };
            Ext.apply(v, cfg);

        } else if (name == 'table') {
            v = {
                type: 'jctable',
                columns: 2
            };
            Ext.apply(v, cfg);

        } else if (name == 'fit') {
            v = {
                type: 'fit'
            };
            Ext.apply(v, cfg);

        } else if (name == 'border') {
            v = {
                type: 'border'
            };
            Ext.apply(v, cfg);

        }
        if (!v) {
            Jc.error("Не найден layout " + name);
        }
        return v;
    },

    /**
     * Создание SGrid
     */
    sgrid: function(config) {
        var cfg = Ext.apply({
        }, config);
        return this.create("Jc.control.SGrid", cfg);
    },

    /**
     * Создание STree
     */
    stree: function(config) {
        var cfg = Ext.apply({
        }, config);
        return this.create("Jc.control.STree", cfg);
    },

    /**
     * Создание GfPanel
     */
    gfpanel: function(config) {
        var cfg = Ext.apply({
        }, config);
        return this.create("Jc.frame.GfPanel", cfg);
    }


});

