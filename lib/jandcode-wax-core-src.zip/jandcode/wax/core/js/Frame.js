/**
 * Предок для фреймов ui
 */
Ext.define('Jc.Frame', {
    extend: 'Ext.panel.Panel',

    _data_loaded: false,
    _loadData_first: true,

    /**
     * Конфигурация для показа фрейма по умолчанию.
     * После показа фрейма содержит дополнительно то, что было передано в методе
     * showFrame
     */
    showConfig: null,


    constructor: function(config) {
        var cfg = Ext.apply({
            cls: 'jc-frame',
            bodyCls: 'jc-frame-body',
            layout: 'auto',
            autoScroll: true,
            border: false,
            closable: true,

            // for app
            shower: 'main'
        }, config);
        //
        this.onInitConfig(cfg);
        this.callParent([cfg]);
        //
        this.on("activate", this._onActivate);
    },

    initComponent: function() {
        this.addEvents("toolbarchange", "choice");
        this.onInit();
        this.callParent(arguments);
        this.onInitAfter();
    },

    ////// for override

    /**
     * Вызывается из конструктора для модификации cfg, который будет использоваться для
     * создания фрейма
     * @param cfg конфигурация фрейма
     */
    onInitConfig: function(cfg) {
    },

    /**
     * Вызывается перед initComponent для настройки this. Компонент еще не создан.
     */
    onInit: function() {
    },

    /**
     * Вызывается после initComponent для настройки this. Компонент уже создан.
     */
    onInitAfter: function() {
    },

    /**
     * Загрузка данных фрейма. dataToControl вызывается автоматически, после
     * выполнения loadData.
     */
    onLoadData: function() {
    },

    /**
     * Вызывается при показе фрейма. Только один раз.
     * Вызывается после loadData. Для перекрытия.
     */
    onShowFrame: function() {
    },

    /**
     * Функция, которая отрабатывает, когда в диалоге нажата ok. Если
     * возвращает false, диалог не закрывается.
     */
    onOk: null,

    ////// activate

    /**
     * Функция вызывается при первой активации фрейма
     */
    _onActivate: function() {
        this.un("activate", this._onActivate); // только один раз!
        if (this._data_loaded) {
            this.dataToControl(); //todo - не факт...
        } else {
            this.loadData();
        }

        // onShowFrame для каждого, кто это поддерживает
        Jc.eachChild(this, function(z) {
            if (z.onShowFrame) {
                z.onShowFrame();
            }
        });

        this.onShowFrame();
        this.focusFirst();
    },

    /**
     * Ставит фокус на первый компонент, который поддерживает focus.
     * Если у компонента свойство isFocusable===false, такие пропускаются.
     * Если у компонента есть функция onFocusComp, то вызывается она.
     * Иначе вызывается focus() для компонента.
     */
    focusFirst: function() {
        var th = this;
        Jc.eachChild(this, function(z) {
            if (th.focusComp(z)) {
                return false; // дальше не ищем
            }
        }, true);
    },

    /**
     * Установить фокус на указанный компонент.
     * Возвращает false, если компонент не может быть сфокусированным (например это label)
     */
    focusComp: function(comp) {
        if (comp.isFocusable === false) return false; // он не может
        if (Ext.isFunction(comp.onFocusComp)) {
            comp.onFocusComp();
            return true;
        }
        if (Ext.isFunction(comp.focus)) {
            comp.focus(false, 50);
            return true;
        }
        return false;
    },

    ////// data

    /**
     * Загрузка данных во фрейм. Вызывается автоматом после того, как фрейм будет
     * показан. Возможно вызывать только один раз. Для повторной загрузки
     * используем reloadData
     */
    loadData: function() {
        if (this._data_loaded) {
            return;
        }
        this._loadData_work = true;
        try {
            this.onLoadData();
            this.dataToControl();
            this._loadData_work = false;
            this._loadData_first = false;
        } catch(e) {
            this._loadData_work = false;
            Jc.error(e);
        }
        this._data_loaded = true;
    },

    /**
     * Возвращает true, если сейчас работает loadData
     */
    isLoadData: function() {
        return this._loadData_work === true;
    },

    /**
     * Возвращает true, если сейчас работает первый loadData
     */
    isLoadDataFirst: function() {
        return this.isLoadData() && this._loadData_first === true;
    },

    /**
     * Безусловный вызов loadData
     */
    reloadData: function() {
        this._data_loaded = false;
        this.loadData();
    },

    dataToControl: function() {
        Jc.dataToControlChilds(this);
        //todo нигде не мешается?
        this.doLayout();  // без этого диалоги не подгоняют свой размер под длинные label!
    },

    controlToData: function() {
        Jc.controlToDataChilds(this);
    },

    ////// show

    /**
     * Показать фрейм
     * @param showConfig параметры показа
     */
    showFrame: function(showConfig) {
        return Jc.app.showFrame(this, showConfig);
    },

    /**
     * Показать фрейм как диалог
     * @param showConfig параметры показа
     */
    showDialog: function(showConfig) {
        var cfg = Ext.apply({
            shower: 'dialog'
        }, showConfig);
        this.showFrame(cfg);
    },

    /**
     * Закрыть фрейм безусловно
     */
    closeFrame: function() {
        return Jc.app.closeFrame(this);
    },

    /**
     * Возвращает content-control. Тот control, который является фреймом с точки зрения
     * внешних компонентов. Обычный фрейм возвращает себя, другие могут возвращать
     * внутренние компоненты.
     */
    getContentControl: function() {
        return this;
    },

    /**
     * Выполнить попытку закрытия фрейма с указанной командой cm (например 'ok', 'cancel')
     * Фрейм делает все необходимые действия по закрытию, включая физическое закрытие.
     * После того, как фрейм окончательно закрылся, он вызывает функцию afterCloseFunc.
     *
     * doClose - асинхронная функция!
     *
     * @param cm команда закрытия (строка)
     * @param afterCloseFunc callBack функция, вызывается после окончательного закрытия фрейма
     */
    doClose: function(cm, afterCloseFunc) {
        var th = this;

        var endProcess = function() {
            if (afterCloseFunc) {
                try {
                    afterCloseFunc(th.getContentControl());
                } catch(e) {
                    // даже если возникла ошибка в afterCloseFunc (а это внешний onOk) все равно закрываем
                    Jc.error(e, false);
                }
            }
            th.closeFrame();
        };

        try {
            var res;
            if (cm == 'ok') {

                var upfs = [];
                this.grabUploadFields(upfs);
                if (upfs.length == 0) {
                    // нет upload полей
                    if (this.onOk) {
                        res = this.onOk();
                        if (res === false) return;
                    }
                    endProcess();
                } else {
                    // есть upload поля!
                    Jc.requestUpload(upfs, {
                        onOk: function() {
                            // нет upload полей
                            if (th.onOk) {
                                res = th.onOk();
                                if (res === false) return;
                            }
                            endProcess();
                        }
                    })
                }

            } else {
                endProcess();
            }
        } catch(e) {
            if (this.handleError) {
                this.handleError(e);
            } else {
                Jc.error(e);
            }
        }
    },

    ////// utils

    /**
     * Создание Jc.utils.UiBuilder
     * В качестве параметра config может быть передан домен или store.
     * Фрейм сохраняется в builder в свойстве frame
     */
    createBuilder: function(config) {
        var b = Jc.app.createBuilder(config);
        b.frame = this;
        return b;
    },

    /**
     * Обработка ошибки на форме
     * @param e ошибка
     */
    handleError: function(e) {
        var ee = Jc.errorCreate(e);
        var fr = ee.toMsgByFields();
        try {
            Jc.eachChild(this, function(z) {
                var msg = fr[z.dataIndex];
                if (!msg) msg = fr[z.name];
                if (msg && z.markInvalid) {
                    z.markInvalid(msg);
                }
            });
        } finally {
            Jc.error(ee);
        }
    },

    /**
     * Метод вызывает событие 'choice' с указанными параметрами.
     * Используется в формах, которые выбирают значения (например в Cbfrm).
     * @param value какое значение выбрано
     * @param text текст значения, если приемник не сможет преобразовать его в текст
     * если не указано, принимается равным value
     */
    choice: function(value, text) {
        if (!text) text = value;
        this.fireEvent("choice", this, value, text);
    },

    /**
     * Устанавливает значение, которое должно быть выбрано во фрейме.
     * Вызывается в Cbfrm.
     * @param value текущее значение в Cbfrm
     * @param inpText текст, который введен в Cbfrm. Обычно один символ.
     */
    setChoiceValue: function(value, inpText) {
        this.onSetChoiceValue(value, inpText);
    },

    /**
     * Реакция на setChoiceValue
     */
    onSetChoiceValue: function(value, inpText) {
    },

    ////// upload

    /**
     * Сбор upload полей
     * @param upfs куда собирать (массив)
     */
    grabUploadFields: function(upfs) {
        Jc.eachChild(this, function(z) {
            if (z.isUploadSupport) {
                z.grabUploadFields(upfs);
            }
        });
    }


});
