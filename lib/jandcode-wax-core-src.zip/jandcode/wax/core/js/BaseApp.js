/**
 * Предок для приложения.
 * Экземпляр приложения будет доступен через Jc.app после создания через Jc.createApp.
 * Создать можно только одно приложение.
 */
Ext.define('Jc.BaseApp', {

    /**
     * Экземпляр темы
     */
    theme: null,

    /**
     * Класс для создания в методе createBuilder
     */
    uiBuilderClass: 'Jc.utils.UiBuilder',


    constructor: function(config) {
        if (Jc.app) {
            throw new Error("Only one app can be created");
        }
        Jc.app = this;
        //
        Ext.apply(Jc.app, config);
        // создаем тему
        Ext.syncRequire(Jc.ini.app.themeClass);
        Jc.app.theme = Ext.create(Jc.ini.app.themeClass);
        // инициализируем глобальные аспекты темы
        Jc.app.theme.initGlobal();
        // остальное в onReady
        Ext.onReady(function() {
            Jc.app.init();
        });
    },

    init: function() {
        this.onInit();
        // инициализируем тему после инициализации приложения, возможно ее поправили
        this.theme.init();
        // init можно перекрыть для изменения уже проинициализированной темы
    },

    /**
     * Инициалиазация приложения. ui еще не создано! Для инициализации после создания
     * ui, перекрывайте метод init
     */
    onInit: function() {
    },

    //////

    /**
     * Показать фрейм
     * @param fr экземпляр фрейма Jc.Frame
     */
    showFrame: function(fr, showConfig) {
        return this.theme.showFrame(fr, showConfig);
    },

    /**
     * Показать фрейм в режиме single (если такой фрейм уже существует, он активируется,
     * иначе создается и показывается)
     * @param frameClass класс фрейма
     * @param frameConfig конфиг фрейма для создания. Если нет id, то принимается равным
     * имени класса, если есть - добавляется к имени класса через '--'.
     * @param showConfig конфигурация для shower
     */
    showFrameSingle: function(frameClass, frameConfig, showConfig) {
        var id = frameClass;
        var fConfig = Ext.apply({}, frameConfig);
        if (fConfig.id) {
            id = id + "--" + fConfig.id
        }
        if (!this.activateFrame(id)) {
            fConfig.id = id;
            var f = Ext.create(frameClass, fConfig);
            f.showFrame(showConfig);
        }
    },

    /**
     * Показать фрейм домена в режиме single (если такой фрейм уже существует, он активируется,
     * иначе создается и показывается)
     * @param domainName имя домена
     * @param frameName имя фрейма
     * @param frameConfig конфиг фрейма для создания. Если нет id, то принимается равным
     * имени домена+имя фрейма, если есть - добавляется к имени класса через '--'.
     * @param showConfig конфигурация для shower
     */
    showDomainFrameSingle: function(domainName, frameName, frameConfig, showConfig) {
        var id = domainName + "--" + frameName;
        var fConfig = Ext.apply({}, frameConfig);
        if (fConfig.id) {
            id = id + "--" + fConfig.id
        }
        if (!this.activateFrame(id)) {
            fConfig.id = id;
            var f = Jc.createDomainFrame(domainName, frameName, fConfig);
            f.showFrame(showConfig);
        }
    },

    /**
     * Закрыть фрейм безусловно
     * @param fr экземпляр фрейма Jc.Frame
     */
    closeFrame: function(fr) {
        return this.theme.closeFrame(fr);
    },

    /**
     * Активировать фрейм по id, если есть.
     * Возвращает активированный фрейм, если активирован, либо null, если фрейма нет.
     */
    activateFrame: function(id) {
        return this.theme.activateFrame(id);
    },

    /**
     * Возвращает фрейм, которому принадлежит указанный control.
     * @param control
     */
    getFrame: function(control) {
        if (!control) return null;
        var own = control.ownerCt;
        while (true) {
            if (!own) return null;
            if (own instanceof Jc.Frame) return own;
            own = own.ownerCt;
        }
    },

    //////

    showWait: function(control, force) {
        return this.theme.showWait(control, force);
    },

    hideWait: function() {
        return this.theme.hideWait();
    },

    hideWaitForce: function() {
        return this.theme.hideWaitForce();
    },

    getShowWaitControl: function() {
        return this.theme.getShowWaitControl();
    },

    //////

    /**
     * Создать экземпляр Jc.utils.UiBuilder
     * В качестве параметра config может быть передан домен или store.
     */
    createBuilder: function(config) {
        if (Ext.isString(config)) config = Jc.model.getDomain(config);
        if (Jc.dbm.DataBinder.isDomain(config)) config = {domain: config};
        if (Jc.dbm.DataBinder.isStore(config)) config = {store: config};
        var cfg = Ext.apply({
        }, config);
        return Ext.create(this.uiBuilderClass, cfg);
    },

    //////

    /**
     * Показать фрейм home
     */
    home: function() {
    },

    /**
     * Создание главного меню. Можно учитывать тему или пользователя, если нужно
     */
    createMainMenu: function() {
        return [
            {text: 'MainMenu'}
        ]
    },

    /**
     * Создание меню для ControlPanel. Можно учитывать пользователя, если нужно
     */
    createControlPanelMenu: function() {
        return [
            {text: 'ControlPanel'}
        ]
    },

    ////// new frame api

    /**
     * Показать фрейм
     *
     * @param config Конфигурация фрейма
     *
     * @param config.frame фрейм. Может быть именем класса или url.
     * Если заканчивается на '.html', то предполагается что заказывается
     * gsp-фрейм (Jc.frame.Gsp). В этом случае config.frame считается загружаемым телом фрейма.
     * Если заканчивается на '.gframe', то предполагается, что заказывается gframe.
     * В тексте javascript должен быть вызов метода TH.create(BASEFRAME, CONFIG)
     * Если заканчивается на '.gf', то предполагается что заказывается gf-фрейм.
     * В этом случае все атрибуты конфигурации, кроме системных (id, функции, shower ...)
     * передаются в запросе на сервер. В атрибуте local - то, что будет присвоено
     * свойствам контента в момент создания.
     * @param config.shower каким shower показывать. По умолчанию тот, который установлен во
     * фрейме ('main', если явно не задан)
     * @param config.onOk функция, которая вызовется в диалоговом окне после того, как
     * в нем будет нажата кнопка 'ok' и оно закроется. В качестве параметра получает фрейм.
     * @param config.id id фрейма. Глобально уникальный. Если уже существует фрейм с таким
     * id, то он активируется и вызов игнорируется. Если в качестве значения задано 'true',
     * то в качестве id принимается config.frame
     * @param config.replace При значении true если фрейм с id существует, то он заменяется
     * на новый
     * @param config.params параметры для gsp-фрейма
     * @param config.onShowFrame функция с параметрами (f,showConfig). Если задана,
     * то вызывается вместо показа фрейма. Если не задана - то фрейм показывается
     * самостоятельно
     *
     */
    newapi_showFrame: function(config) {
        var th = this;
        var f;
        var cfg = Ext.apply({}, config);
        var frame = cfg.frame;
        cfg.params = Ext.apply({}, cfg.params);
        var replace = cfg.replace || false;
        var shower = cfg.shower;
        var onOk = cfg.onOk;
        var onShowFrame = cfg.onShowFrame;
        //
        delete cfg.frame;
        delete cfg.replace;
        delete cfg.shower;
        delete cfg.onOk;
        delete cfg.onShowFrame;
        //
        var showConfig = {
        };
        if (shower) {
            showConfig.shower = shower;
        }
        if (onOk) {
            showConfig.onOk = onOk;
        }

        var doShowFrame = function(f, showConfig) {
            if (!onShowFrame) {
                th.showFrame(f, showConfig);
            } else {
                onShowFrame(f, showConfig);
            }
        };

        // id
        if (cfg.id) {
            if (cfg.id === true) {
                cfg.id = frame;
            }
            if (replace) {
                th.closeFrame(cfg.id);
            } else {
                // activate
                if (f = th.activateFrame(cfg.id)) {
                    return f;
                }
            }
        }

        //
        if (!cfg.id) {
            cfg.id = Ext.id();
        }

        //
        if (Ext.isString(frame)) {
            if (frame.indexOf('/') == -1) {
                // нет слешей, считаем именем класса
                try {
                    f = Ext.create(frame, cfg);
                    doShowFrame(f, showConfig);
                } catch(e) {
                    Jc.error(e);
                }
            } else {
                // есть слеши, считаем url
                var ext_html = '.html';
                var ext_gframe = '.gframe';
                var ext_gf = '.gf';
                if (frame.match(ext_html + "$") == ext_html) {
                    // расширение html. Это gsp фрейм
                    cfg.url = frame;
                    frame = 'Jc.frame.Gsp';
                    //
                    f = Ext.create(frame, cfg);
                    doShowFrame(f, showConfig);

                } else if (frame.match(ext_gframe + "$") == ext_gframe) {
                    // расширение gframe. Это сгенеренный процесс создания фрейма
                    Ext.Ajax.request({
                        url: frame,
                        params: cfg.params,
                        success: function(response, opts) {
                            var s = response.responseText;
                            // загрузка прошла, создаем
                            var saveTH = window.TH;
                            window.TH = {};
                            window.TH.create = function(frameCls, frameConfig) {
                                Ext.apply(frameConfig, cfg);
                                f = Ext.create(frameCls, frameConfig);
                            };
                            try {
                                // препроцессор
                                // замена ~id~ на id фрейма
                                // замена ~id~X на id-X фрейма (если X буква),
                                // например: <div id="~id~form"> заменится на <div id="x-123-form">
                                s = s.replace(/~id~(\w)/g, cfg.id + '-$1');
                                s = s.replace(/~id~/g, cfg.id);
                                // запоминаем полученную строку во фрейме
                                cfg.sourceText = s;
                                // выполняем. Должен вызваться метод TH.create
                                Jc.evalHtml(s);

                                // проверяем
                                if (f) {
                                    // да, вызвался. Показываем
                                    doShowFrame(f, showConfig);
                                }

                            } finally {
                                window.TH = saveTH;
                            }

                        },
                        failure: function(response, opts) {
                            Jc.error(response, false);
                        }
                    });
                } else if (frame.match(ext_gf + "$") == ext_gf) {
                    //
                    var frameCfg = {id: cfg.id};
                    delete cfg.id;
                    //
                    f = Ext.create('Jc.frame.GfFrame', frameCfg);
                    f.parseParams(cfg);
                    f.contentUrl = frame;
                    //
                    f.reloadContent(function(txt) {
                        f.updateContent(txt);
                        doShowFrame(f, showConfig);
                    });
                } else {
                    Jc.error('unsupported:' + frame);
                }
            }
        } else {
            Jc.error('frame должен быть строкой');
        }
    }

}, function() {

    ////// new frame api

    Jc.showFrame = function() {
        return Jc.app.newapi_showFrame.apply(Jc.app, arguments);
    }

});
 