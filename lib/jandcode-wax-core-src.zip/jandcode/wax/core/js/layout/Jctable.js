/**
 * TableLayout.
 * Дополнительно для каждой последней ячейки в строке ставит класс
 * x-jctable-layout-cell-lastcol
 * Дополнительно для каждой последней ячейки в столбце ставит класс
 * x-jctable-layout-cell-lastrow
 * Дополнительно свойства компонента:
 *  cellWidth - ширина ячейки
 *  cellStyle - стиль ячейки (объект)
 *
 */
Ext.define('Jc.layout.Jctable', {
    extend: 'Ext.layout.container.Table',
    alias: ['layout.jctable'],
    type: 'jctable',
    alternateClassName: 'Ext.layout.JctableLayout',

    targetCls: Ext.baseCSSPrefix + 'jctable-layout-ct',
    tableCls: Ext.baseCSSPrefix + 'jctable-layout',
    cellCls: Ext.baseCSSPrefix + 'jctable-layout-cell',
    lastcolCls: Ext.baseCSSPrefix + 'jctable-layout-cell-lastcol',
    lastrowCls: Ext.baseCSSPrefix + 'jctable-layout-cell-lastrow',

    renderChildren: function() {
        // вызов этого метода перекрывает содержимое полученное из getRenderTree
    },

    //todo 4.2 оригинальный метод getRenderTree с моими вставками
    getRenderTree: function() {
        var me = this,
          items = me.getLayoutItems(),
          cells,
          rows = [],
          result = Ext.apply({
              tag: 'table',
              role: 'presentation',
              cls: me.tableCls,
              cellspacing: 0,
              cellpadding: 0,
              cn: {
                  tag: 'tbody',
                  cn: rows
              }
          }, me.tableAttrs),
          tdAttrs = me.tdAttrs,
          needsDivWrap = me.needsDivWrap(),
          i, len = items.length, item, curCell, tr, rowIdx, cellIdx, cell;

        // Calculate the correct cell structure for the current items
        cells = me.calculateCells(items);

        for (i = 0; i < len; i++) {
            item = items[i];

            curCell = cells[i];
            rowIdx = curCell.rowIdx;
            cellIdx = curCell.cellIdx;

            // If no row present, create and insert one
            tr = rows[rowIdx];
            if (!tr) {
                tr = rows[rowIdx] = {
                    tag: 'tr',
                    cn: []
                };
                if (me.trAttrs) {
                    Ext.apply(tr, me.trAttrs);
                }
            }

            // If no cell present, create and insert one
            cell = tr.cn[cellIdx] = {
                tag: 'td'
            };
            if (tdAttrs) {
                Ext.apply(cell, tdAttrs);
            }
            Ext.apply(cell, {
                colSpan: item.colspan || 1,
                rowSpan: item.rowspan || 1,
                id: item.cellId || '',
                cls: me.cellCls + ' ' + (item.cellCls || '')
            });
            me.ks_configureItem(cell, item); //todo ks for 4.2

            if (needsDivWrap) { //create wrapper div if needed - see docs below
                cell = cell.cn = {
                    tag: 'div'
                };
            }

            me.configureItem(item);
            // The DomHelper config of the item is the cell's sole child
            cell.cn = item.getRenderTree();
        }
        me.ks_getRenderTree_after(result); //todo ks for 4.2
        return result;
    },


    ks_getRenderTree_after: function(res) {
        var th = this;

        // перебираем ячейки
        var rows = res['cn']['cn'];
        for (var ri = 0; ri < rows.length; ri++) {
            var cols = rows[ri]['cn'];
            for (var ci = 0; ci < cols.length; ci++) {
                var td = cols[ci];
                //  Для последней ячейке в строке добавляем класс x-jctable-layout-cell-lastcol
                //  Для ячеек последней строки добавляем класс x-jctable-layout-cell-lastrow
                if (ci == cols.length - 1) {
                    td.cls += ' ' + th.lastcolCls + ' ';
                }
                if (ri == rows.length - 1) {
                    td.cls += ' ' + th.lastrowCls + ' ';
                }
            }
        }
    },

    ks_configureItem: function(td, item) {
        if (item.cellWidth) {
            if (!td.style) {
                td.style = {}
            }
            Ext.apply(td.style, {width: item.cellWidth});
        }
        if (item.cellStyle) {
            if (!td.style) {
                td.style = {}
            }
            Ext.apply(td.style, item.cellStyle);
        }
    }

});
