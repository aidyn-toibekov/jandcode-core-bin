/**
 * Для text
 */
Ext.define('Jc.layout.Jctextfield', {
    extend: 'Ext.layout.component.field.Text',
    alias: 'layout.jctextfield',
    type: 'jctextfield',

    finishedLayout: function(ownerContext) {
        this.callParent(arguments);
        //todo 4.2 грубый хак: input будет шириной 100% всегда, что бы заполнять td, внутри которой он
        var inputEl = ownerContext.target.inputEl;
        if (inputEl) {
            inputEl.setStyle('width', '100%');
        }
    }

});