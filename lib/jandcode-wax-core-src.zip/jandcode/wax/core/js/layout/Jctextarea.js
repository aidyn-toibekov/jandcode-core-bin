/**
 * Для memo
 */
Ext.define('Jc.layout.Jctextarea', {
    extend: 'Ext.layout.component.field.TextArea',
    alias: 'layout.jctextareafield',
    type: 'jctextareafield',

    finishedLayout: function(ownerContext) {
        this.callParent(arguments);
        //todo 4.2 грубый хак: input будет шириной 100% всегда, что бы заполнять td, внутри которой он
        var inputEl = ownerContext.target.inputEl;
        if (inputEl) {
            inputEl.setStyle('width', '100%');
        }
    }

});