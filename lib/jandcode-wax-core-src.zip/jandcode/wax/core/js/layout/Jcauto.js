/**
 * Компоненты в столбик. Для скроллируемых страниц.
 * Имеет defaultMargins как в vbox.
 */
Ext.define('Jc.layout.Jcauto', {

    alias: ['layout.jcauto'],
    extend: 'Ext.layout.container.Auto',
    alternateClassName: 'Jc.layout.JcautoLayout',
    type: 'jcauto',

    defaultMargins: null,
    manageMargins: true,

    configureItem: function(item) {
        var th = this;
        var res = th.callParent(arguments);
        if (th.defaultMargins && !item.rendered) {
            var margin = item.margin;
            if (!margin) {
                item.margin = Ext.apply({}, th.defaultMargins);
            }
        }
        return res;
    }

});