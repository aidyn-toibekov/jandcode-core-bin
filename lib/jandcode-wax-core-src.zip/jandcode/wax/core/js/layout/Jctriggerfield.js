/**
 * Для trigger
 */
//todo 4.2 для ширины типа '100%' отрабатывать отказывается. Пока отложим
Ext.define('Jc.layout.Jctriggerfield', {
    extend: 'Ext.layout.component.field.Trigger',
    alias: 'layout.jctriggerfield',
    type: 'jctriggerfield'

});