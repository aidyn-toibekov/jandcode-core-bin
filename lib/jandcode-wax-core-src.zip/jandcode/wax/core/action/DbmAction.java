package jandcode.wax.core.action;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.wax.core.utils.json.*;
import jandcode.wax.core.utils.upload.*;
import jandcode.web.*;
import org.apache.commons.fileupload.*;

import java.util.*;

/**
 * Поддержка dbm
 */
public class DbmAction extends WebAction {

    public static final String P_DAONAME = "daoname";
    public static final String P_DAOMETHOD = "daomethod";
    public static final String P_DAOPARAMS = "daoparams";
    public static final String P_MODEL = "model";
    public static final String P_DOMAIN = "domain";
    public static final String P_MODEL_DEFAULT = "default";
    public static final String P_VALUE = "value";
    public static final String P_DATA = "data";
    public static final String P_DICTDATA = "dictdata";
    public static final String P_CACHEINFO = "cacheinfo";
    public static final String P_FILEITEM = "fileitem";
    public static final String P_FILEITEM_NAME = "fileitem_name";
    public static final String P_CLIENTDATA = "clientdata";
    public static final String P_RENDERTYPE = "rendertype";

    /**
     * Модель, в контексте которой работает action
     */
    protected Model getModel() {
        String modelName = getParams().getValueString(P_MODEL, P_MODEL_DEFAULT);
        return getApp().service(ModelService.class).getModel(modelName);
    }

    protected void checkCacheInfo(Map result, Model model) {
        long oldVersion = getParams().getValueLong(P_CACHEINFO, -123456);
        if (oldVersion == -123456) {
            return; // клиент не хочет знать о кэше
        }
        //
        long curVersion = model.getCacheService().getCacheVersion();
        if (curVersion <= oldVersion) {
            return; // ничего не поменялось
        }
        List<String> dataNames = model.getCacheService().getChangedFromVersion(oldVersion);
        if (dataNames == null) {
            return; // ничего не поменялось
        }
        // уведомляем, что поменялось
        Map ci = new HashMap();
        ci.put("version", curVersion);
        ci.put("dataNames", dataNames);
        result.put(P_CACHEINFO, ci);
    }

    /**
     * Описание структуры домена в виде json
     */
    public void domain(JsonActionWrapper wrap) throws Exception {
        Model model = getModel();
        String dn = getParams().getValueString(P_DOMAIN);
        if (UtString.empty(dn)) {
            throw new XError("domain not specified");
        }
        Domain domain = model.getDomain(dn);
        Map m = getApp().service(WaxJsonService.class).domainToJson(domain);
        checkCacheInfo(m, model);
        wrap.setJson(m);
    }

    /**
     * Выполнение dao метода и возврат результата в виде Json
     */
    public void daoinvoke(JsonActionWrapper wrap) throws Exception {
        WaxJsonService svc = getApp().service(WaxJsonService.class);
        Model model = getModel();
        String domainName = getParams().getValueString(P_DAONAME);
        String daomethodName = getParams().getValueString(P_DAOMETHOD);
        List mapParams = (List) UtJson.toObject(getParams().getValueString(P_DAOPARAMS));
        //
        Object resObj = svc.daoinvoke(getParams(), model, domainName, daomethodName, mapParams);
        Map res = svc.toJson(resObj, model);
        checkCacheInfo(res, model);
        wrap.setJson(res);
    }

    /**
     * Выполнение dao метода и возврат результата в виде json в формате,
     * пригодного для использования в качестве данных для store.
     */
    public void loadstore(JsonActionWrapper wrap) throws Exception {
        WaxJsonService svc = getApp().service(WaxJsonService.class);
        Model model = getModel();
        String domainName = getParams().getValueString(P_DAONAME);
        String daomethodName = getParams().getValueString(P_DAOMETHOD);
        List mapParams = (List) UtJson.toObject(getParams().getValueString(P_DAOPARAMS));
        //
        Object res = svc.daoinvoke(getParams(), model, domainName, daomethodName, mapParams);
        //
        Map map = svc.toJson(res, model);
        Map json = new LinkedHashMap();
        //
        if (res instanceof DataStore || res instanceof DataTreeNode || res instanceof DataRecord) {
            Map v1 = (Map) map.get(P_VALUE);
            json.put(P_DATA, v1.get(P_DATA));
            if (v1.containsKey(P_DICTDATA)) {
                json.put(P_DICTDATA, v1.get(P_DICTDATA));
            }
            if (v1.containsKey(P_CLIENTDATA)) {
                json.put(P_CLIENTDATA, v1.get(P_CLIENTDATA));
            }
        } else if (res instanceof Map) {
            List lst = new ArrayList();
            Map v1 = (Map) map.get(P_VALUE);
            lst.add(v1.get(P_DATA));
            json.put(P_DATA, lst);
            if (v1.containsKey(P_DICTDATA)) {
                json.put(P_DICTDATA, v1.get(P_DICTDATA));
            }
            if (v1.containsKey(P_CLIENTDATA)) {
                json.put(P_CLIENTDATA, v1.get(P_CLIENTDATA));
            }
        } else {
            throw new XError("Return type [{0}] not compatible with store");
        }
        //
        checkCacheInfo(json, model);
        //
        wrap.setJson(json);
    }

    /**
     * ping. используется для получения хвостиков в запросе без собственно запроса.
     */
    public void ping(JsonActionWrapper wrap) throws Exception {
        Model model = getModel();
        Map json = new LinkedHashMap();
        //
        checkCacheInfo(json, model);
        //
        wrap.setJson(json);
    }

    /**
     * Закгрузка файла для использования его в store
     */
    public void upload(JsonActionWrapper wrap) throws Exception {
        wrap.setContentType("text/html");
        Object p = getParams().get(P_FILEITEM);
        if (p == null) {
            throw new XError("Not assigned param {0}", P_FILEITEM);
        }
        if (!(p instanceof FileItem)) {
            throw new XError("Param {0} is not file", P_FILEITEM);
        }

        // клиентское имя файла на русском
        Map m = (Map) UtJson.toObject(getParams().getValueString(P_FILEITEM_NAME));
        String clientFileName = UtString.toString(m.get("name"));

        // запоминаем и удаляем оригинал
        WaxUploadService svc = getApp().service(WaxUploadService.class);
        FileItem fi = (FileItem) p;
        UploadFile uf = svc.add(fi);
        uf.setClientFileName(clientFileName);
        fi.delete();

        // выдаем id файла
        wrap.getJson().put("id", uf.getId());
    }

    /**
     * Выполняем daoinvoke. То, что возвращает dao, просто рендерим через стандартный
     * механизм рендеринга
     *
     * @throws Exception
     */
    public void daorender() throws Exception {
        WaxJsonService svc = getApp().service(WaxJsonService.class);
        Model model = getModel();
        String daoName = getParams().getValueString(P_DAONAME);
        String daomethodName = getParams().getValueString(P_DAOMETHOD);
        List mapParams = (List) UtJson.toObject(getParams().getValueString(P_DAOPARAMS));
        //
        Object res = svc.daoinvoke(getParams(), model, daoName, daomethodName, mapParams);
        //
        String renderType = getParams().getValueString(P_RENDERTYPE, "html");
        //
        render(res, renderType);
    }

}
