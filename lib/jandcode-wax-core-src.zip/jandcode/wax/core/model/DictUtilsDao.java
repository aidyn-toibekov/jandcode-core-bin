package jandcode.wax.core.model;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Работа со словарями через dao
 */
public class DictUtilsDao extends WaxDao {

    /**
     * Данные из словаря. Только для обычных словарей
     *
     * @param dictName имя словаря
     * @return store с данными словаря
     */
    @DaoMethod
    public DataStore getData(String dictName) throws Exception {
        Dict d = getModel().getDictService().getDict(dictName);
        if (d.isResolve()) {
            throw new XError(UtLang.t("Для resolve словаря операция getData неподдерживается"));
        }
        return UtData.copyStore(d.getData());
    }

    /**
     * Разрешение словарей. На входе map вида:
     * {dictname:[value,value...],..}
     * на выходе:
     * {dictname:{key:{fieldname:value, ...}}}
     */
    @DaoMethod
    public Map resolveDicts(Map data) throws Exception {
        DictService svc = getModel().getDictService();
        // грузим данные
        List<DataStore> sts = new ArrayList<DataStore>();
        for (Object key : data.keySet()) {
            List values = (List) data.get(key);
            DataStore st = svc.getDictData(key.toString(), values);
            sts.add(st);
        }

        // формируем нужный результат
        Map res = new HashMap();
        for (DataStore st : sts) {
            Map d1 = new HashMap();
            res.put(st.getName(), d1);
            for (DataRecord rec : st) {
                Map v = rec.getValues();
                v.remove("id");
                d1.put(rec.getValue("id"), v);
            }
        }

        //
        return res;
    }

    /**
     * Разрешение словарей для объекта. Используется только на сервере!
     *
     * @param data для кого (DataRecord, DataStore ...)
     */
    @DaoMethod
    public void resolveDictsFor(Object data) {
        ut.resolveDicts(data);
    }

}
