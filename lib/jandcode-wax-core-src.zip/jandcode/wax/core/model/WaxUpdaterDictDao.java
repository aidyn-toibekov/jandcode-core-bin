package jandcode.wax.core.model;

import jandcode.dbm.dao.*;

/**
 * updater для простых словарей
 */
public class WaxUpdaterDictDao extends WaxUpdaterDao implements IAfterDaoMethod {

    public void afterDaoMethod(String methodName, Object[] args, Object[] result, int level) throws Exception {
        // при изменении словаря уведомляем кеш
        if (methodName.indexOf("load") == -1) {
            getModel().getCacheService().notifyChange(ut.getTableName());
        }
    }

}
