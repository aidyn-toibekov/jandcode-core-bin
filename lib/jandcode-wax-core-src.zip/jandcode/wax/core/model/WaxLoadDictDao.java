package jandcode.wax.core.model;

import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;

import java.util.*;

/**
 * Простая полная загрузка словаря из таблицы
 */
public class WaxLoadDictDao extends WaxDao implements ILoadDict {

    @DaoMethod
    public void loadDict(Dict dict) throws Exception {
        // игнорируем blob и вычисляемые поля при загрузке словаря
        List<String> loadedFields = new ArrayList<String>();
        for (Field f : dict.getDomain().getFields()) {
            if (!f.isCalc() && f.getDataType() != DataType.BLOB) {
                loadedFields.add(f.getName());
            }
        }
        String sql = ut.subst("select ${flds} from ${@table} order by id",
                "flds", UtString.join(loadedFields, ","));
        //
        ut.loadSql(dict.getData(), sql);
    }

}
