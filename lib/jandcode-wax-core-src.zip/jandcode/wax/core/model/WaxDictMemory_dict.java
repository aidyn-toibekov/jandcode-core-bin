package jandcode.wax.core.model;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

/**
 * Загрузка словаря в памяти. Данные берутся из узла dictdata домена словаря.
 */
public class WaxDictMemory_dict extends WaxDao implements ILoadDict {

    @DaoMethod
    public void loadDict(jandcode.dbm.dict.Dict dict) {
        Rt rt = getDomain().getRt().findChild("dictdata");
        if (rt == null) {
            throw new XError(UtLang.t("В домене {0} нет узла dictdata", getDomain().getName()));
        }
        for (Rt x : rt.getChilds()) {
            DataRecord r = dict.getData().add();
            for (IRtAttr a : x.getAttrs()) {
                r.setValue(a.getName(), a.getValue());
            }
        }
    }

}

