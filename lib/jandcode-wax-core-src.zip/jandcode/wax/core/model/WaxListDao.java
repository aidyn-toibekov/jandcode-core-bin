package jandcode.wax.core.model;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

/**
 * Простой dao для получения записей из таблицы как полностью, так и по одной.
 */
public class WaxListDao extends WaxDao {

    protected String getLoadSql(boolean rec) {
        return ut.subst("" +
                //
                "select * from ${@table} ${part}",
                //
                "part", rec ?
                        "where id=:id" :
                        "order by id");
    }

    //////

    /**
     * Загрузить список записей
     */
    @DaoMethod
    public DataStore load() throws Exception {
        DataStore st = ut.createStore();
        ut.loadSql(st, getLoadSql(false));
        return st;
    }

    /**
     * Загрузить одну запись так же, как был загружен список
     */
    @DaoMethod
    public DataRecord loadRec(long id) throws Exception {
        DataStore st = ut.createStore();
        ut.loadSql(st, getLoadSql(true), id);
        if (st.size() == 0) {
            throw new XError(UtLang.t("Запись #{0} не найдена", id));
        }
        return st.getCurRec();
    }

}
