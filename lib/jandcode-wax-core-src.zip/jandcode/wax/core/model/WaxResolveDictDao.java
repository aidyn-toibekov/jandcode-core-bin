package jandcode.wax.core.model;

import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;

import java.util.*;

/**
 * Простая загрузка resolve словаря из таблицы
 */
public class WaxResolveDictDao extends WaxDao implements ILoadDict {

    private int blockSize = 200;

    /**
     * Размер блока. По умолчанию 200
     */
    public int getBlockSize() {
        return blockSize;
    }

    public void setBlockSize(int blockSize) {
        this.blockSize = blockSize;
    }

    @DaoMethod
    public void loadDict(Dict dict) throws Exception {
        // игнорируем blob и вычисляемые поля при загрузке словаря
        List<String> loadedFields = new ArrayList<String>();
        for (Field f : dict.getDomain().getFields()) {
            if (!f.isCalc() && f.getDataType() != DataType.BLOB) {
                loadedFields.add(f.getName());
            }
        }
        //
        String flds = UtString.join(loadedFields, ",");
        CollectionBlockIterator z = new CollectionBlockIterator(dict.getResolveIds(), getBlockSize());
        for (List itms : z) {
            String sql = ut.subst("select ${flds} from ${@table} where id in (${itmsS})",
                    "flds", flds,
                    "itmsS", UtString.join(itms, ",")
            );
            ut.loadSql(dict.getData(), sql);
        }

    }

}
