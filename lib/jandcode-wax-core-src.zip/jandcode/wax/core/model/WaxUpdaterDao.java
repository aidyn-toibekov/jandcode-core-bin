package jandcode.wax.core.model;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

/**
 * Обычный updater
 */
public class WaxUpdaterDao extends WaxDao {

    /**
     * Загрузка записи с указанным id
     */
    @DaoMethod
    public DataRecord loadRec(long id) throws Exception {
        DataStore st = ut.createStore();
        ut.loadSql(st, getLoadRecSql(), id);
        if (st.size() == 0) {
            throw new XError(UtLang.t("Запись #{0} не найдена", id));
        }
        return st.getCurRec();
    }

    /**
     * Создание новой пустой записи
     *
     * @return
     * @throws Exception
     */
    @DaoMethod
    public DataRecord newRec() throws Exception {
        return ut.createRecord();
    }

    //////

    /**
     * Добавить новую запись
     */
    @DaoMethod
    public long ins(DataRecord rec) throws Exception {
        DataStore st = ut.createStore(rec);
        rec = st.getCurRec();
        //
        onBeforeSave(rec, true);
        onValidateSave(rec, true);
        ut.checkErrors();
        //
        return onIns(rec);
    }

    /**
     * Изменить запись. rec - новые данные для записи. rec.id - какую запись изменять.
     */
    @DaoMethod
    public void upd(DataRecord rec) throws Exception {
        DataStore st = ut.createStore(rec);
        rec = st.getCurRec();
        //
        onBeforeSave(rec, false);
        onValidateSave(rec, false);
        ut.checkErrors();
        //
        onUpd(rec);
    }

    /**
     * Удалить запись с указанной id
     */
    @DaoMethod
    public void del(long id) throws Exception {
        onValidateDel(id);
        ut.checkErrors();
        //
        onDel(id);
    }

    //////

    /**
     * sql для загрузки записи из связанной с dao таблицы
     */
    protected String getLoadRecSql() {
        return ut.subst("select * from ${@table} where id=:id");
    }

    //////

    /**
     * Вызывается перед добавлением до валидации для ins,upd
     *
     * @param rec запись с данными
     * @param ins true - добавление записи
     */
    protected void onBeforeSave(DataRecord rec, boolean ins) throws Exception {
    }

    /**
     * Валидация для ins,upd.
     *
     * @param rec данные записи
     * @param ins true - добавление записи
     */
    protected void onValidateSave(DataRecord rec, boolean ins) throws Exception {
        ut.validateRecord(rec, ins ? "ins" : "upd");
    }

    /**
     * Валидация для del
     *
     * @param id какая запись
     */
    protected void onValidateDel(long id) throws Exception {
        ut.validateDelRef(ut.getTableName(), id);
    }

    /**
     * Реализация физического добавления записи
     */
    protected long onIns(DataRecord rec) throws Exception {
        return ut.insertRec(ut.getTableName(), rec);
    }

    /**
     * Реализация физического обновления записи
     */
    protected void onUpd(DataRecord t) throws Exception {
        ut.updateRec(ut.getTableName(), t);
    }

    /**
     * Реализация физического удаления записи
     */
    protected void onDel(long id) throws Exception {
        ut.deleteRec(ut.getTableName(), id);
    }

}
