package jandcode.wax.core.model;

import jandcode.app.*;
import jandcode.dbm.dao.*;
import jandcode.web.*;

/**
 * Утилиты для dao объектов
 */
public class WaxDaoUtils extends DaoUtils {

    public WaxDaoUtils(Comp comp) {
        super(comp);
    }

    ////// поддержка web-среды

    public WebService getWebService() {
        return getModel().getApp().service(WebService.class);
    }

    public WebRequest getRequest() {
        return getWebService().getRequest();
    }

}
