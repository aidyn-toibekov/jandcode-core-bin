package jandcode.wax.core.model;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.sqlfilter.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Предок для загрузчиков данных через SqlFilter с refresh записи
 */
public abstract class WaxLoadSqlFilterDao extends WaxDao implements IWaxLoadSqlFilterDao {

    private String domainFilter = "id";
    private String domainResult = "id";
    private String idField = "id";

    /**
     * Домен со структурой фильтра
     */
    public String getDomainFilter() {
        return domainFilter;
    }

    public void setDomainFilter(String domainFilter) {
        this.domainFilter = domainFilter;
    }

    /**
     * Домен со структурой результата
     */
    public String getDomainResult() {
        return domainResult;
    }

    public void setDomainResult(String domainResult) {
        this.domainResult = domainResult;
    }

    /**
     * Имя sql-поля id для loadRec. По умолчанию - id. Возможны ситуации, когда
     * sql сложный и id выглядет например так: 't.id'. В этом случае - нужно
     * установить правильное значение.
     */
    public String getIdField() {
        return idField;
    }

    public void setIdField(String idField) {
        this.idField = idField;
    }

    /**
     * Этот метод должен настраивать sqlfilter, который был создан в createFilter
     */
    protected abstract void onCreateFilter(SqlFilter f) throws Exception;

    /**
     * Вызывается после загрузки данных методом load и loadRec. Предназначено
     * для post-обработки результатов.
     *
     * @param f         фильтр
     * @param t         загруженные данные
     * @param isLoadRec true - вызвано для loadRec, false - для load
     * @return DataStore, которая фактически будет результатом. Можно просто вернуть t
     */
    protected DataStore onAfterLoad(SqlFilter f, DataStore t, boolean isLoadRec) {
        return t;
    }

    /**
     * Создание sqlfilter
     *
     * @param params для каких параметров
     */
    public SqlFilter createFilter(Map params) throws Exception {
        SqlFilter f = ut.createSqlFilter(getDomainFilter(), params);
        onCreateFilter(f);
        return f;
    }


    /**
     * Загрузка данных по параметрам и фильтру
     */
    @DaoMethod
    public DataStore load(Map params) throws Exception {
        // создаем фильтр
        SqlFilter f = createFilter(params);
        // загружаем данные
        DataStore res = ut.createStore(getDomainResult());
        f.load(res);
        res = onAfterLoad(f, res, false);
        return res;
    }

    /**
     * Загрузка одной записи по id
     */
    @DaoMethod
    public DataRecord loadRec(long id) throws Exception {
        // создаем фильтр
        Map params = new HashMap();
        params.put("id", id);
        SqlFilter f = createFilter(params);
        // добавляем фильтр по id
        f.filter(UtCnv.toMap(
                "field", "id",
                "type", "equal",
                "param", "id",
                "sqlfield", getIdField()
        ));
        // отключаем пагинацию
        f.setPaginate(false);
        // загружаем данные записи
        DataStore res = ut.createStore(getDomainResult());
        f.load(res);
        if (res.size() == 0) {
            throw new XError("Не найдена запись #{0}", id);
        }
        res = onAfterLoad(f, res, true);
        return res.getCurRec();
    }


}
