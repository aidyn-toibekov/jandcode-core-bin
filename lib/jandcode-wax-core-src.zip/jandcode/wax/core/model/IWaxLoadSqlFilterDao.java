package jandcode.wax.core.model;

import jandcode.dbm.data.*;

import java.util.*;

/**
 * Интерфейс для dao, который загружает фильтрованные store.
 */
public interface IWaxLoadSqlFilterDao {

    /**
     * Домен со структурой фильтра
     */
    String getDomainFilter();

    /**
     * Домен со структурой результата
     */
    String getDomainResult();

    /**
     * Загрузка данных по параметрам и фильтру
     */
    DataStore load(Map params) throws Exception;

    /**
     * Загрузка одной записи по id
     */
    DataRecord loadRec(long id) throws Exception;

}
