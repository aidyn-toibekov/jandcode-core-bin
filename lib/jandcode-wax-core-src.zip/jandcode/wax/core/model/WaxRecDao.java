package jandcode.wax.core.model;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;

/**
 * Простой dao для получения записи по id
 */
public class WaxRecDao extends WaxDao {

    /**
     * Загрузить одну запись
     */
    @DaoMethod
    public DataRecord loadRec(long id) throws Exception {
        DataRecord rec = ut.createRecord();
        ut.loadSqlRec(rec, "select * from " + ut.getTableName() + " where id=:id", id);
        return rec;
    }

}
