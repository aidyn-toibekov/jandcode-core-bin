package jandcode.wax.core.model;

import jandcode.dbm.dao.*;

/**
 * Предок для dao объектов wax
 */
public abstract class WaxDao extends Dao {

    protected WaxDaoUtils ut = new WaxDaoUtils(this);

}
