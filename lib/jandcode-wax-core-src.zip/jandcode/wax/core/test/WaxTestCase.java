package jandcode.wax.core.test;

import jandcode.app.test.*;
import jandcode.dbm.test.*;
import jandcode.web.test.*;

/**
 * Предок для wax-тестов с поддержкой и dbm и web.
 */
public abstract class WaxTestCase extends AppTestCase {

    public TestExtDbm dbm = createExt(TestExtDbm.class);
    public TestExtWeb web = createExt(TestExtWeb.class);

}
