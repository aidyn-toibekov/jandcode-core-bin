package jandcode.wax.core.tml.jc.value;

import jandcode.web.*;

public class BooleanTml extends Tml {
    protected void onRender() throws Exception {
        boolean v = getArgs().getValueBoolean("value");
        out("<span class=\"fg-icon-16 icon-" + v + "\"></span>");
    }
}
