package jandcode.wax.core.tml.jc.value;

import jandcode.web.*;

public class StringTml extends Tml {
    protected void onRender() throws Exception {
        Object value = getArgs().getValue("value");
        out(value);
    }
}
