package jandcode.wax.core.tml.jc.value;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.web.*;

public class DictTml extends Tml {
    protected void onRender() throws Exception {
        Field f = (Field) getArgs().getValue("field");
        if (f == null) {
            return;
        }
        DataRecord rec = null;
        try {
            rec = (DataRecord) getArgs().getValue("data");
        } catch (Exception e) {
            return; // ignore
        }
        if (rec == null) {
            return;
        }
        out(rec.getDictText(f.getName()));
    }
}
