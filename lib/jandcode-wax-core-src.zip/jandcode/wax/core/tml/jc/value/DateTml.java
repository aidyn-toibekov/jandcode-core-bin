package jandcode.wax.core.tml.jc.value;

import jandcode.utils.*;
import jandcode.web.*;
import org.joda.time.*;

public class DateTml extends Tml {
    protected void onRender() throws Exception {
        String fmt = getArgs().getValueString("format", "dd.MM.yyyy");
        DateTime v = getArgs().getValueDateTime("value");
        String s;
        if (UtDate.isEmpty(v) || v.getYear() > 2222) {
            s = "...";
        } else {
            s = v.toString(fmt);
        }
        out(s);
    }
}
