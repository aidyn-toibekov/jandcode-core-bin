package jandcode.wax.core.tml.jc;

/**
 * Текст ячейки с данными. Может быть использована как ячейка гриды или для
 * отображения текста в виде метки.
 */
public class ValueTml extends CustomValueWrapper {

    protected void onRender() throws Exception {
        prepareArgs();
        include("jc/value/" + getArgs().getValueString("type"));
    }

}
