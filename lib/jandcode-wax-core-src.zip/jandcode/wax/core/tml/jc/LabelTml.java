package jandcode.wax.core.tml.jc;

import jandcode.dbm.*;
import jandcode.utils.*;

/**
 * Метка для поля.
 *
 * @args text текст метки. Если не указан и можно определеить поле - метка берется из поля
 */
public class LabelTml extends CustomValueWrapper {

    protected void onRender() throws Exception {
        prepareArgs();
        String txt = getArgs().getValueString("text");
        if (UtString.empty(txt)) {
            Field f = (Field) getArgs().getValue("field");
            if (f != null) {
                txt = f.getTitle();
            }
        }
        txt = txt.trim();
        if (!txt.endsWith(":")) {
            txt = txt + ":";
        }
        out(txt);
    }

}
