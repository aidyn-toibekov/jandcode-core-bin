package jandcode.wax.core.tml.jc;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.utils.variant.*;
import jandcode.web.*;

/**
 * Враппер для выводилок ячеек c данными данных
 *
 * @arg type:string тип ячейки. Для вывода этой ячейки будет использован шаблон 'jc/value/TYPE'
 * Если не указан и можно определить поле, то берется из него (gsp/value:type).
 * По умолчанию - 'string'.
 * @arg data:object объект с данными. Должен поддерживать интерфейс {@link IVariantNamed}
 * (либо преобразововаться к такому)
 * @arg fn:object имя поля с данными. Если data - IDomainLink - то поле берется оттуда
 * @arg value: object значение. Если явно не указано, то предполагается как data.getValue(fieldname)
 */
public abstract class CustomValueWrapper extends Tml {

    /**
     * Подготовка аргументов.
     *
     * @throws Exception
     */
    protected void prepareArgs() throws Exception {
        VariantMap ar = getArgs();
        String type = ar.getValueString("type");
        String fn = ar.getValueString("fn");
        Object data = ar.getValue("data");
        IVariantNamed vdata = null;
        //
        if (data != null) {
            vdata = UtData.toVariantNamed(data);
            if (UtString.empty(type) && data instanceof IDomainLink && !UtString.empty(fn)) {
                Field f = ((IDomainLink) data).getDomain().findField(fn);
                if (f != null) {
                    ar.put("field", f);
                    Rt z = f.getRt().findChild("gsp/value");
                    if (z != null) {
                        type = z.getValueString("type");
                        for (IRtAttr attr : z.getAttrs()) {
                            String attrName = attr.getName();
                            if ("type".equals(attrName) || "value".equals(attrName)) {
                                continue;
                            }
                            ar.put(attrName, attr.getValue());
                        }
                    }
                }
            }
        }
        //
        Object value = null;
        if (!ar.containsKey("value")) {
            if (vdata != null && !UtString.empty(fn)) {
                try {
                    value = vdata.getValue(fn);
                } catch (Exception e) {
                    // игнорируем, пусть null будет
                }
            }
        } else {
            value = ar.getValue("value");
        }
        //
        ar.put("data", vdata);
        ar.put("value", value);
        if (UtString.empty(type)) {
            type = "string";
        }
        ar.put("type", type);
    }


}
