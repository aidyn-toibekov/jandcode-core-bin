package jandcode.wax.core.utils.theme;

import jandcode.app.*;
import jandcode.utils.*;

/**
 * Сервис тем
 */
public abstract class WaxThemeService extends CompRt {

    /**
     * Текущая тема
     */
    public abstract WaxTheme getTheme();

    /**
     * Получить тему по имени. Если тема не будет найдена, возвращается тема
     * по умолчанию.
     */
    public abstract WaxTheme getTheme(String name);

    /**
     * Список доступных тем
     */
    public abstract ListNamed<WaxTheme> getThemes();

}
