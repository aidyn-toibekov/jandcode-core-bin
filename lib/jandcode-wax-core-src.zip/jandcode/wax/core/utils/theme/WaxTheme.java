package jandcode.wax.core.utils.theme;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Описание темы wax
 */
public class WaxTheme extends CompRt implements Iterable<WaxTheme.ThemeMember> {

    private String jsClass;
    private ThemeMember rootMember = new ThemeMember();

    /**
     * Член темы. css/js/gsp...
     */
    public static class ThemeMember extends CompRt implements Iterable<WaxTheme.ThemeMember> {
        private String path = "";
        private String pathDebug = "";
        private String type;
        private ListComp<ThemeMember> items = new ListComp<ThemeMember>();


        protected void onSetRt(Rt rt) {
            super.onSetRt(rt);
            //
            Rt z = rt.findChild("item");
            if (z != null) {
                for (Rt z1 : z.getChilds()) {
                    ThemeMember m = (ThemeMember) getApp().getObjectFactory().create(z1, ThemeMember.class);
                    items.add(m);
                }
            }
        }

        /**
         * Дочерние элементы
         */
        public ListComp<ThemeMember> getItems() {
            return items;
        }

        public Iterator<ThemeMember> iterator() {
            return getItems().iterator();
        }

        public String getPath() {
            if (!UtString.empty(pathDebug)) {
                if (getApp().isDebug()) {
                    return pathDebug;
                }
            }
            return path;
        }

        public void setPath(String path) {
            this.path = path;
            if (UtString.empty(type)) {
                type = UtFile.ext(path);
            }
        }

        /**
         * Путь для отладочного режима. Если установлен, то getPath() возвращает
         * getPathDebug() в отладочном режиме.
         */
        public String getPathDebug() {
            return pathDebug;
        }

        public void setPathDebug(String pathDebug) {
            this.pathDebug = pathDebug;
        }

        /**
         * Тип. css/js/gsp
         */
        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public boolean hasType(String type) {
            return this.type != null && this.type.equalsIgnoreCase(type);
        }

        public boolean isCss() {
            return hasType("css");
        }

        public boolean isGsp() {
            return hasType("gsp");
        }

        public boolean isJs() {
            return hasType("js");
        }

    }

    //////

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        rootMember.setApp(getApp());
        rootMember.setRt(rt);
    }

    //////

    /**
     * js class темы. Наследник от Jc.theme.Base
     */
    public String getJsClass() {
        return jsClass;
    }

    public void setJsClass(String jsClass) {
        this.jsClass = jsClass;
    }

    //////

    /**
     * Элементы темы
     */
    public ListComp<ThemeMember> getItems() {
        return rootMember.getItems();
    }

    public Iterator<ThemeMember> iterator() {
        return getItems().iterator();
    }
}
