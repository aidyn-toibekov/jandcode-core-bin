package jandcode.wax.core.utils.theme.impl;

import jandcode.app.*;
import jandcode.utils.rt.*;
import jandcode.wax.core.utils.theme.*;

public class WaxThemeServiceImpl extends WaxThemeService {

    private ListComp<WaxTheme> themes = new ListComp<WaxTheme>();
    private String themeName = "ide";

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt themeRt = getApp().getRt().getChild("web/theme");
        themeName = themeRt.getValueString("default", "ide");
        //
        for (Rt t1 : themeRt.getChilds()) {
            WaxTheme theme = (WaxTheme) getApp().getObjectFactory().create(t1, WaxTheme.class);
            themes.add(theme);
        }
    }

    //////


    public WaxTheme getTheme() {
        return themes.get(themeName);
    }

    public ListComp<WaxTheme> getThemes() {
        return themes;
    }

    public WaxTheme getTheme(String name) {
        WaxTheme t = themes.find(name);
        if (t == null) {
            return getTheme();
        }
        return t;
    }

    public void setThemeName(String themeName) {
        this.themeName = themeName;
    }

    //////

}
