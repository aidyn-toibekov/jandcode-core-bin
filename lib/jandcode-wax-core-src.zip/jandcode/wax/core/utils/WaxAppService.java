package jandcode.wax.core.utils;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

/**
 * Сервис для wax-приложения
 */
public class WaxAppService extends CompRt {

    private String title = "Wax";
    private String titleShort;

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        rt = getApp().getRt().getChild("app");
        setRtAttrs(rt);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitleShort() {
        if (UtString.empty(titleShort)) {
            return getTitle();
        }
        return titleShort;
    }

    public void setTitleShort(String titleShort) {
        this.titleShort = titleShort;
    }

}
