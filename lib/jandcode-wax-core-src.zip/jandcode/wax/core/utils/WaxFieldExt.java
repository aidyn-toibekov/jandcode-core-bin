package jandcode.wax.core.utils;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Расширение для поля от wax
 */
public class WaxFieldExt extends FieldExt {

    public WaxFieldExt(Field field) {
        super(field);
    }

    /**
     * true - поле видимое для автогенерируемого интерфейса
     */
    public boolean isVisible() {
        return getRt().getValueBoolean("visible", true);
    }

    /**
     * true - поле редактируемое для автогенерируемого интерфейса
     */
    public boolean isEditable() {
        return getRt().getValueBoolean("editable", true);
    }

    /**
     * true - поле редактируемое для автогенерируемого интерфейса
     */
    public int getWeight() {
        return getRt().getValueInt("weight", 50);
    }

    ////// json

    /**
     * Конвертация описания поля в json
     */
    public Map toJson() {
        Map m = new LinkedHashMap();
        Field f = getComp();
        MapBuilder b = new MapBuilder();
        //

        m.put("name", f.getName());

        String s = f.getTitle();
        if (!UtString.empty(s)) {
            m.put("title", UtLang.t(f.getTitle()));
        }
        if (!s.equals(f.getTitleShort())) {
            m.put("titleShort", UtLang.t(f.getTitleShort()));
        }
        //
        m.put("datatype", f.getDataTypeName());
        if (f.getSize() > 0) {
            m.put("size", f.getSize());
        }
        //
        if (!isVisible()) {
            m.put("visible", isVisible());
        }
        //
        if (!isEditable()) {
            m.put("editable", isEditable());
        }
        //
        if (f.hasDict()) {
            m.put("dict", f.getDictName());
        }
        //
        if (f.isReq()) {
            m.put("req", true);
        }
        // накладываем тег json
        Rt r1 = f.getRt().findChild("js");
        if (r1 != null) {
            b.joinJson(m, r1);
        }
        //
        return m;
    }


}
