package jandcode.wax.core.utils.upload;

import jandcode.dbm.*;
import jandcode.dbm.data.*;

/**
 * Поле для хранения upload полей.
 * getValue() - возвращает объект типа jandcode.wax.core.utils.upload.UploadFile
 * setValue() - используется только сервисом
 */
public class UploadField extends Field {

    public void setRecordValue(DataRecord rec, Object value) {
        if (value instanceof CharSequence) {
            WaxUploadService svc = getApp().service(WaxUploadService.class);
            UploadFile v = svc.find(value.toString());
            rec.setInternalValue(this, v);
        } else if (value instanceof UploadFile) {
            rec.setInternalValue(this, value);
        } else {
            rec.setInternalValue(this, null);
        }
    }

    public Object getRecordValue(DataRecord rec) {
        Object v = rec.getInternalValue(this);
        if (v instanceof UploadFile) {
            return v;
        }
        if (v != null) {
            rec.setInternalValue(this, null);
        }
        return null;
    }
}
