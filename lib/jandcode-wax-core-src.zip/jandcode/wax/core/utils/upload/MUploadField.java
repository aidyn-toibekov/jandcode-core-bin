package jandcode.wax.core.utils.upload;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

import java.util.*;

/**
 * Поле для хранения списка upload полей.
 * getValue() - возвращает список объектов типа jandcode.wax.core.utils.upload.UploadFile
 * (всегда не null)
 * setValue() - используется только сервисом
 */
public class MUploadField extends Field {

    public void setRecordValue(DataRecord rec, Object value) {
        List lst = (List) getRecordValue(rec);
        lst.clear();
        //
        if (value instanceof CharSequence) {
            WaxUploadService svc = getApp().service(WaxUploadService.class);
            String s = value.toString();
            if (!UtString.empty(s)) {
                String[] ar = s.split(",");
                for (String s1 : ar) {
                    UploadFile v = svc.find(s1);
                    if (v != null) {
                        lst.add(v);
                    }
                }
            }
        } else if (value instanceof List) {
            lst.addAll((List) value);
        } else if (value instanceof UploadFile) {
            lst.add(value);
        }
    }

    public Object getRecordValue(DataRecord rec) {
        Object v = rec.getInternalValue(this);
        if (v instanceof List) {
            return v;
        }
        v = new ArrayList<UploadFile>();
        rec.setInternalValue(this, v);
        return v;
    }
}
