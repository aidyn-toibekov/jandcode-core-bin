package jandcode.wax.core.utils.upload;

/**
 * upload файл во временном каталоге
 */
public class UploadFile {

    private WaxUploadService owner;
    private String id;
    private String fileName;
    private String clientFileName;
    private long timeCreated;

    public UploadFile(WaxUploadService owner, String fileName, String clientFileName, String id) {
        this.owner = owner;
        this.id = id;
        this.fileName = fileName;
        this.clientFileName = clientFileName;
        this.timeCreated = System.currentTimeMillis();
    }

    public String toString() {
        return getId();
    }

    protected void finalize() throws Throwable {
        remove();
        super.finalize();
    }

    /**
     * Уникальный id этого файла
     */
    public String getId() {
        return id;
    }

    /**
     * Локальное полное имя временного файла
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Имя клиентского файла (то, что выбрал пользователь)
     */
    public String getClientFileName() {
        return clientFileName;
    }

    public void setClientFileName(String clientFileName) {
        this.clientFileName = clientFileName;
    }

    /**
     * Возраст этого файла в милисекундах со времени создания
     */
    public long getAge() {
        return System.currentTimeMillis() - timeCreated;
    }

    /**
     * Удалить файл, который более не нужен
     */
    public void remove() {
        owner.remove(this);
    }

}
