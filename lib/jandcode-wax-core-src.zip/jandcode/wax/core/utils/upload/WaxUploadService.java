package jandcode.wax.core.utils.upload;

import jandcode.app.*;
import jandcode.utils.*;
import org.apache.commons.fileupload.*;
import org.joda.time.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Сервис для обработки upload-файлов
 */
public class WaxUploadService extends CompRt {

    protected Map<String, UploadFile> items = new ConcurrentHashMap<String, UploadFile>();

    public UploadFile find(String id) {
        return items.get(id);
    }

    public UploadFile add(FileItem f) throws Exception {
        UploadFile res = createFrom(f);
        items.put(res.getId(), res);
        return res;
    }

    public UploadFile add(File f) throws Exception {
        UploadFile res = createFrom(f);
        items.put(res.getId(), res);
        return res;
    }

    public void remove(UploadFile f) {
        File ff = new File(f.getFileName());
        ff.delete();
        items.remove(f.getId());
    }

    //////

    protected File createTmpFile() throws Exception {
        DateTime dt = new DateTime();
        return File.createTempFile("jcwaxupload_" + dt.toString("yyyyMMdd") + "_", "_file.tmp");
    }

    protected UploadFile createFrom(FileItem fi) throws Exception {
        File tmp = createTmpFile();
        UtFile.copyStream(fi.getInputStream(), tmp);
        return new UploadFile(this, tmp.getAbsolutePath(), fi.getName(), UtFile.basename(tmp.getName()));
    }

    protected UploadFile createFrom(File fi) throws Exception {
        File tmp = createTmpFile();
        InputStream stm = new FileInputStream(fi);
        UtFile.copyStream(stm, tmp);
        return new UploadFile(this, tmp.getAbsolutePath(), fi.getName(), UtFile.basename(tmp.getName()));
    }

}
