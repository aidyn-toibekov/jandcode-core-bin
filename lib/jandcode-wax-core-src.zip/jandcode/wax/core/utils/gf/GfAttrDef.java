package jandcode.wax.core.utils.gf;

import jandcode.utils.*;

/**
 * Описание атрибута
 */
public class GfAttrDef extends Named {

    private String value = "";
    private String type = "string";
    private boolean ext = false;
    private boolean local = false;

    /**
     * Значение по умолчанию
     */
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isExt() {
        return ext;
    }

    public void setExt(boolean ext) {
        this.ext = ext;
    }

    public boolean isLocal() {
        return local;
    }

    public void setLocal(boolean local) {
        this.local = local;
    }

    //

    public String toString() {
        return getName() + ":" + getType();
    }

}
