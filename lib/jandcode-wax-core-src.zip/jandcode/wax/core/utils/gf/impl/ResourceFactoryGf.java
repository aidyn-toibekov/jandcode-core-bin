package jandcode.wax.core.utils.gf.impl;

import jandcode.utils.vdir.*;
import jandcode.wax.core.utils.gf.*;
import jandcode.web.impl.*;
import org.apache.commons.vfs2.*;
import org.joda.time.*;

import java.io.FileNotFoundException;
import java.io.*;

public class ResourceFactoryGf extends ResourceFactoryCustomText {

    protected FileObject file;

    protected void onGetFiles() throws Exception {
        VFile fn = vdir.findFile(resourcePath);
        if (fn == null) {
            throw new FileNotFoundException(resourcePath);
        }
        file = fn.getRealFileObject();
    }

    protected DateTime onGetLastMod() throws Exception {
        return null;
    }

    protected void onSaveTo(Writer w) throws Exception {
        getRequest().noCache();
        String text = getApp().service(GfService.class).renderFrame(resourcePath);
        w.write(text);
    }

}
