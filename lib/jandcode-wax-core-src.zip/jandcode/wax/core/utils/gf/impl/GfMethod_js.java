package jandcode.wax.core.utils.gf.impl;

import jandcode.utils.*;
import jandcode.wax.core.utils.gf.*;

import java.util.*;

public class GfMethod_js extends GfMethod {

    public String getMethodText() {
        StringBuilder b = new StringBuilder();
        //
        String spaces = "  ";
        b.append(getRealName());
        b.append(": function(").append(params).append(") {");
        b.append('\n').append(spaces).append("var th = this;");
        //
        genAddBody(b, bodyBefore, spaces);
        genAddBody(b, body, spaces);
        genAddBody(b, bodyAfter, spaces);
        //
        b.append("\n}");
        //
        return b.toString();
    }

    protected void genAddBody(StringBuilder b, List<String> texts, String spaces) {
        for (String s : texts) {
            b.append("\n");
            b.append(UtString.indent(s, spaces));
        }
    }

}
