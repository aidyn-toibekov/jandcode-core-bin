package jandcode.wax.core.utils.gf.impl;

import jandcode.wax.core.utils.gf.*;

public class GfClass_js extends GfClass {

    public GfClass_js() {
        baseClass = "Jc.frame.GfContent";
    }

    protected GfMethod createMethod() {
        return new GfMethod_js();
    }

    public String getClassText() {
        StringBuilder b = new StringBuilder();

        b.append("TH.content('").append(baseClass).append("',{");

        //
        for (int i = 0; i < methods.size(); i++) {
            GfMethod m = methods.get(i);
            String mt = m.getMethodText();
            b.append("\n");
            b.append("\n");
            b.append(mt);
            if (i < methods.size() - 1) {
                b.append(",");
            }
        }

        b.append("\n\n});");
        //
        return b.toString();
    }

}
