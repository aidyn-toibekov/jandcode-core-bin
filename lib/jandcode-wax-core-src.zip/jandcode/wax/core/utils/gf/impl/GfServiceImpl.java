package jandcode.wax.core.utils.gf.impl;

import jandcode.wax.core.utils.gf.*;
import jandcode.web.*;

import java.util.*;

public class GfServiceImpl extends GfService {

    public String renderFrame(String path) throws Exception {
        OutBuilder b = new OutBuilder(getApp());
        Map args = new HashMap();
        args.put("path", path);
        b.outTml("gf/renderFrame", args, null);
        return b.toString();
    }

}
