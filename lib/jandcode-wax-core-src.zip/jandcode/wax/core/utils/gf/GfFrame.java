package jandcode.wax.core.utils.gf;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.wax.core.utils.gf.impl.*;
import jandcode.wax.core.utils.json.*;
import jandcode.web.*;

/**
 * Представление фрейма на сервере. В gsp-шаблоне этот экземпляр используется
 * в процессе формирования выходного файла и как поставщик утилит.
 */
public class GfFrame extends Comp {

    private GfAttrs attrs = new GfAttrs();
    private GfClass jsClass = new GfClass_js();

    public GfAttrs getAttrs() {
        return attrs;
    }

    public GfClass getJsClass() {
        return jsClass;
    }

    ////// model

    /**
     * Возвращает модель по умолчанию. Все остальные методы связанные с
     * моделью работают с ней.
     */
    public Model getModel() {
        return getApp().service(ModelService.class).getModel();
    }

    /**
     * Возвращает модель по имени
     */
    public Model getModel(String name) {
        return getApp().service(ModelService.class).getModel(name);
    }

    public Domain getDomain(String name) {
        return getModel().getDomain(name);
    }

    public Domain createDomain(String name) {
        return getModel().createDomain(name);
    }

    public Object daoinvoke(String daoName, String methodName, Object... args) throws Exception {
        return getModel().daoinvoke(daoName, methodName, args);
    }

    public Dao createDao(String daoName) {
        return getModel().createDao(daoName);
    }

    public <A extends Dao> A createDao(Class<A> cls) {
        return getModel().createDao(cls);
    }

    public DataStore createStore(String domainName) {
        return getModel().createStore(domainName);
    }

    public DataRecord createRecord(String domainName) {
        return getModel().createRecord(domainName);
    }

    /**
     * Разрешение словарей для указанного объекта
     *
     * @param data объект (DataStore, DataRecord ...)
     * @throws Exception
     */
    public void resolveDicts(Object data) throws Exception {
        daoinvoke("dict.utils/default", "resolveDictsFor", data);
    }

    //////

    public SGridDataStore createSGridStore(String daoName) {
        SGridDataStore st = getModel().getObjectFactory().create(SGridDataStore.class);
        st.setDaoName(daoName);
        return st;
    }

    public STreeDataStore createSTreeStore(String daoName) {
        STreeDataStore st = getModel().getObjectFactory().create(STreeDataStore.class);
        st.setDaoName(daoName);
        return st;
    }

    ////// json

    /**
     * Конвертация объекта в json по правилам dbm. Т.е. получается map {type:'xxx',value:'yyy'},
     * которую понимают утилиты json на клиенте
     */
    public String toDbmJson(Object v) {
        return UtJson.toString(getApp().service(WaxJsonService.class).toJson(v, getModel()));
    }

    /**
     * Конвертация объекта в json
     */
    public String toJson(Object v) {
        return UtJson.toString(v);
    }

}
