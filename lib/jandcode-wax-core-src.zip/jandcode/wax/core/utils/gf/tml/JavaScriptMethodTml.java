package jandcode.wax.core.utils.gf.tml;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;
import jandcode.wax.core.utils.gf.*;

public class JavaScriptMethodTml extends BaseGfTml {

    public void doGfRender() throws Exception {
        //
        VariantMap a = getArgs();
        GfFrame f = getGfFrame();
        //
        String name = a.getValueString("method");
        if (UtString.empty(name)) {
            name = "init";
        }
        //
        GfMethod m = f.getJsClass().findMetod(name, true);
        //
        String realName = a.getValueString("realName");
        if (!UtString.empty(realName)) {
            m.setRealName(realName);
        }
        //
        String params = a.getValueString("params");
        if (!UtString.empty(params)) {
            if (!UtString.empty(m.getParams())) {
                if (!m.getParams().equals(params)) {
                    throw new XError("Параметры метода [{0}] отличаются в разных описаниях в теге {1}", params, getName());
                }
            } else {
                m.setParams(params);
            }
        }
        //
        String txt = null;
        if (getBody() != null) {
            txt = grabBody().toString();
        }
        //
        if (txt != null) {
            txt = makeJsText(txt);
            m.addBody(txt, GfMethod.P_DEFAULT);
        }
        //
    }

    /**
     * Возвращает js текст по txt
     *
     * @param txt исходный текст, полученный в body тега
     * @return текст метода js
     * @throws Exception
     */
    protected String makeJsText(String txt) throws Exception {
        return txt;
    }

}
