package jandcode.wax.core.utils.gf.tml;

import jandcode.web.*;

/**
 * Тег для включения в тестовый gsp текста фрейма с автоматическим показом его.
 */
public class TstFrameTml extends Tml {

    protected void onRender() throws Exception {
        include("/utils/gf/tml/tstFrame.gsp");
    }

}
