package jandcode.wax.core.utils.gf.tml;

public class GroovyTml extends BaseGfTml {

    public void doGfRender() throws Exception {
        // просто выполняем код
        grabBody();
    }

}
