package jandcode.wax.core.utils.gf.tml;

import jandcode.utils.*;
import jandcode.utils.variant.*;
import jandcode.utils.vdir.*;
import jandcode.wax.core.utils.gf.*;
import jandcode.wax.core.utils.json.*;
import jandcode.web.*;

import java.util.*;

public class RenderFrameTml extends Tml implements ITmlTagOwner {

    public static final int PLACE_BEFORE = 1;
    public static final int PLACE_DEFAULT = 2;
    public static final int PLACE_AFTER = 3;

    private GfFrame gfFrame;
    private List<BaseGfTml> tags;

    public GfFrame getGfFrame() {
        return gfFrame;
    }

    public boolean needRenderChildTml(String tmlName, Map args, Object body) {
        String[] ar = tmlName.split("/");
        if (ar.length != 2) {
            return true;
        }
        if (ar[0].equals("gf") || ar[0].equals("g")) {
            return false;
        }
        return true;
    }

    public void registerChildTml(Tml tml) {
        if (tml instanceof BaseGfTml) {
            tags.add((BaseGfTml) tml);
        }
    }

    //////

    protected void onRender() throws Exception {
        // path
        String path = getArgs().getValueString("path");
        if (!UtString.empty(path)) {
            path = "/" + VDir.normalize(path);
        }

        tags = new ArrayList<BaseGfTml>();
        LinkedHashMap<String, BaseGfTml> tagsId = new LinkedHashMap<String, BaseGfTml>();
        //
        gfFrame = new GfFrame();
        gfFrame.setApp(getApp());
        getArgs().put("gf", gfFrame);
        GfAttrs attrs = gfFrame.getAttrs();

        // выполняем, вывод игнорируем
        pushBuffer();
        if (!UtString.empty(path)) {
            include(path);
        }
        outBody();
        // рендерим все отложенные
        for (BaseGfTml t : tags) {
            t.render();
            BaseGfTml pt = tagsId.get(t.getId());
            if (pt != null) {
                // уже есть. Собираем бывшие аргументы
                for (String k : pt.getArgs().keySet()) {
                    if (!t.getArgs().containsKey(k)) {
                        t.getArgs().put(k, pt.getArgs().get(k));
                    }
                }
                // обрабатываем аргументы еще раз
                t.render();
            }
            // сораняем в уникальный по id набор
            tagsId.put(t.getId(), t);
        }
        popBuffer();

        // делим
        List<BaseGfTml> attrTags = new ArrayList<BaseGfTml>();
        for (BaseGfTml t : tagsId.values()) {
            if (t instanceof AttrTml) {
                attrTags.add(t);
            }
        }

        List<BaseGfTml> groovyTags = new ArrayList<BaseGfTml>();
        for (BaseGfTml t : tagsId.values()) {
            if (t instanceof GroovyTml) {
                groovyTags.add(t);
            }
        }

        List<BaseGfTml> javascriptTags = new ArrayList<BaseGfTml>();
        for (BaseGfTml t : tagsId.values()) {
            if (t instanceof JavaScriptMethodTml) {
                javascriptTags.add(t);
            }
        }


        // 1) атрибуты
        doGfRender(attrTags);

        // default attrs values
        WaxJsonService svc = getApp().service(WaxJsonService.class);
        for (GfAttrDef a : attrs.getAttrDefs()) {
            Object value = svc.fromString(a.getType(), a.getValue(), gfFrame.getModel());
            attrs.put(a.getName(), value);
        }

        // забираем параметры
        grabRequestParams();

        // 2) серверный код
        doGfRender(groovyTags);

        // 3) генерация js

        // базовый js
        generateBaseJs();

        // остальные js
        doGfRender(javascriptTags);

        // атрибуты для js
        generateAttrsBind();

        // формируем js
        out("<script type=\"text/javascript\">\n");
        out(gfFrame.getJsClass().getClassText());
        if (!UtString.empty(path)) {
            out("\n//@ sourceURL=");
            out(path);
        }
        out("\n</script>");
    }

    protected void doGfRender(Collection<BaseGfTml> tmls) throws Exception {
        for (BaseGfTml t : tmls) {
            if (t.getPlace() == PLACE_BEFORE) {
                t.doGfRender();
            }
        }
        for (BaseGfTml t : tmls) {
            if (t.getPlace() == PLACE_DEFAULT) {
                t.doGfRender();
            }
        }
        for (BaseGfTml t : tmls) {
            if (t.getPlace() == PLACE_AFTER) {
                t.doGfRender();
            }
        }
    }

    protected void generateAttrsBind() {
        // bind attrs to js
        GfAttrs attrs = gfFrame.getAttrs();
        if (attrs.size() > 0) {
            StringBuilder b = new StringBuilder();
            for (String n : attrs.keySet()) {
                GfAttrDef adef = attrs.findAttrDef(n);
                if (adef != null) {
                    if (adef.isLocal()) {
                        // локальные не отдаем на клиента
                        continue;
                    }
                }
                Object v = attrs.get(n);
                String vv = gfFrame.toDbmJson(v);
                b.append("th.").append(n).append("=");
                b.append("th.jsonToVar(");
                b.append(vv);
                b.append(");\n");
            }

            //
            for (GfAttrDef adef : attrs.getAttrDefs()) {
                if (!adef.isExt()) {
                    // не внешний
                    continue;
                }
                b.append("th.frame.contentParamNames.push('");
                b.append(adef.getName());
                b.append("');\n");
            }

            GfMethod m = gfFrame.getJsClass().findMetod("initAttrs", true);
            m.addBody(b.toString(), GfMethod.P_BEFORE);

        }
    }

    protected void grabRequestParams() {
        IVariantMap params = getApp().service(WebService.class).getRequest().getParams();
        String gfparams = params.getValueString("gfparams");
        if (UtString.empty(gfparams)) {
            return;
        }
        //
        Map gfp = (Map) UtJson.toObject(gfparams);
        WaxJsonService svc = getApp().service(WaxJsonService.class);
        for (GfAttrDef adef : gfFrame.getAttrs().getAttrDefs()) {
            if (!adef.isExt()) {
                // не внешний!
                continue;
            }
            if (!gfp.containsKey(adef.getName())) {
                continue; // нет параметра
            }
            //
            Map data = (Map) gfp.get(adef.getName());
            Object value = svc.fromJson(data, adef.getType(), gfFrame.getModel());
            gfFrame.getAttrs().put(adef.getName(), value);
        }
    }

    protected void generateBaseJs() throws Exception {
        GfMethod m = gfFrame.getJsClass().findMetod("init", true);
        m.setRealName("onInit");
        StringBuilder b = new StringBuilder();
        b.append("var b = th.b = th.createBuilder();\n");
        b.append("th.items = [];\n");
        m.addBody(b.toString(), GfMethod.P_BEFORE);
    }

}
