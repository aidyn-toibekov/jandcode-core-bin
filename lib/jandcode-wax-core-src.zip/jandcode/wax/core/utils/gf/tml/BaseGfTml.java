package jandcode.wax.core.utils.gf.tml;

import jandcode.utils.*;
import jandcode.wax.core.utils.gf.*;
import jandcode.web.*;

public abstract class BaseGfTml extends Tml {

    private int place = RenderFrameTml.PLACE_DEFAULT;
    private String id;

    public RenderFrameTml getOwner() {
        return (RenderFrameTml) super.getOwner();
    }

    public GfFrame getGfFrame() {
        return getOwner().getGfFrame();
    }

    public int getPlace() {
        return place;
    }

    public String getId() {
        return id;
    }

    /**
     * В этом методе нужно сделать свою инициализацию, но не render!
     */
    protected void onRender() throws Exception {
        super.onRender();
        String s;

        // place
        s = getArgs().getValueString("place");
        if ("before".equals(s)) {
            place = RenderFrameTml.PLACE_BEFORE;
        } else if ("after".equals(s)) {
            place = RenderFrameTml.PLACE_AFTER;
        }

        // id
        s = getArgs().getValueString("id");
        if (UtString.empty(s)) {
            s = "__GF__" + getNextId();
        }
        id = s;

    }

    /**
     * В этом месте сделать render того, что нужно
     */
    public void doGfRender() throws Exception {
    }

}
