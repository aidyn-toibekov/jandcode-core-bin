package jandcode.wax.core.utils.gf.tml;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;
import jandcode.wax.core.utils.gf.*;

public class AttrTml extends BaseGfTml {

    public void doGfRender() throws Exception {
        //
        VariantMap a = getArgs();
        GfFrame f = getGfFrame();
        //
        String an = a.getValueString("name");
        if (UtString.empty(an)) {
            throw new XError("name not defined");
        }
        //
        GfAttrDef attr = f.getAttrs().findAttrDef(an, true);

        if (a.containsKey("value")) {
            attr.setValue(a.getValueString("value"));
        }
        if (a.containsKey("type")) {
            attr.setType(a.getValueString("type"));
        }
        if (a.containsKey("ext")) {
            attr.setExt(a.getValueBoolean("ext"));
        }
        if (a.containsKey("local")) {
            attr.setLocal(a.getValueBoolean("local"));
        }
        //
    }

}
