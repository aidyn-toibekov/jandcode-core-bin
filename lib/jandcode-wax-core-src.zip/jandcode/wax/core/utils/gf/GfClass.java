package jandcode.wax.core.utils.gf;

import jandcode.utils.*;

/**
 * Генератор класса
 */
public abstract class GfClass extends Named {

    protected String baseClass = "";
    protected ListNamed<GfMethod> methods = new ListNamed<GfMethod>();

    public GfMethod findMetod(String name, boolean autoCreate) {
        GfMethod m = methods.find(name);
        if (m == null && autoCreate) {
            m = createMethod();
            m.setName(name);
            methods.add(m);
        }
        return m;
    }

    public ListNamed<GfMethod> getMethods() {
        return methods;
    }

    /**
     * Создает экземпляр правильного метода
     *
     * @return
     */
    protected abstract GfMethod createMethod();

    /**
     * Текст класса
     *
     * @return
     */
    public abstract String getClassText();


}
