package jandcode.wax.core.utils.gf;

import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;
import jandcode.wax.core.model.*;

import java.util.*;

/**
 * Специальный DataStore, который является враппером вокруг DataStore и
 * предназначен для использования в SGrid.
 * <p/>
 * Особенности:
 * - настраивается только на dao с интерфейсом jandcode.wax.core.model.IWaxLoadSqlFilterDao
 * - предоставляет всю дополнительную информацию сам. Т.е. нужно просто указать имя dao
 * и параметры для метода load, все остальное делается автоматом.
 */
public class SGridDataStore extends WrapperDataStore implements IModelLink, IModelLinkSet {

    private Model model;
    private String daoName;
    private String daoMethodLoad = "load";
    private String daoMethodLoadRec = "loadRec";
    private IVariantMap loadParams = new VariantMap();
    private long pageSize;
    private Dao dao;
    private Object result;

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public String getDaoName() {
        return daoName;
    }

    public void setDaoName(String daoName) {
        this.daoName = daoName;
    }

    public String getDaoMethodLoad() {
        return daoMethodLoad;
    }

    public void setDaoMethodLoad(String daoMethodLoad) {
        this.daoMethodLoad = daoMethodLoad;
    }

    public String getDaoMethodLoadRec() {
        return daoMethodLoadRec;
    }

    public void setDaoMethodLoadRec(String daoMethodLoadRec) {
        this.daoMethodLoadRec = daoMethodLoadRec;
    }

    public IVariantMap getLoadParams() {
        return loadParams;
    }

    public long getPageSize() {
        return pageSize;
    }

    public void setPageSize(long pageSize) {
        this.pageSize = pageSize;
    }

    ///////


    public DataStore getWrapped() {
        if (wrapped == null) {
            Dao dao = getDao();
            if (dao instanceof IWaxLoadSqlFilterDao) {
                wrapped = getModel().createStore(((IWaxLoadSqlFilterDao) dao).getDomainResult());
            } else {
                wrapped = getModel().createStore(dao.getDomain().getName());
            }
        }
        return super.getWrapped();
    }

    public Dao getDao() {
        if (dao == null) {
            dao = getModel().createDao(getDaoName());
        }
        return dao;
    }

    public String getDomainFilter() {
        Dao d = getDao();
        if (d instanceof IWaxLoadSqlFilterDao) {
            return ((IWaxLoadSqlFilterDao) d).getDomainFilter();
        } else {
            return null;
        }
    }

    protected void wrapResult(Object res, String methodName) {
        if (res instanceof DataTreeNode) {
            res = ((DataTreeNode) res).getStore();
            if (res == null) {
                throw new XError("dao-метод {0}.{1} возвращает DataTreeNode, но корневой узел не имеет ссылки на store", getDaoName(), methodName);
            }
        }
        //
        if (res instanceof DataStore) {
            setWrapped((DataStore) res);
        } else if (res instanceof DataRecord) {
            setWrapped(((DataRecord) res).getStore());
        } else {
            throw new XError("dao-метод {0}.{1} должен возвращать DataStore, DataRecord или DataTreeNode для использования в SGridDataStore", getDaoName(), methodName);
        }
    }

    public void load(Map params) throws Exception {
        Dao dao = getDao();
        //
        if (params != null) {
            getLoadParams().putAll(params);
        }
        //
        result = null;
        result = getModel().daoinvoke(dao, getDaoMethodLoad(), getLoadParams());
        wrapResult(result, getDaoMethodLoad());
    }

    public void loadRec(long id) throws Exception {
        Dao dao = getDao();
        //
        result = null;
        result = getModel().daoinvoke(dao, getDaoMethodLoadRec(), id);
        wrapResult(result, getDaoMethodLoadRec());
    }

    /**
     * Результат выполнения dao-метода
     */
    public Object getResult() {
        return result;
    }

    /**
     * Результат как tree или null, если результат не дерево
     */
    public DataTreeNode getResultTreeNode() {
        if (getResult() instanceof DataTreeNode) {
            return (DataTreeNode) getResult();
        }
        return null;
    }
}
