package jandcode.wax.core.utils.gf;

/**
 * Специальный DataStore, который является враппером вокруг DataStore и
 * предназначен для использования в STree.
 */
public class STreeDataStore extends SGridDataStore {
}
