package jandcode.wax.core.utils.gf;

import jandcode.utils.*;
import jandcode.utils.variant.*;

/**
 * Атрибуты фрейма. Это VariantMap с дополнительным внутрунним списком
 * описания атрибутов getAttrDefs().
 */
public class GfAttrs extends VariantMap {

    private ListNamed<GfAttrDef> attrDefs = new ListNamed<GfAttrDef>();

    public GfAttrDef findAttrDef(String name, boolean autoCreate) {
        GfAttrDef m = attrDefs.find(name);
        if (m == null && autoCreate) {
            m = new GfAttrDef();
            m.setName(name);
            attrDefs.add(m);
        }
        return m;
    }

    public GfAttrDef findAttrDef(String name) {
        return findAttrDef(name, false);
    }

    public ListNamed<GfAttrDef> getAttrDefs() {
        return attrDefs;
    }

    //////

}
