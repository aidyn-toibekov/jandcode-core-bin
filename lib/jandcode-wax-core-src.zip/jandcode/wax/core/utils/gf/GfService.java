package jandcode.wax.core.utils.gf;

import jandcode.app.*;

/**
 * Сервис поддержки gf-фреймов
 */
public abstract class GfService extends CompRt {

    /**
     * Рендерит фрейм
     *
     * @param path виртуальный путь до файла gf
     * @return html текст для возврата клиенту
     */
    public abstract String renderFrame(String path) throws Exception;

}
