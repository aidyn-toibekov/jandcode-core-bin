package jandcode.wax.core.utils.gf;

import jandcode.utils.*;

import java.util.*;

/**
 * Представление метода
 */
public abstract class GfMethod extends Named {

    public static final int P_BEFORE = 1;
    public static final int P_DEFAULT = 2;
    public static final int P_AFTER = 3;

    protected List<String> bodyBefore = new ArrayList<String>();
    protected List<String> bodyAfter = new ArrayList<String>();
    protected List<String> body = new ArrayList<String>();

    protected String params = "";
    protected String realName = "";

    public abstract String getMethodText();

    public void addBody(String text, int place) {
        List<String> b = body;
        if (place == P_BEFORE) {
            b = bodyBefore;
        } else if (place == P_AFTER) {
            b = bodyAfter;
        }
        //
        text = UtString.normalizeIndent(text);
        onAddBody(b, text);
    }

    protected void onAddBody(List<String> b, String text) {
        b.add(text);
    }

    public void setParams(String params) {
        this.params = params;
    }

    public String getParams() {
        return params;
    }

    public String getRealName() {
        if (UtString.empty(realName)) {
            return getName();
        }
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

}
