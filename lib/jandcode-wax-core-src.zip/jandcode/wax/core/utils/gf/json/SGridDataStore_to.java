package jandcode.wax.core.utils.gf.json;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.gf.*;
import jandcode.wax.core.utils.json.*;
import jandcode.wax.core.utils.json.convertor.*;

import java.util.*;

public class SGridDataStore_to extends DataStore_to {

    public Object toJson(Object v, Model model) {
        Map m = (Map) super.toJson(v, model);
        SGridDataStore st = (SGridDataStore) v;
        //
        Map<String, Object> instdata = new HashMap<String, Object>();
        instdata.put("daoname", st.getDaoName());
        instdata.put("daomethod", st.getDaoMethodLoad());
        List prms = new ArrayList();
        prms.add(st.getLoadParams());
        instdata.put("daoparams", prms);
        //
        String dnf = st.getDomainFilter();
        if (dnf != null) {
            instdata.put("filterDomain", dnf);
        }
        //
        m.put("instdata", makeInstData(instdata, model));
        //
        return m;
    }

    protected Map makeInstData(Map<String, Object> instdata, Model model) {
        WaxJsonService svc = model.getApp().service(WaxJsonService.class);
        Map res = new HashMap();
        for (String k1 : instdata.keySet()) {
            Object v1 = instdata.get(k1);
            res.put(k1, svc.toJson(v1, model));
        }
        return res;
    }

    protected void storeToMap(DataStore store, List listdata, Map dictdata, MapBuilder b) {
        SGridDataStore st = (SGridDataStore) store;
        DataTreeNode tn = st.getResultTreeNode();
        if (tn == null) {
            super.storeToMap(store, listdata, dictdata, b);
        } else {
            DataTreeNode_to totree = new DataTreeNode_to();
            totree.nodeToJson(listdata, dictdata, tn, b);
        }
    }

}
