package jandcode.wax.core.utils;

import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.utils.variant.*;
import jandcode.wax.core.utils.json.*;
import jandcode.web.*;

/**
 * Расширение Tml утилитами для использования в gsp.
 * Обычно используется так (в gsp):
 * <p/>
 * WaxTml th = new WaxTml(this)
 */
public class WaxTml extends Tml {

    public WaxTml(Tml delegate) {
        setDelegate(delegate);
    }

    ////// app

    public <A extends Object> A service(Class<A> clazz) {
        return getApp().service(clazz);
    }

    ////// web

    /**
     * Параметры request
     */
    public IVariantMap getParams() {
        return getRequest().getParams();
    }

    ////// model

    /**
     * Возвращает модель по умолчанию. Все остальные методы связанные с
     * моделью работают с ней.
     */
    public Model getModel() {
        return getApp().service(ModelService.class).getModel();
    }

    /**
     * Возвращает модель по имени
     */
    public Model getModel(String name) {
        return getApp().service(ModelService.class).getModel(name);
    }

    public Domain getDomain(String name) {
        return getModel().getDomain(name);
    }

    public Domain createDomain(String name) {
        return getModel().createDomain(name);
    }

    public Object daoinvoke(String daoName, String methodName, Object... args) throws Exception {
        return getModel().daoinvoke(daoName, methodName, args);
    }

    public Dao createDao(String daoName) {
        return getModel().createDao(daoName);
    }

    public <A extends Dao> A createDao(Class<A> cls) {
        return getModel().createDao(cls);
    }

    public DataStore createStore(String domainName) {
        return getModel().createStore(domainName);
    }

    public DataRecord createRecord(String domainName) {
        return getModel().createRecord(domainName);
    }

    ////// json

    /**
     * Конвертация объекта в json по правилам dbm. Т.е. получается map {type:'xxx',value:'yyy'},
     * которую понимают утилиты json на клиенте
     */
    public String toDbmJson(Object v) {
        return UtJson.toString(getApp().service(WaxJsonService.class).toJson(v, getModel()));
    }

    /**
     * Конвертация объекта в json
     */
    public String toJson(Object v) {
        return UtJson.toString(v);
    }

}
