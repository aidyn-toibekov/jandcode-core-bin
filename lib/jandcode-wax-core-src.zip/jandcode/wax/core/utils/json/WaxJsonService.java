package jandcode.wax.core.utils.json;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * Сервис для работы с моделью через json. В том числе и вызов dao.
 * Для javaScript.
 */
public class WaxJsonService extends CompRt {

    protected Convertor nullConvertor;
    protected List<Convertor> convertors = new ArrayList<Convertor>();
    protected Map<Class, Convertor> convertorsByClass = new HashMap<Class, Convertor>();
    protected HashMapNoCase<JsType> jstypes = new HashMapNoCase<JsType>();
    protected HashMapNoCase<Class> shortTypes = new HashMapNoCase<Class>();

    class Convertor {
        Class clsValue;
        ToJson toJson;
        FromString fromString;
        Map<String, FromJson> fromJson = new LinkedHashMapNoCase<FromJson>();
        int index;
    }

    class JsType {
        String name;
        Class prefferedType;
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt z = rt.findChild("type");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                Convertor cnv = new Convertor();
                cnv.toJson = (ToJson) UtClass.createInst(z1.getValueString("tojson"));
                String cnFromString = z1.getValueString("fromstring");
                if (!UtString.empty(cnFromString)) {
                    cnv.fromString = (FromString) UtClass.createInst(cnFromString);
                }
                cnv.toJson.setJsonType(z1.getValueString("jsontype", "string"));
                Rt fromList = z1.findChild("from");
                if (fromList != null) {
                    for (Rt from : fromList.getChilds()) {
                        FromJson fjs = (FromJson) getApp().getObjectFactory().create(from);
                        cnv.fromJson.put(from.getName(), fjs);
                    }
                }
                if (z1.hasName("null")) {
                    nullConvertor = cnv;
                } else {
                    cnv.clsValue = getApp().getClass(z1.getName());
                    cnv.index = convertors.size();
                    convertors.add(cnv);
                    convertorsByClass.put(cnv.clsValue, cnv);
                }
            }
        }
        //
        z = rt.findChild("jstype");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                JsType jst = new JsType();
                jst.name = z1.getName();
                String cn = z1.getValueString("type");
                if (!UtString.empty(cn)) {
                    jst.prefferedType = getApp().getClass(cn);
                }
                jstypes.put(jst.name, jst);
            }
        }
        //
        z = rt.findChild("shorttype");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                shortTypes.put(z1.getName(), UtClass.getClass(z1.getValueString("class")));
            }
        }
        // сортируем по наследственности. Более общие предки должны быть дальше от конца
        Collections.sort(convertors, new Comparator<Convertor>() {
            public int compare(Convertor o1, Convertor o2) {
                if (o2.clsValue.isAssignableFrom(o1.clsValue)) {
                    return -1;
                } else {
                    return 1;
                }
            }
        });
        //
    }

    /**
     * Конвертация значения из json в тип данных для dao
     *
     * @param data          данные json вида: {type:"TYPE",value: XXX}
     * @param prefferedType предпочтительный тип
     * @param model         из какой модели
     * @return значение
     */
    public Object fromJson(Map data, Class prefferedType, Model model) {
        String type = UtString.toString(data.get("type"));
        Object value = data.get("value");
        //
        if (prefferedType == null) {
            // не указан, определяем автоматически (это для databox нужно)
            JsType jst = jstypes.get(type);
            if (jst == null) {
                throw new XError(UtLang.t("Не известный json-тип [{0}]", type));
            }
            if (jst.prefferedType == null) {
                throw new XError(UtLang.t("Для json-типа [{0}] неуказан java-тип по умолчанию", type));
            }
            prefferedType = jst.prefferedType;
            // уточняем для чисел и boolean
            if (value != null && Double.class == prefferedType) {
                if (value instanceof Integer || value.getClass() == int.class) {
                    prefferedType = Integer.class;
                } else if (value instanceof Long || value.getClass() == long.class) {
                    prefferedType = Long.class;
                } else if (value instanceof Boolean || value.getClass() == boolean.class) {
                    prefferedType = Boolean.class;
                }
            }
        }
        //
        Convertor cnv = convertorsByClass.get(prefferedType);
        if (cnv == null) {
            throw new XError(UtLang.t("Не найден конвертор из json для класса [{0}]", prefferedType.getName()));
        }
        FromJson fj = cnv.fromJson.get(type);
        if (fj == null) {
            throw new XError(UtLang.t("Не найден конвертор из json-типа [{1}] для класса [{0}]", prefferedType.getName(), type));
        }
        return fj.fromJson(value, prefferedType, model);
    }

    /**
     * Конвертация значения из json в тип данных для dao
     *
     * @param data          данные json вида: {type:"TYPE",value: XXX}
     * @param shortTypeName короткое имя предпочтительного типа
     * @param model         из какой модели
     * @return значение
     */
    public Object fromJson(Map data, String shortTypeName, Model model) {
        Class prefferedType = shortTypes.get(shortTypeName);
        if (prefferedType == null) {
            throw new XError(UtLang.t("Не найден тип с коротким именем [{0}]", shortTypeName));
        }
        return fromJson(data, prefferedType, model);
    }

    /**
     * Конвертация значения, полученного из dao в json представление вида: {type:"TYPE",value: XXX}
     *
     * @param value исходное значение
     * @return json map
     */
    public Map toJson(Object value, Model model) {
        Convertor cnv = null;
        if (value == null) {
            cnv = nullConvertor;
        } else {
            Class cls = value.getClass();
            cnv = convertorsByClass.get(cls);
            if (cnv == null) {
                for (Convertor z : convertors) {
                    if (z.clsValue.isAssignableFrom(cls)) {
                        cnv = z;
                        break;
                    }
                }
            }
            if (cnv == null) {
                throw new XError(UtLang.t("Не найден конвертор в json для класса [{0}]", cls.getName()));
            }
        }
        //
        Map res = new LinkedHashMap();
        res.put("type", cnv.toJson.getJsonType());
        res.put("value", cnv.toJson.toJson(value, model));
        return res;
    }

    /**
     * Конвертация строкового значения в объект java
     *
     * @param value исходное значение
     * @return объект
     */
    public Object fromString(Class prefferedType, String value, Model model) {
        Convertor cnv = convertorsByClass.get(prefferedType);
        FromString fs = null;
        if (cnv == null) {
            for (Convertor z : convertors) {
                if (z.clsValue.isAssignableFrom(prefferedType)) {
                    cnv = z;
                    break;
                }
            }
        }
        if (cnv != null) {
            fs = cnv.fromString;
        }
        if (fs == null) {
            throw new XError(UtLang.t("Не найден конвертор из строки для класса [{0}]", prefferedType));
        }
        //
        return fs.fromString(value, prefferedType, model);
    }

    /**
     * Конвертация строкового значения в объект java
     *
     * @param value исходное значение
     * @return объект
     */
    public Object fromString(String shortTypeName, String value, Model model) {
        Class prefferedType = shortTypes.get(shortTypeName);
        if (prefferedType == null) {
            throw new XError(UtLang.t("Не найден конвертор из строки для короткого типа [{0}]", shortTypeName));
        }
        return fromString(prefferedType, value, model);
    }

    /**
     * Домен в json
     *
     * @param domain
     * @return
     */
    public Map domainToJson(Domain domain) {
        JsonDomainCnv cnv = new JsonDomainCnv();
        return cnv.toJson(domain);
    }

    /**
     * Выполнение метода dao
     *
     * @throws Exception
     */
    public Object daoinvoke(Map contextParams, Model model, String domainName, String daomethod, List mapParams) throws Exception {
        if (UtString.empty(domainName)) {
            throw new XError("dao not specified");
        }
        //
        if (UtString.empty(daomethod)) {
            throw new XError("daomethod not specified");
        }
        //
        if (mapParams == null) {
            throw new XError("daoparams not specified");
        }
        //
        Method dm = model.getDaoService().getDaoMethod(domainName, daomethod);
        //
        List daoparamsCnv = mapParamsToMethodParams(mapParams, dm, model);
        //
        Object res = model.daoinvoke(contextParams, domainName, daomethod, daoparamsCnv.toArray());
        //
        return res;
    }

    /**
     * Выполнение метода dao
     *
     * @throws Exception
     */
    public Object daoinvoke(Model model, String domainName, String daomethod, List mapParams) throws Exception {
        return daoinvoke(null, model, domainName, daomethod, mapParams);
    }

    /**
     * Конвертируем параметры полученные от клиента в параметры метода
     */
    public List mapParamsToMethodParams(List mapParams, Method method, Model model) {
        Class[] mparams = method.getParameterTypes();
        if (mparams.length != mapParams.size()) {
            throw new XError("method {0} need {1} params", method.getName(), mparams.length);
        }
        //
        ArrayList daoparamsCnv = new ArrayList();
        for (int i = 0; i < mparams.length; i++) {
            Object p = fromJson((Map) mapParams.get(i), mparams[i], model);
            daoparamsCnv.add(p);
        }
        return daoparamsCnv;
    }

}
