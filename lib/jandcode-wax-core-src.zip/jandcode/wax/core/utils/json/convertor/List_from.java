package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class List_from extends FromJson {

    public Object fromJson(Object v, Class prefferedType, Model model) {
        if (v instanceof List) {
            return v;
        }
        return new ArrayList();
    }

}
