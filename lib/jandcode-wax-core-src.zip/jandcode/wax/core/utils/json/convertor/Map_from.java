package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class Map_from extends FromJson {

    public Object fromJson(Object v, Class prefferedType, Model model) {

        if (v instanceof Map) {
            return v;
        }
        return new HashMap();
    }

}
