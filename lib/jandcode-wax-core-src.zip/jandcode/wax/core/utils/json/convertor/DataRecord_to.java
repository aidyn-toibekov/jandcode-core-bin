package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class DataRecord_to extends DataStore_to {

    public Object toJson(Object v, Model model) {
        //
        JsonDomainCnv dc = new JsonDomainCnv();
        Domain domain = ((IDomainLink) v).getDomain();
        Map m = dc.toJsonDynamicStruct(domain);  // структура, возможно динамическая
        //
        MapBuilder b = new MapBuilder();
        List listdata = b.getList(m, "data");
        Map dictdata = b.getMap(m, "dictdata");

        Map datarec = new LinkedHashMap();
        recToMap((DataRecord) v, datarec, dictdata, b);
        listdata.add(datarec);

        if (dictdata.size() == 0) {
            m.remove("dictdata");
        }

        // clientdata
        Object clientdata = ((DataRecord) v).getProp("clientdata");
        if (clientdata != null) {
            m.put("clientdata", clientdata);
        }

        //
        return m;
    }

}
