package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

public class Boolean_from extends FromJson {

    public Object fromJson(Object v, Class prefferedType, Model model) {
        return UtCnv.toBoolean(v);
    }

}
