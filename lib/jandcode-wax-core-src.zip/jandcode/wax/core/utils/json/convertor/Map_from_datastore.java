package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;

import java.util.*;

public class Map_from_datastore extends DataStore_from {

    public Object fromJson(Object v, Class prefferedType, Model model) {
        Map m = (Map) v;
        List lst = getDataList(m);
        if (lst.size() == 0) {
            return new HashMap();
        }
        return lst.get(0);
    }

}
