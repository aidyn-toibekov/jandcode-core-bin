package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

/**
 * Возвращает DateTime!
 */
public class DateTime_to extends ToJson {

    public Object toJson(Object v, Model model) {
        if (v == null) {
            return UtDate.EMPTY_DATE;
        }
        return UtCnv.toDateTime(v);
    }

}
