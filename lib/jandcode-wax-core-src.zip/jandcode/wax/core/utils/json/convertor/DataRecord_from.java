package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.dbm.data.*;

public class DataRecord_from extends DataStore_from {

    public Object fromJson(Object v, Class prefferedType, Model model) {
        DataStore store = (DataStore) super.fromJson(v, prefferedType, model);
        //
        if (store.hasProp("clientdata")) {
            store.getCurRec().setProp("clientdata", store.getProp("clientdata"));
            store.setProp("clientdata", null);
        }
        //
        return store.getCurRec();
    }
}
