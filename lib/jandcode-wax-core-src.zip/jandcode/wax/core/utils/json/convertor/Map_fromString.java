package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;
import jandcode.web.*;

import java.util.*;

public class Map_fromString extends FromString {
    public Object fromString(String v, Class prefferedType, Model model) {
        Object res = UtJson.toObject(v);
        if (res instanceof Map) {
            return res;
        }
        return new HashMap();
    }
}
