package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class DataBox_to extends ToJson {

    public Object toJson(Object v, Model model) {
        WaxJsonService svc = model.getApp().service(WaxJsonService.class);
        DataBox box = (DataBox) v;
        for (String key : box.keySet()) {
            Object value = box.get(key);
            Map m = svc.toJson(value, model);
            box.put(key, m);
        }
        return box;
    }

}
