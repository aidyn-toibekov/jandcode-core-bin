package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class DataStore_from extends FromJson {

    public Object fromJson(Object v, Class prefferedType, Model model) {
        Map m = (Map) v;
        Domain d = createDomain(model, getStructMap(m));
        DataStore store = UtData.createStore(d);
        List lst = getDataList(m);
        //
        for (Object recData : lst) {
            DataRecord rec = store.add();
            rec.setValues((Map) recData);
        }
        //
        if (m.containsKey("clientdata")) {
            store.setProp("clientdata", m.get("clientdata"));
        }
        //
        return store;
    }

    protected Domain createDomain(Model model, Map struct) {
        String tn = UtString.toString(struct.get("name"));
        Domain domain = model.createDomain(tn);
        return domain;
    }

    protected List getDataList(Map m) {
        Object a = m.get("data");
        if (a instanceof List) {
            return (List) a;
        }
        return new ArrayList();
    }

    protected Map getStructMap(Map m) {
        Object a = m.get("struct");
        if (a instanceof Map) {
            return (Map) a;
        }
        return new HashMap();
    }

}
