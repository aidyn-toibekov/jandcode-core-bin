package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

import java.util.*;

public class DataTreeNode_to extends DataStore_to {

    public Object toJson(Object v, Model model) {
        DataTreeNode root = (DataTreeNode) v;

        Map m = new LinkedHashMap();

        MapBuilder b = new MapBuilder();
        Map dictData = b.getMap(m, "dictdata");
        List data = b.getList(m, "data");

        nodeToJson(data, dictData, root, b);

        if (dictData.size() == 0) {
            m.remove("dictdata");
        }

        return m;
    }

    public void nodeToJson(List records, Map dictData, DataTreeNode root, MapBuilder b) {
        for (DataTreeNode node : root.getChilds()) {
            DataRecord rec = node.getRecord();
            if (rec == null) continue;
            //
            Map mm = new LinkedHashMap();
            recToMap(rec, mm, dictData, b);
            records.add(mm);
            //
            if (node.hasChilds()) {
                List childs = b.getList(mm, "data");
                nodeToJson(childs, dictData, node, b);
            } else {
                mm.put("leaf", true);
            }
        }
    }

}
