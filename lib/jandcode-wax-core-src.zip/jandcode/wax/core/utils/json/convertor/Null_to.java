package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;

public class Null_to extends ToJson {

    public Object toJson(Object v, Model model) {
        return null;
    }

}
