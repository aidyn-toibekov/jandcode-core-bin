package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;

public class String_fromString extends FromString {
    public Object fromString(String v, Class prefferedType, Model model) {
        if (v == null) {
            v = "";
        }
        return v;
    }
}
