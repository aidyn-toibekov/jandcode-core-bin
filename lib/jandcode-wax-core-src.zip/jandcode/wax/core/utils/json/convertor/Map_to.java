package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class Map_to extends ToJson {

    public Object toJson(Object v, Model model) {
        if (v instanceof Map) {
            return v;
        }
        return new HashMap();
    }

}
