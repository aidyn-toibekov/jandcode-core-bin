package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;

public class Null_from extends FromJson {

    public Object fromJson(Object v, Class prefferedType, Model model) {
        return null;
    }

}
