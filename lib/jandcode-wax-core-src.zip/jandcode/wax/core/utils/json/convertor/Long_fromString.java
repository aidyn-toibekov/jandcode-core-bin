package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

public class Long_fromString extends FromString {
    public Object fromString(String v, Class prefferedType, Model model) {
        return UtCnv.toLong(v);
    }
}
