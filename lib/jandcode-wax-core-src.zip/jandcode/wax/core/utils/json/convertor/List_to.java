package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class List_to extends ToJson {

    public Object toJson(Object v, Model model) {
        if (v instanceof List) {
            return v;
        }
        return new ArrayList();
    }

}
