package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class DataStore_to extends ToJson {

    public Object toJson(Object v, Model model) {
        //
        JsonDomainCnv dc = new JsonDomainCnv();
        Domain domain = ((IDomainLink) v).getDomain();
        Map m = dc.toJsonDynamicStruct(domain);  // структура, возможно динамическая
        //
        MapBuilder b = new MapBuilder();
        List listdata = b.getList(m, "data");
        Map dictdata = b.getMap(m, "dictdata");
        storeToMap((DataStore) v, listdata, dictdata, b);
        if (dictdata.size() == 0) {
            m.remove("dictdata");
        }

        // clientdata
        Object clientdata = ((DataStore) v).getProp("clientdata");
        if (clientdata != null) {
            m.put("clientdata", clientdata);
        }

        //
        return m;
    }

    protected void recToMap(DataRecord rec, Map data, Map dictdata, MapBuilder b) {
        for (Field field : rec.getDomain().getFields()) {
            if (rec.isValueNull(field)) {
                continue;
            }
            Object value = rec.getValue(field);
            data.put(field.getName(), value);
            if (field.hasDict()) {
                Map dd = b.getMap(dictdata, field.getDictName().toLowerCase());
                String vs = UtString.toString(value);
                if (!dd.containsKey(vs)) {
                    Map dmr = b.getMap(dd, vs);
                    Dict dict = rec.getStore().getDict(field.getDictName());
                    for (Field df : dict.getDomain().getFields()) {
                        if (df.hasName("id")) {
                            continue;
                        }
                        dmr.put(df.getName(), rec.getDictValue(field.getName(), df.getName()));
                    }
                }
            }
        }
    }

    protected void storeToMap(DataStore store, List listdata, Map dictdata, MapBuilder b) {
        for (DataRecord rec : store) {
            Map data = new LinkedHashMap();
            recToMap(rec, data, dictdata, b);
            listdata.add(data);
        }
    }

}
