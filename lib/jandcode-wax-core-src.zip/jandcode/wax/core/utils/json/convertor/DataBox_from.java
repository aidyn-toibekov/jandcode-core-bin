package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

import java.util.*;

public class DataBox_from extends FromJson {

    public Object fromJson(Object v, Class prefferedType, Model model) {
        WaxJsonService svc = model.getApp().service(WaxJsonService.class);

        DataBox box = new DataBox();
        Map data = (Map) v;

        //
        for (Object o : data.keySet()) {
            String key = UtString.toString(o);
            Map value = (Map) data.get(o);
            Object v2 = svc.fromJson(value, (Class) null, model);
            box.put(key, v2);
        }
        //

        return box;
    }

}
