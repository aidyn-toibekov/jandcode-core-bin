package jandcode.wax.core.utils.json.convertor;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.json.*;

public class Int_to extends ToJson {

    public Object toJson(Object v, Model model) {
        if (v == null) {
            return 0;
        }
        return UtCnv.toInt(v);
    }

}
