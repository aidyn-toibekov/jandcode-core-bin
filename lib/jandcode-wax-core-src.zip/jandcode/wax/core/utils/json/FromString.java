package jandcode.wax.core.utils.json;

import jandcode.dbm.*;

/**
 * Конвертор из строки
 */
public abstract class FromString {

    /**
     * Реализация fromString
     *
     * @param v             строковое значение
     * @param prefferedType предпочтительный тип. Конкретный тип, который требуется
     * @param model         в контексте какой модели
     * @return объект нужного типа
     */
    public abstract Object fromString(String v, Class prefferedType, Model model);

}
