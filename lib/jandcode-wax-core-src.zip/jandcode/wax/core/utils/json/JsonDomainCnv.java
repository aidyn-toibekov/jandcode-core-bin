package jandcode.wax.core.utils.json;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.wax.core.utils.*;

import java.util.*;

public class JsonDomainCnv {

    protected MapBuilder b = new MapBuilder();

    /**
     * Структуру домена в json
     */
    public Map toJson(Domain d) {
        Map m = new LinkedHashMap();
        Map dm = new WaxDomainExt(d).toJson();
        m.put("struct", dm);
        return m;
    }

    /**
     * Структуру домена в json с проверкой донамической структуры
     */
    public Map toJsonDynamicStruct(Domain d) {
        Map m = new LinkedHashMap();
        Map dm;
        if (d.isModified()) {
            dm = new WaxDomainExt(d).toJson();
            dm.put("name", "sys"); // ставим имя sys - это домен без полей
        } else {
            dm = new WaxDomainExt(d).toJsonSimple();
        }
        m.put("struct", dm);
        return m;
    }

}
