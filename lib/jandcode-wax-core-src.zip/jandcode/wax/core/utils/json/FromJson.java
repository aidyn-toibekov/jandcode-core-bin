package jandcode.wax.core.utils.json;

import jandcode.dbm.*;

/**
 * Конвертор из json
 */
public abstract class FromJson {

    /**
     * Реализация fromJson
     *
     * @param v             значение из json
     * @param prefferedType предпочтительный тип. Конкретный тип, который требуется
     * @param model         в контексте какой модели
     * @return объект нужного типа
     */
    public abstract Object fromJson(Object v, Class prefferedType, Model model);

}
