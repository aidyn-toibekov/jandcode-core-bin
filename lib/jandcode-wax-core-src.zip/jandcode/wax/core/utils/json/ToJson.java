package jandcode.wax.core.utils.json;

import jandcode.dbm.*;

/**
 * Конвертор в json
 */
public abstract class ToJson {

    private String jsonType = "UNKNOWN";

    /**
     * Тип json (string, datastore ...)
     */
    public String getJsonType() {
        return jsonType;
    }

    public void setJsonType(String jsonType) {
        this.jsonType = jsonType;
    }

    /**
     * Реализация конвертора
     *
     * @param v     значение для конвертации
     * @param model
     * @return значение для свойства 'value' в json
     */
    public abstract Object toJson(Object v, Model model);

}
