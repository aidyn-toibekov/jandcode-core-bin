package jandcode.wax.core.utils;

import jandcode.dbm.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Расширение для домена от wax
 */
public class WaxDomainExt extends DomainExt {

    public WaxDomainExt(Domain domain) {
        super(domain);
    }

    class ComparatorFieldOrder implements Comparator<WaxFieldExt> {
        public int compare(WaxFieldExt o1, WaxFieldExt o2) {
            Integer i1 = o1.getWeight();
            Integer i2 = o2.getWeight();
            int n = i1.compareTo(i2);
            if (n == 0) {
                i1 = o1.getComp().getIndex();
                i2 = o2.getComp().getIndex();
                n = i1.compareTo(i2);
            }
            return n;
        }
    }

    /**
     * Является ли домен словарем
     */
    public boolean isDict() {
        return getModel().getDictService().hasDict(getComp().getName());
    }

    /**
     * Возвращает словарь, которым является домен (если isDict()==true)
     *
     * @return
     */
    public Dict getDict() {
        return getModel().getDictService().getDict(getComp().getName());
    }

    /**
     * Возвращает список полей в правильном порядке (по weight)
     */
    public List<Field> getFieldsByOrder() {
        List<WaxFieldExt> fields = new ArrayList<WaxFieldExt>();
        for (Field f : getComp().getFields()) {
            fields.add(new WaxFieldExt(f));
        }
        Collections.sort(fields, new ComparatorFieldOrder());
        List<Field> res = new ArrayList<Field>();
        for (WaxFieldExt waxFieldExt : fields) {
            res.add(waxFieldExt.getComp());
        }
        return res;
    }

    ////// json

    /**
     * Конвертация описания домена в json
     */
    public Map toJson() {
        Map m = new LinkedHashMap();
        Domain d = getComp();
        MapBuilder b = new MapBuilder();
        //.
        m.put("name", d.getName());
        //
        String s = d.getTitle();
        if (!UtString.empty(s)) {
            m.put("title", UtLang.t(d.getTitle()));
        }
        //
        if (isDict()) {
            // есть такой словарь, как и имя домена
            Dict dict = getDict();
            Map dictInfo = new HashMap();
            dictInfo.put("defaultField", dict.getDefaultField());
            dictInfo.put("resolve", dict.isResolve());
            dictInfo.put("domain", dict.getDomain().getName());
            m.put("dict", dictInfo);
        }
        //
        List flst = b.getList(m, "fields");
        for (Field f : getFieldsByOrder()) {
            Map fm = new WaxFieldExt(f).toJson();
            flst.add(fm);
        }
        //
        Rt r1 = d.getRt().findChild("js");
        if (r1 != null) {
            b.joinJson(m, r1);
        }
        //
        return m;
    }

    /**
     * Конвертация простого описания домена в json (без структуры!)
     */
    public Map toJsonSimple() {
        Map m = new LinkedHashMap();
        Domain d = getComp();
        m.put("name", d.getName());
        return m;
    }

}
