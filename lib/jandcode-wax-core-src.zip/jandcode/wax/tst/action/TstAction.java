package jandcode.wax.tst.action;

import jandcode.utils.*;
import jandcode.utils.vdir.*;
import jandcode.web.*;
import jandcode.web.action.*;

import java.util.*;

/**
 * Тестирование.
 * url: /tst/PATH рассматривается либо как каталог либо как gsp в каталоге '/tst'
 */
public class TstAction extends Static {

    protected String rootDirName = "tst";

    public class RootTst {
        public String path;
        public List<DirTst> dirs = new ArrayList<DirTst>();

        public RootTst(String path) {
            this.path = path;
            dirs.add(new DirTst(".", path));
            //
            VDir vd = getApp().service(WebService.class).getResourceService().getVirtualDir();
            List<VFile> lst = vd.findFiles(path);
            for (VFile it : lst) {
                String nm = UtFile.filename(it.getVirtualPath());
                if (nm.startsWith("_")) {
                    continue;
                }
                if (it.isDir()) {
                    dirs.add(new DirTst(nm, it.getVirtualPath()));
                }
            }
        }

        public List<String> getBreadcrum() {
            ArrayList<String> res = new ArrayList<String>();
            StringBuilder sb = new StringBuilder();
            String[] ar = VDir.normalize(path).split("/");
            for (String s : ar) {
                sb.append("/").append(s);
                res.add(sb.toString());
            }
            return res;
        }

    }

    public class DirTst {
        public String name;
        public String path;
        public List<String> files = new ArrayList<String>();
        public List<String> dirs = new ArrayList<String>();

        public DirTst(String name, String path) {
            this.name = name;
            this.path = path;
            //
            VDir vd = getApp().service(WebService.class).getResourceService().getVirtualDir();
            List<VFile> lst = vd.findFiles(path);
            for (VFile it : lst) {
                String nm = UtFile.basename(it.getRealPath());
                if (nm.startsWith("_")) {
                    continue;
                }
                if (it.isFile()) {
                    String ext = UtFile.ext(it.getRealPath());
                    if ("gsp".equals(ext)) {
                        String s1 = UtFile.removeExt(it.getVirtualPath());
                        String ext2 = UtFile.ext(s1);
                        if (UtString.empty(ext2)) {
                            files.add(s1);
                        }
                    }
                } else {
                    dirs.add(UtFile.removeExt(it.getVirtualPath()));
                }
            }
        }
    }


    protected void onExec() throws Exception {
        VDir vd = getApp().service(WebService.class).getResourceService().getVirtualDir();
        String pi = VDir.normalize(getPathInfo());
        //
        if (pi.length() == 0) {
            showIndex("/" + rootDirName);
        } else {
            VFile ff;
            String fn = "/" + rootDirName + "/" + pi;
            ff = vd.findFile(fn);
            if (ff != null && ff.isDir()) {
                showIndex(fn);
            } else {
                String ext = UtFile.ext(fn);
                if (!UtString.empty(ext)) {
                    // есть расширение - передаем на стандартную обработку статического файла
                    super.onExec();
                } else {
                    fn = fn + ".gsp";
                    ff = vd.findFile(fn);
                    if (ff != null && ff.isFile()) {
                        render(fn);
                    } else {
                        super.onExec();
                    }
                }
            }
        }
    }

    protected void showIndex(String path) {
        render("/tst/_index.gsp", UtCnv.toMap(
                "root", new RootTst(path), "rootDir", rootDirName
        ));
    }

}
