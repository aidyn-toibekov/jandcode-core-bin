Ext.define('Jc.tst.ControlPanel', {
    extend: 'Jc.Frame',

    onInit: function() {
        this.callParent();
        //
        this.title = "Tst Control Panel";
    }
});