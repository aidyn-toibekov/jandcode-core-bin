/**
 * Просмотр md5 хешей для строк
 */
Ext.define('Jc.tst.Md5Hash', {
    extend: 'Jc.Frame',

    onInit: function() {
        this.callParent();
        var th = this;
        Ext.apply(th, {
            title: 'Md5Hash'
        });
        //
        var b = th.createBuilder();
        //
        var srctext, md5label;
        this.items = [
            b.pageheader(th.title, 'tools'),
            b.databox({
                items: [
                    b.label("Введите произвольную строку"),
                    b.box({
                        items: [
                            srctext = b.input(null, {value: ''}),
                            b.button({text: 'Показать MD5', icon: 'ok', onExec: function() {
                                var s = Jc.requestText({
                                    url: 'js/tst/Md5Hash-calc.html',
                                    params: {
                                        s: srctext.getValue()
                                    }
                                });
                                md5label.setValue(s);
                            }})
                        ]
                    }),
                    b.delim("Результат"),
                    b.label("MD5"),
                    md5label = b.datalabel(null, {value: ''})
                ]
            })
        ];
    }

});
 