/**
 * Приложение для devtools
 */
Ext.define('Jc.tst.App', {
    extend: 'Jc.BaseApp',

    createMainMenu: function() {
        //
        var menu = Jc.menu;
        var item = Jc.action;
        //
        var logo = Ext.create('Jc.control.PageHeader', {
            text: Jc.ini.app.title,
            icon: Jc.url("images/icon32/options.png"),
            width: 240,
            listeners: {
                click: {
                    element: 'el',
                    fn: function() {
                        Jc.app.home();
                    }
                }
            }
        });
        //
        var mm = [
            logo,
            '-',
            item({text: "Главная", icon: "home", scope: Jc.app, onExec: Jc.app.home}),
            item({text: 'RtAppViewer', icon: "admin", scope: Jc.app, onExec: Jc.app.tst_RtAppViewer}),
            item({text: 'Md5Hash', icon: "admin", scope: Jc.app, onExec: Jc.app.tst_Md5Hash}),
            item({text: 'IconViewer', icon: "admin", scope: Jc.app, onExec: Jc.app.tst_iconViewer}),
            item({text: 'DomainViewer', icon: "admin", scope: Jc.app, onExec: Jc.app.tst_domainViewer})
        ];
        //
        return mm;
    },

    //////

    home: function() {
        Jc.app.showFrameSingle("Jc.tst.Home");
    },

    tst_RtAppViewer: function() {
        this.showFrameSingle("Jc.tst.RtAppViewer");
    },

    tst_Md5Hash: function() {
        this.showFrameSingle("Jc.tst.Md5Hash");
    },

    tst_iconViewer: function() {
        var id = "tst_iconViewer";
        if (Jc.app.activateFrame(id)) return;
        var f = Ext.create('Jc.frame.Gsp', {
            id: id,
            url: Jc.url('js/tst/iconViewer.html')
        });
        f.showFrame();
    },

    tst_domainViewer: function() {
        this.showFrameSingle("Jc.tst.DomainList");
    }

});
 