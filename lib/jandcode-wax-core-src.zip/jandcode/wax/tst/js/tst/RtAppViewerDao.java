package jandcode.wax.tst.js.tst;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.wax.core.model.*;

import java.util.*;

public class RtAppViewerDao extends WaxDao {

    /**
     * Узлы. parent находится в context.node
     *
     * @param expanded true - раскрытое дерево
     */
    @DaoMethod
    public DataStore nodes(boolean expanded) throws Exception {
        String root = ut.getContextParams().getValueString("node");
        //

        DataStore res = ut.createStore("/jandcode/wax/tst/js/tst/RtAppViewer.tree.domain.xml");

        Rt apprt = getApp().getRt();
        Rt node = apprt.findChild(root);
        if (node != null) {
            if (expanded) {
                for (Rt x : node.getChilds()) {
                    addRtNode(res, x, expanded);
                }
            } else {
                for (Rt x : node.getSelfChilds()) {
                    addRtNode(res, x, expanded);
                }
            }
        }

        return res;
    }

    /**
     * Добавить узел в результат
     *
     * @param res      куда
     * @param x        что
     * @param expanded раскрытая?
     */
    private void addRtNode(DataStore res, Rt x, boolean expanded) {
        DataRecord r = res.add();
        r.setValue("id", x.getPath());
        r.setValue("text", x.getName());
        Collection<Rt> childs;
        if (expanded) {
            childs = x.getChilds();
        } else {
            childs = x.getSelfChilds();
        }
        r.setValue("leaf", childs.size() == 0);
        r.setValue("iconCls", "icon-xml-node");
        Rt own = x.getOwner();
        if (own != null) {
            String icon = "";
            if (own.hasName("service")) {
                icon = "tool";
            } else if (own.hasName("domain")) {
                icon = "table";
            }
            if (!UtString.empty(icon)) {
                r.setValue("iconCls", "icon-" + icon);
            }
        }
    }

}
