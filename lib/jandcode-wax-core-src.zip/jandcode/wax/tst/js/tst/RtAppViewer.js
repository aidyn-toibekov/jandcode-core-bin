/**
 * Просмотр текущей apprt
 */
Ext.define('Jc.tst.RtAppViewer', {
    extend: 'Jc.Frame',

    onInit: function() {
        this.callParent();
        var th = this;
        Ext.apply(th, {
            title: 'RtAppViewer',
            layout: {type: 'vbox', align: 'stretch'}
        });
        //
        var store = Jc.createTreeStore("/jandcode/wax/tst/js/tst/RtAppViewer.tree.domain.xml", {
            daoname: "jandcode.wax.tst.js.tst.RtAppViewerDao",
            daomethod: "nodes",
            daoparams: [true],
            root: {
                id: '',
                expanded: true
            }
        });
        //
        var b = th.createBuilder(store);
        //
        var tree = this.tree = b.tree({
            store: store,
            region: 'west',
            width: 250,
            split: true
        });
        //
        var content = b.panel({
            region: 'center',
            cls: 'jc-frame',
            bodyCls: 'jc-frame-body',
            layout: 'auto',
            autoScroll: true
        });
        //
        var v_expanded;
        this.items = [
            b.pageheader(th.title, 'tools'),
            b.panel({
                flex: 1,
                border: false,
                layout: {type: 'border'},
                items: [tree, content]
            })
        ];
        //////

        th.toolbar = [
            ' ',
            b.label("Раскрытая"),
            v_expanded = b.input(null, {jsclass: "Checkbox", value: true})
        ];

        var showXml = function(r) {
            var txt = Jc.requestText({
                url: Jc.url("js/tst/RtAppViewer-getxml.html"),
                params: {
                    path: r.get("id"),
                    expanded: v_expanded.getValue()
                }
            });
            content.update(txt);
        };

        tree.on("itemclick", function(v, r) {
            showXml(r);
        });

        v_expanded.on("change", function(v, r) {
            var r = tree.getSelectionModel().getSelection();
            if (!r) return;
            showXml(r[0]);
        });
    }

});
 