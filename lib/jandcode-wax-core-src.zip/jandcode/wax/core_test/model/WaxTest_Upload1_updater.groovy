package jandcode.wax.core_test.model

import jandcode.dbm.dao.*
import jandcode.dbm.data.*
import jandcode.utils.error.*
import jandcode.wax.core.model.*
import jandcode.wax.core.utils.upload.*

class WaxTest_Upload1_updater extends WaxDao {

    @DaoMethod
    public void upload1(DataRecord rec) throws Exception {
        rec = ut.createRecord(rec)
        ut.validateRecord(rec)
        UtData.outTable(rec)

        UploadFile f = rec.getValue("up1");
        println f.getFileName()
        println f.getClientFileName()

        ut.checkErrors()
        f.remove()
    }

    @DaoMethod
    public void mupload1(DataRecord rec) throws Exception {
        rec = ut.createRecord(rec)
        UtData.outTable(rec)

        List<UploadFile> f = rec.getValue("mup1");
        println "FILES mup1::${f.size()}"
        for (f1 in f) {
            println f1.getFileName()
            println f1.getClientFileName()
            f1.remove()
        }
        println "============"

        f = rec.getValue("mup2");
        println "FILES mup2::${f.size()}"
        for (f1 in f) {
            println f1.getFileName()
            println f1.getClientFileName()
            f1.remove()
        }
        println "============"

        throw new XError("Error!")
    }

}
