package jandcode.wax.core_test.model;

import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.*;
import jandcode.utils.rt.*;

import java.util.*;

public class WaxTest_Tab1_default extends jandcode.dbm.dao.SimpleIdeDao {

    @DaoMethod
    public DataRecord rec1() throws Exception {
        return super.rec(1);
    }

    /**
     * Генерация динамического store
     *
     * @return
     * @throws Exception
     */
    @DaoMethod
    public DataStore dynamicTab1() throws Exception {
        Domain d = ut.createDomain();
        d.addField("f1", "string");
        d.addField("f2", "int");
        // грузим random
        Rt rt = getRt().getChild("dataloader/r10");
        RandomDataLoader ldr = (RandomDataLoader) getModel().getObjectFactory().create(rt);
        ldr.setDomain(d);
        ldr.load();
        //
        return ldr.getData();
    }

    @DaoMethod
    public DataRecord rec_clientdata1() throws Exception {
        DataRecord r = super.rec(1);
        HashMap m = new HashMap();
        m.put("hello1", 1);
        m.put("hello2", true);
        m.put("hello3", "Hi!");
        r.setProp("clientdata", m);
        return r;
    }

    @DaoMethod
    public DataStore list_clientdata1() throws Exception {
        DataRecord r = super.rec(1);
        HashMap m = new HashMap();
        m.put("hello1", 1);
        m.put("hello2", true);
        m.put("hello3", "Hi!");
        r.getStore().setProp("clientdata", m);
        return r.getStore();
    }

    @DaoMethod
    public void get_rec_clientdata1(DataRecord r) throws Exception {
        System.out.println("******** get_rec_clientdata1***" + r.getProp("clientdata"));
    }

    @DaoMethod
    public void get_list_clientdata1(DataStore r) throws Exception {
        System.out.println("******** get_rec_clientdata1***" + r.getProp("clientdata"));
    }

}
