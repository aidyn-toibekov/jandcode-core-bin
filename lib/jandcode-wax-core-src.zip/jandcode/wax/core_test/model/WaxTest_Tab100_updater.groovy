package jandcode.wax.core_test.model

import jandcode.wax.core.model.*

class WaxTest_Tab100_updater extends WaxUpdaterDao {
}
