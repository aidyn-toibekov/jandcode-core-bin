package jandcode.wax.core_test.model

import jandcode.dbm.sqlfilter.*
import jandcode.wax.core.model.*

class WaxTest_Tab100_list extends WaxLoadSqlFilterDao {

    WaxTest_Tab100_list() {
        domainResult = "WaxTest_Tab100"
        domainFilter = "WaxTest_Tab100.filter"
    }

    protected void onCreateFilter(SqlFilter f) throws Exception {
        f.filter(field: "f_string", type: "contains")

        f.orderBy("id", "id")
        f.orderBy("name", "f_string")

        f.paginate = true;
        f.sql = "select * from ${ut.tableName} where 0=0 order by id"
    }

}
