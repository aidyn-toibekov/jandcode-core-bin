package jandcode.wax.core_test.model;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

import java.util.*;

public class WaxTest_Tree1_default extends SimpleIdeDao {

    /**
     * Дочерние узлы. Используется контекст.
     *
     * @return
     * @throws Exception
     */
    @DaoMethod
    public DataStore nodes() throws Exception {
        Long root = ut.getContextParams().getValueLong("node");
        String sql;
        if (root == 0) {
            sql = "select * from WaxTest_Tree1 where parent is null";
        } else {
            sql = "select * from WaxTest_Tree1 where parent=:id";
        }
        DataStore res = ut.createStore("WaxTest_Tree1.tree");
        ut.loadSql(res, sql, root);
        return res;
    }

    /**
     * Дочерние узлы. Используется контекст и определяется папка/непапка.
     *
     * @return
     * @throws Exception
     */
    @DaoMethod
    public DataStore nodes2() throws Exception {
        Long root = ut.getContextParams().getValueLong("node");
        String sql;
        if (root == 0) {
            sql = "select * from WaxTest_Tree1 where parent is null";
        } else {
            sql = "select * from WaxTest_Tree1 where parent=:id";
        }
        //
        DataStore res = ut.createStore("WaxTest_Tree1.tree");
        ut.loadSql(res, sql, root);

        // определяем папки
        Set ids = UtData.uniqueValues(res, "id");
        DataStore prs = ut.createStore("id");
        if (ids.size() > 0) {
            ut.loadSql(prs, ut.subst("select parent as id from WaxTest_Tree1 where parent in (${ids})", "ids", UtString.join(ids, ",")));
        }
        DataIndex prsIndex = UtData.createIndex(prs, "id");
        //
        for (DataRecord r : res) {
            if (prsIndex.get(r.getValue("id")) != null) {
                r.setValue("leaf", false);
            } else {
                r.setValue("iconCls", "icon-user");
                r.setValue("leaf", true);
            }
        }
        return res;
    }

    @DaoMethod
    public DataTreeNode nodes_all() throws Exception {
        DataStore res = ut.createStore("WaxTest_Tree1.tree");
        ut.loadSql(res, "select * from WaxTest_Tree1");
        DataTreeNode t = UtData.createTreeIdParent(res, "id", "parent");
        return t;
    }

    @DaoMethod
    public DataStore nodesLoad(Map params) throws Exception {
        return nodes2();
    }

}
