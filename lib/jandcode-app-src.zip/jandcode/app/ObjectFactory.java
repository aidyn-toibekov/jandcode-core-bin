package jandcode.app;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.text.*;

/**
 * Создание объектов по Rt.
 * Для создания объекта может использоваться:
 * - rt объект
 * - имя класса объекта
 * - класс объекта
 * <p/>
 * В случае создания по rt, объект получает эту rt, если может конечно
 * (реализует IRtLinkSet).
 * Из rt так или иначе выявляется класс, экземпляр которого нужно создать.
 * Затем производится его создание и инициализация по алгоритмам создателя.
 * <p/>
 * В случае создания по имени класса или классу (когда объект желает иметь Rt)
 * Rt генерится (пустая) и предоставляется объекту.
 */
public class ObjectFactory implements IAppLink {

    protected IIniter defaultBeforeIniter;

    public ObjectFactory(IIniter defaultBeforeIniter) {
        this.defaultBeforeIniter = defaultBeforeIniter;
    }

    public App getApp() {
        if (defaultBeforeIniter instanceof IAppLink) {
            return ((IAppLink) defaultBeforeIniter).getApp();
        }
        if (defaultBeforeIniter instanceof App) {
            return (App) defaultBeforeIniter;
        }
        throw new XError("ObjectFactory не имеет информации о App");
    }

    /**
     * Получение класса по его имени
     *
     * @param className имя класса
     * @return класс или ошибка, если класс не обнаружен
     */
    public Class getClass(String className) {
        return UtClass.getClass(className);
    }

    /**
     * Создание объекта по rt.
     * Если в rt не указан атрибут class, используется класс cls
     */
    public Object create(Rt rt, Class cls, IIniter beforeIniter) {
        if (rt == null) {
            throw new XError("Создание объекта по rt=null невозможно");

        }
        String cn = getClassName(rt);
        if (cn == null) {
            if (cls == null) {
                throw new XError("Не удалось определить класс для rt [{0}]", rt.getPath());
            }
        } else {
            cls = getClass(cn);
        }
        try {
            return doCreate(cls, rt, beforeIniter);
        } catch (Exception e) {
            throw new XErrorMark(e, "создание объекта для rt: " + rt.getPath());
        }
    }

    /**
     * Создание объекта по rt
     */
    public Object create(Rt rt, Class cls) {
        return create(rt, cls, null);
    }

    /**
     * Создание объекта по rt
     */
    public Object create(Rt rt, IIniter beforeIniter) {
        return create(rt, null, beforeIniter);
    }


    /**
     * Создание объекта по rt
     */
    public Object create(Rt rt) {
        return create(rt, null, null);
    }

    /**
     * Создание объекта по классу
     */
    public <A> A create(Class<A> cls, IIniter beforeIniter) {
        try {
            return (A) doCreate(cls, null, beforeIniter);
        } catch (Exception e) {
            throw new XErrorMark(e, MessageFormat.format("создание объекта для класса [{0}]", cls.getName()));
        }
    }

    /**
     * Создание объекта по классу
     */
    public <A> A create(Class<A> cls) {
        return create(cls, null);
    }

    //////

    /**
     * Для rt возвращает ассоциированное имя класса или null, если класс не найден
     */
    public String getClassName(Rt rt) {
        String cn = rt.getValueString("class");
        if (UtString.empty(cn)) {
            return null;
        }
        return cn;
    }

    /**
     * Для rt возвращает ассоциированный класс или null, если класс не найден
     */
    public Class getClass(Rt rt) {
        String cn = getClassName(rt);
        if (cn == null) {
            return null;
        }
        return getClass(cn);
    }

    /**
     * Процесс создания объекта
     *
     * @param cls класс
     * @param rt  Rt (может быть null)
     * @return созданный объект
     */
    protected Object doCreate(Class cls, Rt rt, IIniter beforeIniter) throws Exception {
        Object inst = onCreateInstance(cls);
        if (defaultBeforeIniter != null) {
            defaultBeforeIniter.initObject(inst);
        }
        if (beforeIniter != null) {
            beforeIniter.initObject(inst);
        }
        onBeforeInit(inst);
        setRt(inst, rt);
        onAfterInit(inst);
        return inst;
    }

    /**
     * Присвоение rt. Экземпляр проинициализирован. Если inst не реализует интерфейс
     * IRtLinkSet - метод ничего не делает. rt может быть null, вызов в этом случае игнорируется.
     * Если rt присвоена, вызывается onAfterSetRt
     */
    public void setRt(Object inst, Rt rt) {
        if (rt == null) {
            return;
        }
        if (!(inst instanceof IRtLinkSet)) {
            return;
        }
        ((IRtLinkSet) inst).setRt(rt);
        onAfterSetRt(inst, rt);
    }

    /**
     * Создание экземпляра по классу
     */
    protected Object onCreateInstance(Class cls) throws Exception {
        return cls.newInstance();
    }

    ////// events

    /**
     * Инициализация экземпляра. rt еще не назначена.
     */
    protected void onBeforeInit(Object inst) throws Exception {
    }

    /**
     * Вызывается после того как rt была назначена объекту. rt точно не null.
     */
    protected void onAfterSetRt(Object inst, Rt rt) {
    }

    /**
     * Окончательная инициализация
     */
    protected void onAfterInit(Object inst) throws Exception {
    }

    //////

}
