package jandcode.app;

import jandcode.utils.rt.*;

/**
 * Объект - приложение.
 * Конфигурация приложения доступна через метод {@link App#getRt()}.
 */
public abstract class App implements IRtLink, IServiceHolder, IObjectFactoryLink, IIniter {

    /**
     * Имя файла с конфигурацией приложения по умолчанию.
     */
    public static final String FILE_APP_RT = "app.rt";

    protected static boolean test = false;

    ////// debug/release/test

    /**
     * Возвращает признак отладочного режима
     */
    public abstract boolean isDebug();

    /**
     * Признак того, что приложение работает в release режиме
     */
    public boolean isRelease() {
        return !isDebug();
    }

    /**
     * Признак тестовой среды (т.е. сейчас выполняется unittest)
     */
    public boolean isTest() {
        return test;
    }

    /**
     * Установка тестовой среды. Используется в unittest
     */
    public static void setTest(boolean v) {
        test = v;
    }

    //////

    /**
     * Каталог приложения. Рассматривается как каталог, где приложение
     * установлено. Обычно соответствует каталогу, в котором расположен файл
     * {@link App#FILE_APP_RT}.
     */
    public abstract String getAppdir();

    //////

    /**
     * Возвращает класс по имени (с правильными ClassLoader).
     */
    public abstract Class getClass(String name);

}
