package jandcode.app;

/**
 * Интерфейс для объектов, которым нужно реагировать на присвоение неизвестных
 * рефлексии атрибутов rt.
 */
public interface IUnknownRtAttr {

    /**
     * Вызывается из {@link ReflectService#setRtAttrs(java.lang.Object, jandcode.utils.rt.Rt)}
     * для неизвестных рефлексии атрибутов rt
     *
     * @param name  имя атрибута
     * @param value значение
     */
    void onUnknownRtAttr(String name, Object value);

}
