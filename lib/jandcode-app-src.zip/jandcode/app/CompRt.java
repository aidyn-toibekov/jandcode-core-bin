package jandcode.app;

import jandcode.utils.rt.*;

import java.util.*;

/**
 * Компонент c поддержкой rt-структур.
 */
public class CompRt extends Comp implements IRtLinkSet, IRtLink, ICustomProp {

    protected Rt _rt;
    protected boolean _rtAssigned;
    protected Map<String, Object> props;

    protected void onClone(Comp r) {
        super.onClone(r);
        CompRt f = (CompRt) r;
        if (isUseCloneRt()) {
            if (_rt != null) {
                f._rt = _rt.cloneRt();
            }
        } else {
            f._rt = _rt;
        }
        f._rtAssigned = _rtAssigned;
    }

    /**
     * Загрузить структуру компонента. Структура клонируется и запоминается в объекте.
     * Далее в нее возможно вносить изменения. Это поведение по умолчанию.
     * Некоторые объекты не используют клоны rt для целей оптимизации. Обычно это
     * оговорено в описании компонента.
     * <p/>
     * Переданная структура пропускается через метод onSetRt.
     * <p/>
     * Запоминается только первая переданная структура, она в дальнейшем будет доступна.
     * через getRt()/ Остальные просто пропускаются через метод onSetRt.
     * <p/>
     * Компонент по умолчанию не имеет rt (при простом создании через new). При создании
     * через фабрику ObjectFactory компонент всегда имеет rt, даже если явно не назначали
     * (она будет пустая).
     *
     * @param rt структура
     */
    public void setRt(Rt rt) {
        if (rt == null) {
            return;
        }
        if (_rtAssigned) {
            // не первая rt
            onSetRt(rt);
            return;
        }
        //
        if (isUseCloneRt()) {
            _rt = rt.cloneRt();
        } else {
            _rt = rt;
        }
        //
        if (!hasName()) {
            setName(_rt.getName());
        }
        _rtAssigned = true;
        //
        onSetRt(_rt);
    }

    public Rt getRt() {
        if (_rt == null) {
            _rt = getApp().getRt().createRt("noname");
        }
        return _rt;
    }

    /**
     * Отреагировать на присвоение rt
     */
    protected void onSetRt(Rt rt) {
        setRtAttrs(rt);
    }

    /**
     * Замена rt у экземпляра. Только для внутреннего использования при клонировании.
     *
     * @param newRt новая rt
     */
    public void internal_replaceRt(Rt newRt) {
        _rt = newRt;
    }

    //////

    /**
     * Установить rt атрибуты через рефлексию
     */
    public void setRtAttrs(Rt rt) {
        getApp().service(ReflectService.class).setRtAttrs(this, rt);
    }

    /**
     * Установить rt атрибуты через рефлексию
     */
    public void setRtAttrs(Map attrs) {
        getApp().service(ReflectService.class).setRtAttrs(this, attrs);
    }

    //////

    /**
     * При значении true объект использует клон rt ({@link Rt#cloneRt()}).
     * Иначе используется оригинальный rt. По умолчанию - true (использовать
     * клон). Перекрывается в компонентах, которые желают использовать оригинальный rt.
     */
    protected boolean isUseCloneRt() {
        return true;
    }

    //////

    public void setProp(String name, Object value) {
        if (props == null) {
            props = new HashMap<String, Object>();
        }
        props.put(name, value);
    }

    public Object getProp(String name) {
        if (props == null) {
            return null;
        }
        return props.get(name);
    }

    public boolean hasProp(String name) {
        if (props == null) {
            return false;
        }
        return props.containsKey(name);
    }

    public Object getProp(String name, Object defaultValue) {
        if (props == null) {
            return defaultValue;
        }
        if (props.containsKey(name)) {
            return props.get(name);
        }
        return defaultValue;
    }

    public Map<String, Object> getProps() {
        Map<String, Object> res = new HashMap<String, Object>();
        if (props != null) {
            res.putAll(props);
        }
        return res;
    }


}
