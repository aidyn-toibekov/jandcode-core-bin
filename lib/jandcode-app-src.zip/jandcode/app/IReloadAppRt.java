package jandcode.app;

/**
 * Интерфейс для тех, кто хочет реагировать на изменения {@link App#getRt()} (перезагрузку в
 * отладочном режиме).
 */
public interface IReloadAppRt {

    /**
     * Вызывается при перегрузке {@link App#getRt()}
     */
    void reloadAppRt();

}
