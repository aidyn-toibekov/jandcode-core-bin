package jandcode.app;

/**
 * Конвертор текстовых значений свойств rt в значения для свойств
 */
public interface IPropConvertor {

    /**
     * Из строки в значение для setter
     *
     * @param s исходная строка
     * @return значение, которое можно передавать в setter
     */
    Object fromString(String s);

}
