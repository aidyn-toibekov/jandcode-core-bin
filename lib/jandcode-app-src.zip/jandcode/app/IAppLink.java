package jandcode.app;

/**
 * Ссылка на приложение
 */
public interface IAppLink {

    App getApp();

}
