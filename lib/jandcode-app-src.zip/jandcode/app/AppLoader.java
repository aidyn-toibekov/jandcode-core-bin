package jandcode.app;

import jandcode.app.impl.*;

/**
 * Загрузчик приложения
 */
public class AppLoader {

    /**
     * Создание и загрузка приложения из файла fileName.
     */
    public static App load(String fileName) {
        AppImpl inst = new AppImpl();
        inst.load(fileName);
        return inst;
    }

    /**
     * Создание и загрузка приложения из файла fileName.
     */
    //todo поменять местами параметры
    public static App load(String appdir, String fileName) {
        AppImpl inst = new AppImpl();
        inst.load(appdir, fileName);
        return inst;
    }

}
