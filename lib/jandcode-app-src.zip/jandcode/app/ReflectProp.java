package jandcode.app;

import java.lang.annotation.*;

/**
 * Аннотация для пометки setter, как инициализируемого из конфигурации rt
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface ReflectProp {

    /**
     * Имя атрибута
     */
    public abstract String name() default "";

    /**
     * Конвертор значений атрибута. Значение ReflectProp.class считается как null!
     */
    public abstract Class convertor() default ReflectProp.class;

}