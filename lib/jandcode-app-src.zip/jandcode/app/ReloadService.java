package jandcode.app;

/**
 * Сервис для отслеживания измененных ресурсов и перегрузки их.
 * Вызывать по мере необходимости! Желательно только в отладочном режиме.
 */
public abstract class ReloadService extends CompRt {

    /**
     * Проверить измененные ресурсы
     */
    public abstract void checkChangedResource();

}
