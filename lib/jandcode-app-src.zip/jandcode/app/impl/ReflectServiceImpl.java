package jandcode.app.impl;

import jandcode.app.*;
import jandcode.app.impl.convs.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

public class ReflectServiceImpl extends ReflectService {

    private HashMap<Class, Clazz> classes = new HashMap<Class, Clazz>();
    private HashMap<Class, IPropConvertor> convertors = new HashMap<Class, IPropConvertor>();
    private HashSet<String> scannedPackages = new HashSet<String>();

    /**
     * Метод для установки значения.
     * Может быть:
     * setXXX(Object) - обычный setter. Требуется конвертор.
     * setXXXName(String) - обычный setter для свойства XXX в виде строки. Не требуется конвертор.
     */
    class Setter {

        /**
         * Имя элемента (lowercase)
         */
        String name;

        /**
         * Конвертор значений
         */
        IPropConvertor convertor;

        /**
         * Метод для установки значения
         */
        Method method;

    }


    public class Clazz implements IReflectClazz {

        Class clazz;
        HashMap<String, Setter> setters = new HashMap<String, Setter>();
        private String packageName;

        public Clazz() {
            addIgnoreSetter("name");
            addIgnoreSetter("parent");
            addIgnoreSetter("class");
            addIgnoreSetter("abstract");
            addIgnoreSetter("comment");
            addIgnoreSetter("text");
            addIgnoreSetter("override");
        }

        public boolean invokeSetter(Object inst, String name, Object value) {
            Setter setr = setters.get(name.toLowerCase());
            if (setr == null) {
                return false;
            }

            if (setr.method == null) {
                return true; // ignore
            }

            try {
                if (value instanceof String) {
                    if (setr.convertor != null) {
                        value = setr.convertor.fromString((String) value);
                    }
                }
                setr.method.invoke(inst, value);
            } catch (IllegalAccessException e) {
                throw new XErrorWrap(e.getCause());
            } catch (InvocationTargetException e) {
                throw new XErrorWrap(e);
            }

            return true;
        }

        void addSetter(Setter st) {
            st.name = st.name.toLowerCase();
            Setter exists = setters.get(st.name);
            if (exists != null && exists.convertor != null &&
                    exists.convertor.getClass() == PropConvertorString.class) {
                return; // отдаем преимущества для строковых setter
            }
            if (st.method != null) {
                st.method.setAccessible(true);
            }
            setters.put(st.name, st);
        }


        void addIgnoreSetter(String name) {
            Setter a = new Setter();
            a.name = name.toLowerCase();
            setters.put(a.name, a);
        }

        public Class getCls() {
            return clazz;
        }
    }


    public ReflectServiceImpl() {
        convertors.put(int.class, new PropConvertorInteger());
        convertors.put(long.class, new PropConvertorLong());
        convertors.put(boolean.class, new PropConvertorBoolean());
        convertors.put(double.class, new PropConvertorDouble());
        convertors.put(char.class, new PropConvertorChar());
        convertors.put(Integer.class, new PropConvertorInteger());
        convertors.put(Long.class, new PropConvertorLong());
        convertors.put(Double.class, new PropConvertorDouble());
        convertors.put(Boolean.class, new PropConvertorBoolean());
        convertors.put(String.class, new PropConvertorString());
        convertors.put(Character.class, new PropConvertorChar());
        convertors.put(Object.class, new PropConvertorString());
        convertors.put(Class.class, new PropConvertorClass(this));
        convertors.put(File.class, new PropConvertorFile());
    }

    public Clazz getClazz(Class c) {
        Clazz cls = classes.get(c);
        if (cls == null) {
            try {
                cls = registerClass(c);
            } catch (Exception e) {
                throw new XErrorWrap(e);
            }
        }
        return cls;
    }

    protected Clazz registerClass(Class c) throws Exception {
        Clazz cls;
        synchronized (this) {
            cls = classes.get(c);
            if (cls != null) {
                // уже был зарегистрирован в другом потоке
                return cls;
            }
            // создаем новую конфигурацию
            cls = createClazz(c);
            cls.packageName = c.getPackage().getName();
            // запоминаем
            classes.put(c, cls);
            return cls;
        }
    }

    private Clazz createClazz(Class c) throws Exception {
        Clazz cls = new Clazz();
        cls.clazz = c;

        while (c != null && c != Object.class) {
            Method[] meth = c.getDeclaredMethods();
            for (Method m : meth) {
                addSetter(cls, m);
            }
            c = c.getSuperclass();
        }

        return cls;
    }

    private void errorMethod(ReflectProp anProp, Method m, String msg) {
        if (anProp == null) {
            return;
        }
        String s = "Ошибка в описании метода [" + m.toString() + "] помеченного атрибутом ReflectProp";
        s = s + ": " + msg;
        throw new XError(s);
    }

    /**
     * Добавить сеттер, если метод - сеттер
     */
    private void addSetter(Clazz cls, Method m) throws Exception {
        ReflectProp anProp = m.getAnnotation(ReflectProp.class);

        String mname = m.getName();

        if (mname.length() < 4) {
            errorMethod(anProp, m, "Имя метода меньше 4 симолов");
            return;
        }

        int md = m.getModifiers();
        if (Modifier.isPrivate(md)) {
            errorMethod(anProp, m, "Метод должен быть public или protected");
            return;
        }

        Setter st = new Setter();
        st.name = mname.substring(3);
        st.method = m;

        Class<?>[] mParams = m.getParameterTypes();
        if (mParams.length != 1) {
            errorMethod(anProp, m, "У метода должен быть один параметр");
            return;
        }

        if (anProp != null) {
            if (anProp.name() != null && anProp.name().length() > 0) {
                st.name = anProp.name();
            }
            st.convertor = getConvertor(anProp.convertor());
        } else {
            if (!mname.startsWith("set")) {
                return;
            }
        }

        if (st.convertor == null) {
            st.convertor = getConvertor(mParams[0]);
            if (st.convertor == null) {
                errorMethod(anProp, m, "Тип параметра не совместим. Определите конвертор");
                // если errorMethod не вывалился, то добавляем без конвертора
                // можно будет использовать в asis присвоениях
                cls.addSetter(st);
                return; // неизвестный тип параметра
            }
        }

        if (st.name.endsWith("Name") && mParams[0] == String.class && !st.name.equals("Name")) {
            // для setXxxName(String) добавляем дополнительный обработчик
            Setter stn = new Setter();
            stn.name = st.name.substring(0, st.name.length() - 4);
            stn.method = m;
            stn.convertor = st.convertor;
            cls.addSetter(stn);
        }

        cls.addSetter(st);
    }

    /**
     * Получить конвертор
     *
     * @param aClass или класс конвертора или класс параметра
     * @return конвертор
     */
    private IPropConvertor getConvertor(Class aClass) throws Exception {
        if (aClass == ReflectProp.class) {
            return null;
        }
        IPropConvertor res = convertors.get(aClass);
        if (res != null) {
            return res;
        }
        if (!IPropConvertor.class.isAssignableFrom(aClass)) {
            return null;
        }
        res = (IPropConvertor) aClass.newInstance();
        convertors.put(aClass, res);
        return res;
    }

    ////// service interface  ///////

    private void scanPackage(String packageName) {
        if (!scannedPackages.contains(packageName)) {
            synchronized (this) {
                if (scannedPackages.contains(packageName)) {
                    return;
                }
                List<Class> lst;
                ClassLoader saveldr = Thread.currentThread().getContextClassLoader();
                Thread.currentThread().setContextClassLoader(getClass().getClassLoader());
                try {
                    lst = UtClass.grabPublic(packageName);
                } finally {
                    Thread.currentThread().setContextClassLoader(saveldr);
                }
                for (Class aClass : lst) {
                    getClazz(aClass);
                }
                scannedPackages.add(packageName);
            }
        }
    }

    public List<IReflectClazz> list(String packageName, boolean recursive) {
        scanPackage(packageName);
        ArrayList<IReflectClazz> res = new ArrayList<IReflectClazz>();
        String pns = packageName + ".";
        for (Clazz clazz : classes.values()) {
            if (recursive) {
                if (packageName.equals(clazz.packageName) || clazz.packageName.startsWith(pns)) {
                    res.add(clazz);
                }
            } else {
                if (packageName.equals(clazz.packageName)) {
                    res.add(clazz);
                }
            }
        }
        return res;
    }

    public void setRtAttrs(Object inst, Rt attrs) {
        if (attrs != null) {
            IUnknownRtAttr unk = null;
            if (inst instanceof IUnknownRtAttr) {
                unk = (IUnknownRtAttr) inst;
            }
            IReflectClazz cz = getApp().service(ReflectService.class).getClazz(inst.getClass());
            for (IRtAttr attr : attrs.getAttrs()) {
                String an = attr.getName();
                if (an.startsWith("_")) {
                    continue;
                }
                Object av = attr.getValue();
                if (!cz.invokeSetter(inst, an, av)) {
                    if (unk != null) {
                        unk.onUnknownRtAttr(an, av);
                    }
                }
            }
        }
    }

    public void setRtAttrs(Object inst, Map attrs) {
        if (attrs != null && !attrs.isEmpty()) {
            IUnknownRtAttr unk = null;
            if (inst instanceof IUnknownRtAttr) {
                unk = (IUnknownRtAttr) inst;
            }
            IReflectClazz cz = getApp().service(ReflectService.class).getClazz(inst.getClass());
            for (Object key : attrs.keySet()) {
                String an = key.toString();
                if (an.startsWith("_")) {
                    continue;
                }
                Object av = attrs.get(key);
                if (!cz.invokeSetter(inst, an, av)) {
                    if (unk != null) {
                        unk.onUnknownRtAttr(an, av);
                    }
                }
            }
        }
    }

}