package jandcode.app.impl;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

public class DataDirServiceImpl extends DataDirService {

    protected ListNamed<PathItem> paths = new ListNamed<PathItem>();
    protected PathItem rootPath;

    class PathItem extends Named {
        String pathFromIni;
        String pathReal;

        PathItem(String name, String pathFromIni) {
            setName(name);
            this.pathFromIni = pathFromIni;
        }

        public String getPath() {
            if (pathReal == null) {
                synchronized (this) {
                    if (pathReal == null) {
                        if (hasName("root")) {
                            // для базового
                            if (UtString.empty(pathFromIni)) {
                                pathReal = UtFile.join(getApp().getAppdir(), "datadir");
                            } else {
                                pathReal = UtFile.abs(pathFromIni);
                            }
                        } else {
                            // для остальных
                            if (UtFile.isAbsolute(pathFromIni)) {
                                pathReal = UtFile.abs(pathFromIni);
                            } else if (UtString.empty(pathFromIni)) {
                                pathReal = UtFile.join(rootPath.getPath(), getName());
                            } else {
                                pathReal = UtFile.join(rootPath.getPath(), pathFromIni);
                            }
                        }
                        if (!UtFile.exists(pathReal)) {
                            UtFile.mkdirs(pathReal);
                        }
                    }
                }
            }
            //
            return pathReal;
        }
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt r = getApp().getRt().findChild("app/datadir");
        if (r != null) {
            for (Rt r1 : r.getChilds()) {
                String name = r1.getName();
                String path = r1.getValueString("path");
                if (UtString.empty(path)) {
                    continue;
                }
                PathItem it = new PathItem(name, path);
                paths.add(it);
            }
        }
        //
        rootPath = paths.find("root");
        if (rootPath == null) {
            rootPath = new PathItem("root", "");
            paths.add(rootPath);
        }
        //
    }

    protected PathItem getPathItem(String name) {
        PathItem pi = paths.find(name);
        if (pi == null) {
            synchronized (this) {
                pi = paths.find(name);
                if (pi == null) {
                    pi = new PathItem(name, "");
                }
            }
        }
        return pi;
    }

    public String getDataDir(String name) {
        PathItem pi = getPathItem(name);
        return pi.getPath();
    }
}
