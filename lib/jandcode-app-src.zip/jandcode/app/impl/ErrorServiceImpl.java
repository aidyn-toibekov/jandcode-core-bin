package jandcode.app.impl;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

public class ErrorServiceImpl extends ErrorService {

    private HashMapNoCase<ErrorFormatter> errorFormatters = new HashMapNoCase<ErrorFormatter>();

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);

        Rt z;

        // форматирование ошибок
        z = getApp().getRt().findChild("error/formatter");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                ErrorFormatter f = (ErrorFormatter) getApp().getObjectFactory().create(z1, ErrorFormatterImpl.class);
                errorFormatters.put(z1.getName(), f);
            }
        }

    }

    public ErrorFormatter getErrorFormatter(String name) {
        ErrorFormatter fmt;
        if (getApp().isDebug()) {
            fmt = errorFormatters.get(name + ".debug");
            if (fmt != null) {
                return fmt;
            }
        }
        fmt = errorFormatters.get(name);
        if (fmt != null) {
            return fmt;
        }
        return errorFormatters.get("default");
    }

}

