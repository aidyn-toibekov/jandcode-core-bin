package jandcode.app.impl.convs;


import jandcode.app.*;
import jandcode.utils.*;

public class PropConvertorDouble implements IPropConvertor {

    public Object fromString(String s) {
        return UtCnv.toDouble(s);
    }

}
