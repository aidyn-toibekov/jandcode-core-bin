package jandcode.app.impl.convs;

import jandcode.app.*;

import java.io.*;


public class PropConvertorFile implements IPropConvertor {

    public Object fromString(String s) {
        return new File(s);
    }

}