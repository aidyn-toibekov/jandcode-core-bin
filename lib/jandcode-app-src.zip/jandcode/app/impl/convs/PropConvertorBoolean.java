package jandcode.app.impl.convs;


import jandcode.app.*;
import jandcode.utils.*;

public class PropConvertorBoolean implements IPropConvertor {

    public Object fromString(String s) {
        return UtCnv.toBoolean(s);
    }

}
