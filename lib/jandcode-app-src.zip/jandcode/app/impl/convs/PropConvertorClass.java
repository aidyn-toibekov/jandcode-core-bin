package jandcode.app.impl.convs;

import jandcode.app.*;


public class PropConvertorClass implements IPropConvertor {

    private ReflectService reflectService;

    public PropConvertorClass(ReflectService reflectService) {
        this.reflectService = reflectService;
    }

    public Object fromString(String s) {
        return reflectService.getApp().getObjectFactory().getClass(s);
    }

}