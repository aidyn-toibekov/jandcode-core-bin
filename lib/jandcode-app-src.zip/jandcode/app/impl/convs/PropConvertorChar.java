package jandcode.app.impl.convs;

import jandcode.app.*;

public class PropConvertorChar implements IPropConvertor {

    public Object fromString(String s) {
        if (s.length() == 0) {
            return (char) 0;
        }
        return s.charAt(0);
    }

}
