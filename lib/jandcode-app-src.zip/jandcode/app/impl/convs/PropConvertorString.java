package jandcode.app.impl.convs;

import jandcode.app.*;

public class PropConvertorString implements IPropConvertor {

    public Object fromString(String s) {
        return s;
    }

}