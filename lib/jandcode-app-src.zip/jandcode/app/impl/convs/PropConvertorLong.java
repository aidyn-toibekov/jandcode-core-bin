package jandcode.app.impl.convs;


import jandcode.app.*;
import jandcode.utils.*;


public class PropConvertorLong implements IPropConvertor {

    public Object fromString(String s) {
        return UtCnv.toLong(s);
    }

}