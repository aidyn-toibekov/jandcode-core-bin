package jandcode.app.impl;

import jandcode.app.*;
import jandcode.utils.error.*;

/**
 * Список компонентов для создания r/o заглушек.
 */
public class ListCompDummy<TYPE extends Comp> extends ListComp<TYPE> {

    protected void onAdd(TYPE it) {
        throw new XError("readonly list");
    }

    protected void onRemove(TYPE it) {
        throw new XError("readonly list");
    }

}
