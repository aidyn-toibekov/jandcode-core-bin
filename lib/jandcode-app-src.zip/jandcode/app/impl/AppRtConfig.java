package jandcode.app.impl;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import org.apache.commons.vfs2.*;

import java.util.*;

/**
 * Конфигурация приложения. Загрузка и хранение.
 */
public class AppRtConfig {

    public static final String rtp_APP_APPDIR = "app:appdir";
    public static final String rtp_APP_DEBUG = "app:debug";
    public static final String vfs_CORE_MODULE = "res:jandcode/app/module.rt";

    private Rt rt = new RtRoot();
    private String file;
    private List<RtSource> rtSources;

    /**
     * исходник rt для отслеживания изменившихся файлов
     */
    class RtSource {
        FileObject file;
        long dmod;

        public RtSource(String filename) {
            this.file = UtFile.getFileObject(filename);
            try {
                dmod = this.file.getContent().getLastModifiedTime();
            } catch (FileSystemException e) {
            }
        }

        public boolean isModify() {
            long dmod1 = 0;
            try {
                dmod1 = this.file.getContent().getLastModifiedTime();
            } catch (FileSystemException e) {
            }
            return dmod1 > dmod;
        }
    }

    /**
     * Ссылка на Rt
     */
    public Rt getRt() {
        return rt;
    }

    /**
     * Установить загружаемый файл
     */
    public void setFile(String file) {
        this.file = file;
    }

    public String getFile() {
        return file;
    }

    /**
     * Установить отладочный режимю В этом режиме отслеживаются изменения в загруженных
     * файлах
     */
    public boolean isDebug() {
        return rt.getValueBoolean(rtp_APP_DEBUG, false);
    }

    /**
     * Каталог приложения. Определяется как каталог загружаемого файла, либо
     * явно задается в rt 'app:appdir'
     */
    public String getAppdir() {
        String fn = rt.getValueString(rtp_APP_APPDIR);
        if (UtString.empty(fn) && file != null) {
            fn = UtFile.vfsPathToLocalPath(file);
            fn = UtFile.path(fn);
        }
        if (UtString.empty(fn)) {
            fn = UtFile.getWorkdir().getAbsolutePath();
        }
        return fn;
    }

    /**
     * Загрузить конфигурацию
     */
    public void load() throws Exception {
        if (UtString.empty(file)) {
            throw new XError("Не указан файл для загрузки");
        }
        //
        Rt tempRt = new RtRoot();
        RtLoader ldr = new RtLoader(tempRt);
        // сначала core-зависимость
        ldr.includePath(tempRt, vfs_CORE_MODULE, false, true);
        // потом все остальное
        UtLoad.fromFileObject(ldr, file);
        //
        rt = tempRt;
        //
        if (isDebug()) {
            doSourcesGrab(tempRt);
        }
    }


    /**
     * Собрать все исходники rt, из которых загружались
     */
    protected void doSourcesGrab(Rt tempRt) {
        List<String> lst = UtRt.getRootSources(tempRt);
        rtSources = new ArrayList<RtSource>();
        for (String s : lst) {
            RtSource rs = new RtSource(s);
            rtSources.add(rs);
        }
    }

    /**
     * Ищет изменившийся файл. Если найден, возвращается полное имя файла.
     * Иначе - null. Работает только в отладочном режиме.
     */
    public String findModifySource() {
        if (!isDebug() || rtSources == null) {
            return null;
        }
        for (RtSource rs : rtSources) {
            if (rs.isModify()) {
                return rs.file.toString();
            }
        }
        return null;
    }

}
