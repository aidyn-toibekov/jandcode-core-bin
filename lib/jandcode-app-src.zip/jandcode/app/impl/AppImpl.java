package jandcode.app.impl;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import org.apache.commons.logging.*;

public class AppImpl extends App implements ICheckChangedResource {

    protected static Log log = LogFactory.getLog(App.class);

    private AppRtConfig appRtConfig = new AppRtConfig();
    private String appdir = null;
    private ServiceContainer services = new ServiceContainer();
    private boolean debug;
    private ObjectFactory objectFactory = new ObjectFactory(this);

    /**
     * Фабрика для создания сервисов
     */
    class ServiceObjectFactory extends ObjectFactory {

        // присваивается в getClassName
        Class serviceClass;

        public ServiceObjectFactory(IIniter defaultBeforeIniter) {
            super(defaultBeforeIniter);
        }

        public String getClassName(Rt rt) {
            String sn = super.getClassName(rt);
            serviceClass = AppImpl.this.getClass(rt.getName());
            return sn;
        }

        protected Object onCreateInstance(Class cls) throws Exception {
            log.info("create service [" + serviceClass.getName() + "] class [" + cls.getName() + "]");
            Object inst = super.onCreateInstance(cls);
            // т.к. сервисы глобальны, сначала создаем, регистрируем, потом инициализируем
            services.add(serviceClass, inst);
            return inst;
        }

    }

    //////

    public Rt getRt() {
        return appRtConfig.getRt();
    }

    public String getAppdir() {
        if (appdir == null) {
            return appRtConfig.getAppdir();
        }
        return appdir;
    }

    public boolean isDebug() {
        return debug;
    }

    public ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    ////// config

    public void load(String filename) {
        load(null, filename);
    }

    public void load(String appdir, String filename) {
        this.appdir = appdir;
        appRtConfig.setFile(filename);
        doLoad(true);
    }

    protected void doLoad(boolean firstLoad) {
        log.info("load: " + appRtConfig.getFile());
        try {
            appRtConfig.load();
            if (firstLoad) {
                init();
            }
        } catch (Exception e) {
            throw new XErrorMark(e, appRtConfig.getFile());
        }
        log.info("load OK");
    }


    protected void init() throws Exception {
        // каталог приложения, если явно не установлен
        if (appdir == null) {
            appdir = appRtConfig.getAppdir();
        }
        // отладочный режим
        debug = appRtConfig.isDebug();

        // само приложение добавляем в сервисы, оно jandcode.app.ICheckChangedResource
        services.add(App.class, this);

        // т.к. сервисы глобальны, сначала создаем, регистрируем, потом инициализируем
        Rt rtServices = getRt().findChild("service");
        if (rtServices != null) {
            ServiceObjectFactory fact = new ServiceObjectFactory(this);
            for (Rt x : rtServices.getChilds()) {
                fact.create(x);
            }
        }

        // пре-активируем
        for (IBeforeActivate a : services.impl(IBeforeActivate.class)) {
            a.beforeActivate();
        }

        // активируем
        for (IActivate a : services.impl(IActivate.class)) {
            a.activate();
        }

        // пост-активируем
        for (IAfterActivate a : services.impl(IAfterActivate.class)) {
            a.afterActivate();
        }

        // все

    }

    //////

    public <A extends Object> A service(Class<A> clazz) {
        return services.get(clazz);
    }

    public ServiceContainer getServices() {
        return services;
    }

    ////// class

    protected Class classForName(String className) throws ClassNotFoundException {
        return Class.forName(className, true, getClass().getClassLoader());
    }

    public Class getClass(String className) {
        return UtClass.getClass(className);
    }

    ////

    /**
     * Проверить, что исходники rt поменялись и перегрузить их
     */
    public void checkChangedResource() {
        String ff = appRtConfig.findModifySource();
        if (ff == null) {
            return;
        }
        log.info("found changed rt: " + ff);
        doLoad(false);
        //
        for (IReloadAppRt a : services.impl(IReloadAppRt.class)) {
            a.reloadAppRt();
        }
    }

    public void initObject(Object obj) throws Exception {
        if (obj instanceof IAppLinkSet) {
            ((IAppLinkSet) obj).setApp(this);
        }
    }
}
