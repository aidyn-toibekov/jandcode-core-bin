package jandcode.app.impl;

import jandcode.app.*;

public class ReloadServiceImpl extends ReloadService {

    /**
     * Последнее время проверки
     */
    private long _lastTime = 0;

    /**
     * Сейчас работает
     */
    private boolean _working;

    /**
     * Интервал проверки перезагрузки в
     */
    private long _reloadInterval = 1000;


    /**
     * Интервал проверки в милисекундах
     */
    public void setReloadInterval(long reloadInterval) {
        _reloadInterval = reloadInterval;
    }

    public long getReloadInterval() {
        return _reloadInterval;
    }

    /**
     * Проверить измененные ресурсы
     */
    public void checkChangedResource() {
        if (_working) {
            return; // уже работает
        }
        _working = true;
        long n = System.currentTimeMillis() - _lastTime;
        try {
            if (n > _reloadInterval) {
                // нужно проверять
                onCheckChangedResource();
            }
        } finally {
            _lastTime = System.currentTimeMillis();
            _working = false;
        }
    }

    protected void onCheckChangedResource() {
        for (ICheckChangedResource r : getApp().getServices().impl(ICheckChangedResource.class)) {
            r.checkChangedResource();
        }
    }

}
