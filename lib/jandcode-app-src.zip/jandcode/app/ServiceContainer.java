package jandcode.app;

import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Контейнер для хранения сервисов.
 * <p/>
 * Iterable по экземплярам сервисов.
 */
public class ServiceContainer implements Iterable<Object> {

    public static String NOTFOUND = "Сервис [{0}] не найден";
    public static String BADCLASS = "Сервис [{0}] не реализует интерфейс [{1}]";

    private Map<Class, Object> items = new LinkedHashMap<Class, Object>();

    /**
     * Элементы в контейнере. Пары "интерфейс:реализация"
     */
    public Map<Class, Object> getItems() {
        return items;
    }

    /**
     * Найти сервис по классу
     *
     * @param serviceClass класс сервиса
     * @return null, если не найден
     */
    public <A extends Object> A find(Class<A> serviceClass) {
        return (A) items.get(serviceClass);
    }

    /**
     * Найти сервис по классу
     *
     * @param serviceClass класс сервиса
     * @return ошибка, если не найден
     */
    public <A extends Object> A get(Class<A> serviceClass) {
        Object svc = items.get(serviceClass);
        if (svc == null) {
            throw new XError(NOTFOUND, serviceClass.getName());
        }
        return (A) svc;
    }

    /**
     * Добавить сервис
     *
     * @param serviceClass интерфейс
     * @param inst         реализация
     */
    public void add(Class serviceClass, Object inst) {
        if (!serviceClass.isAssignableFrom(inst.getClass())) {
            throw new XError(BADCLASS, inst.getClass(), serviceClass);
        }
        items.put(serviceClass, inst);
    }

    /**
     * Добавить из rt
     *
     * @param service узел с описанием сервиса. Исползуются атрибуты:
     *                name - имя класса интерфейса сервиса
     *                class - имя класса реализатора сервиса
     * @param factory инициализатор экземпляра после создания (зависимости)
     * @return созданный сервис
     */
    public Object add(Rt service, ObjectFactory factory) {
        Class serviceClass = factory.getClass(service.getName());
        Object svc = factory.create(service);
        add(serviceClass, svc);
        return svc;
    }

    /**
     * Добавить все сервисы из дочерних узлов элемента services.
     * Каждый дочерний - определение сервиса
     * (см. {@link ServiceContainer#add(java.lang.Class, java.lang.Object)})
     *
     * @param services набор сервисов. Может быть null, тогда вызов игнорируется
     * @param factory  инициализатор экземпляра после создания (зависимости)
     */
    public void addAll(Rt services, ObjectFactory factory) {
        if (services == null) {
            return;
        }
        for (Rt x : services.getChilds()) {
            add(x, factory);
        }
    }

    /**
     * Сервисы, реализующие определенный интерфейс.
     *
     * @param clazz какой интерфейс
     * @return список с объектами. Всегда не null.
     */
    public <A> List<A> impl(Class<A> clazz) {
        List<A> res = new ArrayList<A>();
        for (Object it : items.values()) {
            if (clazz.isAssignableFrom(it.getClass())) {
                res.add((A) it);
            }
        }
        return res;
    }

    public Iterator<Object> iterator() {
        return items.values().iterator();
    }
}
