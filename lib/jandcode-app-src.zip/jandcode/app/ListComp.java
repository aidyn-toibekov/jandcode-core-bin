package jandcode.app;

import jandcode.utils.*;

import java.util.*;

/**
 * Список компонентов
 */
public class ListComp<TYPE extends Comp> extends ListNamed<TYPE> {

    private Comp _owner;

    public ListComp() {
    }

    public ListComp(Comp owner) {
        this();
        _owner = owner;
    }

    protected void onAdd(TYPE it) {
        super.onAdd(it);
        if (_owner != null) {
            it.setOwner(_owner);
        }
    }

    public Comp getOwner() {
        return _owner;
    }

    public void add(String name, TYPE it) {
        it.setName(name);
        add(it);
    }

    /**
     * Объекты, реализующие определенный интерфейс.
     *
     * @param clazz какой интерфейс
     * @return список с объектами. Всегда не null.
     */
    public <A> List<A> impl(Class<A> clazz) {
        List<A> res = new ArrayList<A>();
        for (TYPE it : this) {
            if (clazz.isAssignableFrom(it.getClass())) {
                res.add((A) it);
            }
        }
        return res;
    }

    /**
     * Последний элемент списка или null, если нет элементов в списке
     */
    public TYPE last() {
        if (size() == 0) {
            return null;
        } else {
            return get(size() - 1);
        }
    }

}
