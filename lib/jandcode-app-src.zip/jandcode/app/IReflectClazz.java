package jandcode.app;

/**
 * Интерфейс к обертке класса в {@link ReflectService}
 */
public interface IReflectClazz {

    /**
     * Реальный класс
     */
    Class getCls();

    /**
     * Установить свойство объекту
     *
     * @param inst     экземпляр
     * @param propname имя свойства. Определяется методами inst:
     *                 setPropname(Object), setPropnameName(String), setPropname(Rt)
     * @param value    значение
     * @return true, если свойство найдено и присвоено (или найдено и проигнорировано).
     *         false, если не найдено. Генерится ошибка, если произошла при присвоении
     */
    boolean invokeSetter(Object inst, String propname, Object value);

}
