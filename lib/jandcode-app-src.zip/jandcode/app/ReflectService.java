package jandcode.app;

import jandcode.utils.rt.*;

import java.util.*;

/**
 * Сервис рефлексии
 */
public abstract class ReflectService extends Comp {

    /**
     * Получить обертку класса
     *
     * @param cls для какого класса
     */
    public abstract IReflectClazz getClazz(Class cls);

    /**
     * Список всех классов из указанного пакета.
     *
     * @param packageName имя пакета java
     * @param recursive   false - только непосредственно в пакете
     */
    public abstract List<IReflectClazz> list(String packageName, boolean recursive);

    /**
     * Установить атрибуты из attrs свойствам объекта inst через рефлексию.
     * Игнорируются атрибуты, который начинаются со знака подчеркивания.
     */
    public abstract void setRtAttrs(Object inst, Rt attrs);

    /**
     * Установить элементы из map свойствам объекта inst через рефлексию
     * Игнорируются атрибуты, который начинаются со знака подчеркивания.
     */
    public abstract void setRtAttrs(Object inst, Map attrs);


}
