package jandcode.app;

/**
 * Хранилище сервисов и доступ к ним
 */
public interface IServiceHolder {

    /**
     * Получить сервис по классу
     *
     * @param clazz какой класс интересует
     * @return ошибка, если не найден
     */
    <A extends Object> A service(Class<A> clazz);

    /**
     * Все зарегистрированные сервисы
     */
    ServiceContainer getServices();

}
