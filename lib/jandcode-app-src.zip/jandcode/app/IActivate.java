package jandcode.app;

/**
 * Активация для сервисов.
 */
public interface IActivate {

    /**
     * Процесс активации. Все сервисы созданы. Конфигурация загружена.
     */
    void activate() throws Exception;

}
