package jandcode.app.test;

import jandcode.utils.test.*;

/**
 * Предок для тестов с поддержкой приложения
 */
public abstract class AppTestCase extends UtilsTestCase {

    public TestExtApp app = createExt(TestExtApp.class);

}
