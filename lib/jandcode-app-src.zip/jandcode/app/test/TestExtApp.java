package jandcode.app.test;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import jandcode.utils.rt.impl.*;
import jandcode.utils.test.*;

import java.util.*;

/**
 * Расширение для тестов: поддержка приложения
 */
public class TestExtApp extends TestExt {

    public static String FILE_TEST_RT = "test.rt";

    private static HashMap<String, App> _cacheApp = new HashMap<String, App>();

    protected App app;

    //////

    public void setUp() throws Exception {
        // устанавливаем тестовую среду
        App.setTest(true);
        // активируем приложение
        activateApp();
    }

    public void activateApp(String cfgfilename) throws Exception {
        App res;
        String pt = test.getTestPath();
        String ptn = UtFile.join(pt, cfgfilename);
        res = _cacheApp.get(ptn);
        if (res == null) {
            String fn = UtFile.findFileUp(cfgfilename, pt);
            if (fn == null) {
                throw new XError(String.format("***** Не найден файл %s начиная с каталога %s и вверх", cfgfilename, pt));
            } else {
                res = _cacheApp.get(fn);
                if (res == null) {
                    test.startTimer("load app");
                    System.out.println("***** [load app: " + fn + " ]***************");
                    res = AppLoader.load(fn);
                    _cacheApp.put(fn, res);
                    _cacheApp.put(ptn, res);
                    test.stopTimer();
                }
            }
        }
        app = res;
    }

    /**
     * Активизация контекста по умолчанию: начиная с каталога тестов и вверх ищется файл
     * {@link TestExtApp#FILE_TEST_RT}
     */
    public void activateApp() throws Exception {
        activateApp(FILE_TEST_RT);
    }

    /**
     * Записать текущее состояние {@link App#getRt()}
     */
    public void saveAppRt() throws Exception {
        UtFile.mkdirs("temp");
        String fn;

        fn = UtFile.abs(test.replaceTestName("temp/#-&.rt"));
        System.out.println("save file: " + fn);
        getApp().getRt().save(false).toFile(fn);

        fn = UtFile.abs(test.replaceTestName("temp/#-&-EXPANDED.rt"));
        System.out.println("save file: " + fn);
        getApp().getRt().save(true).toFile(fn);
    }

    //////

    /**
     * Загружает rt из ресурса. Загрузка производится в контексте {@link App#getRt()},
     * т.е. в загружаемом файле будут правильно распознаны все parent.
     */
    public Rt loadRt(String resPath) throws Exception {
        Rt r = getApp().getRt().createRt("root");
        r.load().fromRes(test.replaceTestName(resPath));
        return r;
    }

    /**
     * Проверка правильности expand path для rt
     *
     * @param path           путь узла
     * @param parent         его значение parent
     * @param expandedParent ожидаемый результат
     */
    public void checkRtExpand(String path, String parent, String expandedParent) {
        RtParentExpander exp = ((RtRootImpl) getApp().getRt().getRoot()).getParentExpander();
        test.assertEquals(exp.expand(path, parent).toString(), expandedParent);
    }

    /**
     * Получить сервис
     *
     * @param clazz
     * @param <A>
     * @return
     */
    public <A extends Object> A service(Class<A> clazz) {
        return getApp().service(clazz);
    }

    /**
     * Текущее приложение
     */
    public App getApp() {
        return app;
    }

    ////// ObjectFactory

    public ObjectFactory getObjectFactory() {
        return getApp().getObjectFactory();
    }

    public Object create(Rt rt) {
        return getObjectFactory().create(rt);
    }

    public Object create(Rt rt, Class cls) {
        return getObjectFactory().create(rt, cls);
    }

    public Object create(Rt rt, Class cls, IIniter beforeIniter) {
        return getObjectFactory().create(rt, cls, beforeIniter);
    }

    public Object create(Rt rt, IIniter beforeIniter) {
        return getObjectFactory().create(rt, beforeIniter);
    }

    public <A> A create(Class<A> cls) {
        return getObjectFactory().create(cls);
    }

    public <A> A create(Class<A> cls, IIniter beforeIniter) {
        return getObjectFactory().create(cls, beforeIniter);
    }
}
