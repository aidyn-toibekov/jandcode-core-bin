package jandcode.app;

/**
 * Для проверки измененных ресурсов
 */
public interface ICheckChangedResource {

    /**
     * Проверить измененные ресурсы и перегрузить их при необходимости
     */
    void checkChangedResource();

}
