package jandcode.app;

/**
 * Пре-активация для сервисов.
 */
public interface IBeforeActivate {

    /**
     * Процесс пре-активации. Все сервисы еще не активированы.
     */
    void beforeActivate() throws Exception;

}
