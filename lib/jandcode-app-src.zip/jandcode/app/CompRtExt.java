package jandcode.app;


import jandcode.utils.rt.*;

/**
 * Предок для "расширения" компонента CompRt.
 */
public class CompRtExt extends CompExt {

    public CompRtExt(CompRt comp) {
        super(comp);
    }

    public CompRt getComp() {
        return (CompRt) comp;
    }

    public Rt getRt() {
        return getComp().getRt();
    }

}
