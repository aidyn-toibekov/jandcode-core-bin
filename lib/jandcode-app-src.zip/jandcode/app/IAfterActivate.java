package jandcode.app;

/**
 * Пост-активация для сервисов.
 */
public interface IAfterActivate {

    /**
     * Процесс пост-активации. Все сервисы активированы.
     */
    void afterActivate() throws Exception;

}
