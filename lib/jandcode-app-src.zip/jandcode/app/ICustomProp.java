package jandcode.app;

import java.util.*;

/**
 * Интерфейс для произвольных свойств компонента
 */
public interface ICustomProp {

    /**
     * Установить значение произвольного свойства для записи
     */
    void setProp(String name, Object value);

    /**
     * Получить значение произвольного свойства для записи.
     * Если свойства нет, возвращается null.
     */
    Object getProp(String name);

    /**
     * Есть ли свойство
     */
    boolean hasProp(String name);

    /**
     * Получить значение произвольного свойства для записи.
     * Если свойства нет, возвращается значение по умолчанию.
     */
    Object getProp(String name, Object defaultValue);

    /**
     * Возвращает все произвольные свойства.
     * Это копия, можно использовать как угодно.
     * Если произвольных свойств нет, возвращается пустой map.
     */
    Map<String, Object> getProps();

}
