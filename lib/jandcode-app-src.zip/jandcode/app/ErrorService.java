package jandcode.app;

import jandcode.utils.error.*;

/**
 * Сервис для ошибок.
 */
public abstract class ErrorService extends CompRt {

    /**
     * Возвращает форматировщик сообщений об ошибках.
     * Если App.isDebug(), то в начале ищется имя name+".debug", если не найдено,
     * тогда name, если не найдено "default".
     */
    public abstract ErrorFormatter getErrorFormatter(String name);

}
