package jandcode.app;

/**
 * Предок для "расширения" компонента.
 * Используется как набор тематических утилит, привязанный к экземпляру компонента.
 */
public abstract class CompExt {

    protected Comp comp;

    protected CompExt(Comp comp) {
        this.comp = comp;
    }

    public Comp getComp() {
        return comp;
    }

    public void setComp(Comp comp) {
        this.comp = comp;
    }

}
