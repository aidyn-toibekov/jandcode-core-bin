package jandcode.app;

/**
 * Инициализатор объекта. Инициализирует объект контекстом создания.
 */
public interface IIniter {

    /**
     * Запуска инициализатора
     *
     * @param obj для кого
     */
    void initObject(Object obj) throws Exception;

}
