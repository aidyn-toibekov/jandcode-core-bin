package jandcode.app;

/**
 * Ссылка на фабрику объектов
 */
public interface IObjectFactoryLink {

    ObjectFactory getObjectFactory();

}
