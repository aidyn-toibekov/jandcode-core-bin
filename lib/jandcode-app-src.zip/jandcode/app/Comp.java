package jandcode.app;

import jandcode.utils.*;
import jandcode.utils.error.*;

/**
 * Компонент.
 */
public class Comp extends Named implements Cloneable, IAppLink, IAppLinkSet {

    protected App app;
    protected Comp _owner;

    /**
     * Проверка на совпадение имени без учета регистра.
     */
    public boolean hasName(String name) {
        return this.name != null && this.name.equalsIgnoreCase(name);
    }

    //////

    public App getApp() {
        if (app == null) {
            throw new XError("Экземпляр создан вне контекста приложения: {0}", getClass());
        }
        return app;
    }

    public void setApp(App app) {
        this.app = app;
    }

    /**
     * Владелец компонента.
     */
    public Comp getOwner() {
        return _owner;
    }

    /**
     * Установить владельца компонента. Обычно не используется в приложении,
     * только в реализациях компонентов-контейнеров.
     */
    public void setOwner(Comp owner) {
        _owner = owner;
    }

    //////

    /**
     * Клонировать этот компонент. Клонирование выполняется через
     * вызов конструктора, в отличии от стандартного clone в java.
     * В потомках нужно перекрывать onClone.
     *
     * @return новая копия
     */
    public Object clone() {
        try {
            Comp r = getClass().newInstance();
            onClone(r);
            return r;
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    /**
     * Реализация клонирования компонента. Не забудьте вызывать super, если
     * перекрываете метод.
     *
     * @param r куда клонировать свои данные
     */
    protected void onClone(Comp r) {
        r.app = app;
        r.name = name;
    }

}
