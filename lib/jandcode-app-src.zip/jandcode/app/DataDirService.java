package jandcode.app;

/**
 * Сервис каталогов с даннымы.
 * <p/>
 * В настройках должен быть указан базовый каталог 'root'. Относительно него будут
 * браться все запрашиваемые пути. Если этот каталог не настроен, то по умолчанию
 * он берется как #APPDIR/datadir
 * <p/>
 * Для каждого имени, запрашиваемого через getDataDir можно настроить путь в rt.
 * Он может быть как относительный, так и абсолютный.
 */
public abstract class DataDirService extends CompRt {

    /**
     * По имени возвращает физический путь
     *
     * @param name имя пути
     * @return физический путь. Каталог автоматически будет создан, если не существует
     */
    public abstract String getDataDir(String name);

    /**
     * Базовый каталог для datadir
     */
    public String getDataDir() {
        return getDataDir("root");
    }

}
