package jandcode.auth;

/**
 * Интерфейс для сервисов сервиса AuthService.
 * Используетсся для создания провайдеров проверок целей.
 */
public interface ICheckTarget {

    /**
     * Проверка цели.
     * При реализации нужно сделать следующее:
     * <li>если цель неизвестна провайдеру - она просто пропускается</li>
     * <li>если цель известна провайдеру и доступ разрешен - ничего не делаем</li>
     * <li>если цель известна провайдеру и доступ запрещен - генерируем exception
     * с интерфейсом {@link IErrorAccessDenied}</li>
     * <li>если при проверке цели возникает неожинанный exception, то он будет обернут
     * в {@link XErrorAccessDeniedWrap}</li>
     *
     * @param ui     для какого пользователя
     * @param target цель
     */
    void checkTarget(IUserInfo ui, AuthTarget target);

}
