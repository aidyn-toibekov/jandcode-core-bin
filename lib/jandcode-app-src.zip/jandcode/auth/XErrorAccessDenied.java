package jandcode.auth;

import jandcode.utils.*;

/**
 * Доступ запрещен. Реализация по умолчанию.
 */
public class XErrorAccessDenied extends RuntimeException implements IErrorAccessDenied {

    public static String MSG = "Вы не имеете доступа для выполнения этой операции";

    private AuthTarget authTarget;
    private String msg;

    public XErrorAccessDenied(String authTarget) {
        this.authTarget = new AuthTarget(authTarget);
    }

    public XErrorAccessDenied(AuthTarget authTarget) {
        this.authTarget = authTarget;
    }

    public XErrorAccessDenied(AuthTarget authTarget, String msg) {
        this.authTarget = authTarget;
        this.msg = msg;
    }

    public AuthTarget getAuthTarget() {
        return authTarget;
    }

    public String getMessage() {
        if (UtString.empty(msg)) {
            return UtLang.t(MSG);
        } else {
            return msg;
        }
    }

}
