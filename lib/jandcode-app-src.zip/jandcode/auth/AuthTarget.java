package jandcode.auth;

import jandcode.utils.*;

import java.util.*;

/**
 * Цель для проверки доступа.
 * Цель - это строка вида 'NAMESPACE:PATH',
 * например 'action:show/basedata'
 * <p/>
 * Этот класс принимает такую строку как цель и предлагает набор утилит для работы с ней.
 */
public class AuthTarget {

    private String target;
    private String nameSpace;
    private String path;
    private List<String> pathList;
    private Map<String, String> pathMap;

    public AuthTarget(String target) {
        if (target == null) {
            target = "";
        }
        this.target = target;
    }

    /**
     * Полная строка цели.
     */
    public String getTarget() {
        return target;
    }

    /**
     * Часть target до ':'
     */
    public String getNameSpace() {
        if (nameSpace == null) {
            int a = target.indexOf(':');
            if (a == -1) {
                nameSpace = "";
                path = target;
            } else {
                nameSpace = target.substring(0, a);
                path = target.substring(a + 1);
            }
        }
        return nameSpace;
    }

    /**
     * Часть target после ':'
     */
    public String getPath() {
        if (path == null) {
            // parse
            getNameSpace();
        }
        return path;
    }

    /**
     * path в виде списка строк. Разделитель '/'.
     * Например для цели 'action:show/basedata' этот метод вернет:
     * ['show', 'basedata']
     */
    public List<String> getPathList() {
        if (pathList == null) {
            pathList = Collections.unmodifiableList(Arrays.asList(getPath().split("/")));
        }
        return pathList;
    }

    /**
     * path в виде map.
     * Формат path 'key1=value;key2=value'.
     * Например для цели 'action:url=show/basedata;id=2' этот метод вернет:
     * [url:show/basedata, id:2]
     */
    public Map<String, String> getPathMap() {
        if (pathMap == null) {
            Map<String, String> m = new LinkedHashMap<String, String>();
            UtCnv.toMap(m, getPath(), ";", "=");
            pathMap = Collections.unmodifiableMap(m);
        }
        return pathMap;
    }

}
