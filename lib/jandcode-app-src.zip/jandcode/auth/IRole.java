package jandcode.auth;

import jandcode.utils.*;

import java.util.*;

/**
 * Роль. Набор привелегий. Хранятся вне приложения (например в базе). Создаются
 * и добавляются реализацией системы аутенфикации.
 * имя=код
 */
public interface IRole extends INamed {

    /**
     * Наименование
     */
    String getTitle();

    /**
     * Список имен привелегий для этой роли
     */
    HashSet<String> getPrivNames();

}
