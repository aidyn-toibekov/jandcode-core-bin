package jandcode.auth;

import jandcode.utils.*;

/**
 * Привелегия. Что-то, что можно разрешить/запретить. Хранятся в приложении.
 * имя=код
 */
public interface IPriv extends INamed {

    /**
     * Наименование
     */
    String getTitle();

    /**
     * Имя родительской привелегии. Для построения дерева привелегий.
     *
     * @return
     */
    String getParentName();

}
