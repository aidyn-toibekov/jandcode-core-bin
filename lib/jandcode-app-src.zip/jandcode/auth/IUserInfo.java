package jandcode.auth;

import jandcode.utils.*;
import jandcode.utils.variant.*;

/**
 * Информация о пользователе
 * name=имя пользователя
 */
public interface IUserInfo extends INamed {

    /**
     * Ссылка на AuthService, через который был получен этот пользователь
     *
     * @return
     */
    AuthService getAuthService();

    /**
     * id пользователя
     */
    long getId();

    /**
     * Полное имя пользователя
     */
    String getFullname();

    /**
     * true - если пользователь не зарегистрирован
     */
    boolean isGuest();

    /**
     * true - если пользователь заблокирован
     */
    boolean isLocked();

    /**
     * Произвольный атрибут пользователя
     *
     * @param name имя атрибута
     * @return значение атрибута или null, если отсутсвует
     */
    @Deprecated
    Object getAttr(String name);

    /**
     * Произвольные атрибуты пользователя. Доступны на чтение и запись.
     */
    IVariantMap getAttrs();

    /**
     * Имеет ли назначенную роль
     *
     * @param name имя роли
     * @return true, если имеет
     */
    boolean hasRole(String name);

    /**
     * Имеет ли назначенную привелегию
     *
     * @param name имя роли
     * @return true, если имеет
     */
    boolean hasPriv(String name);

    /**
     * Все привелегии пользователя
     */
    ListNamed<IPriv> getPrivs();

    /**
     * Все роли пользователя
     */
    ListNamed<IRole> getRoles();

    /**
     * Проверить цель.
     *
     * @param target        цель. Цель - это строка вида 'NAMESPACE:OBJECTNAME',
     *                      например 'action:show/basedata'
     * @param generateError true - генерится ошибка XErrorAccessDenied,
     *                      false - возвращается false
     */
    boolean checkTarget(String target, boolean generateError);

}
