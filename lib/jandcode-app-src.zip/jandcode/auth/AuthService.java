package jandcode.auth;

import jandcode.app.*;
import jandcode.utils.*;
import org.apache.commons.logging.*;

import java.util.*;

public abstract class AuthService extends CompRt implements IServiceHolder {

    protected static Log log = LogFactory.getLog(AuthService.class);

    protected boolean threaded = true;

    /**
     * true - каждый поток - собственный пользователь
     *
     * @return
     */
    public boolean isThreaded() {
        return threaded;
    }

    public void setThreaded(boolean threaded) {
        this.threaded = threaded;
    }

    /**
     * Возвращает текущего пользователя
     */
    public abstract IUserInfo getCurrentUser();

    /**
     * Установка текущего пользователя.
     *
     * @param user если null, то гость
     */
    public abstract IUserInfo setCurrentUser(IUserInfo user);

    /**
     * Список привелегий, которые существуют
     */
    public abstract ListNamed<IPriv> getPrivs();


    /**
     * Список ролей, которые существуют
     */
    public abstract ListNamed<IRole> getRoles();


    /**
     * Пересоздать список доступных ролей по переданному
     */
    public abstract void updateRoles(Collection<IRole> roles);

    /**
     * Проверить цель
     *
     * @param ui             для какого пользователя
     * @param target         строка описывающая цель
     * @param generateErrors true - генерировать ошибку, false - возвращать разрешенность
     * @return true - разрешено, false - запрещено
     */
    public abstract boolean checkTarget(IUserInfo ui, String target, boolean generateErrors);

}
