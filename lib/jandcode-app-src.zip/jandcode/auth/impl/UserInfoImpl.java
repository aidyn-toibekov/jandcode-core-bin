package jandcode.auth.impl;

import jandcode.auth.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Простейшая реализация IUserInfo
 */
public class UserInfoImpl extends Named implements IUserInfo {

    protected AuthService authService;
    protected long id;
    protected String fullname = "";
    protected boolean guest;
    protected boolean locked;
    protected VariantMap attrs = new VariantMap();
    protected HashSetNoCase roles = new HashSetNoCase();

    public UserInfoImpl(AuthService authService) {
        this.authService = authService;
    }

    public AuthService getAuthService() {
        return authService;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFullname() {
        return UtString.empty(fullname) ? getName() : fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public boolean isGuest() {
        return guest;
    }

    public void setGuest(boolean guest) {
        this.guest = guest;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public VariantMap getAttrs() {
        return attrs;
    }

    public Object getAttr(String name) {
        return attrs.get(name);
    }

    public ListNamed<IRole> getRoles() {
        ListNamed<IRole> res = new ListNamed<IRole>();
        AuthService svc = getAuthService();
        for (String r : roles) {
            IRole rr = svc.getRoles().find(r);
            if (rr != null) {
                res.add(rr);
            }
        }
        return res;
    }

    public ListNamed<IPriv> getPrivs() {
        ListNamed<IPriv> res = new ListNamed<IPriv>();
        AuthService svc = getAuthService();
        for (IRole r : getRoles()) {
            for (String priv : r.getPrivNames()) {
                IPriv p = svc.getPrivs().find(priv);
                if (p != null) {
                    res.add(p);
                }
            }
        }
        return res;
    }

    public boolean hasRole(String name) {
        return roles.contains(name);
    }

    public boolean hasPriv(String name) {
        return getPrivs().find(name) != null;
    }

    public boolean checkTarget(String target, boolean generateError) {
        return getAuthService().checkTarget(this, target, generateError);
    }

    public void updateRoles(Collection<String> roleNames) {
        roles.clear();
        roles.addAll(roleNames);
    }

}
