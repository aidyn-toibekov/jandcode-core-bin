package jandcode.auth.impl;

import jandcode.app.*;
import jandcode.auth.*;

public class PrivImpl extends CompRt implements IPriv {

    protected String title;
    protected String parentName;

    public String getTitle() {
        return title == null ? getName() : title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getParentName() {
        return parentName == null ? "" : parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }
}
