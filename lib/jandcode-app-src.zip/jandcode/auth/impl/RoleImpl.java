package jandcode.auth.impl;

import jandcode.auth.*;
import jandcode.utils.*;

public class RoleImpl extends Named implements IRole {

    protected String title = "";
    protected HashSetNoCase privNames = new HashSetNoCase();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public HashSetNoCase getPrivNames() {
        return privNames;
    }
}
