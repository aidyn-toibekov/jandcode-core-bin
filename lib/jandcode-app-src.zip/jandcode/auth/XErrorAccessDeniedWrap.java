package jandcode.auth;

import jandcode.utils.*;

/**
 * Враппер для "Доступ запрещен". Реализация по умолчанию.
 * В эту exception оборачиваются все неожиданные ошибки, которые возникли в процессе выполнения
 * проверок прав.
 */
public class XErrorAccessDeniedWrap extends RuntimeException implements IErrorAccessDenied {

    public static String MSG = "Ошибка при проверке прав";

    private AuthTarget authTarget;

    public XErrorAccessDeniedWrap(Throwable cause, AuthTarget authTarget) {
        super(cause);
        this.authTarget = authTarget;
    }

    public AuthTarget getAuthTarget() {
        return authTarget;
    }

    public String getMessage() {
        return UtLang.t(MSG);
    }

}
