package jandcode.auth;

/**
 * Этот интерфейс должны реализовывать exception, которые генерируются при проверке
 * прав пользователя. Exception должен быть наследником от RuntimeException!
 */
public interface IErrorAccessDenied {

    /**
     * При проверке какой цели возникла ошибка.
     */
    AuthTarget getAuthTarget();

}
