package jandcode.lang;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.lang.*;

import java.util.*;

/**
 * Сервис для много
 */
public abstract class LangService extends CompRt implements ILangService {

    /**
     * Возвращает список зарегистрированных языков
     */
    public abstract ListNamed<Lang> getLangs();

    /**
     * Язык по умолчанию в системе. Т.е. тот, который используется, если не
     * известно, какой язык использовать.
     */
    public abstract Lang getDefaultLang();

    /**
     * Возвращает текущий язык для потока
     */
    public abstract Lang getCurrentLang();

    /**
     * Установить текущий язык по имени. Если такого языка нету, устанавливается
     * язык по умолчанию
     */
    public abstract void setCurrentLang(String lang);

    /**
     * Данные перевода для указанного языка
     *
     * @param lang
     * @return
     */
    public abstract Map<String, String> getTranslateData(String lang);
}
