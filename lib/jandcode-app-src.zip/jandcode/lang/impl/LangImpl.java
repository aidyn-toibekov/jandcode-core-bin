package jandcode.lang.impl;

import jandcode.lang.*;
import jandcode.utils.*;

public class LangImpl extends Named implements Lang, Comparable<Lang> {

    private String title;
    private int weight;

    public String getTitle() {
        return title == null ? getName() : title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String toString() {
        return getName() + " (" + getTitle() + ")";
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int compareTo(Lang o) {
        Integer i1 = getWeight();
        Integer i2 = ((LangImpl) o).getWeight();
        int n = i1.compareTo(i2);
        if (n == 0) {
            String s1 = getName();
            String s2 = o.getName();
            n = s1.compareTo(s2);
        }
        return n;
    }

}
