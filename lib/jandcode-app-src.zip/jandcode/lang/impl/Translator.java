package jandcode.lang.impl;

import jandcode.utils.*;

import java.util.*;

public class Translator {

    private Map<String, String> data = new HashMap<String, String>();

    public Translator() {
    }

    public Map<String, String> getData() {
        return data;
    }

    public void addData(Map<String, String> data) {
        this.data.putAll(data);
    }

    public String translate(String s) {
        if (s == null) {
            s = "";
        }
        s = s.trim();
        String s1 = data.get(s);
        if (UtString.empty(s1)) {
            return s;
        }
        return s1;
    }

}
