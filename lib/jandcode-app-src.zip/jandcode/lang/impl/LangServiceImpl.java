package jandcode.lang.impl;

import jandcode.app.*;
import jandcode.lang.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.text.*;
import java.util.*;

public class LangServiceImpl extends LangService implements IActivate {

    private ListNamed<Lang> langs = new ListNamed<Lang>();
    private Lang defaultLang;
    private ThreadLocal<Lang> langsThreaded = new ThreadLocal<Lang>();
    private Map<Lang, Translator> translators = new HashMap<Lang, Translator>();

    //////

    public void activate() throws Exception {
        UtLang.setInst(this);
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt langList = getApp().getRt().findChild("lang/lang");
        if (langList != null) {
            for (Rt x : langList.getChilds()) {
                Lang lang = createLangFromRt(x);
                if (lang != null) {
                    addLang(lang);
                }
            }
        }
        // если ничего не описано
        if (langs.size() == 0) {
            LangImpl lang = new LangImpl();
            lang.setName("ru");
            lang.setTitle("Русский");
            addLang(lang);
        }
        // default
        String defLang = getApp().getRt().getValueString("lang:default", "ru");
        if (defLang == null) {
            langs.get(0).getName();
        }
        // обозначаем язык по умолчанию
        defaultLang = langs.find(defLang);
        if (defaultLang == null) {
            defaultLang = langs.get(0);
        }
        // сортируем
        Collections.sort(langs);

        // грузим переводы
        Rt trList = getApp().getRt().findChild("lang/translate");
        if (trList != null) {
            for (Rt x : trList.getChilds()) {
                String fn = x.getValueString("file");
                String langName = x.getValueString("lang");
                if (UtString.empty(langName)) {
                    langName = "ru";
                }
                Lang tlang = langs.find(langName);
                if (tlang == null) {
                    continue; // перевод имеется, но язык не подключен - игнорируем
                }
                TranslateLoader ldr = new TranslateLoader();
                try {
                    ldr.load().fromFileObject(fn);
                } catch (Exception e) {
                    throw new XErrorMark(e, fn);
                }
                Translator trn = translators.get(tlang);
                if (trn != null) {
                    trn.addData(ldr.getData());
                }
            }
        }

    }

    protected Lang createLangFromRt(Rt x) {
        boolean enabled = x.getValueBoolean("enabled", true);
        if (!enabled) {
            return null; // язык выключен
        }
        LangImpl lang = new LangImpl();
        lang.setName(x.getName());
        lang.setTitle(x.getValueString("title", x.getName()));
        lang.setWeight(x.getValueInt("weight", 50));
        return lang;
    }

    protected void addLang(Lang lang) {
        langs.add(lang);
        Translator tr = new Translator();
        translators.put(lang, tr);
    }

    //////

    public ListNamed<Lang> getLangs() {
        return langs;
    }

    public Lang getDefaultLang() {
        return defaultLang;
    }

    public Lang getCurrentLang() {
        Lang res = langsThreaded.get();
        if (res == null) {
            res = defaultLang;
        }
        return res;
    }

    public void setCurrentLang(String lang) {
        Lang res = langs.find(lang);
        if (res == null) {
            res = defaultLang;
        }
        langsThreaded.set(res);
    }

    //////


    public String t(String s, Object... params) {
        if (s == null) {
            return "";
        }
        //
        Lang lang = getCurrentLang();
        Translator tr = translators.get(lang);
        if (tr != null) {
            s = tr.translate(s);
        }
        //
        if (params == null || params.length == 0) {
            return s;
        } else {
            return MessageFormat.format(s, params);
        }
    }

    public Map<String, String> getTranslateData(String lang) {
        LinkedHashMap<String, String> res = new LinkedHashMap<String, String>();
        Lang lg = langs.find(lang);
        Translator tr = translators.get(lg);
        if (tr != null) {
            res.putAll(tr.getData());
        }
        return res;
    }
}
