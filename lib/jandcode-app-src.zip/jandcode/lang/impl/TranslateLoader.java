package jandcode.lang.impl;

import jandcode.utils.*;
import jandcode.utils.easyxml.*;
import jandcode.utils.io.*;

import java.io.*;
import java.util.*;

public class TranslateLoader implements ILoader {

    private Map<String, String> data = new LinkedHashMap<String, String>();

    public Map<String, String> getData() {
        return data;
    }

    public LoadFrom load() {
        return new LoadFrom(this);
    }

    public void loadFrom(Reader reader) throws Exception {
        EasyXml x = new EasyXml();
        x.load().fromReader(reader);
        //
        for (EasyXml x1 : x) {
            if (x1.hasName("i")) {
                String key = x1.getValueString("s");
                String val = x1.getValueString("t");
                if (!UtString.empty(key)) {
                    String keyN = key.trim();
                    if (UtString.empty(val)) {
                        val = key;
                    }
                    data.put(keyN, val);
                }
            }
        }
    }

    /**
     * Сортировка данных
     */
    public void sortData() {
        LinkedHashMap<String, String> tmp = new LinkedHashMap<String, String>();
        List<String> keys = new ArrayList<String>();
        for (String s : data.keySet()) {
            keys.add(s);
        }
        Collections.sort(keys);
        for (String s : keys) {
            tmp.put(s, data.get(s));
        }
        data = tmp;
    }
}
