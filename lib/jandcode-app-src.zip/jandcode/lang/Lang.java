package jandcode.lang;

import jandcode.utils.*;

/**
 * Язык
 */
public interface Lang extends INamed, Comparable<Lang> {

    /**
     * Читаемое название языка
     */
    String getTitle();

}
