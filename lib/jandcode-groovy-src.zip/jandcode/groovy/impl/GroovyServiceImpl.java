package jandcode.groovy.impl;

import jandcode.groovy.*;
import jandcode.utils.rt.*;

public class GroovyServiceImpl extends GroovyService {


    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt x = rt.findChild("compiler");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                // создаем компилятор
                GroovyCompiler compiler = GroovyManager.getInst().getCompiler(x1.getName(), true);

                // настраиваем компилятор
                Rt x2 = x1.findChild("preprocessor");
                if (x2 != null) {
                    for (Rt x3 : x2.getChilds()) {
                        GroovyPreprocessor p = (GroovyPreprocessor) getApp().getObjectFactory().create(x3);
                        compiler.addPreprocessor(x3.getName(), p);
                    }
                }
            }
        }

    }

    public GroovyCompiler getCompiler(String name) {
        return GroovyManager.getInst().getCompiler(name, false);
    }

    //////

    public void checkChangedResource() {
        GroovyManager.getInst().checkChangedResource();
    }

    public GroovyClazz findClazz(Class cls) {
        return GroovyManager.getInst().findClazz(cls);
    }

}
