package jandcode.groovy.impl;

import jandcode.groovy.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Реализация для UtGroovy
 */
public class GroovyManager {

    public static final String CLASS_NAME_PREFIX = "G__";
    public static final String SIGN_CLASS = "class";
    public static final String SIGN_BODY = "body";

    private static GroovyManager inst;

    static {
        inst = new GroovyManager();
        // groovy конвертор ошибок
        UtError.addErrorConvertor(new ErrorConvertorGroovy(inst));
    }

    public static GroovyManager getInst() {
        return inst;
    }

    //////

    private HashMap<String, GroovyCompilerImpl> compilers = new HashMap<String, GroovyCompilerImpl>();

    public GroovyCompiler getCompiler(String name, boolean autoCreate) {
        GroovyCompilerImpl res = compilers.get(name);
        if (res == null) {
            if (!autoCreate) {
                throw new XError("Не найден groovy-компилятор с именем: {0}", name);
            }
            synchronized (this) {
                res = compilers.get(name);
                if (res == null) {
                    res = new GroovyCompilerImpl();
                    compilers.put(name, res);
                }
            }
        }
        return res;
    }

    /**
     * Возвращает {@link ErrorSource} для указанной строки
     * describer, где возможно есть упоминание имени класса.
     * Используется при поиске ошибок компиляции.
     *
     * @param describer строка, которая содержит имя класса
     * @param line      для какой строки
     * @return Если не найдено, возвращается null
     */
    public ErrorSource getErrorSource(String describer, int line) {
        for (GroovyCompilerImpl compiler : compilers.values()) {
            ErrorSource a = compiler.getErrorSource(describer, line);
            if (a != null) {
                return a;
            }
        }
        return null;
    }

    /**
     * Возвращает {@link ErrorSource} для указанного элемента стека.
     *
     * @param st для какого элемента стека
     * @return Если StackTraceElement не связан с исходником скриптов, возвращается null.
     */
    public ErrorSource getErrorSource(StackTraceElement st) {
        for (GroovyCompilerImpl compiler : compilers.values()) {
            ErrorSource a = compiler.getErrorSource(st);
            if (a != null) {
                return a;
            }
        }
        return null;
    }

    /**
     * Запустить проверку изменных исходников скриптов
     */
    public void checkChangedResource() {
        for (GroovyCompilerImpl compiler : compilers.values()) {
            compiler.checkChangedResource();
        }
    }

    public GroovyClazz findClazz(Class cls) {
        for (GroovyCompilerImpl compiler : compilers.values()) {
            GroovyClazz res = compiler.findClazz(cls);
            if (res != null) {
                return res;
            }
        }
        return null;
    }

}
