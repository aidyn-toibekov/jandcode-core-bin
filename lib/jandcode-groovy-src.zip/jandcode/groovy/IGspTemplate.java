package jandcode.groovy;

import groovy.lang.*;

import java.util.*;

/**
 * Интерфейс для классов, являющихся gsp шаблонами
 */
public interface IGspTemplate {

    /**
     * Вывести текст
     */
    void out(Object s) throws Exception;

    /**
     * Вывести тег
     */
    void outTag(String tmlName, Map args, Closure cls) throws Exception;

    /**
     * Вывести тег
     */
    void outTag(Map args, String tmlName, Closure cls) throws Exception;

    /**
     * Вывести тег
     */
    void outTag(Map args, String tmlName) throws Exception;

    /**
     * Вывести тег
     */
    void outTag(String tmlName) throws Exception;

    /**
     * Вывести тег
     */
    void outTag(String tmlName, Map args) throws Exception;

    /**
     * Вывести тег
     */
    void outTag(String tmlName, Closure cls) throws Exception;

}
