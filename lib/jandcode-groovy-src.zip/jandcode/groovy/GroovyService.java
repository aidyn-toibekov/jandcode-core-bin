package jandcode.groovy;

import jandcode.app.*;

/**
 * Сервис для groovy-скриптов и шаблонов.
 */
public abstract class GroovyService extends CompRt implements ICheckChangedResource {

    /**
     * Возвращает компилятор с именем "default"
     */
    public GroovyCompiler getCompiler() {
        return getCompiler("default");
    }

    public abstract GroovyCompiler getCompiler(String name);

    /**
     * Найти GroovyClazz по обычному классу
     *
     * @param cls какой класс интересует
     * @return null, если не найден
     */
    public abstract GroovyClazz findClazz(Class cls);

}
