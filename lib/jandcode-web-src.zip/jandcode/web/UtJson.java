package jandcode.web;

import jandcode.utils.*;
import org.joda.time.*;
import org.json.simple.*;

import java.util.*;

/**
 * Утилиты для json
 */
public class UtJson {

    static {
        JSONValue.registerConvertor("jandcode.web.UtJson", new JsonConvertor());
    }

    public static class JsonConvertor implements JSONValue.Convertor {

        public String toJsonString(Object value) {
            if (value instanceof Date) {
                value = new DateTime((Date) value);
            }
            if (value instanceof DateTime) {
                return UtDate.toString((DateTime) value);
            }
            return null;
        }
    }

    public static String toString(Object value) {
        return JSONValue.toJSONString(value);
    }

    public static Object toObject(String s) {
        return JSONValue.parse(s);
    }

}
