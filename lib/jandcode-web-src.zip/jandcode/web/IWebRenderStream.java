package jandcode.web;

import java.io.*;

/**
 * Объект для преобразования объекта в то, что можно отдать web-клиенту.
 * Бинарные данные, которые пишутся непосредственно в getOutWriter().
 * Перед записью нужно обязательно установить request.setContentType(),
 * если он нужен.
 */
public interface IWebRenderStream extends IWebRender {

    void saveTo(Object data, OutputStream stm, WebRequest request) throws Exception;

}
