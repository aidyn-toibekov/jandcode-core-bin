package jandcode.web;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import org.apache.commons.logging.*;

import javax.servlet.http.*;
import java.util.*;

/**
 * Сервис web
 */
public class WebService extends CompRt implements IServiceHolder,
        IActivate, IObjectFactoryLink, IIniter {

    protected static Log log = LogFactory.getLog(WebService.class);

    private HttpServlet httpServlet;
    protected ThreadLocal<WebRequest> request = new ThreadLocal<WebRequest>();
    protected ServiceContainer services = new ServiceContainer();
    protected String defaultAction = "page/index.html";
    private ObjectFactory objectFactory = new ObjectFactory(this);

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        // сервисы
        services.addAll(rt.findChild("service"), objectFactory);
    }

    ////// factory


    public void initObject(Object obj) throws Exception {
        getApp().initObject(obj);
    }

    public ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    ////// services

    public <A extends Object> A service(Class<A> clazz) {
        return services.get(clazz);
    }

    public ServiceContainer getServices() {
        return services;
    }

    public void activate() throws Exception {
        for (IActivate svc : services.impl(IActivate.class)) {
            svc.activate();
        }
    }

    public ResourceService getResourceService() {
        return service(ResourceService.class);
    }

    public ActionService getActionService() {
        return service(ActionService.class);
    }

    public TmlService getTmlService() {
        return service(TmlService.class);
    }

    public FilterService getFilterService() {
        return service(FilterService.class);
    }

    public RenderService getRenderService() {
        return service(RenderService.class);
    }

    ////// servlet

    public HttpServlet getHttpServlet() {
        return httpServlet;
    }

    public void setHttpServlet(HttpServlet httpServlet) {
        this.httpServlet = httpServlet;
    }

    ////// request

    public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (!getApp().isRelease() && !getApp().isTest()) {
            // отладочный режим!
            getApp().service(ReloadService.class).checkChangedResource();
        }
        // создаем запрос
        WebRequest req = new WebRequest(httpServlet, request, response, this);
        // делаем его текущим
        setRequest(req);
        // исполняем
        handleRequest(req);
    }

    /**
     * Текущий запрос для потока
     */
    public WebRequest getRequest() {
        return request.get();
    }

    /**
     * Установить текущий запрос. Используется в тестах.
     */
    public void setRequest(WebRequest inst) {
        request.set(inst);
    }

    //////

    public void handleRequest(WebRequest request) throws Exception {
        // кодировка запроса
        request.getHttpRequest().setCharacterEncoding("UTF-8");
        //
        long starttime = 0;
        if (log.isInfoEnabled()) {
            starttime = System.currentTimeMillis();
            log.info(UtString.repeat("-", 80));
            String s = request.getHttpRequest().getRequestURL().toString();
            if (s == null) {
                s = "";
            }
            String qs = request.getHttpRequest().getQueryString();
            if (qs != null) {
                s = s + "?" + qs;
            }
            log.info("request: " + s);
        }
        try {
            //
            onHandleRequest(request);
            onHandleOut(request);
            //
        } catch (Exception e) {
            request.setException(e);
            throw e;
        } finally {
            // запоминаем flash
            request.storeFlash();
            //
            logException(request.getException());

            // выполняем последние фильтры
            getFilterService().afterHandleRequest();

            //
            if (log.isInfoEnabled()) {
                log.info("end request. Exec time: " + String.format("%.3f", (System.currentTimeMillis() - starttime) / 1000.0) + " sec.");
            }
        }
    }

    protected void logException(Throwable e) {
        if (e == null) {
            return;
        }
        if (log.isErrorEnabled()) {
            String msg = getApp().service(ErrorService.class).getErrorFormatter("log").getMessage(e);
            log.error("\n" + msg + "\n");
        }
    }

    protected void onHandleRequest(WebRequest request) throws Exception {
        // фильтры перед всем
        getFilterService().beforeHandleRequest();
        if (request.isStopExec()) {
            return;
        }
        // action
        if (UtString.empty(request.getPathInfo())) {
            request.setPathInfo(defaultAction);
        }
        WebAction action = getActionService().getAction();
        if (action == null) {
            // не найдено ничего подходящего
            request.sendError(404);
        } else {
            request.setAction(action);

            // фильтры перед action
            getFilterService().beforeExec();
            if (request.isStopExec()) {
                return;
            }
            //
            request.getAction().handleRequest();
            //
            getFilterService().afterExec();
        }
    }

    protected boolean handleHttpError(WebRequest request) throws Exception {
        if (request.getErrorCode() != -1) {
            if (request.getErrorMessage() == null) {
                if (log.isInfoEnabled()) {
                    log.info("status: " + request.getErrorCode());
                }
                request.getHttpResponse().sendError(request.getErrorCode());
            } else {
                if (log.isInfoEnabled()) {
                    log.info("status: " + request.getErrorCode() + ", message: " + request.getErrorMessage());
                }
                request.getHttpResponse().sendError(request.getErrorCode(), request.getErrorMessage());
            }
            return true;
        }
        return false;
    }

    protected void onHandleOut(WebRequest request) throws Exception {
        // проверка ошибок
        if (handleHttpError(request)) {
            return;
        }

        // проверка redirect
        if (request.getRedirectUrl() != null) {
            return;
        }

        if (request.getOutStarted() == WebRequest.OUT_STARTED_NO) {
            onRender(request);
        }

    }

    protected void onRender(WebRequest request) throws Exception {
        Object result = request.renderObject;
        String renderType = request.renderType;

        if (UtString.empty(renderType)) {
            throw new XError("Не указан render type");
        }

        if (result == null) {
            throw new XError("Не указан объект для render");
        }


        IWebRender render = getRenderService().createRender(result, renderType);
        //
        String ct = request.getContentType();
        if (!UtString.empty(ct)) {
            request.getHttpResponse().setContentType(ct);
        }
        //
        if (render instanceof IWebRenderStream) {
            ((IWebRenderStream) render).saveTo(result, request.getOutStream(), request);
        } else if (render instanceof IWebRenderWriter) {
            ((IWebRenderWriter) render).saveTo(result, request.getOutWriter(), request);
        } else if (render instanceof IWebRenderBuilder) {
            OutBuilder b = new OutBuilder(getApp());
            ((IWebRenderBuilder) render).saveTo(result, b, request);
            ct = request.getContentType();
            if (!UtString.empty(ct)) {
                request.getHttpResponse().setContentType(ct);
            }
            if (handleHttpError(request)) {
                return;
            }
            b.writeTo(request.getOutWriter());
        }

    }

    ////// utils

    /**
     * Формирование url-адреса для ссылок.
     *
     * @param url         Либо часть url без contextPath, либо полный url
     *                    (с префиксом, например <code>http://</code>).
     *                    Может включать явные параметры через '?'
     * @param virtualRoot при значении true в url добавляется значение request.virtualRoot
     * @param params      параметры
     */
    public String ref(String url, boolean virtualRoot, Map params) {
        UrlBuilder u = new UrlBuilder();
        if (!UrlBuilder.isAbsoluteUrl(url)) {
            u.setRoot(true);
            u.append(getRequest().getHttpRequest().getContextPath());
            u.append(getRequest().getHttpRequest().getServletPath());
            if (virtualRoot) {
                u.append(getRequest().getVrtualRoot());
            }
        }
        u.append(url);

        if (params != null) {
            for (Object o : params.keySet()) {
                String pn = UtString.toString(o);
                Object pv = params.get(o);
                u.append(pn, pv);
            }
        }

        return u.toString();
    }

    /**
     * Формирование url-адреса для ссылок. Автоматически добавляется request.virtualRoot,
     * если он установлен.
     *
     * @param url    Либо часть url без contextPath, либо полный url
     *               (с префиксом, например <code>http://</code>).
     *               Может включать явные параметры через '?'
     * @param params параметры
     */
    public String ref(String url, Map params) {
        return ref(url, true, params);
    }

    /**
     * Формирование url-адреса для ссылок. Автоматически добавляется request.virtualRoot,
     * если он установлен.
     *
     * @param url Либо часть url без contextPath, либо полный url
     *            (с префиксом, например <code>http://</code>).
     *            Может включать явные параметры через '?'
     */
    public String ref(String url) {
        return ref(url, true, null);
    }

}
