package jandcode.web;

import java.util.*;

/**
 * Объект для описания шаблона. Используется для рендеринга.
 */
public class ResponseTml {

    private String tmlName;
    private Map args = new LinkedHashMap();

    public ResponseTml(String tmlName) {
        this.tmlName = tmlName;
    }

    public ResponseTml(String tmlName, Map args) {
        this.tmlName = tmlName;
        if (args != null) {
            this.args.putAll(args);
        }
    }

    public ResponseTml(Map args, String tmlName) {
        this.tmlName = tmlName;
        if (args != null) {
            this.args.putAll(args);
        }
    }

    public String getTmlName() {
        return tmlName;
    }

    public void setTmlName(String tmlName) {
        this.tmlName = tmlName;
    }

    public Map getArgs() {
        return args;
    }
}
