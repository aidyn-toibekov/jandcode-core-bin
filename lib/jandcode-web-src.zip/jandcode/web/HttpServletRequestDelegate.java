package jandcode.web;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.security.*;
import java.util.*;

/**
 * Делегат для HttpServletRequest
 */
public class HttpServletRequestDelegate implements HttpServletRequest {

    protected HttpServletRequest delegate;

    public HttpServletRequestDelegate(HttpServletRequest delegate) {
        this.delegate = delegate;
    }

    public HttpServletRequest getDelegate() {
        return delegate;
    }

    public String getAuthType() {
        return delegate.getAuthType();
    }

    public Cookie[] getCookies() {
        return delegate.getCookies();
    }

    public long getDateHeader(String s) {
        return delegate.getDateHeader(s);
    }

    public String getHeader(String s) {
        return delegate.getHeader(s);
    }

    public Enumeration getHeaders(String s) {
        return delegate.getHeaders(s);
    }

    public Enumeration getHeaderNames() {
        return delegate.getHeaderNames();
    }

    public int getIntHeader(String s) {
        return delegate.getIntHeader(s);
    }

    public String getMethod() {
        return delegate.getMethod();
    }

    public String getPathInfo() {
        return delegate.getPathInfo();
    }

    public String getPathTranslated() {
        return delegate.getPathTranslated();
    }

    public String getContextPath() {
        return delegate.getContextPath();
    }

    public String getQueryString() {
        return delegate.getQueryString();
    }

    public String getRemoteUser() {
        return delegate.getRemoteUser();
    }

    public boolean isUserInRole(String s) {
        return delegate.isUserInRole(s);
    }

    public Principal getUserPrincipal() {
        return delegate.getUserPrincipal();
    }

    public String getRequestedSessionId() {
        return delegate.getRequestedSessionId();
    }

    public String getRequestURI() {
        return delegate.getRequestURI();
    }

    public StringBuffer getRequestURL() {
        return delegate.getRequestURL();
    }

    public String getServletPath() {
        return delegate.getServletPath();
    }

    public HttpSession getSession(boolean b) {
        return delegate.getSession(b);
    }

    public HttpSession getSession() {
        return delegate.getSession();
    }

    public boolean isRequestedSessionIdValid() {
        return delegate.isRequestedSessionIdValid();
    }

    public boolean isRequestedSessionIdFromCookie() {
        return delegate.isRequestedSessionIdFromCookie();
    }

    public boolean isRequestedSessionIdFromURL() {
        return delegate.isRequestedSessionIdFromURL();
    }

    public boolean isRequestedSessionIdFromUrl() {
        return delegate.isRequestedSessionIdFromUrl();
    }

    public Object getAttribute(String s) {
        return delegate.getAttribute(s);
    }

    public Enumeration getAttributeNames() {
        return delegate.getAttributeNames();
    }

    public String getCharacterEncoding() {
        return delegate.getCharacterEncoding();
    }

    public void setCharacterEncoding(String s) throws UnsupportedEncodingException {
        delegate.setCharacterEncoding(s);
    }

    public int getContentLength() {
        return delegate.getContentLength();
    }

    public String getContentType() {
        return delegate.getContentType();
    }

    public ServletInputStream getInputStream() throws IOException {
        return delegate.getInputStream();
    }

    public String getParameter(String s) {
        return delegate.getParameter(s);
    }

    public Enumeration getParameterNames() {
        return delegate.getParameterNames();
    }

    public String[] getParameterValues(String s) {
        return delegate.getParameterValues(s);
    }

    public Map getParameterMap() {
        return delegate.getParameterMap();
    }

    public String getProtocol() {
        return delegate.getProtocol();
    }

    public String getScheme() {
        return delegate.getScheme();
    }

    public String getServerName() {
        return delegate.getServerName();
    }

    public int getServerPort() {
        return delegate.getServerPort();
    }

    public BufferedReader getReader() throws IOException {
        return delegate.getReader();
    }

    public String getRemoteAddr() {
        return delegate.getRemoteAddr();
    }

    public String getRemoteHost() {
        return delegate.getRemoteHost();
    }

    public void setAttribute(String s, Object o) {
        delegate.setAttribute(s, o);
    }

    public void removeAttribute(String s) {
        delegate.removeAttribute(s);
    }

    public Locale getLocale() {
        return delegate.getLocale();
    }

    public Enumeration getLocales() {
        return delegate.getLocales();
    }

    public boolean isSecure() {
        return delegate.isSecure();
    }

    public RequestDispatcher getRequestDispatcher(String s) {
        return delegate.getRequestDispatcher(s);
    }

    public String getRealPath(String s) {
        return delegate.getRealPath(s);
    }

    public int getRemotePort() {
        return delegate.getRemotePort();
    }

    public String getLocalName() {
        return delegate.getLocalName();
    }

    public String getLocalAddr() {
        return delegate.getLocalAddr();
    }

    public int getLocalPort() {
        return delegate.getLocalPort();
    }
}
