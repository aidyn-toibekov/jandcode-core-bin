package jandcode.web;

/**
 * Стилизированный шаблон. В папке с именем компонента лежат шаблоны. Имя одного
 * из них указывается в аргументе tml. Вывод начинается с шаблона '_render.gsp'.
 * Пример: {@code outTml("jc/page", tml: "main")}. Сначала выводится шаблон
 * 'tml/jc/page/_render.gsp', который потом выведет шаблон 'tml/jc/page/main.gsp'.
 * <p/>
 * Если имя tml содержит '/', то оно считается полным именем шаблона.
 *
 * @args tml имя шаблона, который нужно использовать. По умолчанию 'default'
 */
public class StyledTml extends Tml {

    public void render() throws Exception {
        getArgs().setValue("tml", getArgs().getValueString("tml", "default"));
        super.render();
    }

    protected void onRender() throws Exception {
        include(tml("_render"));
    }

    /**
     * Возвращает полное имя шаблона по короткому.
     * Например для 'main' вернет 'jc/page/main.gsp'
     */
    public String tml(String shortName) {
        if (shortName.indexOf('/') != -1) {
            return shortName;
        }
        return getName() + "/" + shortName + ".gsp";
    }
}
