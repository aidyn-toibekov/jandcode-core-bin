package jandcode.web;

import java.io.*;

/**
 * Объект для преобразования объекта в то, что можно отдать web-клиенту.
 * Текстовые данные, которые пишутся непосредственно в getOutWriter().
 * Перед записью нужно обязательно установить request.setContentType(),
 * если он нужен.
 */
public interface IWebRenderWriter extends IWebRender {

    void saveTo(Object data, Writer w, WebRequest request) throws Exception;

}
