package jandcode.web;

import java.util.*;

/**
 * Интерфейс для тегов, которые сами управляют своими дочерними тегами
 */
public interface ITmlTagOwner {

    /**
     * Проверка: нужно ли рендерить этот тег. Если рендерить не нужно, то для
     * тега создается персональный экземпляр и для него будет вызван метод registerChildTml
     *
     * @param tmlName имя тега
     * @param args    аргументы
     * @param body    тело
     * @return true, если рендерить нужно
     */
    boolean needRenderChildTml(String tmlName, Map args, Object body);

    /**
     * Принять дочерний тег. Вызывается, если needRenderChildTml возвращает false.
     *
     * @param tml
     * @return
     */
    void registerChildTml(Tml tml);

}
