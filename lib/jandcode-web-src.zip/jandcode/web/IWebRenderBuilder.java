package jandcode.web;

/**
 * Объект для преобразования объекта в то, что можно отдать web-клиенту.
 * Текстовые данные, которые пишутся в OutBuilder.
 * Перед записью нужно обязательно установить request.setContentType(),
 * если он нужен.
 */
public interface IWebRenderBuilder extends IWebRender {

    void saveTo(Object data, OutBuilder b, WebRequest request) throws Exception;

}
