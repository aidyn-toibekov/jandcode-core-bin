package jandcode.web.tml.jc;


import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.web.*;

/**
 * Иконка (картинка) {@code <script/>}
 *
 * @args icon имя иконки
 * @args type тип (16, 32), по умолчанию - 16
 * @args cssclass класс css
 */
public class IconTml extends Tml {

    protected void onRender() throws Exception {
        //
        String icon = getArgs().getValueString("icon");
        if (UtString.empty(icon)) {
            throw new XError("Аргумент icon не указан");
        }
        String type = getArgs().getValueString("type", "16");
        String cssclass = getArgs().getValueString("cssclass");
        //
        if (icon.indexOf("/") == -1) {
            icon = "images/icon" + type + "/" + icon + ".png";
        }
        icon = ref(icon);
        out("<img src=\"");
        out(icon);
        out("\"");
        if (!UtString.empty(cssclass)) {
            out(" class=\"");
            out(cssclass);
            out("\"");
        }
        out(">");
    }

}