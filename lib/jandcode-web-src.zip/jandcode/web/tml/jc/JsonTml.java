package jandcode.web.tml.jc;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.web.*;

import java.util.*;

/**
 * json
 *
 * @arg data map, которую выводим как json
 * @arg contentType тип контента. Если не указано - "application/json"
 */
public class JsonTml extends Tml {

    public static final String MIME = "application/json";

    protected void onRender() throws Exception {
        Object ct = getArgs().getValue("contentType");
        if (ct == null) {
            ct = MIME;
        }
        getRequest().setContentType(ct.toString());
        Object data = getArgs().getValue("data");
        if (data == null) {
            throw new XError("Аргумент data не указан");
        }
        if (data instanceof Map) {
            MapBuilder b = new MapBuilder();
            b.normalizeSuccess(((Map) data));
        }
        out(UtJson.toString(data));
    }
}
