package jandcode.web.tml.jc;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.vdir.*;
import jandcode.web.*;

import java.util.*;

/**
 * Реализация метода include через тег
 */
public class IncludeTml extends Tml implements ITmlInclude {

    public void doInclude(Map tmlArgs, Object body) throws Exception {
        String path = UtCnv.toString(tmlArgs.get("path"));
        if (UtString.empty(path)) {
            path = UtCnv.toString(tmlArgs.get("url"));
        }
        if (UtString.empty(path)) {
            throw new XError("'path' or 'url' not defined in include");
        }
        path = "/" + VDir.normalize(path);
        getOutBuilder().includeTml(this, path);
    }
}
