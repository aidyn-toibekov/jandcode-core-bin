package jandcode.web.tml.jc;

import jandcode.web.*;

/**
 * Блок. Просто выводит свое тело. Для использования в отложенном рендеренге.
 */
public class BlockTml extends Tml {
    protected void onRender() throws Exception {
        outBody();
    }
}
