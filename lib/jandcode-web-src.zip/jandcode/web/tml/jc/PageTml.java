package jandcode.web.tml.jc;

import jandcode.web.*;

/**
 * Страница.
 * Шаблоны страниц лежат в каталоге 'page'
 *
 * @args tml имя шаблона (из каталога page, без расширения), который нужно использовать.
 * По умолчанию 'main'
 */
public class PageTml extends Tml {

    public void render() throws Exception {
        getArgs().setValue("tml", getArgs().getValueString("tml", "main"));
        super.render();
    }

    protected void onRender() throws Exception {
        include("/page/_render.gsp");
    }

}
