package jandcode.web.tml.jc;


import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.web.*;

import java.util.*;

/**
 * Тег {@code <script/>}
 *
 * @arg url relf куда ссылка
 * @arg params:Map параметры ссылки
 */
public class LinkJsTml extends Tml {

    protected void onRender() throws Exception {
        //
        String url = getArgs().getValueString("url");
        if (UtString.empty(url)) {
            throw new XError("Аргумент url не указан");
        }
        //
        Map params = (Map) getArgs().get("params");

        String icref = ref(url, params);
        out("<script type=\"text/javascript\" src=\"");
        out(icref);
        out("\"></script>");
    }

}