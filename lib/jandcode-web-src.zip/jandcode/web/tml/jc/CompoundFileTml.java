package jandcode.web.tml.jc;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.web.*;
import org.joda.time.*;

import java.io.*;
import java.util.*;

/**
 * Файл-сборник. Составляется из ресурсов, указанных в аргументе files
 *
 * @args files список имен файлов (виртуальных путей)
 * @args before разделитель перед выводом файла. по умолчанию ''. Можно использовать подстановки:
 * ${file} - виртуальный путь
 * @args after разделитель после вывода файла. по умолчанию '\n'. Можно использовать подстановки:
 * ${file} - виртуальный путь
 * @args checkModified проверять дату последней модификации, переданную в заголовке http 'If-Modified-Since'.
 * Если файлы сборника не поменялись то генерится 304. По умолчанию - true
 */
public class CompoundFileTml extends Tml implements ISubstVar {

    private String _var_file;

    protected void onRender() throws Exception {
        List files = (List) getArgs().getValue("files");
        if (files == null || files.size() == 0) {
            throw new XError("Аргумент files не указан");
        }
        String before = getArgs().getValueString("before", "");
        String after = getArgs().getValueString("after", "\n");
        boolean checkModified = getArgs().getValueBoolean("checkModified", true);

        //
        ResourceService svc = getWebService().getResourceService();

        //
        List<ResourceFactory> files2 = new ArrayList<ResourceFactory>();
        DateTime maxDateMod = UtDate.EMPTY_DATE;
        for (Object it : files) {
            ResourceFactory rf = svc.getResourceFactory(UtString.toString(it));
            files2.add(rf);

            // дата модификации
            DateTime lastMod = rf.getLastMod();
            if (lastMod.isAfter(maxDateMod)) {
                maxDateMod = lastMod;
            }
        }

        // дата модификации в запросе
        DateTime lastModReq = null;
        String lastModReqText = getRequest().getHttpRequest().getHeader("If-Modified-Since");
        if (!UtString.empty(lastModReqText)) {
            lastModReq = UtDate.stringToDateTimeGMT(lastModReqText);
            if (checkModified) {
                if (!maxDateMod.isAfter(lastModReq)) {
                    getRequest().sendError(304, "Not Modified");
                    return;
                }
            }
        }

        // устанавливаем дату модификации
        getRequest().getHttpResponse().setHeader("Last-Modified", UtDate.dateToStringGMT(maxDateMod));

        // выводим
        for (ResourceFactory rf1 : files2) {
            _var_file = rf1.getResourcePath();

            StringWriter w = new StringWriter();
            rf1.saveTo(w);
            out(UtString.substVar(before, this));
            out(w.toString());
            out(UtString.substVar(after, this));
        }

    }

    public String onSubstVar(String v) {
        if (v.equals("file")) {
            return _var_file;
        }
        return "";
    }

}
