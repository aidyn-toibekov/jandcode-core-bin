package jandcode.web.tml.jc;


import jandcode.utils.*;
import jandcode.web.*;

/**
 * Преобразование текст в многострочную строку javascript.
 * Текст берется из аргумента value или body (приоритетней)
 *
 * @arg value текст
 * @arg normalizeIndent делать normalizeIndent. По умолчанию - false
 */
public class StringTml extends Tml {

    protected void onRender() throws Exception {
        //
        Body b = getBody();
        String value = "";
        if (b != null) {
            value = grabBody(b).toString();
        } else {
            value = getArgs().getValueString("value");
        }
        boolean doNormalizeIndent = getArgs().getValueBoolean("normalizeIndent", false);
        if (doNormalizeIndent) {
            value = UtString.normalizeIndent(value);
        }
        if (UtString.empty(value)) {
            out("\"\"");
        } else {
            String[] ar = value.split("\n");
            boolean last;
            for (int i = 0; i < ar.length; i++) {
                last = i == ar.length - 1;
                String s = ar[i];
                out("\"");
                out(s.replace("\"", "\\\"").replace("</script>", "<\"+\"/script>"));
                if (!last) {
                    out("\\n");
                }
                out("\"");
                if (!last) {
                    out("+\n");
                }
            }
        }
    }

}