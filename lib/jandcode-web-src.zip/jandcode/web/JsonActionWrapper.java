package jandcode.web;

import jandcode.utils.*;

import java.util.*;

/**
 * wrapper для json. Все ошибки отражает в json.
 */
public class JsonActionWrapper extends ActionWrapper {

    protected Map json = new LinkedHashMap();
    protected String contentType;

    public void exec() throws Exception {
        try {
            super.exec();
        } catch (Exception e) {
            getAction().getRequest().setException(e);
            json.clear();
            MapBuilder b = new MapBuilder();
            b.addError(json, e);
        }
        getAction().getRequest().render("jc/json", UtCnv.toMap(
                "data", json, "contentType", contentType
        ));
    }

    public Map getJson() {
        return json;
    }

    public void setJson(Map json) {
        this.json = json;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
