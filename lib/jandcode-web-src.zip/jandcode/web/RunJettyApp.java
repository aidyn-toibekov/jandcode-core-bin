package jandcode.web;

import jandcode.utils.*;
import jandcode.utils.cli.*;
import org.mortbay.jetty.*;
import org.mortbay.jetty.nio.*;
import org.mortbay.jetty.webapp.*;

/**
 * Запуск web-приложения непосредственно из проекта, без tomcat и настроек.
 * Параметры командной строки:
 * <p/>
 * -p:PORT      // по умолчанию 8080
 * -c:CONTEXT   // по умолчанию /wax
 * -w:WEBDIR    // по умолчанию web
 */
public class RunJettyApp {

    public static void main(String[] args) {
        CliMap cli = new CliMap(args);

        // каталог приложения (задаем в IDE в настройках запуска)
        String appDir = UtFile.getWorkdir().getAbsolutePath();

        // params
        int port = cli.getValueInt("p", 8080);
        String context = cli.getValueString("c", "/wax");
        String webdir = cli.getValueString("w", "web");

        //
        webdir = UtFile.join(appDir, webdir);

        // запускаем сервер
        Server server = new Server();
        Connector connector = new SelectChannelConnector();
        connector.setPort(port);
        server.addConnector(connector);

        WebAppContext root = new WebAppContext(webdir, context);
        server.setHandlers(new Handler[]{root});

        try {
            server.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
