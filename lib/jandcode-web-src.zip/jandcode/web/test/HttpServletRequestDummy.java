package jandcode.web.test;


import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.security.*;
import java.util.*;

@SuppressWarnings({"deprecation"})
public class HttpServletRequestDummy implements HttpServletRequest {

    private String _contextPath = "/";
    private String _authType;
    private Cookie[] _cookies;
    private String _queryString;
    private HashMap<String, String> _parameters = new HashMap<String, String>();
    private String _pathInfo;

    private HttpSessionDummy _session = new HttpSessionDummy();

    private String _requestURI = "";
    private StringBuffer _requestURL = new StringBuffer();

    ///

    public String getAuthType() {
        return _authType;
    }

    public void setAuthType(String authType) {
        _authType = authType;
    }

    //

    public Cookie[] getCookies() {
        return _cookies;
    }

    public void setCookies(Cookie[] cookies) {
        _cookies = cookies;
    }

    //

    public long getDateHeader(String s) {
        return 0;
    }

    public String getHeader(String s) {
        return null;
    }

    //

    public Enumeration getHeaders(String s) {
        return null;
    }

    public Enumeration getHeaderNames() {
        return null;
    }

    public int getIntHeader(String s) {
        return 0;
    }

    public String getMethod() {
        return "GET";
    }

    public String getPathInfo() {
        return _pathInfo;
    }

    public void setPathInfo(String pathInfo) {
        _pathInfo = pathInfo;
    }

    public String getPathTranslated() {
        return null;
    }

    public void setContextPath(String contextPath) {
        _contextPath = contextPath;
    }

    public String getContextPath() {
        return _contextPath;
    }

    public String getQueryString() {
        return _queryString;
    }

    public void setQueryString(String s) {
        _queryString = s;
        _parameters.clear();
        if (s == null) {
            return;
        }
        StringTokenizer st1 = new StringTokenizer(s, "&");
        while (st1.hasMoreTokens()) {
            StringTokenizer st2 = new StringTokenizer(st1.nextToken(), "=");
            _parameters.put(st2.nextToken(),
                    java.net.URLDecoder.decode(st2.nextToken()));
        }
    }

    public String getRemoteUser() {
        return null;
    }

    public boolean isUserInRole(String s) {
        return false;
    }

    public Principal getUserPrincipal() {
        return null;
    }

    public String getRequestedSessionId() {
        return null;
    }

    //////

    public String getRequestURI() {
        return _requestURI;
    }

    public void setRequestURI(String requestURI) {
        _requestURI = requestURI;
    }

    //////

    public StringBuffer getRequestURL() {
        return _requestURL;
    }

    public void setRequestURL(StringBuffer requestURL) {
        _requestURL.setLength(0);
        if (requestURL != null) {
            _requestURL.append(requestURL);
        }
    }

    public void setRequestURL(String requestURL) {
        _requestURL.setLength(0);
        if (requestURL != null) {
            _requestURL.append(requestURL);
        }
    }

    //////

    public String getServletPath() {
        return null;
    }

    public HttpSession getSession(boolean b) {
        return null;
    }

    public HttpSession getSession() {
        return _session;
    }

    public boolean isRequestedSessionIdValid() {
        return false;
    }

    public boolean isRequestedSessionIdFromCookie() {
        return false;
    }

    public boolean isRequestedSessionIdFromURL() {
        return false;
    }

    public boolean isRequestedSessionIdFromUrl() {
        return false;
    }

    public Object getAttribute(String s) {
        return null;
    }

    public Enumeration getAttributeNames() {
        return null;
    }

    public String getCharacterEncoding() {
        return null;
    }

    public void setCharacterEncoding(String s) throws UnsupportedEncodingException {

    }

    public int getContentLength() {
        return 0;
    }

    public String getContentType() {
        return null;
    }

    public ServletInputStream getInputStream() throws IOException {
        return null;
    }

    public String getParameter(String s) {
        return _parameters.get(s);
    }

    public void putParameter(String key, String value) {
        _parameters.put(key, value);
    }

    public Enumeration getParameterNames() {
        return new Enumeration() {
            Object[] ar = _parameters.keySet().toArray();
            int idx = 0;

            public boolean hasMoreElements() {
                return idx < ar.length;
            }

            public Object nextElement() {
                idx++;
                return ar[idx - 1];
            }
        };
    }

    public String[] getParameterValues(String s) {
        return new String[0];
    }

    public Map getParameterMap() {
        return null;
    }

    public String getProtocol() {
        return null;
    }

    public String getScheme() {
        return null;
    }

    public String getServerName() {
        return null;
    }

    public int getServerPort() {
        return 0;
    }

    public BufferedReader getReader() throws IOException {
        return null;
    }

    public String getRemoteAddr() {
        return null;
    }

    public String getRemoteHost() {
        return null;
    }

    public void setAttribute(String s, Object o) {

    }

    public void removeAttribute(String s) {

    }

    public Locale getLocale() {
        return null;
    }

    public Enumeration getLocales() {
        return null;
    }

    public boolean isSecure() {
        return false;
    }

    public RequestDispatcher getRequestDispatcher(String s) {
        return null;
    }

    public String getRealPath(String s) {
        return null;
    }

    public int getRemotePort() {
        return 0;
    }

    public String getLocalName() {
        return null;
    }

    public String getLocalAddr() {
        return null;
    }

    public int getLocalPort() {
        return 0;
    }
}