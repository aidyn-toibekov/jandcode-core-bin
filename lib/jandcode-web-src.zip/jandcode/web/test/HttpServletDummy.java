package jandcode.web.test;

import javax.servlet.http.*;

public class HttpServletDummy extends HttpServlet {

}
