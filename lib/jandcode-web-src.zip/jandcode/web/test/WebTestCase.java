package jandcode.web.test;

import jandcode.app.test.*;

/**
 * Предок для web-тестов
 */
public abstract class WebTestCase extends AppTestCase {

    public TestExtWeb web = createExt(TestExtWeb.class);

}
