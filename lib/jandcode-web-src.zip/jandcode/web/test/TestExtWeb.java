package jandcode.web.test;

import jandcode.app.*;
import jandcode.app.test.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.test.*;
import jandcode.web.*;

import java.net.*;
import java.util.*;

/**
 * Расширение для web-тестов
 */
public class TestExtWeb extends TestExt {

    public String serverUrl = "http://unittest";
    public String contextPath = "/test";
    public HttpServletDummy httpServlet;
    public HttpServletRequestDummy httpRequest;
    public HttpServletResponseDummy httpResponse;
    public WebRequest request;

    public void setUp() throws Exception {
        super.setUp();
        httpServlet = new HttpServletDummy();
        createRequest("TEST");
    }

    public TestExtApp getAppTest() {
        return test.getExt(TestExtApp.class);
    }

    public App getApp() {
        return getAppTest().getApp();
    }

    public WebService getWebService() {
        return getApp().service(WebService.class);
    }

    public ResourceService getResourceService() {
        return getWebService().getResourceService();
    }

    public ActionService getActionService() {
        return getWebService().getActionService();
    }

    public TmlService getTmlService() {
        return getWebService().getTmlService();
    }

    public FilterService getFilterService() {
        return getWebService().getFilterService();
    }

    public RenderService getRenderService() {
        return getWebService().getRenderService();
    }

    /**
     * Создать запрос с указанными свойствами и сделать его текущим
     */
    public WebRequest createRequest(String url, Map params) {
        //
        httpRequest = new HttpServletRequestDummy();
        httpRequest.setContextPath(contextPath);
        //
        httpResponse = new HttpServletResponseDummy();
        httpResponse.createOutWriter();

        url = test.replaceTestName(url);

        URL u;

        if (!url.startsWith(contextPath)) {
            if (url.startsWith("/")) {
                url = url.substring(1);
            }
            url = contextPath + "/" + url;
        }
        if (!url.startsWith("/")) {
            url = "/" + url;
        }

        try {
            u = new URL(url);
        } catch (MalformedURLException e) {
            try {
                u = new URL(serverUrl + url);
            } catch (MalformedURLException e1) {
                throw new XErrorWrap(e1);
            }
        }

        String s = u.getQuery();
        if (s != null) {
            httpRequest.setQueryString(s);
        }

        s = u.getPath();
        if (s.startsWith(contextPath + "/")) {
            s = s.substring(contextPath.length() + 1);
        }
        httpRequest.setPathInfo(s);
        //
        String us = u.getProtocol() + "://" + u.getHost() + u.getPath();
        httpRequest.setRequestURL(us);
        httpRequest.setRequestURI(us);

        // params
        if (params != null) {
            for (Object key : params.keySet()) {
                Object value = params.get(key);
                String ks = UtString.toString(key);
                httpRequest.putParameter(ks, UtString.toString(value));
            }
        }

        //
        request = new WebRequest(httpServlet, httpRequest, httpResponse, getWebService());
        getWebService().setRequest(request);
        //
        return request;
    }

    /**
     * Создать запрос с указанными свойствами и сделать его текущим
     */
    public WebRequest createRequest(String url) {
        return createRequest(url, null);
    }

    /**
     * Выполнить url и вернуть текст
     */
    public String execRequest(String url, Map params) throws Exception {
        createRequest(url, params);
        // исполняем
        getWebService().handleRequest(request);
        //
        return getOutText();
    }

    /**
     * Выполнить url и вернуть текст
     */
    public String execRequest(String url) throws Exception {
        return execRequest(url, null);
    }

    /**
     * Результат выполнения последнего запроса в виде текста
     */
    public String getOutText() {
        return httpResponse.getOutText();
    }

    /**
     * Проверить, что не было ошибок http
     */
    public void checkError() {
        if (request.getErrorCode() != -1) {
            throw new XError("HTTP ERROR: " + request.getErrorCode() + ":" + request.getErrorMessage());
        }
    }

    //////

    public String render(String tmlName, Map args) throws Exception {
        createRequest("dummy");
        request.render(tmlName, args);
        // исполняем
        getWebService().handleRequest(request);
        //
        return getOutText();
    }

    public String render(String tmlName, Object... args) throws Exception {
        return render(tmlName, UtCnv.toMap(args));
    }

    public void outMapJson(String s) {
        if (s == null) return;
        Map map = (Map) UtJson.toObject(s);
        test.outMap(map);
    }
}
