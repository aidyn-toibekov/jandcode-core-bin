package jandcode.web;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;
import jandcode.utils.vdir.*;
import jandcode.web.impl.*;
import org.apache.commons.fileupload.*;
import org.apache.commons.fileupload.disk.*;
import org.apache.commons.fileupload.servlet.*;
import org.joda.time.*;

import javax.servlet.http.*;
import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Запрос. Объект создается в начале обработки и используется на всех ее этапах.
 * Содержит данные запроса, ответа и некоторые утилиты для запроса/ответа.
 */
public class WebRequest {

    /**
     * Имя переменной сессии, где хранится flash-данные
     */
    public static final String SESSION_FLASH = WebRequest.class.getName() + ".FLASH";

    /**
     * Имя переменной сессии, где хранится генератор id в рамках сессии
     */
    public static final String SESSION_NEXTID = WebRequest.class.getName() + ".NEXTID";

    /**
     * Префикс для ajax-сообщений об ошибках
     */
    public static final String ERROR_AJAX_PREFIX = "ERROR_AJAX:";

    protected HttpServletRequest httpRequest;
    protected HttpServletResponse httpResponse;
    protected HttpServlet httpServlet;
    protected WebService webService;

    protected IVariantMap params = new VariantMap();
    protected IVariantMap session;
    protected FlashVariantMap flash = new FlashVariantMap();
    protected String pathInfo;

    protected int errorCode = -1;
    protected String errorMessage;
    protected Throwable exception;

    protected String redirectUrl;
    protected int nextId;

    protected int outStarted;
    public static int OUT_STARTED_NO = 0;
    public static int OUT_STARTED_TEXT = 1;
    public static int OUT_STARTED_BIN = 2;

    protected String contentType;

    protected WebAction action;

    /**
     * Объект для render результата запроса
     */
    protected Object renderObject;

    /**
     * тип render
     */
    protected String renderType;

    /**
     * Виртуальный root
     */
    protected String vrtualRoot;

    private long startTime;


    public WebRequest(HttpServlet servlet, HttpServletRequest request, HttpServletResponse response, WebService webService) {
        // время начала запроса
        this.startTime = System.currentTimeMillis();
        //
        this.httpServlet = servlet;
        this.httpRequest = request;
        this.httpResponse = response;
        this.webService = webService;
        // забираем параметры
        grabParams();
        grabSession();
        grabFlash();
    }

    public WebService getWebService() {
        return webService;
    }

    ////// real http objects

    public HttpServletRequest getHttpRequest() {
        return httpRequest;
    }

    public HttpServletResponse getHttpResponse() {
        return httpResponse;
    }

    public HttpServlet getHttpServlet() {
        return httpServlet;
    }

    ////// virtual http objects

    /**
     * Параметры запроса
     */
    public IVariantMap getParams() {
        return params;
    }

    /**
     * Атрибуты сессии запроса
     */
    public IVariantMap getSession() {
        return session;
    }

    /**
     * Специальный map, который хранит, так называемые, flash-данные. Эти данные будут доступны
     * только в следующем запросе в рамках одной и той же сессии. Обычно используется
     * при redirect. Перед redirect сюда сохраняем значения, внутри redirect они доступны, после - нет.
     */
    public IVariantMap getFlash() {
        return flash;
    }

    /**
     * Путь в url
     */
    public String getPathInfo() {
        return pathInfo;
    }

    public void setPathInfo(String pathInfo) {
        this.pathInfo = pathInfo;
    }

    /**
     * Забрать параметры в getParams()
     */
    protected void grabParams() {
        getParams().clear();
        HttpServletRequest hreq = getHttpRequest();
        Enumeration en = hreq.getParameterNames();
        while (en.hasMoreElements()) {
            String pn = en.nextElement().toString();
            getParams().put(pn, hreq.getParameter(pn));
        }

        // multipart form
        if (ServletFileUpload.isMultipartContent(getHttpRequest())) {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            ServletFileUpload upload = new ServletFileUpload(factory);
            try {
                List<FileItem> items = upload.parseRequest(getHttpRequest());

                for (FileItem it : items) {
                    if (it.isFormField()) {
                        String nm = it.getFieldName();
                        String vl = it.getString();
                        getParams().put(nm, vl);
                    } else {
                        String nm = it.getFieldName();
                        getParams().put(nm, it);
                    }
                }
            } catch (FileUploadException e) {
                throw new XErrorWrap(e);
            }
        }

        // pathinfo
        pathInfo = getHttpRequest().getPathInfo();
        pathInfo = VDir.normalize(pathInfo); // '/' превращается в пусто!
    }

    /**
     * Забрать атрибуты сессии в getSession()
     */
    protected void grabSession() {
        session = new VariantMapWrap(new HttpSessionMap(getHttpRequest().getSession()));
    }

    /**
     * Забрать flash в getFlash() из сессии
     */
    protected void grabFlash() {
        FlashVariantMap flash;
        try {
            flash = (FlashVariantMap) getSession().get(SESSION_FLASH);
        } catch (Exception e) {
            flash = null;
            getSession().put(SESSION_FLASH, flash);
        }

        if (flash != null) {
            this.flash = flash;
        }

        //
        this.flash.setChanged(false);
    }

    /**
     * Запомнить flash
     */
    public void storeFlash() {
        if (flash.isChanged()) {
            // была модификация flash, оставляем для следующего запроса
            getSession().put(SESSION_FLASH, flash);
        } else {
            // не было модификаций, значит не нужен
            getSession().put(SESSION_FLASH, null);
        }
    }

    ////// error

    /**
     * Уведомление об ошибке http (например: {@link HttpServletResponse#SC_NOT_FOUND})
     * и сообщением.
     *
     * @param error   код ошибки
     * @param message сообщение. Можно передать null, тогда используется сообщение по умолчанию
     */
    public void sendError(int error, String message) {
        errorCode = error;
        errorMessage = message;
    }

    /**
     * {@link WebRequest#sendError(int, java.lang.String)}, где
     * <code>message=null</code>.
     */
    public void sendError(int error) {
        sendError(error, null);
    }

    /**
     * Код установленный sendError
     */
    public int getErrorCode() {
        return errorCode;
    }

    /**
     * Сообщение, установленное sendError
     */
    public String getErrorMessage() {
        return errorMessage == null ? "" : errorMessage;
    }

    public Throwable getException() {
        return exception;
    }

    /**
     * Установить Exception, которая возникла в процессе обработки, но была
     * скрыта по каким то причинам (например при возврате в формате json)
     *
     * @param exception
     */
    public void setException(Throwable exception) {
        this.exception = exception;
    }

    ////// redirect

    /**
     * redirect на указанный url.
     * Адрес формируется методом {@link WebService#ref(java.lang.String, boolean, java.util.Map)}
     */
    public void redirect(String url, boolean virtualRoot, Map params) {
        try {
            redirectUrl = getWebService().ref(url, virtualRoot, params);
            getHttpResponse().sendRedirect(redirectUrl);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    /**
     * redirect на указанный url.
     * Адрес формируется методом {@link WebService#ref(java.lang.String, java.util.Map)}
     */
    public void redirect(String url, Map params) {
        redirect(url, true, params);
    }


    /**
     * {@link WebRequest#redirect(java.lang.String, java.util.Map)}, где
     * <code>params=null</code>.
     */
    public void redirect(String url) {
        redirect(url, null);
    }

    /**
     * url, на который заказан redirect или null
     */
    public String getRedirectUrl() {
        return redirectUrl;
    }


    ////// id

    /**
     * Возвращает уникальный id в пределах запроса
     */
    public int getNextId() {
        nextId++;
        return nextId;
    }

    /**
     * Возвращает уникальный id в пределах сессии
     */
    public int getSessionNextId() {
        int a = getSession().getValueInt(SESSION_NEXTID);
        a++;
        getSession().setValue(SESSION_NEXTID, a);
        return a;
    }

    //////

    /**
     * Признак ajax запроса
     */
    public boolean isAjax() {
        String hdr = getHttpRequest().getHeader("X-Requested-With");
        return !UtString.empty(hdr);
    }

    ////// response

    /**
     * Возвращает writer, куда нужно писать текст
     */
    public Writer getOutWriter() {
        if (outStarted == OUT_STARTED_NO) {
            outStarted = OUT_STARTED_TEXT;
            getHttpResponse().setCharacterEncoding(UtString.UTF8);
            try {
                return getHttpResponse().getWriter();
            } catch (IOException e) {
                throw new XErrorWrap(e);
            }
        }
        if (outStarted == OUT_STARTED_TEXT) {
            try {
                return getHttpResponse().getWriter();
            } catch (IOException e) {
                throw new XErrorWrap(e);
            }
        }
        throw new XError("Попытка получить getOutWriter после получения getOutStream");
    }

    /**
     * Возвращает stream, куда нужно писать бинарные данные
     */
    public OutputStream getOutStream() {
        if (outStarted == OUT_STARTED_NO) {
            outStarted = OUT_STARTED_BIN;
            try {
                return getHttpResponse().getOutputStream();
            } catch (IOException e) {
                throw new XErrorWrap(e);
            }
        }
        if (outStarted == OUT_STARTED_BIN) {
            try {
                return getHttpResponse().getOutputStream();
            } catch (IOException e) {
                throw new XErrorWrap(e);
            }
        }
        throw new XError("Попытка получить getOutStream после получения getOutWriter");
    }

    /**
     * Что было взято для вывода: writer,stream или ничего
     */
    public int getOutStarted() {
        return outStarted;
    }

    /**
     * Метка, что вывод осуществлен (например какими либо внешними инструментами)
     * и рендерить ничего не нужно.
     */
    public void markOutStarted() {
        outStarted = OUT_STARTED_BIN;
    }

    /**
     * Установить contentType ответа
     */
    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    /**
     * Установленный contentType ответа или null, если не переопределен
     */
    public String getContentType() {
        return contentType;
    }

    //////

    /**
     * Возвращает true, если нужно прервать выполнение запроса.
     * Либо ошибка передана через sendError, либо был redirect.
     */
    public boolean isStopExec() {
        if (errorCode != -1) {
            return true;
        }
        if (redirectUrl != null) {
            return true;
        }
        return false;
    }

    //////

    /**
     * Исполняемая action
     */
    public WebAction getAction() {
        return action;
    }

    public void setAction(WebAction action) {
        this.action = action;
    }

    ////// render

    /**
     * Результатом запроса объявить шаблон с указанным именем и аргументами
     *
     * @param tmlName имя шаблона
     * @param tmlArgs аргументы для шаблона
     */
    public void render(String tmlName, Map tmlArgs) {
        render(new ResponseTml(tmlName, tmlArgs), "html");
    }

    /**
     * Результатом запроса объявить шаблон с указанным именем и без аргументов
     *
     * @param tmlName имя шаблона
     */
    public void render(String tmlName) {
        render(tmlName, (Map) null);
    }

    /**
     * Результатом запроса объявить объект result с типом рендеринга renderType
     *
     * @param result     что рендерить
     * @param renderType каким рендером
     */
    public void render(Object result, String renderType) {
        this.renderObject = result;
        this.renderType = renderType;
    }

    //////

    /**
     * Устанавливает атрибуты ответа такими, что бы ответ не кешировался
     */
    public void noCache() {
        String pastDate = UtDate.dateToStringGMT(new DateTime("1973-09-15"));
        HttpServletResponse r = getHttpResponse();
        r.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        r.setHeader("Pragma", "no-cache");
        r.setHeader("Last-Modified", pastDate);
        r.setHeader("Expires", pastDate);
    }

    /**
     * Установить заголовок http для download файла.
     * Пытается поддерживать русские имена файлов
     *
     * @param fileName имя файла, которым будет представляется ответ
     */
    public void setHeaderDownload(String fileName) throws Exception {
        if (contentType == null) {
            setContentType("application/octet-stream");
        }
        String userAgent = getHttpRequest().getHeader("USER-AGENT").toLowerCase();
        if (userAgent == null) {
            userAgent = "";
        }
        fileName = URLEncoder.encode(fileName, "UTF8");
        boolean isMozilla = userAgent.contains("mozilla") && userAgent.contains("gecko")
                && !userAgent.contains("applewebkit");
        if (isMozilla) {
            getHttpResponse().setHeader(
                    "Content-Disposition",
                    "attachment; filename*=\"utf-8'" + fileName + "\""
            );
        } else {
            getHttpResponse().setHeader(
                    "Content-Disposition",
                    "attachment; filename=\"" + fileName + "\""
            );
        }
    }

    //////

    /**
     * Виртуальный root. Если установлен, то в функции ref() он будет добавлен
     * к любому виртуальному пути. Для получения ref() без этого виртуального корня
     * имеется функция ref() с явным требованием включения/исключения виртуального пути.
     */
    public String getVrtualRoot() {
        return vrtualRoot;
    }

    public void setVrtualRoot(String vrtualRoot) {
        this.vrtualRoot = vrtualRoot;
    }

    //////

    /**
     * Время начала выполнения запроса.
     */
    public long getStartTime() {
        return startTime;
    }

}
