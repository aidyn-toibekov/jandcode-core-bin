package jandcode.web;

import jandcode.app.*;
import jandcode.utils.error.*;
import jandcode.utils.io.*;
import jandcode.utils.vdir.*;
import org.apache.commons.vfs2.*;
import org.joda.time.*;

import java.io.*;

/**
 * Формирование статических ресурсов
 */
public abstract class ResourceFactory extends CompRt implements ISaver {

    protected String resourcePath;
    protected boolean binary;
    private boolean getFilesOk;
    protected VDirVfs vdir;
    protected ResourceService.FileType fileType;

    /**
     * Виртуальный путь к ресурсу, например 'js/core/Utils.js'
     */
    public void setResourcePath(String resourcePath) {
        if (this.resourcePath != null) {
            throw new XError("setResourcePath called twisted");
        }
        this.resourcePath = VDir.normalize(resourcePath);
    }

    public String getResourcePath() {
        return resourcePath;
    }

    /**
     * Признак бинарного ресурса
     */
    public boolean isBinary() {
        return binary;
    }

    /**
     * Виртуальный каталог для поиска файлов
     */
    public void setVdir(VDirVfs vdir) {
        this.vdir = vdir;
    }

    public ResourceService.FileType getFileType() {
        return fileType;
    }

    public void setFileType(ResourceService.FileType fileType) {
        this.fileType = fileType;
    }

    /**
     * Записать в writer для текстового ресурса
     */
    public void saveTo(Writer w) throws Exception {
        if (binary) {
            throw new XError("Resource {0} is binary", resourcePath);
        }
        getFiles();
        onSaveTo(w);
    }

    public SaveTo save() {
        return new SaveTo(this);
    }

    /**
     * Записать в бинарный поток для бинарного ресурса
     */
    public void saveTo(OutputStream stm) throws Exception {
        if (!binary) {
            throw new XError("Resource {0} is not binary", resourcePath);
        }
        getFiles();
        onSaveTo(stm);
    }

    /**
     * Возвращает дату последнего модифицирования ресурса или null, если это нельзя
     * определить
     *
     * @return
     */
    public DateTime getLastMod() throws Exception {
        getFiles();
        return onGetLastMod();
    }


    ////// utils

    /**
     * Проверка на дату модификации после указанной
     */
    protected DateTime getMaxLastMod(FileObject f, DateTime curLastMod) throws Exception {
        if (f == null) {
            return curLastMod;
        }
        // проверяем дату модификации, если нужно
        DateTime lastMod = new DateTime(f.getContent().getLastModifiedTime()).withMillisOfSecond(0);
        if (curLastMod == null) {
            return lastMod;
        }
        if (lastMod.isAfter(curLastMod)) {
            return lastMod;
        }
        return curLastMod;
    }

    private void getFiles() throws Exception {
        if (getFilesOk) {
            return;
        }
        getFilesOk = true;
        onGetFiles();
    }

    public WebRequest getRequest() {
        return getApp().service(WebService.class).getRequest();
    }

    //////

    /**
     * Тут можно собрать все нужные реальные файлы. Автоматически вызывается перед
     * записью и проверкой даты модификации. Вызывается только раз.
     */
    protected abstract void onGetFiles() throws Exception;

    /**
     * Реализация записи в бинарный поток для бинарного ресурса
     */
    protected abstract void onSaveTo(OutputStream stm) throws Exception;

    /**
     * Реализация записи в бинарный поток для бинарного ресурса
     */
    protected abstract void onSaveTo(Writer w) throws Exception;

    /**
     * Реализация getLastMod
     */
    protected abstract DateTime onGetLastMod() throws Exception;

}
