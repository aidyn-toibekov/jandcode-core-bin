package jandcode.web;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

/**
 * Сервис для рендеринга объектов в клиентское представление
 */
public class RenderService extends CompRt {

    private ClassLinks<TypeInfo> typeInfos = new ClassLinks<TypeInfo>();

    class TypeInfo {
        private HashMapNoCase<Class> renderCls = new HashMapNoCase<Class>();

        public void addRender(String name, Class cls) {
            renderCls.put(name, cls);
        }

        public Class getRender(String type) {
            return renderCls.get(type);
        }
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt z;
        //
        z = getApp().getRt().findChild("web/type");
        if (z != null) {
            for (Rt rt1 : z.getChilds()) {
                TypeInfo ri = new TypeInfo();
                Rt z1 = rt1.findChild("render");
                if (z1 != null) {
                    for (Rt rt2 : z1.getChilds()) {
                        ri.addRender(rt2.getName(), getObjectFactory().getClass(rt2.getValueString("class")));
                    }
                }
                typeInfos.add(rt1.getName(), ri);
            }
        }
        //
    }

    public ObjectFactory getObjectFactory() {
        return getApp().service(WebService.class).getObjectFactory();
    }

    /**
     * Создать render указанного типа для объекта
     *
     * @param result     для какого объекта
     * @param renderType какой тип render
     * @return render
     */
    public IWebRender createRender(Object result, String renderType) {
        TypeInfo ri;
        String cn = "null";
        if (result != null) {
            cn = result.getClass().getName();
        }
        ri = typeInfos.get(cn);
        if (ri == null) {
            throw new XError("Не определен render для класса {0}", cn);
        }
        Class rndCls = ri.getRender(renderType);
        if (rndCls == null) {
            throw new XError("Не определен render {1} для класса {0}", cn, renderType);
        }
        return (IWebRender) getObjectFactory().create(rndCls);
    }


}
