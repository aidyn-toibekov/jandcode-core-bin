package jandcode.web;

/**
 * Объект для преобразования объекта в то, что можно отдать web-клиенту.
 * Этот интерфейс - метка. Конкретные render должны реализовывать интерфейсы
 * IWebRenderXXX
 */
public interface IWebRender {
}
