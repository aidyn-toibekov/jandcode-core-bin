package jandcode.web;

import org.joda.time.*;

import java.io.*;

/**
 * Для поддержки ResourceFactory через делегатов
 */
public abstract class ResourceFactoryDelegate extends ResourceFactory {

    protected abstract ResourceFactory getDelegate();

    protected ResourceFactory createDelegate(Class delegateClass, String resourcePath) {
        ResourceFactory delegate = (ResourceFactory) getApp().service(WebService.class).getObjectFactory().create(delegateClass);
        delegate.setVdir(vdir);
        if (resourcePath == null) {
            resourcePath = getResourcePath();
        }
        delegate.setResourcePath(resourcePath);
        delegate.setFileType(getFileType());
        return delegate;
    }

    protected void onGetFiles() throws Exception {
        getDelegate().onGetFiles();
    }

    protected void onSaveTo(OutputStream stm) throws Exception {
        getDelegate().onSaveTo(stm);
    }

    protected void onSaveTo(Writer w) throws Exception {
        getDelegate().onSaveTo(w);
    }

    protected DateTime onGetLastMod() throws Exception {
        return getDelegate().onGetLastMod();
    }

}
