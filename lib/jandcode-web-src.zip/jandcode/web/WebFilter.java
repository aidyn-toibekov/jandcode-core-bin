package jandcode.web;

import jandcode.app.*;
import jandcode.utils.variant.*;

/**
 * Фильтр для обработки запроса.
 */
public class WebFilter extends CompRt {

    protected int index;
    protected int weight = 50;

    //////

    /**
     * Метод выполняется в самом начале процесса обработки запроса.
     * К момену выполнения action еще не известна.
     */
    protected void onBeforeHandleRequest() throws Exception {
    }

    /**
     * Метод выполняется в самом конце процесса обработки запроса.
     * Все уже отрендерено.
     * Вызывается всегда, даже если были ошибки.
     * Необходимо гарантировать, что exception не возникнет в этом методе,
     * иначе запрос будет с ошибкой.
     */
    protected void onAfterHandleRequest() throws Exception {
    }


    /**
     * Метод выполняется перед тем, как управление будет передано action.
     */
    protected void onBeforeExec() throws Exception {

    }

    /**
     * Метод выполняется после того, как будет выполнена action.
     */
    protected void onAfterExec() throws Exception {

    }


    //////

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public void beforeExec() throws Exception {
        onBeforeExec();
    }

    public void afterExec() throws Exception {
        onAfterExec();
    }

    public void beforeHandleRequest() throws Exception {
        onBeforeHandleRequest();
    }

    public void afterHandleRequest() throws Exception {
        onAfterHandleRequest();
    }

    public WebRequest getRequest() {
        return getApp().service(WebService.class).getRequest();
    }

    public IVariantMap getParams() {
        return getRequest().getParams();
    }

    public IVariantMap getSession() {
        return getRequest().getSession();
    }

    public WebAction getAction() {
        return getRequest().getAction();
    }
}
