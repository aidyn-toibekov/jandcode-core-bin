package jandcode.web;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import java.lang.reflect.*;
import java.util.*;

/**
 * Action для обработки запроса.
 * В момент handleRequest метод getPathInfo() возвращается без имени action.
 * Если выполняется стандартная обработка через onExec, которая выполняет метод,
 * имя которого первым в pathInfo, то имя метода удаляется из getPathInfo().
 * В любом случае оригинальный getRequest().getPathInfo() не трогается.
 */
public class WebAction extends Comp {

    private String methodName = "index";
    private String pathInfo;

    public void handleRequest() throws Exception {
        onHandleRequest();
    }

    protected void onHandleRequest() throws Exception {
        WebRequest request = getRequest();
        onBeforeExec();
        if (request.isStopExec()) {
            return;
        }

        onExec();
        if (request.isStopExec()) {
            return;
        }

        onAfterExec();
    }

    /**
     * Реализация обработки запроса. По умолчанию вызывает метод methodName
     */
    protected void onExec() throws Exception {
        parsePathInfo(getPathInfo());
        execMethod(methodName);
    }

    /**
     * Выполняется перед onExec
     */
    protected void onBeforeExec() throws Exception {
    }

    /**
     * Выполняется после onExec
     */
    protected void onAfterExec() throws Exception {
    }

    //////

    protected void execMethod(String name) throws Exception {
        Method m = findActionMethod(methodName);
        if (m == null) {
            getRequest().sendError(404, getName() + "/" + methodName);
            return;
        }
        Class[] prms = m.getParameterTypes();
        if (prms.length == 1) {
            if (ActionWrapper.class.isAssignableFrom(prms[0])) {
                ActionWrapper w = (ActionWrapper) getApp().getObjectFactory().create(prms[0]);
                w.setAction(this, m);
                w.exec();
                return;
            }
        }
        m.invoke(this);
    }

    /**
     * Имя исполняемого метода
     */
    public String getMethodName() {
        return methodName;
    }

    /**
     * Остаток пути из pathInfo, откуда удален methodName
     */
    public String getPathInfo() {
        if (pathInfo == null) {
            return getRequest().getPathInfo();
        }
        return pathInfo;
    }

    public void setPathInfo(String pathInfo) {
        this.pathInfo = pathInfo;
    }

    /**
     * Устанавливает methodName и pathInfo для action.
     *
     * @param pi pathInfo из request. Первая часть до '/' - methodName, остальное - pathInfo
     */
    protected void parsePathInfo(String pi) {
        if (UtString.empty(pi)) {
            methodName = "index";
            pathInfo = "";
        } else {
            int a = pi.indexOf('/');
            if (a == -1) {
                methodName = pi;
                pathInfo = "";
            } else {
                methodName = pi.substring(0, a);
                pathInfo = pi.substring(a + 1);
            }
        }
    }

    protected Method findActionMethod(String name) {
        return findActionMethod(name, WebAction.class);
    }

    protected Method findActionMethod(String name, Class stopClass) {
        Class cur = this.getClass();
        while (cur != null && cur != stopClass) {
            Method[] mts = cur.getDeclaredMethods();
            for (Method mt : mts) {
                if (!mt.getName().equalsIgnoreCase(name)) {
                    continue;
                }
                int md = mt.getModifiers();
                if (!Modifier.isPublic(md)) {
                    continue;
                }
                if (mt.getReturnType() != void.class) {
                    continue;
                }
                if (mt.getParameterTypes().length > 1) {
                    continue;
                }
                return mt;
            }
            cur = cur.getSuperclass();
        }
        return null;
    }

    ////// delegate

    public WebRequest getRequest() {
        return getApp().service(WebService.class).getRequest();
    }

    public IVariantMap getParams() {
        return getRequest().getParams();
    }

    public IVariantMap getSession() {
        return getRequest().getSession();
    }

    public IVariantMap getFlash() {
        return getRequest().getFlash();
    }

    public void sendError(int error, String message) {
        getRequest().sendError(error, message);
    }

    public void sendError(int error) {
        getRequest().sendError(error);
    }

    public void redirect(String url, Map params) {
        getRequest().redirect(url, params);
    }

    public void redirect(String url) {
        getRequest().redirect(url);
    }

    public void render(String tmlName, Map tmlArgs) {
        getRequest().render(tmlName, tmlArgs);
    }

    public void render(String tmlName) {
        getRequest().render(tmlName);
    }

    public void render(Object result, String renderType) {
        getRequest().render(result, renderType);
    }

}
