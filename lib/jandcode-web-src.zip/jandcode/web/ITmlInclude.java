package jandcode.web;

import java.util.*;

/**
 * Интерфейс для tml, которые не рендерятся обычным способом,
 * а работают в режиме include.
 */
public interface ITmlInclude {

    /**
     * Обработать включение
     *
     * @param tmlArgs аргументы тега
     * @param body    тело тега
     */
    void doInclude(Map tmlArgs, Object body) throws Exception;

}
