package jandcode.web;

import jandcode.utils.*;
import org.codehaus.groovy.runtime.*;

import java.io.*;
import java.util.*;

/**
 * Буфер вывода текста при рендеринге.
 * Объекты null заменяются при выводе на пустую строку.
 */
public class TextBuffer implements CharSequence {

    protected StringBuilder sb = new StringBuilder();

    /**
     * Вернуть текст буфера в виде строки
     */
    public String toString() {
        return sb.toString();
    }

    /**
     * Вывести значение в буфер. Основной метода для использования.
     *
     * @param s что вывести
     * @return самого себя
     */
    public TextBuffer out(Object s) {
        if (s != null) {
            if (s instanceof TextBuffer) {
                append((TextBuffer) s);
            } else if (s instanceof CharSequence) {
                append(s.toString());
            } else if (s instanceof Map) {
                append(DefaultGroovyMethods.toMapString((Map) s));
            } else if (s instanceof Collection) {
                append(DefaultGroovyMethods.toListString((Collection) s));
            } else {
                append(s.toString());
            }
        }
        return this;
    }

    /**
     * Добавить текст из другого TextBuffer.
     * Подразумевается что у b такая же реализация, как и у this.
     *
     * @param b откуда добавлять
     */
    protected void append(TextBuffer b) {
        sb.append(b.sb);
    }

    /**
     * Добавить строку.
     *
     * @param b откуда добавлять
     */
    protected void append(String b) {
        sb.append(b);
    }

    /**
     * Проверка на пустой буфер
     */
    public boolean isEmpty() {
        return sb.length() == 0;
    }

    /**
     * Проверка, что буфер состоит только из пробельных символов (включая переводы строк
     * и табуляцию).
     */
    public boolean isWhite() {
        return UtString.isWhite(sb);
    }

    /**
     * Записать буфер во writer
     *
     * @param writer
     */
    public void writeTo(Writer writer) throws IOException {
        writer.write(sb.toString());
    }

    ////// char sequence

    public int length() {
        return sb.length();
    }

    public char charAt(int index) {
        return sb.charAt(index);
    }

    public CharSequence subSequence(int start, int end) {
        return sb.subSequence(start, end);
    }

}
