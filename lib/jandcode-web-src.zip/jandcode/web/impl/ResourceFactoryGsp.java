package jandcode.web.impl;

import jandcode.utils.vdir.*;
import jandcode.web.*;
import org.apache.commons.vfs2.*;
import org.joda.time.*;

import java.io.FileNotFoundException;
import java.io.*;

/**
 * Текст, сгенеренный через gsp
 */
public class ResourceFactoryGsp extends ResourceFactoryCustomText {

    protected FileObject file;

    protected void onGetFiles() throws Exception {
        VFile fn = vdir.findFile(resourcePath);
        if (fn == null) {
            throw new FileNotFoundException(resourcePath);
        }
        file = fn.getRealFileObject();
    }

    protected DateTime onGetLastMod() throws Exception {
        return getMaxLastMod(file, null);
    }

    protected void outFile(Writer w, FileObject f) throws Exception {
        // выводим шаблон
        OutBuilder b = new OutBuilder(getApp());
        b.outTml(f.toString(), null, null);
        b.writeTo(w);
    }

    protected void onSaveTo(Writer w) throws Exception {
        outFile(w, file);
    }

}
