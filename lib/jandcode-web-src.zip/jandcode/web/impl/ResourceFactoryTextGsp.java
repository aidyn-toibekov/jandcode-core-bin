package jandcode.web.impl;

import jandcode.utils.*;
import jandcode.utils.io.*;
import jandcode.utils.vdir.*;
import jandcode.web.*;
import org.apache.commons.vfs2.*;
import org.joda.time.*;

import java.io.FileNotFoundException;
import java.io.*;

/**
 * Текст с перекрытием через gsp.
 * <p/>
 * Выбирается приоритетный файл resourcePath или resourcePath.gsp.
 * <p/>
 * Если имеется файл resourcePath.gsp, то он рендерится и возвращается как ресурс,
 * иначе возвращается файл resourcePath
 */
public class ResourceFactoryTextGsp extends ResourceFactoryCustomText {

    protected FileObject file;

    protected void onGetFiles() throws Exception {
        VFile tf = vdir.findFile(resourcePath);
        VFile gf = vdir.findFile(resourcePath + ".gsp");
        if (gf == null && tf == null) {
            // обоих нету
            throw new FileNotFoundException(resourcePath);
        }
        if (tf == null) {
            // только gsp
            file = gf.getRealFileObject();
        } else if (gf == null) {
            // только текст
            file = tf.getRealFileObject();
        } else if (gf.getIndex() <= tf.getIndex()) {
            // gsp приоритетней
            file = gf.getRealFileObject();
        } else {
            file = tf.getRealFileObject();
        }
    }

    protected DateTime onGetLastMod() throws Exception {
        return getMaxLastMod(file, null);
    }

    protected void outFile(Writer w, FileObject f) throws Exception {
        String ext = UtFile.ext(f.toString());
        if ("gsp".equals(ext)) {
            // выводим шаблон
            OutBuilder b = new OutBuilder(getApp());
            b.outTml(f.toString(), null, null);
            //
            String ext2 = UtFile.ext(resourcePath);
            if ("js".equals(ext2)) {
                // для js обернутого в gsp - забираем <script>
                String txt = b.toString();
                // убираем теги <script>
                txt = txt.replaceAll("<script.*?>", "").replaceAll("</script>", "");
                w.write(txt);
            } else {
                b.writeTo(w);
            }
        } else {
            // текст отдаем (utf-8!)
            InputStream stm = f.getContent().getInputStream();
            try {
                StringLoader ldr = new StringLoader();
                UtLoad.fromStream(ldr, stm, UtString.UTF8);
                String data = ldr.getResult();
                w.write(data);
            } finally {
                stm.close();
            }
        }
    }

    protected void onSaveTo(Writer w) throws Exception {
        outFile(w, file);
    }

}
