package jandcode.web.impl;

import jandcode.web.*;

import java.io.*;

/**
 * render для ошибки в html
 */
public class RenderExceptionHtml implements IWebRenderWriter {
    public void saveTo(Object data, Writer w, WebRequest request) throws Exception {
        // для html не рендерим, а просто отдаем ошибку
        throw (Exception) data;
    }
}
