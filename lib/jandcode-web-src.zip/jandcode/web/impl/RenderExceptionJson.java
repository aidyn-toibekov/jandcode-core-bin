package jandcode.web.impl;

import jandcode.utils.*;
import jandcode.web.*;

import java.io.*;
import java.util.*;

/**
 * render для ошибки в json
 */
public class RenderExceptionJson implements IWebRenderWriter {

    public void saveTo(Object data, Writer w, WebRequest request) throws Exception {
        request.setContentType("application/json");
        //
        Throwable err = (Throwable) data;
        //
        Map json = new HashMap();
        MapBuilder b = new MapBuilder();
        b.addError(json, err);
        //
        w.write(UtJson.toString(json));
    }
}
