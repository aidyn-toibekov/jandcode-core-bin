package jandcode.web.impl;

import jandcode.web.*;

public class RenderResponseTml implements IWebRenderBuilder {

    public void saveTo(Object data, OutBuilder b, WebRequest request) throws Exception {
        ResponseTml t = (ResponseTml) data;
        b.outTml(t.getTmlName(), t.getArgs(), null);
    }

}
