package jandcode.web.impl;

import jandcode.utils.*;
import jandcode.utils.vdir.*;
import org.apache.commons.vfs2.*;
import org.joda.time.*;

import java.io.*;
import java.util.*;

/**
 * Текст с перекрытием через gsp и иньекциями.
 */
public class ResourceFactoryTextGspInject extends ResourceFactoryTextGsp {

    private List<FileObject> inject = new ArrayList<FileObject>();

    class CompareVF implements Comparator<VFile> {
        public int compare(VFile o1, VFile o2) {
            Integer i1 = o1.getIndex();
            Integer i2 = o2.getIndex();
            return i2.compareTo(i1);
        }
    }

    protected void outDelimiter(Writer w, FileObject f) throws Exception {
        if (getApp().isDebug()) {
            w.write("\n/* INJECT: " + f.toString() + " */\n");
        } else {
            w.write("\n/* INJECT */\n");
        }
    }

    protected void onGetFiles() throws Exception {
        super.onGetFiles();
        //
        String ext = UtFile.ext(resourcePath);
        String noext = UtFile.removeExt(resourcePath);
        List<VFile> vf = vdir.getFileEntry(noext + "-inject." + ext);
        List<VFile> vf2 = vdir.getFileEntry(noext + "-inject." + ext + ".gsp");
        vf.addAll(vf2);
        Collections.sort(vf, new CompareVF());
        for (VFile f : vf) {
            inject.add(f.getRealFileObject());
        }
    }

    protected DateTime onGetLastMod() throws Exception {
        DateTime z = super.onGetLastMod();
        for (FileObject f : inject) {
            z = getMaxLastMod(f, z);
        }
        return z;
    }

    protected void onSaveTo(Writer w) throws Exception {
        super.onSaveTo(w);
        //
        for (FileObject f : inject) {
            outDelimiter(w, f);
            outFile(w, f);
        }
    }
}
