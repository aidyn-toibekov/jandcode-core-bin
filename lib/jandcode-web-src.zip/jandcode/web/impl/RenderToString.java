package jandcode.web.impl;

import jandcode.web.*;

/**
 * render в текст через метод toString()
 */
public class RenderToString implements IWebRenderBuilder {

    public void saveTo(Object data, OutBuilder b, WebRequest request) throws Exception {
        if (data == null) {
            return;
        }
        b.out(data.toString());
    }

}
