package jandcode.web.impl;

import jandcode.utils.*;

import java.util.*;

/**
 * Абстрактный стековый пул поименнованных компонентов
 */
public abstract class StackedPool<TYPE> {

    private HashMap<String, Item> _items = new HashMap<String, Item>();

    /**
     * Элемент пула
     */
    class Item extends Named {

        /**
         * Экземпляры
         */
        ArrayList<TYPE> insts = new ArrayList<TYPE>();

        /**
         * Позиция в списке первого свободного
         */
        int pos;

        /**
         * Взять объект из пула
         */
        TYPE getObject() throws Exception {
            TYPE c;
            if (insts.size() <= pos) {
                // пул пустой
                c = createInstance(getName());
                insts.add(c);
            } else {
                c = insts.get(pos);
            }
            pos++;
            return c;
        }

        /**
         * Вернуть объект в пул
         */
        void returnObject() {
            pos--;
            if (pos < 0) {
                throw new XErrorBadPool();
            }
        }
    }

    /**
     * Создать новый экземпляр объекта с указанным именем
     */
    protected abstract TYPE createInstance(String name) throws Exception;

    //////

    /**
     * Получить объект из пула
     *
     * @param name имя объекта
     * @return экземпляр объекта
     */
    public TYPE getObject(String name) throws Exception {
        Item a = _items.get(name);
        if (a == null) {
            a = new Item();
            a.setName(name);
            _items.put(name, a);
        }
        //
        return a.getObject();
    }

    /**
     * Вернуть последний взятый объект в пул
     *
     * @param name имя объекта
     * @return
     */
    public void returnObject(String name) {
        Item a = _items.get(name);
        if (a == null) {
            throw new XErrorBadPool();
        }
        a.returnObject();
    }

}
