package jandcode.web.impl;

import jandcode.utils.*;
import jandcode.utils.vdir.*;
import jandcode.web.*;
import org.apache.commons.vfs2.*;
import org.joda.time.*;

import java.io.FileNotFoundException;
import java.io.*;

public class ResourceFactoryBin extends ResourceFactory {

    private FileObject file;

    public ResourceFactoryBin() {
        binary = true;
    }

    protected void onGetFiles() throws Exception {
        VFile fn = vdir.findFile(resourcePath);
        if (fn == null) {
            throw new FileNotFoundException(resourcePath);
        }
        file = fn.getRealFileObject();
    }

    protected void onSaveTo(OutputStream stm) throws Exception {
        InputStream stmSource = file.getContent().getInputStream();
        try {
            UtFile.copyStream(stmSource, stm);
        } finally {
            stm.close();
        }
    }

    protected void onSaveTo(Writer w) throws Exception {
    }

    protected DateTime onGetLastMod() throws Exception {
        return getMaxLastMod(file, null);
    }

}
