package jandcode.web.impl;

import jandcode.utils.variant.*;

import java.util.*;

/**
 * Map для хранения flash
 */
public class FlashVariantMap extends VariantMap {

    private boolean changed = false;

    /**
     * Были ли изменения
     *
     * @return
     */
    public boolean isChanged() {
        return changed;
    }

    public void setChanged(boolean changed) {
        this.changed = changed;
    }

    //////

    public void clear() {
        changed = true;
        super.clear();
    }

    public Object put(String key, Object value) {
        changed = true;
        return super.put(key, value);
    }

    public void putAll(Map<? extends String, ? extends Object> m) {
        changed = true;
        super.putAll(m);
    }

    public Object remove(Object key) {
        changed = true;
        return super.remove(key);
    }

}
