package jandcode.web.impl;

import jandcode.web.*;
import org.joda.time.*;

import java.io.*;

public class ResourceFactoryPrivate extends ResourceFactory {

    protected void onGetFiles() throws Exception {
        throw new FileNotFoundException(resourcePath);
    }

    protected void onSaveTo(OutputStream stm) throws Exception {
        throw new FileNotFoundException(resourcePath);
    }

    protected void onSaveTo(Writer w) throws Exception {
        throw new FileNotFoundException(resourcePath);
    }

    protected DateTime onGetLastMod() throws Exception {
        throw new FileNotFoundException(resourcePath);
    }

}
