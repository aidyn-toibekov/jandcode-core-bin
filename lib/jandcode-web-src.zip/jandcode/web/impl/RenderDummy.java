package jandcode.web.impl;

import jandcode.web.*;

import java.io.*;

/**
 * Ничего не делающий render
 */
public class RenderDummy implements IWebRenderWriter {
    public void saveTo(Object data, Writer w, WebRequest request) throws Exception {
    }
}
