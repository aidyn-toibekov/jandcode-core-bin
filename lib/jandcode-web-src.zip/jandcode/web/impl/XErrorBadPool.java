package jandcode.web.impl;

import jandcode.utils.error.*;

public class XErrorBadPool extends XError {

    public XErrorBadPool() {
        super("Нарушение целостности пула компонентов");
    }
}
