package jandcode.web.impl;

import jandcode.web.*;

import java.io.*;

public abstract class ResourceFactoryCustomText extends ResourceFactory {

    protected void onSaveTo(OutputStream stm) throws Exception {
    }

}
