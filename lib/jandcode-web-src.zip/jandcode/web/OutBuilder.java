package jandcode.web;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;
import jandcode.web.impl.*;

import java.io.*;
import java.util.*;

/**
 * Построитель вывода
 */
public class OutBuilder {

    private App app;
    private TmlService tmlService;
    protected TextBuffer curTextBuffer;
    protected StackList<TextBuffer> stackTextBuffer = new StackList<TextBuffer>();
    private TmlPool tmlPool = new TmlPool();
    protected VariantMapLayer vars = new VariantMapLayer();
    protected StackList<Tml> stackTml = new StackList<Tml>();
    protected int nextId;
    protected String baseId = "BASEID";

    class TmlPool extends StackedPool<Tml> {
        protected Tml createInstance(String name) throws Exception {
            Tml tml = OutBuilder.this.tmlService.createTml(name);
            tml.setOutBuilder(OutBuilder.this);
            return tml;
        }
    }


    public OutBuilder(App app) {
        this.app = app;
        this.tmlService = app.service(WebService.class).service(TmlService.class);
        // главный буфер
        pushBuffer();
        // вершина стека компонентов
        Tml dummy = app.getObjectFactory().create(Tml.class);
        dummy.setOutBuilder(this);
        stackTml.push(dummy);
    }

    public App getApp() {
        return app;
    }

    ////// out

    /**
     * Вывести текст
     */
    public void out(Object s) {
        curTextBuffer.out(s);
    }

    public TextBuffer pushBuffer() {
        TextBuffer b = new TextBuffer();
        stackTextBuffer.push(b);
        curTextBuffer = b;
        return b;
    }

    public TextBuffer popBuffer() {
        if (stackTextBuffer.size() == 1) {
            throw new XError("popBuffer без pushBuffer");
        }
        TextBuffer b = stackTextBuffer.pop();
        curTextBuffer = stackTextBuffer.last();
        return b;
    }

    public void writeTo(Writer w) throws Exception {
        stackTextBuffer.first().writeTo(w);
    }

    public String toString() {
        return stackTextBuffer.first().toString();
    }

    /**
     * Вывести шаблон
     *
     * @param tmlName имя шаблона
     * @param tmlArgs аргументы. Если есть атрибут 'arg' - то не выводится, а запоминается
     *                в аргументах текущего с указанным именем
     * @param body    тело
     * @throws Exception
     */
    public void outTml(String tmlName, Map tmlArgs, Object body) throws Exception {
        boolean noRender = tmlArgs != null && tmlArgs.containsKey("arg");
        Tml tml;
        Tml ownerTml = stackTml.last();
        if (ownerTml instanceof ITmlTagOwner) {
            ITmlTagOwner tgo = (ITmlTagOwner) ownerTml;
            noRender = !tgo.needRenderChildTml(tmlName, tmlArgs, body);
            if (noRender) {
                // не нужно сразу рисовать. Нужно передать владельцу, он сам разберется потом
                tml = tmlPool.createInstance(tmlName);
                tgo.registerChildTml(tml);
            } else {
                tml = tmlPool.getObject(tmlName);
            }
        } else {
            if (noRender) {
                // не нужно сразу рисовать. Нужно запомнить в аргументах текущего
                tml = tmlPool.createInstance(tmlName);
                stackTml.last().getArgs().put(UtString.toString(tmlArgs.get("arg")), tml);
            } else {
                tml = tmlPool.getObject(tmlName);
            }
        }
        tml.setOwner(ownerTml);
        tml.getArgs().clear();
        tml.setArgs(tmlArgs);
        if (body != null) {
            tml.getArgs().put(Tml.ARG_BODY, body);
        }
        //
        if (noRender) {
            return;  // отрисовка не нужна
        }
        //
        if (tml instanceof ITmlInclude) {
            tml.args = ownerTml.args;
            if (tmlArgs == null) {
                tmlArgs = new HashMap();
            }
            ((ITmlInclude) tml).doInclude(tmlArgs, body);
            return;
        }
        //
        VariantMapLayer.Layer lay = vars.push(tml.getName(), null);
        stackTml.push(tml);
        try {
            lay.setMap(tml.getArgs());
            tml.render();
        } finally {
            vars.pop();
            stackTml.pop();
            tmlPool.returnObject(tmlName);
        }
    }

    /**
     * Включить шаблон в контексте текущего
     *
     * @param tmlName имя шаблона
     */
    public void includeTml(Tml from, String tmlName) throws Exception {
        Tml tml = tmlPool.getObject(tmlName);
        tml.setOwner(from.getOwner());
        tml.args = from.args;
        try {
            tml.render();
        } finally {
            tmlPool.returnObject(tmlName);
        }
    }

    ////// vars

    /**
     * Слоеные переменные
     */
    public VariantMapLayer getVars() {
        return vars;
    }

    ////// utils

    /**
     * Уникальная id в контексте вывода
     */
    public int getNextId() {
        nextId++;
        return nextId;
    }

    /**
     * Базовая id, которая, например, используется для генерации id в html.
     */
    public String getBaseId() {
        return baseId;
    }

    public void setBaseId(String baseId) {
        this.baseId = baseId;
    }
}
