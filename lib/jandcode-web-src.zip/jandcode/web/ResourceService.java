package jandcode.web;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import jandcode.utils.vdir.*;
import org.apache.commons.logging.*;
import org.apache.commons.vfs2.*;

import java.io.FileNotFoundException;
import java.util.*;

/**
 * Сервис статических ресурсов.
 * <p/>
 * Конфигурация:
 * <pre>{@code
 * <root>
 *      <web>
 *          <resource.i path="PATH" package="PACKAGE"/>
 *          <filetype.ext type="TYPE" mime="MIME"/>
 *          ...
 *      </web>
 * </root>}</pre>
 */
public class ResourceService extends CompRt implements IActivate {

    protected static Log log = LogFactory.getLog(ResourceService.class);

    /**
     * Текстовый файл
     */
    public static final String TYPE_TEXT = "text";

    /**
     * Бинарный файл
     */
    public static final String TYPE_BIN = "bin";

    /**
     * Приватный файл. Такие файлы не доступны как ресурсы
     */
    public static final String TYPE_PRIVATE = "private";


    private VDirVfs virtualDir;
    private HashMap<String, FileType> fileTypes = new HashMap<String, FileType>();

    /**
     * Тип файла
     */
    public class FileType {

        private String ext;
        private String mime;
        private String type;
        private Class resourceFactoryClass;

        /**
         * Расширение
         */
        public String getExt() {
            return ext;
        }

        /**
         * mime - тип
         */
        public String getMime() {
            if (!UtString.empty(mime)) {
                return mime;
            }
            if (TYPE_TEXT.equals(type)) {
                return "text/" + ext;
            }
            return "application/octet-stream";
        }

        /**
         * Тип (bin, text, private)
         */
        public String getType() {
            if (!UtString.empty(type)) {
                return type;
            }
            return TYPE_BIN;
        }

        public boolean isPrivate() {
            return TYPE_PRIVATE.equals(getType());
        }

        public boolean isBin() {
            return TYPE_BIN.equals(getType());
        }

        public boolean isText() {
            return TYPE_TEXT.equals(getType());
        }

        public ResourceFactory createResourceFactory() {
            return (ResourceFactory) getApp().service(WebService.class).getObjectFactory().create(resourceFactoryClass);
        }
    }

    //////

    public void activate() throws Exception {
        // virtual dir
        virtualDir = new VDirVfs();

        // из конфигурации
        Rt cfg = getApp().getRt().findChild("web/resource");
        if (cfg != null) {
            for (Rt rt : cfg.getChilds()) {
                String prefix = rt.getValueString("prefix");
                String s = rt.getValueString("package");
                if (!UtString.empty(s)) {
                    s = "res:" + s.replace('.', '/');
                    String s1 = s + "/" + rt.getValueString("filemark", "module.rt");
                    FileObject ob = UtFile.getFileObject(s1);
                    if (ob.exists()) {
                        addRoot(ob.getParent().toString(), prefix);
                    }
                } else {
                    s = rt.getValueString("path");
                    if (!UtString.empty(s)) {
                        addRoot(s, prefix);
                    }
                }
            }
        }

        // resourceFactory
        HashMap<String, Class> resourceFactorys = new HashMap<String, Class>();
        cfg = getApp().getRt().findChild("web/resourcefactory");
        if (cfg != null) {
            for (Rt rt : cfg.getChilds()) {
                String nm = rt.getName();
                String cls = rt.getValueString("class", null);
                if (cls == null) {
                    throw new XError("resourcefactory name={0} not assignet attribute class", nm);
                }
                resourceFactorys.put(nm, getApp().getClass(cls));
            }
        }

        // filetype из конфигурации
        cfg = getApp().getRt().findChild("web/filetype");
        if (cfg != null) {
            for (Rt rt : cfg.getChilds()) {
                String ext = rt.getName();
                String type = rt.getValueString("type", null);
                String mime = rt.getValueString("mime", null);
                String rf = rt.getValueString("resourcefactory", null);
                if (rf == null) {
                    rf = type;
                }
                Class rfc = resourceFactorys.get(rf);
                if (rfc == null) {
                    throw new XError("Not found resourcefactory={0} for filetype={1}", rf, ext);
                }
                addFileType(ext, type, mime, rfc);
            }
        }

    }

    ////// virtual dir

    /**
     * Добавить путь в виртуальный каталог
     */
    protected void addRoot(String realPath, String prefix) {
        if (log.isInfoEnabled()) {
            log.info("addRoot: " + realPath + " to prefix: " + prefix);
        }
        virtualDir.addRoot(realPath, prefix);
    }

    /**
     * Виртуальный каталог
     */
    public VDirVfs getVirtualDir() {
        return virtualDir;
    }

    /**
     * Возвращает список полных абсолютных путей файлов в указанном виртуальном каталоге.
     * Включая папки.
     *
     * @param virtualPath виртуальный путь
     * @return список путей
     */
    public List<String> findFileList(String virtualPath) {
        List<VFile> vi = virtualDir.findFiles(virtualPath);
        List<String> res = new ArrayList<String>();
        for (VFile item : vi) {
            res.add(item.getRealPath());
        }
        return res;
    }

    /**
     * Возвращает полный реальный путь файла или папки для виртуального файла.
     *
     * @param virtualPath виртуальный путь
     * @return реальный путь или null, если не найден
     */
    public String findFile(String virtualPath) {
        VFile a = virtualDir.findFile(virtualPath);
        if (a == null) {
            return null;
        }
        return a.getRealPath();
    }

    /**
     * Возвращает полный реальный путь файла или папки для виртуального файла.
     *
     * @param virtualPath виртуальный путь
     * @return реальный путь или null, если не найден
     */
    public String getFile(String virtualPath) {
        VFile a = virtualDir.findFile(virtualPath);
        if (a == null) {
            throw new XError("Файл не найден: " + virtualPath);
        }
        return a.getRealPath();
    }

    ////// file types

    /**
     * Добавить новый тип файлов. Если такое расширение уже зарегистрировано, то
     * заменяется.
     *
     * @param ext                  расширение
     * @param type                 тип (например "bin")
     * @param mime                 mime-тип
     * @param resourceFactoryClass класс {@link ResourceFactory}
     */
    public void addFileType(String ext, String type, String mime, Class resourceFactoryClass) {
        FileType f = new FileType();
        f.ext = ext;
        f.type = type;
        f.mime = mime;
        f.resourceFactoryClass = resourceFactoryClass;
        fileTypes.put(ext, f);
    }

    /**
     * Возвращает тип для указанного расширения
     *
     * @param ext расширение
     * @return тип (константа TYPE_xxx) или null, если не найден
     */
    public FileType findFileType(String ext) {
        return fileTypes.get(ext);
    }

    /**
     * Список зарегистрированных расширений файлов
     */
    public Collection<FileType> getFileTypes() {
        return fileTypes.values();
    }

    ////// resoorceFactory

    /**
     * Создает и возвращает {@link ResourceFactory} для указанного виртуального пути
     */
    public ResourceFactory getResourceFactory(String vpath) throws Exception {
        String ext = UtFile.ext(vpath);
        FileType ft = findFileType(ext);
        if (ft == null) {
            // нет такого расширения
            if (getApp().isDebug()) {
                throw new FileNotFoundException("Extension not registred: " + vpath);
            } else {
                throw new FileNotFoundException(vpath);
            }
        }
        ResourceFactory rf = ft.createResourceFactory();
        rf.setVdir(virtualDir);
        rf.setResourcePath(vpath);
        rf.setFileType(ft);
        return rf;
    }
}
