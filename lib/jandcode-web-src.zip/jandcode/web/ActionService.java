package jandcode.web;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.utils.vdir.*;
import org.apache.commons.logging.*;

import java.text.*;
import java.util.*;

/**
 * Сервис для action
 */
public class ActionService extends CompRt implements IActivate {

    protected static Log log = LogFactory.getLog(ActionService.class);

    public static final String PACKAGE_ACTION = "action";
    public static final String SUFFIX_ACTION = "Action";
    public static final String STATIC_ACTION = "_static";

    protected ListComp<WebAction> actions;

    class ActionComparator implements Comparator<INamed> {
        public int compare(INamed o1, INamed o2) {
            Integer len1 = o1.getName().split("/").length;
            int len2 = o1.getName().split("/").length;
            int res = len1.compareTo(len2);
            if (res != 0) {
                return res;
            }
            return o1.getName().compareTo(o2.getName());
        }
    }

    public void activate() throws Exception {
        loadActions();
    }

    //////

    /**
     * Список всех action
     */
    public ListComp<WebAction> getActions() {
        if (actions == null) {
            synchronized (this) {
                if (actions == null) {
                    loadActions();
                }
            }
        }
        return actions;
    }

    protected void loadActions() {
        ListComp<WebAction> res = new ListComp<WebAction>();
        res.setNotFoundMessage("action [{0}] not found");
        //
        // из конфигурации
        List<String> actionPackages = new ArrayList<String>();
        Rt cfg = getApp().getRt().findChild("web/resource");
        if (cfg != null) {
            for (Rt rt : cfg.getChilds()) {
                String s = rt.getValueString("package");
                if (!UtString.empty(s)) {
                    actionPackages.add(s);
                }
            }
        }
        //
        for (String actpak : actionPackages) {
            String ppfx = actpak + "." + PACKAGE_ACTION + ".";
            List<IReflectClazz> lst = getApp().service(ReflectService.class).list(
                    actpak + "." + PACKAGE_ACTION, true);
            for (IReflectClazz rc : lst) {
                Class cls = rc.getCls();
                String an = cls.getSimpleName();
                if (an.endsWith(SUFFIX_ACTION) && WebAction.class.isAssignableFrom(cls)) {
                    // это action
                    an = UtString.removeSuffix(an, SUFFIX_ACTION);
                    String s = UtString.removePrefix(cls.getPackage().getName(), ppfx);
                    if (s != null) {
                        s = s.replace('.', '/') + '/';
                    } else {
                        s = "";
                    }
                    an = s + an;
                    WebAction act = (WebAction) getApp().service(WebService.class).getObjectFactory().create(cls);
                    act.setName(an.toLowerCase());
                    res.add(act);
                    if (log.isInfoEnabled()) {
                        log.info(MessageFormat.format("found action: {0} ({1})", act.getName(), act.getClass().getName()));
                    }
                }
            }
        }
        //
        loadFromRt(res, getApp().getRt().getChild("web"), "action", "");
        //
        res.sort(new ActionComparator());
        //
        actions = res;
    }

    protected void loadFromRt(ListComp<WebAction> res, Rt rt, String childName, String prefix) {
        Rt z = rt.findChild(childName);
        if (z != null) {
            if (!UtString.empty(prefix)) {
                prefix = prefix + "/";
            }
            for (Rt z1 : z.getChilds()) {
                String cn = z1.getValueString("class");
                String an = prefix + z1.getName();
                String url = z1.getValueString("url");
                if (!UtString.empty(url)) {
                    an = VDir.normalize(url);
                }
                // есть класс - это action, иначе - папка
                if (!UtString.empty(cn)) {
                    WebAction act = (WebAction) getApp().service(WebService.class).getObjectFactory().create(z1);
                    act.setName(an);
                    res.add(act);
                    if (log.isInfoEnabled()) {
                        log.info(MessageFormat.format("found action: {0} ({1})", act.getName(), act.getClass().getName()));
                    }
                }
                loadFromRt(res, z1, childName, an);
            }
        }
    }

    /**
     * Найти action по параметрам запроса.
     * Возвращает или новый экземпляр action или null, если не найдено.
     * Изменяет request.pathInfo: присваивает остаток пути после извлечения имени action.
     */
    public WebAction getAction() {
        WebRequest request = getApp().service(WebService.class).getRequest();
        String pi = request.getPathInfo().toLowerCase();

        // ищем, какой action совпадает с началом пути
        WebAction act = null;
        for (WebAction it : getActions()) {
            if (pi.startsWith(it.getName() + "/") || pi.equals(it.getName())) {
                act = it;
                break;
            }
        }

        if (act != null) {
            // клонируем
            act = (WebAction) act.clone();
            // убираем имя action из пути
            int actNameLen = act.getName().length();
            if (pi.length() > actNameLen) {
                // уже не lowercase
                pi = request.getPathInfo();
                act.setPathInfo(pi.substring(actNameLen + 1));
            } else {
                // остатка нет
                act.setPathInfo("");
            }
        } else {
            // action не найдена. Попробуем статический файл
            // проверяем расширение
            String ext = UtFile.ext(pi);
            if (!UtString.empty(ext)) {
                // путь не пустой, есть расширение - статический файл
                return getActions().find(STATIC_ACTION);
            }
        }

        return act;
    }

}
