package jandcode.web;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Сервис для фильтров
 */
public class FilterService extends CompRt {

    protected ListNamed<WebFilter> filters = new ListNamed<WebFilter>();

    class ComparatorWebFilter implements Comparator<WebFilter> {
        public int compare(WebFilter o1, WebFilter o2) {
            Integer i1 = o1.getWeight();
            Integer i2 = o2.getWeight();
            int n = i1.compareTo(i2);
            if (n == 0) {
                i1 = o1.getIndex();
                i2 = o2.getIndex();
                n = i1.compareTo(i2);
            }
            return n;
        }
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        grabFilters(rt.findChild("filter"));
        grabFilters(getApp().getRt().findChild("web/filter"));
        //
        Collections.sort(filters, new ComparatorWebFilter());
    }

    protected void grabFilters(Rt z) {
        if (z != null) {
            for (Rt rt1 : z.getChilds()) {
                WebFilter f = (WebFilter) getApp().service(WebService.class).getObjectFactory().create(rt1);
                f.setIndex(filters.size());
                filters.add(f);
            }
        }
    }

    public void beforeHandleRequest() throws Exception {
        if (filters.size() == 0) {
            return;
        }
        WebRequest request = getApp().service(WebService.class).getRequest();
        for (WebFilter filter : filters) {
            if (request.isStopExec()) {
                return;
            }
            filter.beforeHandleRequest();
        }
    }

    public void beforeExec() throws Exception {
        if (filters.size() == 0) {
            return;
        }
        WebRequest request = getApp().service(WebService.class).getRequest();
        for (WebFilter filter : filters) {
            if (request.isStopExec()) {
                return;
            }
            filter.beforeExec();
        }
    }

    public void afterExec() throws Exception {
        if (filters.size() == 0) {
            return;
        }
        WebRequest request = getApp().service(WebService.class).getRequest();
        for (int i = filters.size() - 1; i >= 0; i--) {
            if (request.isStopExec()) {
                return;
            }
            WebFilter filter = filters.get(i);
            filter.afterExec();
        }
    }

    public void afterHandleRequest() throws Exception {
        if (filters.size() == 0) {
            return;
        }
        for (int i = filters.size() - 1; i >= 0; i--) {
            WebFilter filter = filters.get(i);
            filter.afterHandleRequest();
        }
    }

}
