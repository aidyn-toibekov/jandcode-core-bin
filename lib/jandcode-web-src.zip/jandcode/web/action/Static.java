package jandcode.web.action;

import jandcode.utils.*;
import jandcode.utils.vdir.*;
import jandcode.web.*;
import org.apache.commons.logging.*;
import org.joda.time.*;

/**
 * Статические ресурсы
 */
public class Static extends WebAction {

    protected static Log log = LogFactory.getLog(Static.class);

    protected void onExec() throws Exception {
        //
        WebRequest request = getRequest();
        ResourceService res = getApp().service(WebService.class).getResourceService();

        // дата модификации в запросе
        DateTime lastModReq = null;
        String lastModReqText = request.getHttpRequest().getHeader("If-Modified-Since");
        if (!UtString.empty(lastModReqText)) {
            lastModReq = UtDate.stringToDateTimeGMT(lastModReqText);
            if (log.isInfoEnabled()) {
                log.info("If-Modified-Since: " + lastModReq);
            }
        }
        //

        // путь в запросе
        String path = VDir.normalize(request.getPathInfo());

        // пустой путь не находим
        if (UtString.empty(path)) {
            request.sendError(404, "Path not defined");
            return;
        }

        // выводим
        ResourceFactory rf = res.getResourceFactory(path);

        // проверяем дату модификации, если нужно
        DateTime lastMod = rf.getLastMod();
        if (lastModReq != null) {
            if (!lastMod.isAfter(lastModReq)) {
                // не поменялся
                request.sendError(304, "Not Modified");
                return;
            }
        }

        // устанавливаем дату модификации
        if (lastMod != null) {
            request.getHttpResponse().setHeader("Last-Modified", UtDate.dateToStringGMT(lastMod));
        }

        // устанавливаем тип
        request.getHttpResponse().setContentType(rf.getFileType().getMime());

        // выводим
        if (rf.isBinary()) {
            rf.saveTo(getRequest().getOutStream());
        } else {
            rf.saveTo(getRequest().getOutWriter());
        }

    }

}
