package jandcode.web.action;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.web.*;

/**
 * Обработчик ошибок. Показывает страницу с ошибкой
 */
public class ShowerrorAction extends WebAction {

    protected void onExec() throws Exception {
        String tml = "showerror/page.gsp";
        if (getRequest().isAjax()) {
            tml = "showerror/ajax.gsp";
            if (!getApp().isRelease()) {
                tml = "showerror/ajax-dev.gsp";
            }
        }
        Throwable exc = (Throwable) getRequest().getHttpRequest().getAttribute("javax.servlet.error.exception");
        ErrorInfo ei = UtError.createErrorInfo(exc);
        render(tml, UtCnv.toMap(
                "exception", exc,
                "errorinfo", ei,
                "message", getRequest().getHttpRequest().getAttribute("javax.servlet.error.message"),
                "exception_type", getRequest().getHttpRequest().getAttribute("javax.servlet.error.exception_type"),
                "request_uri", getRequest().getHttpRequest().getAttribute("javax.servlet.error.request_uri")
        ));
    }

}