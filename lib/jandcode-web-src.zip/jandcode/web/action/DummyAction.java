package jandcode.web.action;

import jandcode.web.*;

/**
 * Ничего не делающая action
 */
public class DummyAction extends WebAction {

    protected void onExec() throws Exception {
    }

}
