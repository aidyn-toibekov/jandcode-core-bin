package jandcode.web;

import jandcode.app.*;
import jandcode.groovy.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import jandcode.utils.vdir.*;
import org.apache.commons.logging.*;

import java.io.*;
import java.text.*;
import java.util.*;

public class TmlService extends CompRt implements IActivate {

    protected static Log log = LogFactory.getLog(TmlService.class);

    public static final String PACKAGE_TML = "tml";
    public static final String SUFFIX_TML = "Tml";

    protected ListNamed<TmlDesc> tmls = new ListNamed<TmlDesc>();

    //////

    class TmlDesc extends Named {
        Class tmlClass;
        GroovyClazz gspClass;
        String resPath;

        TmlDesc(Class tmlClass) {
            this.tmlClass = tmlClass;
        }

        private void loadGsp() throws Exception {
            String fn = getName();
            if (!fn.startsWith("/")) {
                fn = PACKAGE_TML + "/" + getName();
            }
            String ff = getApp().service(WebService.class).getResourceService().findFile(fn);
            if (ff == null) {
                throw new FileNotFoundException(fn);
            }
            GroovyCompiler gs = getApp().service(GroovyService.class).getCompiler();
            gspClass = gs.getClazz(Tml.class, "protected void onRender()", UtFile.getFileObject(ff), true);
            resPath = "/" + VDir.normalize(UtFile.path(fn));
        }

        private void loadGspAbsolute() throws Exception {
            String fn = getName();
            String vf = getApp().service(WebService.class).getResourceService().getVirtualDir().getVirtualPath(fn);
            if (vf == null) {
                throw new XError("File {0} out side virtual dir");
            }
            GroovyCompiler gs = getApp().service(GroovyService.class).getCompiler();
            gspClass = gs.getClazz(Tml.class, "protected void onRender()", UtFile.getFileObject(fn), true);
            resPath = "/" + VDir.normalize(UtFile.path(vf));
        }

        public Tml createTml() {
            Class cls = tmlClass;
            if (gspClass != null) {
                cls = gspClass.getClazz();
            }
            Tml res = (Tml) getApp().service(WebService.class).getObjectFactory().create(cls);
            res.setName(getName());
            res.setResPath(resPath);
            return res;
        }

    }

    //////

    public TmlService() {
        tmls.setNotFoundMessage("tml [{0}] not found");
    }

    //////

    public void activate() throws Exception {
        tmls.clear();
        loadTmlClasses();
        loadFromRt(getApp().getRt().getChild("web"), "tml", "");
    }

    protected void loadTmlClasses() {
        // из конфигурации
        List<String> tmlPackages = new ArrayList<String>();
        Rt cfg = getApp().getRt().findChild("web/resource");
        if (cfg != null) {
            for (Rt rt : cfg.getChilds()) {
                String s = rt.getValueString("package");
                if (!UtString.empty(s)) {
                    tmlPackages.add(s);
                }
            }
        }
        //
        for (String pak : tmlPackages) {
            String ppfx = pak + "." + PACKAGE_TML + ".";
            List<IReflectClazz> lst = getApp().service(ReflectService.class).list(
                    pak + "." + PACKAGE_TML, true);
            for (IReflectClazz rc : lst) {
                Class cls = rc.getCls();
                String an = cls.getSimpleName();
                if (an.endsWith(SUFFIX_TML) && Tml.class.isAssignableFrom(cls)) {
                    // это tml
                    an = UtString.removeSuffix(an, SUFFIX_TML);
                    String s = UtString.removePrefix(cls.getPackage().getName(), ppfx);
                    if (s != null) {
                        s = s.replace('.', '/') + '/';
                    } else {
                        s = "";
                    }
                    an = s + an;
                    TmlDesc desc = new TmlDesc(cls);
                    desc.setName(an.toLowerCase());
                    desc.resPath = "/" + PACKAGE_TML + "/" + desc.getName();
                    tmls.add(desc);
                    if (log.isInfoEnabled()) {
                        log.info(MessageFormat.format("found tml: {0} ({1})", desc.getName(), cls.getName()));
                    }
                }
            }
        }
    }

    protected void loadFromRt(Rt rt, String childName, String prefix) throws Exception {
        Rt z = rt.findChild(childName);
        if (z != null) {
            if (!UtString.empty(prefix)) {
                prefix = prefix + "/";
            }
            for (Rt z1 : z.getChilds()) {
                String cn = z1.getValueString("class");
                String an = prefix + z1.getName();
                // есть класс - это tml, иначе - папка
                if (!UtString.empty(cn)) {
                    Class cls = getApp().getObjectFactory().getClass(z1);
                    TmlDesc desc = new TmlDesc(cls);
                    desc.setName(an);
                    //
                    VDirVfs vdir = getApp().service(WebService.class).getResourceService().getVirtualDir();
                    String vp = vdir.getVirtualPath("res:" + cls.getPackage().getName().replace('.', '/'));
                    //
                    desc.resPath = "/" + vp + "/" + z1.getName();
                    tmls.add(desc);
                    if (log.isInfoEnabled()) {
                        log.info(MessageFormat.format("found tml: {0} ({1})", desc.getName(), cls.getName()));
                    }
                }
                loadFromRt(z1, childName, an);
            }
        }
    }

    protected TmlDesc getTmlDesc(String name) throws Exception {
        TmlDesc desc = tmls.find(name);
        if (desc == null) {
            synchronized (this) {
                String ext = UtFile.ext(name);

                if (!UtString.empty(ext)) {
                    // gsp, который еще не кеширован. Расширение любое
                    desc = new TmlDesc(null);

                    if (name.indexOf(':') != -1) {
                        // абсолютное vfs имя
                        desc.setName(name);
                        desc.loadGspAbsolute();
                        tmls.add(desc);
                    } else {
                        boolean root = name.startsWith("/");
                        name = VDir.normalize(name);
                        if (root) {
                            name = "/" + name;
                        }
                        desc.setName(name);
                        desc.loadGsp();
                        tmls.add(desc);
                    }
                } else {
                    // ищем вариант '/tml/NAME.gsp'
                    boolean root = name.startsWith("/");
                    if (root) {
                        throw new XError(tmls.getNotFoundMessage(), name);
                    }
                    desc = new TmlDesc(null);
                    String gname = VDir.normalize(name) + ".gsp";
                    desc.setName(gname);
                    desc.loadGsp();
                    desc.setName(name);
                    tmls.add(desc);
                }
            }
        }
        //
        return desc;
    }

    /**
     * Создать экземпляр шаблона по имени.
     * Имя может быть именем gsp-шаблона или путем класса относительно tml.
     */
    public Tml createTml(String name) throws Exception {
        return getTmlDesc(name).createTml();
    }

    /**
     * Возвращает исходник класса, который был сделан из шаблона gsp
     *
     * @param name имя gsp-шаблона
     */
    public String getGspSourceClazz(String name) throws Exception {
        TmlDesc desc = getTmlDesc(name);
        if (desc.gspClass == null) {
            throw new XError("{} не является шаблоном gsp");
        }
        return desc.gspClass.getSourceClazz();
    }

}
