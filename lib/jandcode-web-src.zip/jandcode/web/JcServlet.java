package jandcode.web;


import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.impl.*;
import org.apache.commons.logging.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * Сервлет.
 */
public class JcServlet extends HttpServlet {

    protected static Log log = LogFactory.getLog(JcServlet.class);

    public static final String INIT_PARAM_app_rt = "app.rt";
    public static final String INIT_PARAM_log = "log";

    protected App app;
    protected WebService webService;

    /**
     * Приложение, связанное с этим сервлетом
     */
    public App getApp() {
        return app;
    }

    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);
        try {
            loadApp();
        } catch (Exception e) {
            String msg = new ErrorFormatterDefault(true, true,
                    true).getMessage(UtError.createErrorInfo(e));
            log.error(msg);
            throw new ServletException(msg, e);
        }
    }

    public void destroy() {
        // уведомляем о старте
        if (webService != null) {
            for (IAppShutdown z : webService.getApp().getServices().impl(IAppShutdown.class)) {
                try {
                    z.appShutdown(this);
                } catch (Exception e) {
                    log.error(e);
                }
            }
        }
        super.destroy();
    }

    protected void loadApp() throws Exception {
        String s;

        // отключаем логирование
        UtLog.logOff();

        // настраиваем логирование
        s = getInitParameter(INIT_PARAM_log);
        if (!UtString.empty(s)) {
            s = UtFile.findFileUp(s, getServletContext().getRealPath("WEB-INF"));
            if (s != null) {
                UtLog.loadProperties(s);
            }
            UtLog.logOn();
        }

        // ищем конфиг
        String cfn = getInitParameter(INIT_PARAM_app_rt);
        if (UtString.empty(cfn)) {
            cfn = App.FILE_APP_RT;
        }

        String appdir = getServletContext().getRealPath("WEB-INF");

        log.info("app.rt file: " + cfn);
        log.info("appdir: " + appdir);

        String cfgfile = UtFile.findFileUp(cfn, appdir);
        if (cfgfile == null) {
            log.info("app.rt file NOT found!");
            throw new FileNotFoundException(cfn);
        } else {
            log.info("app.rt file found: " + cfgfile);
        }

        // загружаем приложение
        app = AppLoader.load(cfgfile);

        // кешируем webService
        webService = app.service(WebService.class);

        log.info("appdir: " + app.getAppdir());

        // настраиваем его
        webService.setHttpServlet(this);

        // уведомляем о старте
        for (IAppStartup z : app.getServices().impl(IAppStartup.class)) {
            z.appStartup(this);
        }

        // помещаем сервлет в контекст для доступа к нему (вернее к его приложению)
        // из других сервлетов
        getServletContext().setAttribute("servlet:" + getServletName(), this);

        // все
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // делегирование запроса
            webService.handleRequest(request, response);
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

}