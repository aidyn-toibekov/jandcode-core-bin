package jandcode.web;

import java.lang.reflect.*;

/**
 * Класс, который можно указать в качестве параметра в action.
 * Если указан, то выполнение осуществляется этим классом.
 */
public abstract class ActionWrapper {

    protected Method method;
    protected WebAction action;

    public void setAction(WebAction action, Method method) {
        this.action = action;
        this.method = method;
    }

    public void exec() throws Exception {
        execMethod();
    }

    protected void execMethod() throws Exception {
        method.invoke(action, this);
    }

    public Method getMethod() {
        return method;
    }

    public WebAction getAction() {
        return action;
    }
}
