package jandcode.web;

import groovy.lang.*;
import jandcode.app.*;
import jandcode.groovy.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Шаблон для вывода текста.
 * В свойстве owner - ссылка на шаблон, который вызвал этот.
 */
public class Tml extends Comp implements IGspTemplate {

    public static final String ARG_BODY = "body";

    protected OutBuilder outBuilder;
    protected VariantMap args = new VariantMap();
    protected String resPath = "";

    public Tml getOwner() {
        return (Tml) super.getOwner();
    }

    ////// body

    public class Body {
        public void render() throws Exception {
        }
    }

    public class BodyRunnable extends Body {
        Runnable runnable;

        public BodyRunnable(Runnable runnable) {
            this.runnable = runnable;
        }

        public void render() throws Exception {
            runnable.run();
        }
    }

    public class BodyClosure extends Body {
        Closure closure;

        public BodyClosure(Closure closure) {
            this.closure = closure;
        }

        public void render() throws Exception {
            closure.call();
        }
    }

    //////

    /**
     * Куда выводим
     */
    public OutBuilder getOutBuilder() {
        return outBuilder;
    }

    public void setOutBuilder(OutBuilder outBuilder) {
        this.outBuilder = outBuilder;
    }

    //////

    /**
     * Вывод шаблона в текущий буфер
     */
    public void render() throws Exception {
        onRender();
    }

    /**
     * Реализация вывода
     */
    protected void onRender() throws Exception {
    }

    public String toString() {
        TextBuffer buf = pushBuffer();
        try {
            render();
        } catch (Exception e) {
            throw new XErrorWrap(e);
        } finally {
            popBuffer();
        }
        return buf.toString();
    }

    //////

    /**
     * Вывести текст
     */
    public void out(Object s) {
        outBuilder.out(s);
    }

    /**
     * Возвращает самого себя. Например, для использования вывода в стиле groovy в скриптах:
     * <code>out << s << s2</code>
     */
    public Tml getOut() {
        return this;
    }

    /**
     * Для вывода в стиле groovy 'out << s << s2'
     */
    public Tml leftShift(Object value) {
        out(value);
        return this;
    }

    ////// buffer

    /**
     * Создать новый буфер и поместить его в стек. Весь вывод будет в новый буфер.
     * Возвращает новый буфер.
     */
    public TextBuffer pushBuffer() {
        return outBuilder.pushBuffer();
    }

    /**
     * Извлечь последний буфер из стека.
     */
    public TextBuffer popBuffer() {
        return outBuilder.popBuffer();
    }

    /**
     * Текущий буфер, в который осуществляется вывод.
     */
    public TextBuffer curBuffer() {
        return outBuilder.curTextBuffer;
    }

    ////// args

    /**
     * Аргументы шаблона, переданные ему при вызове
     */
    public VariantMap getArgs() {
        return args;
    }

    /**
     * Установить значения для аргументов. Накладиваются на существующие.
     */
    public void setArgs(Map args) {
        if (args != null) {
            for (Object key : args.keySet()) {
                String nm = UtString.toString(key);
                this.args.put(nm, args.get(key));
            }
        }
    }

    /**
     * Замена ссылки args
     *
     * @param args
     */
    public void assignArgs(VariantMap args) {
        this.args = args;
    }

    /**
     * Все глобальные переменные в "слоеном пироге".
     * Когда выводится шаблон, сюда добавляется новый слой, который содержит аргументы (args),
     * переданные шаблону при его вызове. Новому слою дается имя шаблона.
     * Когда шаблон закончил выводится, слой уничтожается.
     * </pre>
     * Присвоение значение переменным в vars всегда происходит на верхний слой и эквивалентно
     * присвоение переменной в args.
     */
    public VariantMapLayer getVars() {
        return outBuilder.vars;
    }

    private String normalizeLayerName(String name) {
        if (name == null) {
            return "";
        }
        if (name.indexOf('/') == -1) {
            name = "jc/" + name;
        }
        return name;
    }

    /**
     * Возвращает переменные, как они доступны при выводе шаблона tmlName.
     * Используется во вложенных шаблонах для получения переменных относительно
     * шаблонов верхнего уровня.
     */
    public VariantMapLayer vars(String tmlName) {
        return outBuilder.vars.layer(normalizeLayerName(tmlName));
    }

    /**
     * Возвращает аргументы, как они доступны при выводе шаблона tmlName.
     * Используется во вложенных шаблонах для получения аргументов
     * шаблонов верхнего уровня.
     */
    public VariantMap args(String tmlName) {
        return outBuilder.vars.layer(normalizeLayerName(tmlName)).getHead().getMap();
    }

    ////// body

    protected Body convertToBody(Object z) {
        if (z instanceof Body) {
            return (Body) z;
        } else if (z instanceof Closure) {
            return new BodyClosure((Closure) z);
        } else if (z instanceof Runnable) {
            return new BodyRunnable((Runnable) z);
        } else {
            return null; // не поддерживается
        }
    }

    /**
     * Тело шаблона. Может быть null.
     */
    public Body getBody() {
        Object a = getArgs().get(ARG_BODY);
        if (a == null) {
            return null;
        }
        if (a instanceof Body) {
            return (Body) a;
        }
        Body b = convertToBody(a);
        if (b != null) {
            getArgs().put(ARG_BODY, b);
        }
        return b;
    }

    /**
     * Вывести тело шаблона, если есть.
     */
    public void outBody() throws Exception {
        Body b = getBody();
        if (b == null) {
            return;
        }
        b.render();
    }

    /**
     * Вывести тело шаблона во временный буфер и вернуть его.
     */
    public TextBuffer grabBody() throws Exception {
        return grabBody(getBody());
    }

    /**
     * Вывести тело шаблона во временный буфер и вернуть его.
     */
    public TextBuffer grabBody(Body b) throws Exception {
        if (b == null) {
            return new TextBuffer();
        }
        TextBuffer buf = pushBuffer();
        try {
            b.render();
        } finally {
            popBuffer();
        }
        return buf;
    }

    ////// out tag (for gsp)

    public void outTag(String tmlName, Map args, Closure cls) throws Exception {
        outBuilder.outTml(tmlName, args, cls);
    }

    public void outTag(Map args, String tmlName, Closure cls) throws Exception {
        outBuilder.outTml(tmlName, args, cls);
    }

    public void outTag(Map args, String tmlName) throws Exception {
        outBuilder.outTml(tmlName, args, null);
    }

    public void outTag(String tmlName) throws Exception {
        outBuilder.outTml(tmlName, null, null);
    }

    public void outTag(String tmlName, Map args) throws Exception {
        outBuilder.outTml(tmlName, args, null);
    }

    public void outTag(String tmlName, Closure cls) throws Exception {
        outBuilder.outTml(tmlName, null, cls);
    }

    ////// out tml

    public void outTml(String tmlName, Map args, Closure cls) throws Exception {
        outBuilder.outTml(tmlName, args, cls);
    }

    public void outTml(Map args, String tmlName, Closure cls) throws Exception {
        outBuilder.outTml(tmlName, args, cls);
    }

    public void outTml(Map args, String tmlName) throws Exception {
        outBuilder.outTml(tmlName, args, null);
    }

    public void outTml(String tmlName) throws Exception {
        outBuilder.outTml(tmlName, null, null);
    }

    public void outTml(String tmlName, Map args) throws Exception {
        outBuilder.outTml(tmlName, args, null);
    }

    public void outTml(String tmlName, Closure cls) throws Exception {
        outBuilder.outTml(tmlName, null, cls);
    }

    ////// include

    /**
     * Включение шаблона в контексте текущего шаблона. Внутри шаблона tmlName
     * args будет такой же, как и у того, откуда включили.
     */
    public void include(String tmlName) throws Exception {
        outBuilder.includeTml(this, tmlName);
    }

    /**
     * Включение шаблона в контексте и относительно пути текущего шаблона. Внутри шаблона tmlName
     * args будет такой же, как и у того, откуда включили.
     */
    public void includeRel(String tmlName) throws Exception {
        outBuilder.includeTml(this, resPath(tmlName));
    }

    ////// utils

    /**
     * Путь с ресурсами шаблона. Для gsp - каталог, в котором она лежит.
     * Для остальных - путь до класса шаблона + имя шаблона (например для
     * 'jc/page' => '/tml/jc/page'
     *
     * @return
     */
    public String getResPath() {
        return resPath;
    }

    public void setResPath(String resPath) {
        this.resPath = resPath;
    }

    /**
     * Абсолютный путь ресурса по относительному
     */
    public String resPath(String p) {
        return getResPath() + "/" + p;
    }

    /**
     * Уникальная id в контексте вывода
     */
    public int getNextId() {
        return outBuilder.getNextId();
    }

    public String getBaseId() {
        return outBuilder.getBaseId();
    }

    public void setBaseId(String baseId) {
        outBuilder.setBaseId(baseId);
    }

    /**
     * Текущий запрос
     */
    public WebRequest getRequest() {
        return getWebService().getRequest();
    }

    public WebService getWebService() {
        return getApp().service(WebService.class);
    }

    public String ref(String url, boolean virtualRoot, Map params) {
        return getApp().service(WebService.class).ref(url, virtualRoot, params);
    }

    public String ref(String url, Map params) {
        return getApp().service(WebService.class).ref(url, params);
    }

    public String ref(String url) {
        return getApp().service(WebService.class).ref(url);
    }

    /**
     * Экранирование html символов
     */
    public String escape(Object text) {
        return UtString.xmlEscape(UtString.toString(text));
    }

    /**
     * Экранирование символов для использования результата в качестве javascript-строки
     */
    public String escapeJs(String s) {
        if (s == null) {
            return "";
        }
        s = s.replace("'", "\\'");
        s = s.replace("\"", "\\\"");
        s = s.replace("\n", "\\\n");
        return s;
    }

    //////

    /**
     * Устанвить делегата. После этого вызова объект будет вести себя как delegate,
     * но может имет дополнительные методы. Используется для создания утилит-расширений
     * для Tml.
     *
     * @param delegate
     */
    protected void setDelegate(Tml delegate) {
        this.app = delegate.app;
        this.outBuilder = delegate.outBuilder;
        this.args = delegate.args;
        this.resPath = delegate.resPath;
    }

}
