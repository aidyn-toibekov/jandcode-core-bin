package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;

public class Resolve1DictDao extends Dao implements ILoadDict {

    @DaoMethod
    public void loadDict(Dict dict) {
        System.out.println("resolve:" + dict.getResolveIds());
        DataRecord r;
        for (Object o : dict.getResolveIds()) {
            r = dict.getData().add();
            r.setValue("id", o);
            r.setValue("text", "V:" + o);
        }
    }
}
