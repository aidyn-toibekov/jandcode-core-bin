package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

public class Dao1Dao extends Dao {

    protected DaoUtils ut = new DaoUtils(this);

    @DaoMethod
    public String method1() throws Exception {
        return "OK-method1";
    }

    @DaoMethod
    public String hello(String s) throws Exception {
        return "hello, " + s;
    }


    @DaoMethod
    public DataStore d1(int size) throws Exception {
        Rt rt = getRt().getChild("dataloader/d1");
        RandomDataLoader ldr = (RandomDataLoader) getModel().getObjectFactory().create(rt);
        ldr.setDomain(getDomain());
        if (size == 0) {
            size = 5;
        }
        ldr.setSize(size);
        ldr.load();
        return ldr.getData();
    }

    @DaoMethod
    public DataBox databox1() throws Exception {
        DataBox b = new DataBox();
        b.put("a", "AA");
        b.put("b", "BB");
        return b;
    }

    @DaoMethod
    public void error1() throws Exception {
        throw new XError("Error1");
    }

    @DaoMethod
    public boolean connected1() throws Exception {
        return ut.getDb().isConnected();
    }

}
