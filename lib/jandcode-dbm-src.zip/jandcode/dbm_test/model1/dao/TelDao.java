package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;

public class TelDao extends CustomDao {

    @DaoMethod
    public DataStore listFirst(int cnt) throws Exception {
        String sql = ut.subst("select * from tel where id<=${cnt}",
                "cnt", cnt);
        DataStore t = UtData.createStore(getDomain());
        ut.loadSql(t, sql);
        return t;
    }

}
