package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.*;
import jandcode.utils.rt.*;

public class Resolve1Dao extends Dao {

    @DaoMethod
    public DataStore d1(int size) throws Exception {
        Rt rt = getRt().getChild("dataloader/d1");
        RandomDataLoader ldr = (RandomDataLoader) getModel().getObjectFactory().create(rt);
        ldr.setDomain(getDomain());
        ldr.setSize(size);
        ldr.load();
        return ldr.getData();
    }


}
