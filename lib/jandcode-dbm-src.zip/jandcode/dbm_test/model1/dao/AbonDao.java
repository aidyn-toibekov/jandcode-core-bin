package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;

import java.util.*;

public class AbonDao extends SimpleIdeDao implements ILoadDict {

    @DaoMethod
    public void loadDict(Dict dict) throws Exception {
        CollectionBlockIterator z = new CollectionBlockIterator(dict.getResolveIds(), 200);
        for (List itms : z) {
            String sql = ut.subst(
                    "select id, name as text from Abon where id in (${itms})",
                    "itms", UtString.join(itms, ","));
            ut.loadSql(dict.getData(), sql);
        }
    }

}
