package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;

public class FreeDao1Dao extends Dao {

    @DaoMethod
    public String test1() throws Exception {
        return "free-dao-1";
    }

}
