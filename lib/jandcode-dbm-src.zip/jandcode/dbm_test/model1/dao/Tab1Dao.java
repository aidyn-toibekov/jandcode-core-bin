package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

import java.util.*;

public class Tab1Dao extends SimpleIdeDao {

    @DaoMethod
    public DataStore recsByMap(Map p) throws Exception {
        StringBuilder sql = new StringBuilder();
        sql.append("select * from ${table} where 1=1");
        for (Object key : p.keySet()) {
            String ks = UtString.toString(key);
            sql.append(" and ").append(ks).append("=:").append(ks);
        }
        DataStore t = UtData.createStore(getDomain());
        ut.loadSql(t, ut.subst(sql), p);
        return t;
    }

    @DaoMethod
    public DataStore loadBlob(long id) throws Exception {
        String s = "select f_blob from Tab1 where id=" + id;
        DataStore t = UtData.createStore(getDomain());
        ut.loadSql(t, s);
        return t;
    }

}
