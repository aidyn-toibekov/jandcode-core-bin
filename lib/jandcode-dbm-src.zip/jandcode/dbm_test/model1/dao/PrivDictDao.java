package jandcode.dbm_test.model1.dao;

import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;

public class PrivDictDao extends Dao implements ILoadDict {

    @DaoMethod
    public void loadDict(Dict dict) {
        DataRecord r;
        //
        r = dict.getData().add();
        r.setValue("id", true);
        r.setValue("text", "Приватный");
        //
        r = dict.getData().add();
        r.setValue("id", false);
        r.setValue("text", "Публичный");
    }
}
