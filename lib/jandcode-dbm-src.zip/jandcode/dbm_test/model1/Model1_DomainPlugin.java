package jandcode.dbm_test.model1;

import jandcode.dbm.*;
import jandcode.utils.rt.*;

/**
 * Пример обработчика домена
 */
public class Model1_DomainPlugin extends RtPluginAdapter implements IRtPluginDomain {

    public void handleDomain(Rt domain, Rt model) {
        if (model.hasName("jandcode.dbm_test.model1")) {
            domain.setValue("_model1_", true);
        }
    }

}
