package jandcode.dbm.doc;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Расширение для модели. Диаграммы.
 * Диаграммы хранятся в модели в узлах вида:
 * <pre>{@code
 * <diagram name="name-diagram" title="Title diagram">
 *      <--@
 *         Diagram comment
 *      -->
 *      <domain name="domain-name-in-this-diagram"/>
 * </diagram>
 * }</pre>
 */
public class DiagramModelExt extends ModelExt {

    private ListNamed<Diagram> diagrams;

    public DiagramModelExt(Model model) {
        super(model);
    }

    /**
     * Элемент диаграммы
     */
    public class DiagramItem extends Named {
        private Domain domain;
        private boolean showFields = true;

        private void setRt(Rt rt) {
            setName(rt.getName());
            domain = getModel().getDomain(rt.getName());
            showFields = rt.getValueBoolean("showFields", true);
        }

        /**
         * Домен
         */
        public Domain getDomain() {
            return domain;
        }

        /**
         * Показывать ли поля
         */
        public boolean isShowFields() {
            return showFields;
        }
    }

    public class Diagram extends Named {

        private String title = "";
        private String comment = "";
        private ListNamed<DiagramItem> items = new ListNamed<DiagramItem>();
        private ListDomain domains;

        /**
         * Заголовок
         *
         * @return
         */
        public String getTitle() {
            return title;
        }

        /**
         * коментарий
         *
         * @return
         */
        public String getComment() {
            return comment;
        }

        /**
         * элементы диаграммы на диаграмме
         *
         * @return
         */
        public ListNamed<DiagramItem> getItems() {
            return items;
        }

        /**
         * Список доменов
         */
        public ListDomain getDomains() {
            if (domains == null) {
                domains = new ListDomain();
                for (DiagramItem it : items) {
                    domains.add(it.getDomain());
                }
            }
            return domains;
        }
    }

    /**
     * Диаграммы
     *
     * @return
     */
    public ListNamed<Diagram> getDiagrams() {
        if (diagrams == null) {
            // забираем и создаем все диаграммы
            diagrams = new ListNamed<Diagram>();
            Rt z = getRt().findChild("diagram");
            if (z != null) {
                for (Rt z1 : z.getChilds()) {
                    Diagram d = new Diagram();
                    d.setName(z1.getName());
                    d.title = z1.getValueString("title");
                    d.comment = z1.getValueString(Rt.COMMENT);
                    Rt zD = z1.findChild("domain");
                    if (zD != null) {
                        for (Rt zD1 : zD.getChilds()) {
                            DiagramItem it = new DiagramItem();
                            it.setRt(zD1);
                            d.items.add(it);
                        }
                    }
                    if (d.items.size() > 0) {
                        diagrams.add(d);
                    }
                }
            }
        }
        return diagrams;
    }

    /**
     * Диаграммы, на которых задействован домен domainName или пустой список
     */
    public List<Diagram> getDiagrams(String domainName) {
        List<Diagram> res = new ArrayList<Diagram>();
        for (Diagram diagram : getDiagrams()) {
            if (diagram.getItems().find(domainName) != null) {
                res.add(diagram);
            }
        }
        return res;
    }

}
