package jandcode.dbm.dblang;

import jandcode.dbm.*;
import jandcode.lang.*;
import jandcode.utils.*;

/**
 * Сервис поддержки баз данных с мультиязыковыми данными
 */
public abstract class DblangService extends ModelMember {

    /**
     * Возвращает список зарегистрированных языков для модели.
     * Все эти языки должны быть зарегистрированы в jandcode.lang.LangService
     * Порядок элементов в списке определяет приоритеты языков.
     * Первый элемент в списке - язык по умолчанию
     */
    public abstract ListNamed<Lang> getLangs();

    /**
     * Язык по умолчанию в базе. Т.е. тот, который используется, если не
     * известно, какой язык использовать.
     */
    public Lang getDefaultLang() {
        return getLangs().get(0);
    }

    /**
     * Возвращает текущий язык для потока. Если текущий язык системы не является
     * языком в базе, то возвращается язык по умолчанию.
     */
    public abstract Lang getCurrentLang();


}
