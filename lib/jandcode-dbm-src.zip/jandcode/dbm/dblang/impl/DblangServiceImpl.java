package jandcode.dbm.dblang.impl;

import jandcode.dbm.dblang.*;
import jandcode.lang.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.util.*;

public class DblangServiceImpl extends DblangService {

    private ListNamed<Lang> langs = new ListNamed<Lang>();

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //

        // сервис должен обработать языку в этом методу, т.к. далее она создает
        // домены и языки уже должны быть

        LangService langServ = getApp().service(LangService.class);
        Rt x = getModel().getRt().findChild("dblang/lang");
        List<IndexWeightContainer<Lang>> lst1 = new ArrayList<IndexWeightContainer<Lang>>();
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                String langName = x1.getName();
                Lang lang = langServ.getLangs().find(langName);
                if (lang == null) {
                    throw new XError("В модели {0} объявлен язык {1}, но он отсутсвует в LangService", getModel().getName(), langName);
                }
                IndexWeightContainer<Lang> c = new IndexWeightContainer<Lang>();
                c.setLink(lang);
                c.setWeight(x1.getValueInt("weight", 50));
                c.setIndex(lst1.size());
                lst1.add(c);
            }
        }
        //
        if (lst1.size() == 0) {
            throw new XError("Не определений языков для модели {0}", getModel().getName());
        }
        Collections.sort(lst1);
        langs.clear();
        for (IndexWeightContainer z : lst1) {
            langs.add((Lang) z.getLink());
        }
        //
    }

    public ListNamed<Lang> getLangs() {
        return langs;
    }

    public Lang getCurrentLang() {
        LangService langServ = getApp().service(LangService.class);
        Lang sysCurLang = langServ.getCurrentLang();
        Lang dbCurLang = getLangs().find(sysCurLang.getName());
        if (dbCurLang == null) {
            dbCurLang = getDefaultLang();
        }
        return dbCurLang;
    }
}
