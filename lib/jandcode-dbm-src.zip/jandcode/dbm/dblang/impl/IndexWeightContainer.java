package jandcode.dbm.dblang.impl;

public class IndexWeightContainer<TYPE> implements Comparable<IndexWeightContainer> {

    private int index;
    private int weight = 50;
    private TYPE link;

    public void setIndex(int index) {
        this.index = index;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getIndex() {
        return index;
    }

    public int getWeight() {
        return weight;
    }

    public void setLink(TYPE link) {
        this.link = link;
    }

    public TYPE getLink() {
        return link;
    }

    public int compareTo(IndexWeightContainer o) {
        Integer i1 = getWeight();
        Integer i2 = o.getWeight();
        int n = i1.compareTo(i2);
        if (n == 0) {
            Integer s1 = getIndex();
            int s2 = o.getIndex();
            n = s1.compareTo(s2);
        }
        return n;
    }

}
