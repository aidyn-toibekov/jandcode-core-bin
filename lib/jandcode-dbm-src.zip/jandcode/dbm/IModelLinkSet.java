package jandcode.dbm;

/**
 * Интерфейс для объектов, получающих ссылку на {@link Model}
 */
public interface IModelLinkSet {

    /**
     * Установить ссылку
     */
    void setModel(Model model);

}
