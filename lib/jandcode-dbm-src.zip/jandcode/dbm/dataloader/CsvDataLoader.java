package jandcode.dbm.dataloader;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.csv.*;

import java.io.*;

/**
 * Загрузчик из формата csv. Первая строка должна содержать имена полей.
 */
public class CsvDataLoader extends FileDataLoader {

    private char delimiter = ',';
    private char encapsulator = '"';
    private char commentStart = ';';

    //////

    /**
     * Символ, с которого начинается коментарий
     */
    public void setCommentStart(char commentStart) {
        this.commentStart = commentStart;
    }

    public char getCommentStart() {
        return commentStart;
    }

    /**
     * Разделитель полей
     */
    public void setDelimiter(char delimiter) {
        this.delimiter = delimiter;
    }

    public char getDelimiter() {
        return delimiter;
    }

    /**
     * Ограничитель полей (кавычки)
     */
    public void setEncapsulator(char encapsulator) {
        this.encapsulator = encapsulator;
    }

    public char getEncapsulator() {
        return encapsulator;
    }

    //////

    protected void onLoad() throws Exception {
        Domain domain = getData().getDomain();
        //
        InputStream stm = openStream();
        try {
            CSVStrategy stg = new CSVStrategy(getDelimiter(), getEncapsulator(), getCommentStart());

            CSVParser p = new CSVParser(new InputStreamReader(stm, getCharset()), stg);

            // первая линия - список полей
            String[] fields = p.getLine();

            // потом данные
            String[] line = p.getLine();
            while (line != null) {
                if (line.length != fields.length) {
                    throw new XError(
                            "Ошибка в строке [{0}]: количество элементов в строке " +
                                    "не совпадает с количеством полей", p.getLineNumber());
                }

                DataRecord rec = getData().add();
                for (int i = 0; i < fields.length; i++) {
                    String s = line[i];
                    if (s == null) {
                        continue;
                    }
                    s = s.trim();
                    if (s.length() == 0) {
                        int dt = domain.f(fields[i]).getDataType();
                        if (DataType.STRING == dt || DataType.BLOB == dt) {
                            continue;
                        }
                    }
                    if (s.equals("<NULL>")) {
                        continue;
                    }
                    rec.setValue(fields[i], s);
                }

                line = p.getLine();
            }
        } finally {
            stm.close();
        }
    }


}
