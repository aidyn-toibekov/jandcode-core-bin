package jandcode.dbm.dataloader;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

/**
 * Загрузчик данных в структуры доменов.
 * Присваиваем домены (setDomain). Выполняем load(). Забираем данные (getData)
 */
public abstract class DataLoader extends ModelMember {

    public static final String DEFAULT = "default";

    protected ListNamed<DataStore> datas = new ListNamed<DataStore>();

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt z = getRt().findChild("domain");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                Domain d = (Domain) getModel().getObjectFactory().create(z1);
                setDomain(z1.getName(), d);
            }
        }
        //
    }

    //////

    public void setDomain(String name, Domain domain) {
        DataStore store = UtData.createStore(domain);
        store.setName(name);
        datas.add(store);
    }

    public void setDomain(Domain domain) {
        setDomain(DEFAULT, domain);
    }

    public void setDomain(String domainName) {
        setDomain(DEFAULT, getModel().createDomain(domainName));
    }

    //////

    /**
     * Заполненные данные
     */
    public DataStore getData(String name) {
        if (name == null || name.length() == 0) {
            name = DEFAULT;
        }
        return datas.get(name);
    }

    public DataStore getData() {
        return getData(DEFAULT);
    }

    public ListNamed<DataStore> getDatas() {
        return datas;
    }

    /**
     * Есть ли данные
     */
    public boolean hasDatas() {
        return datas.size() > 0;
    }

    //////

    /**
     * Загрузить данные
     */
    public void load() throws Exception {
        onLoad();
    }

    protected abstract void onLoad() throws Exception;

}
