package jandcode.dbm.dataloader;

import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.easyxml.*;
import jandcode.utils.error.*;
import jandcode.utils.io.*;
import org.apache.commons.vfs2.*;

import java.io.*;

/**
 * Загрузчик данных из формата xml. Это простой формат, где каждый узел верхнего уровня
 * считается строкой, а каждый атрибут - значением соответствующего поля. Вложенные
 * узлы считаются значением полей, которые совпадают с именем узла (обычно для blob
 * используется). Если у вложенного узла есть атрибут 'src', то он указывает на
 * файл VFS, откуда нужно загрузить значение. Если путь не абсолютный, то
 * пути относительно file. При наличии атрибута 'src' атрибут 'encoding' рассматривается
 * как кодировка. По умолчанию 'utf-8'
 */
public class XmlDataLoader extends CustomXmlDataLoader {

    protected void onLoad() throws Exception {
        InputStream stm = openStream();
        try {
            EasyXml data = new EasyXml();
            data.load().fromStream(stm);
            // авто домен
            if (getDatas().isEmpty()) {
                // не установлен домен
                String tn = data.getValueString("@domain");
                if (UtString.empty(tn)) {
                    tn = data.getValueString("@table");
                }
                if (UtString.empty(tn)) {
                    throw new XError("Нет явно установленного домена и нет атрибута domain или table в корневом узле");
                }
                setDomain(tn);
            }
            //
            for (EasyXml row : data) {
                DataRecord rec = getData().add();
                loadRow(rec, row);
            }
        } finally {
            stm.close();
        }
    }

    protected void loadRow(DataRecord rec, EasyXml row) throws Exception {
        super.loadRow(rec, row);
        //
        for (EasyXml child : row) {
            String src = child.getValueString("@src");
            if (src.length() == 0) {
                rec.setValue(child.getName(), UtString.toString(child.getValue()));
            } else {
                FileObject srcFile = getRelativeFile(src);
                String enc = child.getValueString("@encoding");
                InputStream srcStm = srcFile.getContent().getInputStream();
                try {
                    StringLoader ldr = new StringLoader();   //todo а вдруг блоб-картинка? исправить!!!
                    if (enc.length() == 0) {
                        UtLoad.fromStream(ldr, srcStm);
                    } else {
                        UtLoad.fromStream(ldr, srcStm, enc);
                    }
                    rec.setValue(child.getName(), ldr.getResult());
                } finally {
                    srcStm.close();
                }
            }
        }

    }


}
