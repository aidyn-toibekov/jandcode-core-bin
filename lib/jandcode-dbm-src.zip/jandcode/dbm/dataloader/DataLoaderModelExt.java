package jandcode.dbm.dataloader;

import jandcode.dbm.*;
import jandcode.utils.io.*;
import jandcode.utils.rt.*;
import org.apache.commons.vfs2.*;

import java.util.*;

/**
 * Расширение для модели для работы с dataloader
 */
public class DataLoaderModelExt extends ModelExt {

    public DataLoaderModelExt(Model model) {
        super(model);
    }

    /**
     * Возвращает набор имен dataloader из модели
     *
     * @return
     */
    public Set<String> getDataLoaderNames() {
        Set<String> res = new HashSet<String>();
        for (Rt z : getModel().getRt().getChild("dataloader").getChilds()) {
            res.add(z.getName());
        }
        return res;
    }

    /**
     * Создать dataloader по файлу.
     * Имя файла должно бфть в формате: DOMAINNAME.EXT или DOMAINNAME-ANYCHARS.EXT
     *
     * @param filename имя файла
     * @return dataloader
     */
    public DataLoader createDataLoaderFromFile(String filename) {
        String nm = UtDataLoader.filenameToDataloaderName(filename);
        //
        DataLoader ldr = getComp().createDataLoader(nm);
        ((IFileDataLoader) ldr).setFile(filename);
        ldr.setDomain(UtDataLoader.filenameToDomainName(filename));
        //
        return ldr;
    }

    /**
     * Создать список dataloader по файлам в каталоге
     *
     * @param dir из какого каталога
     * @return список dataloader
     */
    public List<DataLoader> createDataLoadersFromDir(String dir) {
        List<DataLoader> res = new ArrayList<DataLoader>();
        DirScannerVfs scanner = new DirScannerVfs();
        scanner.setRootDir(dir);
        scanner.setRecursive(true);
        scanner.scan();
        Set<String> names = getDataLoaderNames();
        for (FileObject f : scanner.getFiles()) {
            String nm = UtDataLoader.filenameToDataloaderName(f.toString());
            if (!names.contains(nm)) {
                continue; // неизвестный файл
            }
            DataLoader ldr = createDataLoaderFromFile(f.toString());
            if (ldr != null) {
                res.add(ldr);
            }
        }
        return res;
    }

    /**
     * Создать список dataloader по типу dbdata
     *
     * @param dbdataName имя dbdata (prod/test)
     * @return список dataloader
     */
    public List<DataLoader> createDataLoadersDbData(String dbdataName) {
        List<DataLoader> res = new ArrayList<DataLoader>();
        for (Domain domain : getComp().getDomainsDb(false)) {
            if (!domain.hasTag("dataloader")) {
                continue;
            }
            List<DataLoader> a = new DataLoaderDomainExt(domain).createDataLoaders(dbdataName);
            res.addAll(a);
        }
        return res;
    }

}
