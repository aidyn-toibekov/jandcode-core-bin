package jandcode.dbm.dataloader;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.rnd.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

/**
 * Загрузчик случайных данных для тестирования.
 */
public class RandomDataLoader extends DataLoader {

    protected int size = 1;
    protected long id = 1;
    protected Rnd rnd = new Rnd();
    protected ListComp<Rnd> fieldRnd = new ListComp<Rnd>();

    //////

    /**
     * Сколько записей заполнять
     */
    public void setSize(int size) {
        this.size = size;
    }

    public int getSize() {
        return size;
    }

    //////

    /**
     * Значение поля id, с которой будет начата генерация. Если в таблице этого поля нет,
     * то можно проигнорировать.
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * Возвращает текущий id
     */
    public long getId() {
        return id;
    }

    /**
     * Увеличивает id
     */
    public void incId() {
        id++;
    }

    /**
     * Личный генератор (для потомков)
     */
    public Rnd getRnd() {
        return rnd;
    }

    //////

    /**
     * Создать Rnd для поля домена
     */
    public Rnd createFieldRnd(String fieldName) {
        Field fld = getData().getDomain().findField(fieldName);

        Rt fieldRt = getRt().findChild("field/" + fieldName);
        String rndName = "";
        if (fieldRt != null) {
            rndName = fieldRt.getValueString("rnd");
        }

        if (UtString.empty(rndName)) {
            if (fld == null) {
                throw new XError("Rnd для поля {0} не найдено", fieldName);
            }
            rndName = fld.getDbDataType();
        }

        Rt rndRt = getRt().findChild("rnd/" + rndName);
        if (rndRt == null) {
            rndRt = getRt().getChild("rnd/null");
        }

        Rnd rndInst = (Rnd) getModel().getObjectFactory().create(rndRt);
        rndInst.setOwner(this);

        if (fieldRt != null) {
            rndInst.setRt(fieldRt);
        }

        rndInst.setName(fieldName);
        if (fld != null) {
            rndInst.setSize(fld.getSize());
        }

        return rndInst;
    }

    /**
     * Возвращает кешированый Rnd для поля домена по умолчанию
     */
    public Rnd getFieldRnd(String fieldName) {
        Rnd rnd = fieldRnd.find(fieldName);
        if (rnd == null) {
            rnd = createFieldRnd(fieldName);
            fieldRnd.add(rnd);
            rnd.initOwner();
        }
        return rnd;
    }

    /**
     * Следующее значение для генератора поля
     */
    public Object nextValue(String fieldName) {
        Rnd rnd = getFieldRnd(fieldName);
        return rnd.nextValue();
    }

    //////

    public void load() throws Exception {
        // сбрасываем генератор
        getRnd().setName(getName());
        // создаем генераторы полей
        Domain domain = getData().getDomain();
        for (Field fld : domain.getFields()) {
            getFieldRnd(fld.getName());
        }
        //
        onLoad();
    }

    /**
     * Перекрыть для собственной реализации загрузки
     */
    protected void onLoad() throws Exception {
        for (int i = 0; i < getSize(); i++) {
            DataRecord rec = addRec();
            onLoadRec(rec);
            incId();
        }
    }

    /**
     * Перекрыть для дополнительной реализации загрузки записи.
     * Запись уже заполнена по умолчанию.
     */
    protected void onLoadRec(DataRecord rec) {
    }

    /**
     * Заполнить запись сгенерированными значениями
     */
    public void fillRec(DataRecord rec) {
        for (Field field : rec.getDomain().getFields()) {
            Rnd r = getFieldRnd(field.getName());
            if (!r.isEnabled()) {
                continue; // запрещен
            }
            r.setValue(rec, field);
        }
    }

    /**
     * Добавить запись и заполнить ее сгенерированными значениями.
     *
     * @param dataName в какой store добавлять
     */
    public DataRecord addRec(String dataName) {
        DataStore st = getData(dataName);
        DataRecord r = st.add();
        fillRec(r);
        return r;
    }

    /**
     * Добавить запись и заполнить ее сгенерированными значениями.
     */
    public DataRecord addRec() {
        return addRec(DEFAULT);
    }

}
