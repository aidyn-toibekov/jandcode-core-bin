package jandcode.dbm.dataloader.rnd;

public class StringRnd extends Rnd {

    protected Object onNextValue() {
        if (hasTemplate()) {
            return expandTemplate();
        } else {
            int sz = getSize();
            if (sz == 0) {
                sz = getMax();
            }
            return text("eng", "lower", 1, sz);
        }
    }

}
