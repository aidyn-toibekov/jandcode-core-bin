package jandcode.dbm.dataloader.rnd;

import jandcode.utils.*;

public class BooleanRnd extends Rnd {

    public BooleanRnd() {
        setMax(1);
    }

    protected Object onNextValue() {
        if (hasTemplate()) {
            return UtCnv.toBoolean(expandTemplate());
        } else {
            return UtCnv.toBoolean(num());
        }
    }

}
