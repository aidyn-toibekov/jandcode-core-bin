package jandcode.dbm.dataloader.rnd;

import org.joda.time.*;

public class DateTimeRnd extends Rnd {

    private DateTime startDate;

    public DateTimeRnd() {
        startDate = new DateTime("1997-05-24T12:00:00");
        setMax(200000000);
    }

    protected Object onNextValue() {
        if (hasTemplate()) {
            return new DateTime(expandTemplate());
        } else {
            return getStartDate().plusSeconds(num()).withMillisOfSecond(0);
        }
    }

    public void setStartDate(DateTime startDate) {
        this.startDate = startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = new DateTime(startDate);
    }

    public DateTime getStartDate() {
        return startDate;
    }

}
