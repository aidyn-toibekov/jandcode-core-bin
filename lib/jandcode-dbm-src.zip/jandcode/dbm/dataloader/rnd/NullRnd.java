package jandcode.dbm.dataloader.rnd;

public class NullRnd extends Rnd {
    public Object nextValue() {
        return null;
    }
}
