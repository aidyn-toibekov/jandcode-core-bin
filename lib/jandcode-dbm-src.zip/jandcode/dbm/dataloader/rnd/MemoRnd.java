package jandcode.dbm.dataloader.rnd;

public class MemoRnd extends Rnd {

    protected Object onNextValue() {
        if (hasTemplate()) {
            return expandTemplate();
        } else {
            int sz = getSize();
            if (sz == 0) {
                sz = getMax();
            }
            return text("eng-num", "lower", 1, sz);
        }
    }

}
