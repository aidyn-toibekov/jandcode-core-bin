package jandcode.dbm.dataloader.rnd;

public class IdRnd extends Rnd {
    protected Object onNextValue() {
        return getId();
    }
}
