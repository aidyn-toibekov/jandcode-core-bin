package jandcode.dbm.dataloader.rnd;

import jandcode.utils.*;

import java.math.*;

public class DoubleRnd extends Rnd {

    protected int decimal;
    protected double divider;

    public DoubleRnd() {
        setMax(1000000 - 1);
        setDecimal(2);
    }

    protected Object onNextValue() {
        double d;
        if (hasTemplate()) {
            d = UtCnv.toDouble(expandTemplate());
        } else {
            d = UtCnv.toDouble(num());
        }
        if (decimal > 0) {
            d = d + num(0, (int) divider) / divider;
        }
        BigDecimal decimal = new BigDecimal(d);
        decimal = decimal.setScale(this.decimal, BigDecimal.ROUND_DOWN);
        d = decimal.doubleValue();
        return d;
    }

    //////

    /**
     * Сколько десятичных знаков
     *
     * @param decimal
     */
    public void setDecimal(int decimal) {
        this.decimal = decimal;
        divider = Math.pow(10, this.decimal);
    }

    public int getDecimal() {
        return decimal;
    }

}
