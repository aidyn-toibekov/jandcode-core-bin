package jandcode.dbm.dataloader.rnd;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.lang.*;
import jandcode.utils.*;

/**
 * Генератор для многоязычных строковых полей. Прикрепляется на виртуальное поле,
 * генерирует физические поля по своим настройкам.
 */
public class LangStringRnd extends StringRnd {

    public void initOwner() {
        ListNamed<Lang> langs = getOwner().getModel().getDblangService().getLangs();
        // запрещаем все генераторы для связанных полей
        for (Lang lang : langs) {
            getOwner().getFieldRnd(getName() + "_" + lang.getName()).setEnabled(false);
        }
    }

    public void setValue(DataRecord rec, Field field) {
        ListNamed<Lang> langs = getOwner().getModel().getDblangService().getLangs();
        for (Lang lang : langs) {
            String nm = getName() + "_" + lang.getName();
            Object v = nextValue();
            rec.setValue(nm, v);
        }
    }

}
