package jandcode.dbm.dataloader.rnd;

import jandcode.utils.*;

public class IntRnd extends Rnd {

    public IntRnd() {
        setMax(10000 - 1);
    }

    protected Object onNextValue() {
        if (hasTemplate()) {
            return UtCnv.toInt(expandTemplate());
        } else {
            return UtCnv.toInt(num());
        }
    }

}
