package jandcode.dbm.dataloader.rnd;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Генератор ожидаемых случайностей
 */
public class Rnd extends CompRt implements ISubstVar {

    private static final String ENG_CHARS_S = "qwertyuiopasdfghjklzxcvbnm";
    private static final String RUS_CHARS_S = "йцукенгшщзхъфывапролджэячсмитьбю";
    private static final String NUM_CHARS_S = "0123456789";

    protected Random rnd = new Random(66673770);
    protected int min = 0;
    protected int max = 10;
    protected String template;
    protected int size;
    protected int nullFactor = 0;
    protected boolean enabled = true;

    public RandomDataLoader getOwner() {
        return (RandomDataLoader) super.getOwner();
    }

    /**
     * Сгенерить и установить значение в записи для поля.
     *
     * @param rec   запись
     * @param field поле
     */
    public void setValue(DataRecord rec, Field field) {
        rec.setValue(field, nextValue());
    }

    //////

    /**
     * Минимально генерируемое число
     */
    public void setMin(int min) {
        this.min = min;
    }

    public int getMin() {
        return min;
    }

    /**
     * Максимально генерируемое число
     */
    public void setMax(int max) {
        this.max = max;
    }

    public int getMax() {
        return max;
    }

    /**
     * id текущей строки
     *
     * @return
     */
    public long getId() {
        return getOwner().getId();
    }

    /**
     * Размер (максимальный для значений строковых полей)
     */
    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    /**
     * Через сколько записей генерировать null значения. Допусти задали число 20,
     * значит приблизительно каждое 20-е значение будет null.
     */
    public int getNullFactor() {
        return nullFactor;
    }

    public void setNullFactor(int nullFactor) {
        this.nullFactor = nullFactor;
    }

    protected boolean nextValueNull() {
        if (nullFactor <= 0) {
            return false;
        }
        return num(1, nullFactor) == 1;
    }

    //////

    public void setName(String name) {
        super.setName(name);
        // привязываем генератор к имени
        int newRnd = getName().toLowerCase().hashCode();
        rnd.setSeed(newRnd);
    }

    //////

    /**
     * Генерит следующий int в диапазоне [min]-[max]
     */
    public int num() {
        return num(min, max);
    }

    /**
     * Генерит int в указанном диапазоне
     *
     * @param min
     * @param max
     * @return
     */
    public int num(int min, int max) {
        int cnt = max - min + 1;
        int v = rnd.nextInt(cnt);
        return v + min;
    }

    /**
     * Генерит текст в указанном диапазоне
     *
     * @param chars  состав текста: 'rus','eng','num' (через '-', например 'rus-num').
     *               Для пробелов указываем 'wNN', где NN-приблизительная длина слова
     * @param kind   upper, lower, fupper
     * @param lenmin минимальная длина
     * @param lenmax максимальная длина
     * @return
     */
    public String text(String chars, String kind, int lenmin, int lenmax) {
        // массив символов
        String cs = "";
        // размер слова
        int wordSize = 0;
        //
        if (UtString.empty(chars)) {
            chars = "eng";
        }
        String[] ar = chars.split("-");
        for (String s : ar) {
            if ("rus".equals(s)) {
                cs = cs + RUS_CHARS_S;
            } else if ("num".equals(s)) {
                cs = cs + NUM_CHARS_S;
            } else if (s.startsWith("w")) {
                wordSize = UtCnv.toInt(s.substring(1), 10);
            } else {
                cs = cs + ENG_CHARS_S;
            }
        }
        char[] ca = cs.toCharArray();

        int len = num(lenmin, lenmax);
        StringBuilder sb = new StringBuilder();
        int curWS = 0;
        for (int i = 0; i < len; i++) {
            char c = ca[num(0, ca.length - 1)];
            if (wordSize > 0 && curWS > wordSize) {
                int a = num(0, 1);
                if (a == 0) {
                    c = ' ';
                    curWS = 0;
                }
            }
            curWS++;
            sb.append(c);
        }

        String s1 = sb.toString().trim();
        if ("upper".equals(kind)) {
            return s1.toUpperCase();
        } else if ("fupper".equals(kind)) {
            return UtString.capFirst(s1);
        } else {
            return s1.toLowerCase();
        }
    }

    /**
     * Возвращает одно из указанных в списке значений
     *
     * @param items допустимый набор значений
     */
    public String choice(String[] items) {
        return items[num(0, items.length - 1)];
    }

    //////

    /**
     * Шаблон генерируемой строки. Можно использовать подстановки ${} по свойствам
     */
    public void setTemplate(String template) {
        this.template = template;
    }

    public String getTemplate() {
        return template;
    }

    public boolean hasTemplate() {
        return !UtString.empty(template);
    }

    /**
     * Раскрыть шаблон template
     */
    public String expandTemplate() {
        return expandTemplate(getTemplate());
    }

    /**
     * Раскрыть шаблон template
     */
    public String expandTemplate(String template) {
        return UtString.substVar(template, this);
    }

    public String onSubstVar(String v) {
        if ("id".equals(v)) {
            return UtString.toString(getId());
        } else if ("min".equals(v)) {
            return UtString.toString(getMin());
        } else if ("max".equals(v)) {
            return UtString.toString(getMax());
        } else if ("name".equals(v)) {
            return getName();
        } else if ("size".equals(v)) {
            return UtCnv.toString(getSize());
        } else if ("num".equals(v)) {
            return UtString.toString(num());
        } else if (v.startsWith("num:")) {
            String s = UtString.removePrefix(v, "num:");
            String[] p = s.split(",");
            if (p.length != 2) {
                throw new XError("В строке \"{0}\" должно быть 2 параметра", v);
            }
            return UtString.toString(num(UtCnv.toInt(p[0], 0), UtCnv.toInt(p[1], 10)));
        } else if (v.startsWith("text:")) {
            String s = UtString.removePrefix(v, "text:");
            String[] p = s.split(",");
            if (p.length != 4) {
                throw new XError("В строке \"{0}\" должно быть 4 параметра", v);
            }
            return text(p[0], p[1], UtCnv.toInt(p[2], 1), UtCnv.toInt(p[3], 1));
        } else if (v.startsWith("choice:")) {
            String s = UtString.removePrefix(v, "choice:");
            String[] p = s.split(",");
            return choice(p);
        } else {
            return "";
        }
    }

    //////

    /**
     * Сгенерировать следующее значение.
     * Вызывает onNextValue() для генерации. В зависимости от nullFactor генерит null-ы.
     * Если механизм nullFactor нужно, перекрывайте onNextValue()
     */
    public Object nextValue() {
        if (nextValueNull()) {
            return null;
        }
        return onNextValue();
    }

    /**
     * Реализация генерации следующего значения
     */
    protected Object onNextValue() {
        return num();
    }

    //////

    /**
     * Если rnd запрещен, то он не используется при автоматической генерации данных
     * для строки store. В остальном - полностью рабочий.
     */
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    //////

    /**
     * Вызывается владельцем (RandomDataLoader) после того, как rnd был создан и
     * зарегистрирован.
     */
    public void initOwner() {
    }

}
