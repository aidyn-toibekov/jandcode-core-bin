package jandcode.dbm.dataloader.rnd;

import org.joda.time.*;

public class DateRnd extends DateTimeRnd {

    public DateRnd() {
        setStartDate(new DateTime("1997-05-24"));
        setMax(2000);
    }

    protected Object onNextValue() {
        if (hasTemplate()) {
            return new DateTime(expandTemplate());
        } else {
            return getStartDate().plusDays(num());
        }
    }

}
