package jandcode.dbm.dataloader.rnd;

import jandcode.utils.*;

public class LongRnd extends Rnd {

    public LongRnd() {
        setMax(100000 - 1);
    }

    protected Object onNextValue() {
        if (hasTemplate()) {
            return UtCnv.toLong(expandTemplate());
        } else {
            return UtCnv.toLong(num());
        }
    }

}
