package jandcode.dbm.dataloader.rnd;

public class BlobRnd extends Rnd {

    public BlobRnd() {
        setMax(20);
    }

    protected Object onNextValue() {
        int cnt = num();
        byte[] ar = new byte[cnt];
        for (int i = 0; i < ar.length; i++) {
            ar[i] = (byte) (i % 127 + 1);
        }
        return ar;
    }

}
