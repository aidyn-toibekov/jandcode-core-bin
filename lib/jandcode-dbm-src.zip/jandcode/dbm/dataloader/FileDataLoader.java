package jandcode.dbm.dataloader;

import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.vfs2.*;

import java.io.*;

/**
 * Загрузчик данных из файла
 */
public abstract class FileDataLoader extends DataLoader implements IFileDataLoader {

    protected FileObject file;
    protected String text;
    private String charset = "utf-8";

    public void load() throws Exception {
        try {
            super.load();
        } catch (Exception e) {
            if (file != null) {
                throw new XErrorMark(e, file.toString());
            } else {
                throw new XErrorWrap(e);
            }
        }
    }

    //////

    /**
     * Файл, который используется в качестве источника данных. Это строка в формате
     * org.apache.commons.vfs2.FileObject.
     */
    public void setFile(String fileName) {
        file = UtFile.getFileObject(fileName);
    }

    public FileObject getFile() {
        if (file == null) {
            throw new XError("Не указан файл");
        }
        return file;
    }

    /**
     * Возвращает файл VFS, относительно загружаемого файла
     *
     * @param path путь. Абсолютный - возвращается как есть. Относительный - относительно file
     */
    public FileObject getRelativeFile(String path) {
        if (file == null) {
            return UtFile.getFileObject(path);
        }
        try {
            return UtFile.getFileObject(file.getParent(), path);
        } catch (FileSystemException e) {
            throw new XErrorWrap(e);
        }
    }

    //////

    /**
     * Текст. Как альтернатива файлу. Если установлен, то берется текст, а не файл
     */
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    //////

    /**
     * Кодировка файла. По умолчанию utf-8
     */
    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    //////

    /**
     * Открыть поток для файла. если текст назначен, то он открывается как utf-8 поток.
     *
     * @return открытый поток.Нужно закрыть после использования
     */
    protected InputStream openStream() throws Exception {
        if (text != null) {
            return new ByteArrayInputStream(getText().getBytes("utf-8"));
        } else {
            return getFile().getContent().getInputStream();
        }
    }

    /**
     * Открыть Reader для файла. Если текст назначен, то открывается он.
     *
     * @return открытый поток.Нужно закрыть после использования
     */
    protected Reader openReader() throws Exception {
        if (text != null) {
            return new StringReader(getText());
        } else {
            return new InputStreamReader(getFile().getContent().getInputStream(), getCharset());
        }
    }


}
