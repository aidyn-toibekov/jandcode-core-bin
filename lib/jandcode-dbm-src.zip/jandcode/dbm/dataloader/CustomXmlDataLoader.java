package jandcode.dbm.dataloader;

import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.easyxml.*;

import java.util.*;

public abstract class CustomXmlDataLoader extends FileDataLoader {

    protected void loadRowAttrs(DataRecord rec, EasyXml row) {
        String rname = row.getName();

        // ide по имени узла
        if (rname.startsWith("ins")) {
            UtData.setPropIde(rec, UtData.INS);
        } else if (rname.startsWith("upd")) {
            UtData.setPropIde(rec, UtData.UPD);
        } else if (rname.startsWith("del")) {
            UtData.setPropIde(rec, UtData.DEL);
        }

        if (row.hasAttrs()) {
            for (Map.Entry<String, Object> a : row.getAttrs().entrySet()) {
                String propName = UtString.removePrefix(a.getKey(), "prop.");
                if (propName != null) {
                    // атрибут prop.XXX -> присваиваем свойство XXX
                    rec.setProp(propName, a.getValue());
                } else {
                    // имя поля
                    rec.setValue(a.getKey(), a.getValue());
                }
            }
        }
    }

    protected void loadRow(DataRecord rec, EasyXml row) throws Exception {
        loadRowAttrs(rec, row);
    }

}
