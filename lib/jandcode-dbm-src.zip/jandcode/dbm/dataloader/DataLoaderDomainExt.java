package jandcode.dbm.dataloader;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Расширение для домена для работы с dataloader
 * <p/>
 * Домен может иметь дочерние dataloader. Каждый имеет тип dbdata="prod|test"
 * Тип по умолчанию не определен.
 */
public class DataLoaderDomainExt extends DomainExt {

    public DataLoaderDomainExt(Domain domain) {
        super(domain);
    }

    /**
     * Создать все dataloader определенного типа
     *
     * @param dbdata тип
     * @return пустой список, если нет dataloader такого типа
     */
    public List<DataLoader> createDataLoaders(String dbdata) {
        List<DataLoader> res = new ArrayList<DataLoader>();
        Rt x = getRt().findChild("dataloader");
        if (x != null) {
            for (Rt x1 : x.getChilds()) {
                if (dbdata.equals(x1.getValueString("dbdata"))) {
                    DataLoader ldr = (DataLoader) getModel().getObjectFactory().create(x1);
                    ldr.setDomain(getComp());
                    res.add(ldr);
                }
            }
        }
        return res;
    }

    /**
     * Загрузить db-данные определенного типа
     *
     * @param dbdata тип (prod/test)
     * @return список store с данными. Каждый store имеет имя, соответствующее имени
     *         таблицы в базе.
     */
    public ListNamed<DataStore> loadDbData(String dbdata) throws Exception {
        ListNamed<DataStore> res = new ListNamed<DataStore>();
        List<DataLoader> loaders = createDataLoaders(dbdata);
        for (DataLoader ldr : loaders) {
            ldr.load();
            for (DataStore st : ldr.getDatas()) {
                String dn = st.getDomain().getName();
                DataStore curSt = res.find(dn);
                if (curSt == null) {
                    curSt = UtData.createStore(st.getDomain());
                    curSt.setName(st.getDomain().getName());
                    res.add(curSt);
                }
                UtData.copyStore(st, curSt);
            }
        }
        return res;
    }

    /**
     * Загрузить данные из конкретного dataloader
     *
     * @param dataloaderName имя dataloader
     * @return данные из dataloader. Каждый store имеет то имя, которое ему даст dataloader.
     *         Первый store в списке обычно имеет имя default
     */
    public ListNamed<DataStore> loadDataLoader(String dataloaderName) throws Exception {
        Rt x = getRt().getChild("dataloader/" + dataloaderName);
        DataLoader ldr = (DataLoader) getModel().getObjectFactory().create(x);
        ldr.setDomain(getComp());
        ldr.load();
        return ldr.getDatas();
    }

}
