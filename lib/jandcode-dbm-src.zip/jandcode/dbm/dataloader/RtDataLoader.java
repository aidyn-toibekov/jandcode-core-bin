package jandcode.dbm.dataloader;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

/**
 * Загрузчик-враппер. В атрибуте file указываем файл, в котором лежит rt.
 * Эта rt загружается в контекте rt-модели, из него выбирается dataloader с именем default
 * и используется как реальный.
 */
public class RtDataLoader extends DataLoader implements IFileDataLoader {

    DataLoader dataLoader;

    public DataLoader getDataLoader() {
        return dataLoader;
    }

    public void setDataLoader(DataLoader dataLoader) {
        this.dataLoader = dataLoader;
    }

    public void setFile(String fileName) {
        // определение заполнителя по месту
        Rt rt = getModel().getRt().createRt("root");
        try {
            rt.load().fromFileObject(fileName);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }

        Rt z = rt.findChild("dataloader/default");
        if (z == null) {
            throw new XError("В файле [{0}] нет узла [dataloader/default]", fileName);
        }
        dataLoader = (DataLoader) getModel().getObjectFactory().create(z);
    }

    ////// wrap

    public void setDomain(String name, Domain domain) {
        dataLoader.setDomain(name, domain);
    }

    public DataStore getData(String name) {
        return dataLoader.getData(name);
    }

    public ListNamed<DataStore> getDatas() {
        return dataLoader.getDatas();
    }

    public boolean hasDatas() {
        return dataLoader.hasDatas();
    }

    public void load() throws Exception {
        dataLoader.load();
    }

    protected void onLoad() throws Exception {
        throw new XError("unsupported");
    }

}
