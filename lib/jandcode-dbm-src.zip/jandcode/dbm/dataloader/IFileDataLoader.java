package jandcode.dbm.dataloader;

/**
 * dataloader который берет информацию из файла
 */
public interface IFileDataLoader {

    void setFile(String file);

}
