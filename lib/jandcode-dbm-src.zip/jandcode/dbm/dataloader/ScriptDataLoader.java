package jandcode.dbm.dataloader;

public class ScriptDataLoader extends DataLoader {

    protected void onLoad() throws Exception {
    }

}
