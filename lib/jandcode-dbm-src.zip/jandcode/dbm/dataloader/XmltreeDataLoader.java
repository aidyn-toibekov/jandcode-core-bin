package jandcode.dbm.dataloader;

import jandcode.dbm.data.*;
import jandcode.utils.easyxml.*;

import java.io.*;

/**
 * Заполнение таблицы из xml дерева.
 * Автоматически генерируются атрибуты idField и parentField
 */
public class XmltreeDataLoader extends CustomXmlDataLoader {

    private String idField = "id";
    private String parentField = "parent";

    private int curId;

    public String getIdField() {
        return idField;
    }

    public void setIdField(String idField) {
        this.idField = idField;
    }

    public String getParentField() {
        return parentField;
    }

    public void setParentField(String parentField) {
        this.parentField = parentField;
    }

    protected void onLoad() throws Exception {
        InputStream stm = openStream();
        try {
            EasyXml data = new EasyXml();
            data.load().fromStream(stm);

            curId = 0;

            addLevel(data, curId);

        } finally {
            stm.close();
        }
    }

    private void addLevel(EasyXml data, int parentId) throws Exception {
        for (EasyXml row : data) {
            DataRecord rec = getData().add();

            loadRow(rec, row);

            curId++;
            rec.setValue(getIdField(), curId);
            if (parentId != 0) {
                rec.setValue(getParentField(), parentId);
            }

            addLevel(row, curId);
        }
    }

}
