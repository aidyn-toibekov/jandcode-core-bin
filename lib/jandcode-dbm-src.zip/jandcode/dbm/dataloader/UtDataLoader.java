package jandcode.dbm.dataloader;

import jandcode.utils.*;

/**
 * Утилиты для dataloader
 */
public class UtDataLoader {

    /**
     * Извлечение имени таблицы из имен файла: первое слово до '-' или до '.'.
     */
    public static String filenameToDomainName(String filename) {
        String fn = UtFile.filename(filename);
        int a = fn.indexOf('-');
        int b = fn.indexOf('.');
        if (a == -1) {
            a = b;
        } else {
            if (b < a && b != -1) {
                a = b;
            }
        }
        return fn.substring(0, a);
    }

    /**
     * По имени файла возвращает имя dataloader (расширение файла)
     *
     * @param filename имя файла
     * @return имя dataloader
     */
    public static String filenameToDataloaderName(String filename) {
        return UtFile.ext(filename);
    }

}
