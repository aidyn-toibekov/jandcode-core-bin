package jandcode.dbm;

import jandcode.app.*;

import java.util.*;

/**
 * Список доменов с расширенной функциональностью
 */
public class ListDomain extends ListComp<Domain> {

    /**
     * Информация о ссылке
     */
    public class RefInfo {

        private Domain src;
        private Domain dest;
        private Field ref;

        /**
         * Откуда ссылка
         */
        public Domain getSrc() {
            return src;
        }

        /**
         * Куда ссылка
         */
        public Domain getDest() {
            return dest;
        }

        /**
         * Через какое поле
         */
        public Field getRef() {
            return ref;
        }


    }

    public ListDomain() {
        setNotFoundMessage("Домен [{0}] не найден");
    }

    /**
     * Получить все ссылки на указанный домен (в рамках этого списка)
     *
     * @param domainName имя домена
     * @return список ссылок, кто на домен ссылается
     */
    public List<RefInfo> getRefsTo(String domainName) {
        List<RefInfo> res = new ArrayList<RefInfo>();
        Domain dest = find(domainName);
        if (dest == null) {
            return res;
        }
        for (Domain domain : this) {
            for (Field field : domain.getFields()) {
                if (field.hasRef() && field.getRefName().equalsIgnoreCase(domainName)) {
                    RefInfo z = new RefInfo();
                    z.src = domain;
                    z.dest = dest;
                    z.ref = field;
                    res.add(z);
                }
            }
        }
        return res;
    }

    /**
     * Получить все ссылки из указанного домена (в рамках этого списка)
     *
     * @param domainName имя домена
     * @return список ссылок, кто на домен ссылается
     */
    public List<RefInfo> getRefsFrom(String domainName) {
        List<RefInfo> res = new ArrayList<RefInfo>();
        Domain src = find(domainName);
        if (src == null) {
            return res;
        }
        for (Field field : src.getFields()) {
            if (field.hasRef()) {
                Domain dest = find(field.getRefName());
                if (dest == null) {
                    continue;
                }
                RefInfo z = new RefInfo();
                z.src = src;
                z.dest = dest;
                z.ref = field;
                res.add(z);
            }
        }
        return res;
    }


}
