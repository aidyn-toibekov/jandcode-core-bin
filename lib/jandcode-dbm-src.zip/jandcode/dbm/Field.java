package jandcode.dbm;

import jandcode.app.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

/**
 * Метаописание поля.
 */
public class Field extends CompRt implements IModelLink {

    protected String title;
    protected String titleShort;
    protected int size;
    protected int dataType = DataType.OBJECT;
    protected String dbDataType = "object";
    protected boolean calc;
    protected String dictName;
    protected String refName;
    protected int index;
    protected boolean req;
    protected boolean notNull;


    protected void onClone(Comp r) {
        super.onClone(r);
        Field f = (Field) r;
        //
        f.title = title;
        f.titleShort = titleShort;
        f.size = size;
        f.dataType = dataType;
        f.dbDataType = dbDataType;
        f.calc = calc;
        f.dictName = dictName;
        f.refName = refName;
        f.req = req;
        f.notNull = notNull;
    }

    /**
     * Поле пользуется тем rt, который ей дал домен
     */
    protected boolean isUseCloneRt() {
        return false;
    }

    protected void checkFrozen() {
        if (_owner != null) {
            getOwner().checkFrozen();
        }
    }

    /**
     * Домен-владелец.
     */
    public Domain getOwner() {
        return (Domain) super.getOwner();
    }

    public Model getModel() {
        Domain own = getOwner();
        if (own == null) {
            return null;
        }
        return own.getModel();
    }

    //////

    /**
     * Заголовок
     */
    public String getTitle() {
        return title == null ? "" : title;
    }

    public void setTitle(String title) {
        checkFrozen();
        this.title = title;
    }

    //

    /**
     * Краткий заголовок
     */
    public String getTitleShort() {
        return titleShort == null ? getTitle() : titleShort;
    }

    public void setTitleShort(String titleShort) {
        checkFrozen();
        this.titleShort = titleShort;
    }

    //

    /**
     * Размер для строковых полей
     */
    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        checkFrozen();
        this.size = size;
    }

    //

    /**
     * Тип данных.
     *
     * @see DataType
     */
    public int getDataType() {
        return dataType;
    }

    public void setDataType(int dataType) {
        checkFrozen();
        this.dataType = dataType;
    }

    public void setDataTypeName(String dataType) {
        checkFrozen();
        this.dataType = DataType.nameToDataType(dataType);
    }

    public String getDataTypeName() {
        return DataType.dataTypeToName(dataType);
    }

    //

    /**
     * Тип данных для базы данных
     */
    public String getDbDataType() {
        return dbDataType;
    }

    public void setDbDataType(String dbDataType) {
        checkFrozen();
        this.dbDataType = dbDataType;
    }

    //

    /**
     * Признак вычисляемого поля
     */
    public boolean isCalc() {
        return calc;
    }

    public void setCalc(boolean calc) {
        checkFrozen();
        this.calc = calc;
    }

    ////// dict

    /**
     * Установить имя используемого словаря.
     */
    public void setDictName(String dictName) {
        checkFrozen();
        this.dictName = dictName;
        if (UtString.empty(this.dictName)) {
            this.dictName = null;
        }
    }

    public String getDictName() {
        return dictName == null ? "" : dictName;
    }

    /**
     * Проверить, что поле связанно со словарем
     */
    public boolean hasDict() {
        return dictName != null;
    }

    ////// ref

    /**
     * Установить имя домена, на который ссылается поле
     */
    public void setRefName(String domainName) {
        checkFrozen();
        refName = domainName;
        if (UtString.empty(refName)) {
            refName = null;
        }
    }

    public String getRefName() {
        return refName == null ? "" : refName;
    }

    /**
     * Проверить, что поле ссылается на домен
     */
    public boolean hasRef() {
        return refName != null;
    }


    //////

    /**
     * Признак обязательного поля (значение не может быть пустым (например 0 недопустим))
     */
    public boolean isReq() {
        return req;
    }

    public void setReq(boolean v) {
        checkFrozen();
        req = v;
    }

    /**
     * Признак обязательного не null значения поля (например 0 допустим, null - нет)
     */
    public boolean isNotNull() {
        return notNull;
    }

    public void setNotNull(boolean v) {
        checkFrozen();
        notNull = v;
    }

    //////

    public int getIndex() {
        return index;
    }

    ////// record value

    public Object getRecordValue(DataRecord rec) {
        return rec.getInternalValue(this);
    }

    public void setRecordValue(DataRecord rec, Object value) {
        rec.setInternalValue(this, value);
    }

    //////

    /**
     * Метод добавляет указанное поле в домен
     *
     * @param f добавляемое поле
     */
    protected void doAddField(Field f) {
        getOwner().doAddField(f);
    }

    /**
     * Метод вызывается доменом, когда тот добавляет это поле себе.
     * По умолчанию оно просто добавляется через метод doAddField
     */
    protected void onAddField() {
        doAddField(this);
    }

}
