package jandcode.dbm;

/**
 * Предок для расширений домена.
 */
public abstract class DomainExt extends ModelMemberExt {

    public DomainExt(Domain domain) {
        super(domain);
    }

    public Domain getComp() {
        return (Domain) comp;
    }

}
