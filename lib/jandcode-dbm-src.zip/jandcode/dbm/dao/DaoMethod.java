package jandcode.dbm.dao;

import java.lang.annotation.*;

/**
 * Метка для метода dao. Все остальные методы, не помеченные этой аннотацией,
 * являются просто методами класса
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface DaoMethod {
}
