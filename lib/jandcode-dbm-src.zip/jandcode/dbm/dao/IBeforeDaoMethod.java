package jandcode.dbm.dao;

/**
 * Интерфейс для Dao. Определяет метод, который будет вызван перед вызовом dao-метода
 */
public interface IBeforeDaoMethod {

    /**
     * Метод вызывается перед вызовом dao-метода
     *
     * @param methodName что за метод
     * @param args       аргументы метода. В принципе можно можифицировать.
     * @param level      уровень вызова метода. Если dao-метод вызывается из другого dao-метода,
     *                   то уровень будет больше 1
     */
    void beforeDaoMethod(String methodName, Object[] args, int level) throws Exception;

}
