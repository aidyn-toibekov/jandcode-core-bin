package jandcode.dbm.dao;

/**
 * Интерфейс для Dao. Определяет метод, который будет вызван при возникновении ошибки
 * в dao-методе
 */
public interface IErrorDaoMethod {

    /**
     * Метод вызывается при возникновении ошибки в dao-методе.
     * Если в этом методе сгенерить Exception, то она заменит оригинальную.
     *
     * @param methodName что за метод
     * @param args       аргументы метода
     * @param e          что за ошибка
     * @param level      уровень вызова метода. Если dao-метод вызывается из другого dao-метода,
     */
    void errorDaoMethod(String methodName, Object[] args, Exception e, int level) throws Exception;

}
