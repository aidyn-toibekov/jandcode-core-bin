package jandcode.dbm.dao.impl;

import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.db.*;
import jandcode.utils.error.*;
import jandcode.utils.test.*;
import javassist.util.proxy.*;
import org.apache.commons.logging.*;

import java.lang.reflect.*;
import java.text.*;

//todo сделать параметр для метода - метод не требует базы данных! @DaoMethod(db=false)

/**
 * Исполнитель dao-метода
 */
public class DaoInvoker implements MethodHandler {

    protected static Log log = LogFactory.getLog(DaoService.class);

    int level = 0;
    StopWatch timer;
    Model model;

    public DaoInvoker(Model model) {
        this.model = model;
    }

    public Object invoke(Object daoInst, Method thisMethod, Method proceed, Object[] args) throws Throwable {
        Object res = null;
        DaoFilterHolder filters = model.getDaoService().getDaoFilters();
        boolean filtersNeedCall = !filters.isEmpty();
        String methodName = thisMethod.getName();
        try {
            push(daoInst, thisMethod);
            //
            if (filtersNeedCall) {
                filters.beforeDaoMethod((Dao) daoInst, methodName, args, level);
            }
            if (daoInst instanceof IBeforeDaoMethod) {
                ((IBeforeDaoMethod) daoInst).beforeDaoMethod(methodName, args, level);
            }
            //
            res = proceed.invoke(daoInst, args);
            //
            Object[] res1 = new Object[]{res};
            if (filtersNeedCall) {
                filters.afterDaoMethod((Dao) daoInst, methodName, args, res1, level);
            }
            if (daoInst instanceof IAfterDaoMethod) {
                ((IAfterDaoMethod) daoInst).afterDaoMethod(methodName, args, res1, level);
            }
            res = res1[0];
            //
            pop(daoInst, thisMethod);
        } catch (Exception e) {
            //
            if (filtersNeedCall) {
                e = filters.errorDaoMethod((Dao) daoInst, methodName, args, e, level);
            }
            if (daoInst instanceof IErrorDaoMethod) {
                try {
                    ((IErrorDaoMethod) daoInst).errorDaoMethod(methodName, args, e, level);
                } catch (Exception e1) {
                    // если была ошибка - заменяем ее
                    e = e1;
                }
            }
            //
            error(e);
            if (model.getApp().isDebug()) {
                throw new XErrorMark(e, MessageFormat.format("dao: {0} ({1})", methodName, daoInst.getClass().getSuperclass().getName()));
            } else {
                throw e;
            }
        }
        if (level == 0) {
            // для самого внешнего вызова - разрешаем словари
            model.getDictService().resolveDicts(res);
        }
        return res;

    }

    public void push(Object dao, Method method) throws Exception {
        level++;
        //
        if (log.isInfoEnabled()) {
            log.info(MessageFormat.format("start exec dao: {0} ({1})", method.getName(), dao.getClass().getSuperclass().getName()));
            if (level == 1) {
                timer = new StopWatch(false, false);
                timer.start();
            }
        }
        //
        if (level == 1) {
            onStart();
        }
    }

    public void pop(Object dao, Method method) throws Exception {
        // проверяем ошибки валидации после каждого метода!
        model.getValidateService().getErrors().checkErrors();
        //
        if (level > 0) {
            level--;
            //
            if (log.isInfoEnabled()) {
                log.info(MessageFormat.format("stop exec dao: {0} ({1})", method.getName(), dao.getClass().getSuperclass().getName()));
                if (level == 0 && timer != null) {
                    timer.stop();
                    log.info(timer.getLastMessage());
                }
            }
            //
            if (level == 0) {
                onStop();
            }
        }
    }

    public void error(Exception e) throws Exception {
        level = 0;
        //
        Db db = model.getDb();
        if (db.isConnected()) {
            db.rollback();
            db.disconnect();
        }
    }

    public void onStart() throws Exception {
        model.getValidateService().getErrors().clear();
        model.getDb().connect();
        model.getDb().startTran();
    }

    public void onStop() throws Exception {
        model.getDb().commit();
        model.getDb().disconnect();
    }

}
