package jandcode.dbm.dao.impl;

import jandcode.utils.*;

import java.lang.reflect.*;

/**
 * Метод с реализацией INamed
 */
public class DaoMethodInfo implements INamed {

    private Method method;

    public DaoMethodInfo(Method method) {
        this.method = method;
    }

    public Method getMethod() {
        return method;
    }

    public void setMethod(Method method) {
        this.method = method;
    }

    public String getName() {
        return method.getName();
    }

}
