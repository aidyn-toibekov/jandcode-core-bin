package jandcode.dbm.dao.impl;

import jandcode.dbm.dao.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import javassist.util.proxy.*;

import java.lang.reflect.*;

/**
 * Информация о dao-классе.
 * Содержит выявленные dao-методы и proxy класс для реального dao-класса.
 */
public class DaoClassInfo implements MethodFilter {

    Class clsReal;
    Class clsProxy;
    ListNamed<DaoMethodInfo> methods = new ListNamed<DaoMethodInfo>();

    public DaoClassInfo(Class clsReal) {
        this.clsReal = clsReal;
        grabMethods(clsReal, this.methods);
        //
        ProxyFactory f = new ProxyFactory();
        f.setSuperclass(this.clsReal);
        f.setFilter(this);
        clsProxy = f.createClass();
    }

    protected void grabMethods(Class cur, ListNamed<DaoMethodInfo> mm) {
        if (cur == null || cur == Dao.class || cur == Object.class) {
            return;
        }

        grabMethods(cur.getSuperclass(), mm);

        Method[] mlst = cur.getDeclaredMethods();

        for (Method m : mlst) {
            int md = m.getModifiers();
            if (!Modifier.isPublic(md)) {
                continue;
            }

            DaoMethod an = m.getAnnotation(DaoMethod.class);
            if (an == null) {
                continue;
            }

            DaoMethodInfo dm = mm.find(m.getName());
            if (dm == null) {
                dm = new DaoMethodInfo(m);
                mm.add(dm);
            } else {
                dm.setMethod(m);  // кто последний был объявлен - тот и прав
            }

        }
    }

    /**
     * для javassist: обрабатывать ли этот метод через proxy
     */
    public boolean isHandled(Method m) {
        return methods.find(m.getName()) != null;
    }

    /**
     * Реальный dao-класс
     */
    public Class getClsReal() {
        return clsReal;
    }

    /**
     * javassist proxy класс
     */
    public Class getClsProxy() {
        return clsProxy;
    }

    /**
     * dao-методы реального класса
     */
    public ListNamed<DaoMethodInfo> getMethods() {
        return methods;
    }

    public Method getMethod(String name) {
        DaoMethodInfo mi = getMethods().find(name);
        if (mi == null) {
            throw new XError("Не найден dao-метод {0} у dao {1}", name, getClsReal().getName());
        }
        return mi.getMethod();
    }

}
