package jandcode.dbm.dao;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.dao.impl.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import javassist.util.proxy.*;

import java.lang.reflect.*;
import java.util.*;

public class DaoService extends ModelMember implements IActivate, IReloadAppRt {

    protected HashMap<Class, DaoClassInfo> daoClasses = new HashMap<Class, DaoClassInfo>();
    protected ThreadLocalDaoInvoker daoInvokers = new ThreadLocalDaoInvoker();
    protected ListNamed<DaoInfo> daos = new ListNamed<DaoInfo>();
    protected DaoFilterHolder daoFilters;

    //////

    class ThreadLocalDaoInvoker extends ThreadLocal<DaoInvoker> {
        protected DaoInvoker initialValue() {
            return new DaoInvoker(getModel());
        }
    }

    /**
     * Информация о поименнованном dao
     */
    class DaoInfo extends Named {
        Domain domain;
        Rt rt;
        Class cls;

        DaoInfo(Domain domain, Rt rt) {
            this.domain = domain;
            this.rt = rt;
            if (domain != null) {
                setName(domain.getName() + "/" + rt.getName());
            } else {
                setName(rt.getName());
            }
            String clsName = rt.getValueString("class");
            if (UtString.empty(clsName)) {
                throw new XError("Для dao [{0}] не указан класс", rt.getPath());
            }
            this.cls = getModel().getObjectFactory().getClass(clsName);
        }

        DaoInfo(Class cls) {
            this.cls = cls;
            setName(cls.getName());
        }

        public Rt getRt() {
            return rt;
        }

        public Domain getDomain() {
            return domain;
        }

        public Class getCls() {
            return cls;
        }

        public DaoClassInfo getDaoClassInfo() {
            return DaoService.this.getDaoClassInfo(cls);
        }

    }

    //////

    protected DaoClassInfo getDaoClassInfo(Class cls) {
        if (ProxyObject.class.isAssignableFrom(cls)) {
            cls = cls.getSuperclass();
        }
        DaoClassInfo res = daoClasses.get(cls);
        if (res == null) {
            synchronized (this) {
                res = daoClasses.get(cls);
                if (res == null) {
                    res = new DaoClassInfo(cls);
                    daoClasses.put(cls, res);
                }
            }
        }
        return res;
    }

    protected DaoInfo getDaoInfo(String daoname) {
        DaoInfo di = daos.find(daoname);
        if (di == null) {
            if (!UtString.empty(daoname)) {
                // не найдено. может класс?
                Class cls = null;
                try {
                    cls = getModel().getObjectFactory().getClass(daoname);
                } catch (Exception e) {
                }
                if (cls != null) {
                    synchronized (this) {
                        di = daos.find(daoname);
                        if (di == null) {
                            di = new DaoInfo(cls);
                            daos.add(di);
                        }
                    }
                }
            }
            if (di == null) {
                throw new XError("Не найден dao {0}", daoname);
            }
        }
        return di;
    }

    /**
     * Собираем все dao из rt
     */
    protected ListNamed<DaoInfo> grabRtDaos() {
        ListNamed<DaoInfo> res = new ListNamed<DaoInfo>();
        // из доменов
        for (Domain domain : getModel().getDomains()) {
            if (!domain.hasTag("db") && !domain.hasTag("dao")) {
                continue; // такие пропускаем
            }
            Rt rtDaos = domain.getRt().findChild("dao");
            if (rtDaos == null) {
                continue; // dao нет у домена
            }
            // собираем
            for (Rt rtDao : rtDaos.getChilds()) {
                DaoInfo di = new DaoInfo(domain, rtDao);
                res.add(di);
            }
        }
        // свободные
        Rt z = getModel().getRt().findChild("dao");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                DaoInfo di = new DaoInfo(null, z1);
                res.add(di);
            }
        }
        return res;
    }

    /**
     * Получить имя dao по 2-м параметрам
     *
     * @param p1 "domain" или "domain/dao" или "class" или "daoname"
     * @param p2 "method" или "dao/method"
     * @return имя dao или ошибка
     */
    protected String extractDaoName(String p1, String p2) {
        if (UtString.empty(p2)) {
            return p1;
        }
        int a = p2.indexOf('/');
        if (a == -1) {
            return p1;
        }
        return p1 + "/" + p2.substring(0, a);
    }

    /**
     * Получить имя dao метода по 2-м параметрам
     *
     * @param p2 "method" или "dao/method"
     * @return имя метода или ошибка
     */
    protected String extractDaoMethodName(String p2) {
        if (UtString.empty(p2)) {
            throw new XError("Имя dao-метода не указано");
        }
        int a = p2.indexOf('/');
        if (a == -1) {
            return p2;
        }
        return p2.substring(a + 1);
    }

    //////

    public void activate() throws Exception {
        daos = grabRtDaos();
    }

    public void reloadAppRt() {
        daoClasses.clear();
        daos = grabRtDaos();
    }

    //////

    /**
     * Создать экземпляр dao по классу
     */
    public <A extends Dao> A createDao(Class<A> cls) {
        DaoClassInfo ci = getDaoClassInfo(cls);
        Dao dao = (Dao) getModel().getObjectFactory().create(ci.getClsProxy());
        dao.setName(cls.getName());
        ((ProxyObject) dao).setHandler(daoInvokers.get());
        return (A) dao;
    }

    /**
     * Создать домен по имени. Имя в формате "Domain/dao"
     */
    public Dao createDao(String name) {
        DaoInfo di = getDaoInfo(name);
        Dao dao = createDao(di.getCls());
        dao.setName(di.getName());
        if (di.getDomain() != null && !dao.hasDomain()) {
            dao.setDomain(di.getDomain().getName());
        }
        if (di.getRt() != null) {
            dao.setRt(di.getRt());
        }
        return dao;
    }


    public Object daoinvoke(String daoName, String methodName, Object... args) throws Exception {
        return daoinvoke(null, daoName, methodName, args);
    }

    public Object daoinvoke(Map contextParams, String daoName, String methodName, Object... args) throws Exception {
        String dn = extractDaoName(daoName, methodName);
        String mn = extractDaoMethodName(methodName);
        Dao dao = createDao(dn);
        if (contextParams != null && contextParams.size() > 0) {
            dao.getContextParams().putAll(contextParams);
        }
        DaoClassInfo ci = getDaoClassInfo(dao.getClass());
        Method m = ci.getMethod(mn);
        return m.invoke(dao, args);
    }

    public Object daoinvoke(Dao dao, String methodName, Object... args) throws Exception {
        DaoClassInfo ci = getDaoClassInfo(dao.getClass());
        Method m = ci.getMethod(methodName);
        return m.invoke(dao, args);
    }

    public Method getDaoMethod(String daoName, String methodName) {
        String dn = extractDaoName(daoName, methodName);
        String mn = extractDaoMethodName(methodName);
        DaoInfo di = getDaoInfo(dn);
        return di.getDaoClassInfo().getMethod(mn);
    }

    //////

    public DaoFilterHolder getDaoFilters() {
        if (daoFilters == null) {
            synchronized (this) {
                if (daoFilters == null) {
                    daoFilters = new DaoFilterHolder(getModel());
                }
            }
        }
        return daoFilters;
    }

}
