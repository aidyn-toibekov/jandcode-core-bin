package jandcode.dbm.dao;

import jandcode.dbm.data.*;
import jandcode.utils.error.*;

/**
 * Простой dao для таблиц типа "справочник".
 * Используется как прототип, но можно и напрямую использовать.
 */
public class SimpleIdeDao extends CustomDao {

    protected String getLoadSql(boolean rec) {
        return ut.subst("" +
                //
                "select * from ${@table} ${part}",
                //
                "part", rec ?
                        "where id=:id" :
                        "order by id");
    }

    //////

    @DaoMethod
    public DataStore list() throws Exception {
        DataStore t = ut.createStore();
        ut.loadSql(t, getLoadSql(false));
        return t;
    }

    @DaoMethod
    public DataRecord rec(long id) throws Exception {
        DataStore t = ut.createStore();
        ut.loadSql(t, getLoadSql(true), id);
        if (t.size() == 0) {
            throw new XError("Запись #{0} не найдена", id);
        }
        return t.getCurRec();
    }

    //////

    protected void onBeforeSave(DataRecord t, boolean newRec) throws Exception {
    }

    protected void onValidateSave(DataRecord t, boolean newRec) throws Exception {
        ut.validateRecord(t, newRec ? "ins" : "upd");
    }

    protected void onValidateDel(long id) throws Exception {
        DataStore r = ut.createStore();
        r.getCurRec().setValue("id", id);
        ut.validate("delref", r.getCurRec(), null, "del");
    }

    protected long onIns(DataRecord t) throws Exception {
        return ut.insertRec(ut.getTableName(), t);
    }

    protected void onUpd(DataRecord t) throws Exception {
        ut.updateRec(ut.getTableName(), t);
    }

    protected void onDel(long id) throws Exception {
        ut.deleteRec(ut.getTableName(), id);
    }

    //////

    @DaoMethod
    public long ins(DataStore data) throws Exception {
        DataStore t = ut.createStore(data);
        //
        onBeforeSave(t.getCurRec(), true);
        onValidateSave(t.getCurRec(), true);
        ut.checkErrors();
        //
        return onIns(t.getCurRec());
    }

    @DaoMethod
    public void upd(DataStore data) throws Exception {
        DataStore t = ut.createStore(data);
        //
        onBeforeSave(t.getCurRec(), false);
        onValidateSave(t.getCurRec(), false);
        ut.checkErrors();
        //
        onUpd(t.getCurRec());
    }

    @DaoMethod
    public void del(long id) throws Exception {
        //
        onValidateDel(id);
        ut.checkErrors();
        //
        onDel(id);
    }

}
