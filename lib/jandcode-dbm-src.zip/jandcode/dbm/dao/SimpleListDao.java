package jandcode.dbm.dao;

import jandcode.dbm.data.*;
import jandcode.utils.error.*;

/**
 * Простой dao для получения таблицы польностью и по записно.
 * Используется как прототип, но можно и напрямую использовать.
 */
public class SimpleListDao extends CustomDao {

    protected String getLoadSql(boolean rec) {
        return ut.subst("" +
                //
                "select * from ${@table} ${part}",
                //
                "part", rec ?
                        "where id=:id" :
                        "order by id");
    }

    //////

    @DaoMethod
    public DataStore list() throws Exception {
        DataStore t = ut.createStore();
        ut.loadSql(t, getLoadSql(false));
        return t;
    }

    @DaoMethod
    public DataStore rec(long id) throws Exception {
        DataStore t = ut.createStore();
        ut.loadSql(t, getLoadSql(true), id);
        if (t.size() == 0) {
            throw new XError("Запись #{0} не найдена", id);
        }
        return t;
    }

}
