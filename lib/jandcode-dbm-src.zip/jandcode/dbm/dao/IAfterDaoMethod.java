package jandcode.dbm.dao;

/**
 * Интерфейс для Dao. Определяет метод, который будет вызван после того, как отработает
 * dao-метод
 */
public interface IAfterDaoMethod {

    /**
     * Метод вызывается после вызова dao-метода. Если при вызове dao-метода произошла
     * ошибка, то этот метод не вызывается.
     *
     * @param methodName что за метод
     * @param args       аргументы метода
     * @param result     результат работы метода. Массив из одного значения.
     * @param level      уровень вызова метода. Если dao-метод вызывается из другого dao-метода,
     *                   то уровень будет больше 1
     */
    void afterDaoMethod(String methodName, Object[] args, Object[] result, int level) throws Exception;

}
