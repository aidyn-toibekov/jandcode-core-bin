package jandcode.dbm.dao;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.dbm.sqlfilter.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Утилиты для базы данных. В основном предназначен для использования внутри dao,
 * но может использоватся и самостоятельно.
 * <p/>
 * Внутри доступны:
 * getDomain() - домен. Либо явно установлен, либо определяется по getComp()
 * getTableName() - имя базовой таблицы. Либо явно установлен, либо определяется по getDomain()
 */
public class DaoUtils extends DbUtils {

    protected String tableName;
    protected Domain domain;

    /**
     * Создание утилит
     *
     * @param comp для кого. Может быть Db, Dao, Domain, Model
     */
    public DaoUtils(Comp comp) {
        super(comp);
    }

    //////

    public Dao getDao() {
        if (comp instanceof Dao) {
            return (Dao) comp;
        }
        throw new XError("DaoUtils not binded to Dao");
    }

    //////

    /**
     * Базовый домен по умолчанию для утилит.
     */
    public Domain getDomain() {
        if (domain == null) {
            if (comp instanceof IDomainLink) {
                domain = ((IDomainLink) comp).getDomain();
            }
            if (domain == null) {
                throw new XError("Домен не назначен");
            }
        }
        return domain;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
    }

    //////

    /**
     * "Базовая таблица". Некое имя таблицы, с которой связан этот экземпляр
     * утилит. Если явно не задано и связанный компонент IDomainLink, то
     * возвращается имя getTableName() из домена.
     */
    public String getTableName() {
        if (tableName == null) {
            tableName = getDomain().getTableName();
            if (UtString.empty(tableName)) {
                throw new XError("Имя таблицы не назначено");
            }
        }
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    ////// domain

    /**
     * Создать новый домен структуры getDomain()
     */
    public Domain createDomain() {
        return (Domain) getDomain().clone();
    }

    ////// store

    /**
     * Создать store структуры getDomain()
     */
    public DataStore createStore() {
        return createStore(getDomain());
    }

    /**
     * Создать store структуры getDomain() и загрузить в нее данные из data
     */
    public DataStore createStore(DataStore data) {
        return createStore(getDomain(), data);
    }

    /**
     * Создать store структуры getDomain() и загрузить в нее данные из data
     */
    public DataStore createStore(Map data) {
        return createStore(getDomain(), data);
    }

    /**
     * Создать store структуры getDomain() и загрузить в нее запись из data
     */
    public DataStore createStore(DataRecord data) {
        return createStore(getDomain(), data);
    }

    ////// create data record

    /**
     * Создать запись структуры getDomain()
     */
    public DataRecord createRecord() {
        return createRecord(getDomain());
    }

    /**
     * Создать запись структуры getDomain() и загрузить в нее данные из data
     */
    public DataRecord createRecord(DataRecord data) {
        return createRecord(getDomain(), data);
    }

    /**
     * Создать запись структуры getDomain() и загрузить в нее данные из data
     */
    public DataRecord createRecord(Map data) {
        return createRecord(getDomain(), data);
    }

    ////// subst

    /**
     * Подстановки
     * <p/>
     * Для ${@table} подставляется {@link DaoUtils#getTableName()}
     */
    public String onSubstVar(String v) {
        if ("table".equals(v)) {
            return getTableName();
        } else {
            return super.onSubstVar(v);
        }
    }

    ////// sqlfilter for dao

    /**
     * Создает фильтр. Параметры params накладываются на getDao().getContextParams()
     * и полученный params исползуется для создания фильтра.
     *
     * @param domainName имя связанного с фильтром домена
     * @param params     данные для параметров фильтра
     */
    public SqlFilter createSqlFilter(String domainName, Map params) {
        Map p1 = new HashMap();
        p1.putAll(getDao().getContextParams());
        if (params != null) {
            p1.putAll(params);
        }
        return super.createSqlFilter(domainName, p1);
    }

    ////// contextParams

    /**
     * Контекстные параметры dao. см: {@link Dao#getContextParams()}
     */
    public IVariantMap getContextParams() {
        return getDao().getContextParams();
    }

    /**
     * Возвращает контекстные параметры dao, на которые накладывается data.
     * Оригинал контекстных параметров dao не изменяется.
     *
     * @param data данные, для наложения на контекстные параметры
     * @return новый экземпляр map
     */
    public IVariantMap getContextParams(Map data) {
        VariantMap p1 = new VariantMap();
        p1.putAll(getContextParams());
        if (data != null) {
            p1.putAll(data);
        }
        return p1;
    }

}
