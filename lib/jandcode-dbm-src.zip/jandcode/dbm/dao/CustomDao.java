package jandcode.dbm.dao;

/**
 * Предок с утилитами
 */
public abstract class CustomDao extends Dao {

    protected DaoUtils ut = new DaoUtils(this);

}
