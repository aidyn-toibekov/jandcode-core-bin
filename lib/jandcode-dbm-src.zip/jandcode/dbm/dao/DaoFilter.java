package jandcode.dbm.dao;

import jandcode.dbm.*;

//todo возможно что result должен быть и в before
//todo возможно флаг - все закончено и делать более ниченго не нужно

/**
 * Фильтр для обработки dao.
 */
public class DaoFilter extends ModelMember {

    protected int index;
    protected int weight = 50;
    protected boolean enabled = true;

    //////

    /**
     * Метод вызывается перед вызовом dao-метода
     *
     * @param daoInst    экземпляр dao, для которого вызывается фильтр
     * @param methodName что за метод
     * @param args       аргументы метода. В принципе можно можифицировать.
     * @param level      уровень вызова метода. Если dao-метод вызывается из другого dao-метода,
     *                   то уровень будет больше 1
     */
    protected void onBeforeDaoMethod(Dao daoInst, String methodName, Object[] args, int level) throws Exception {
    }


    /**
     * Метод вызывается после вызова dao-метода. Если при вызове dao-метода произошла
     * ошибка, то этот метод не вызывается.
     *
     * @param daoInst    экземпляр dao, для которого вызывается фильтр
     * @param methodName что за метод
     * @param args       аргументы метода
     * @param result     результат работы метода. Массив из одного значения.
     * @param level      уровень вызова метода. Если dao-метод вызывается из другого dao-метода,
     *                   то уровень будет больше 1
     */
    protected void onAfterDaoMethod(Dao daoInst, String methodName, Object[] args, Object[] result, int level) throws Exception {
    }

    /**
     * Метод вызывается при возникновении ошибки в dao-методе.
     * Если в этом методе сгенерить Exception, то она заменит оригинальную.
     *
     * @param daoInst    экземпляр dao, для которого вызывается фильтр
     * @param methodName что за метод
     * @param args       аргументы метода
     * @param e          что за ошибка
     * @param level      уровень вызова метода. Если dao-метод вызывается из другого dao-метода,
     */
    protected void onErrorDaoMethod(Dao daoInst, String methodName, Object[] args, Exception e, int level) throws Exception {
    }

    //////

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void beforeDaoMethod(Dao daoInst, String methodName, Object[] args, int level) throws Exception {
        onBeforeDaoMethod(daoInst, methodName, args, level);
    }

    public void afterDaoMethod(Dao daoInst, String methodName, Object[] args, Object[] result, int level) throws Exception {
        onAfterDaoMethod(daoInst, methodName, args, result, level);
    }

    public void errorDaoMethod(Dao daoInst, String methodName, Object[] args, Exception e, int level) throws Exception {
        onErrorDaoMethod(daoInst, methodName, args, e, level);
    }

}
