package jandcode.dbm.dao;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Хранилище для dao-фильтров
 */
public class DaoFilterHolder {

    protected ListNamed<DaoFilter> items = new ListNamed<DaoFilter>();

    class ComparatorDaoFilter implements Comparator<DaoFilter> {
        public int compare(DaoFilter o1, DaoFilter o2) {
            Integer i1 = o1.getWeight();
            Integer i2 = o2.getWeight();
            int n = i1.compareTo(i2);
            if (n == 0) {
                i1 = o1.getIndex();
                i2 = o2.getIndex();
                n = i1.compareTo(i2);
            }
            return n;
        }
    }

    public DaoFilterHolder(Model model) {
        initFromModel(model);
    }

    protected void initFromModel(Model model) {
        Rt z = model.getRt().findChild("daofilter");
        if (z != null) {
            for (Rt rt1 : z.getChilds()) {
                DaoFilter f = (DaoFilter) model.getObjectFactory().create(rt1);
                f.setIndex(items.size());
                if (f.isEnabled()) {
                    items.add(f);
                }
            }
        }
        //
        Collections.sort(items, new ComparatorDaoFilter());
    }

    public boolean isEmpty() {
        return items.size() == 0;
    }

    // вызовы

    public void beforeDaoMethod(Dao daoInst, String methodName, Object[] args, int level) throws Exception {
        if (items.size() == 0) {
            return;
        }
        for (DaoFilter filter : items) {
            filter.beforeDaoMethod(daoInst, methodName, args, level);
        }
    }

    public void afterDaoMethod(Dao daoInst, String methodName, Object[] args, Object[] result, int level) throws Exception {
        if (items.size() == 0) {
            return;
        }
        for (int i = items.size() - 1; i >= 0; i--) {
            DaoFilter filter = items.get(i);
            filter.afterDaoMethod(daoInst, methodName, args, result, level);
        }
    }

    /**
     * Возвращает либо e, либо ошибку, которую нужно сгенерировать вместо оригинальной e
     */
    public Exception errorDaoMethod(Dao daoInst, String methodName, Object[] args, Exception e, int level) throws Exception {
        if (items.size() == 0) {
            return e;
        }
        for (DaoFilter filter : items) {
            try {
                filter.errorDaoMethod(daoInst, methodName, args, e, level);
            } catch (Exception e1) {
                e = e1;
            }
        }
        return e;
    }

}
