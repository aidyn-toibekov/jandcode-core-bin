package jandcode.dbm.dao;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

/**
 * Dao-объект. Средство выполнения каких-либо действий в контексте модели
 * и домена.
 */
public abstract class Dao extends ModelMember implements IDomainLink {

    private Domain _domain;
    private String _domainName;
    private VariantMap contextParams;

    //////

    /**
     * Сменить домен по умолчанию
     */
    public void setDomain(String domainName) {
        this._domain = null;
        this._domainName = domainName;
        if (UtString.empty(this._domainName)) {
            this._domainName = null;
        }
    }

    /**
     * Домен по умолчанию.
     * Если dao создан через домен, то тут ссылка на экземпляр этого домена.
     * Если dao создан через класс, то по умолчанию тут домен 'id'
     */
    public Domain getDomain() {
        if (_domain == null) {
            String dn = _domainName;
            if (dn == null) {
                dn = "id";
            }
            _domain = getModel().createDomain(dn);
        }
        return _domain;
    }

    /**
     * Есть ли явно назначенный домен.
     */
    public boolean hasDomain() {
        return _domain != null || _domainName != null;
    }

    /////

    /**
     * Контекстные параметры dao. Являются частью экземпляра dao.
     * По умолчанию - пусто. Можно присвоить что-то до вызова dao (в случае явного
     * использования экземпляра dao) или в момент вызова (в случае использования
     * daoinvoke). В web-среде при вызове dao через action заполняется параметрами
     * web-запроса.
     * <p/>
     * Позиционируется как некоторый контекст, в рамках которого выполняется dao.
     * Например состояние ui-компонентов, которое позволяет уточнить ожидаемый результат.
     * К примеру - требуемая сортировка для данных гриды. Или узел дерева, для которого
     * нужно получить дочерние. Такие "контекстные" параметры затруднительно передавать
     * в явных параметрах, т.к. их состав и предназначение разнятся от одного компонента
     * к другому.
     */
    public IVariantMap getContextParams() {
        if (contextParams == null) {
            contextParams = new VariantMap();
        }
        return contextParams;
    }

}
