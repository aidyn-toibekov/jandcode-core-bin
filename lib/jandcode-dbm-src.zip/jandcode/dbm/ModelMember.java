package jandcode.dbm;

import jandcode.app.*;

/**
 * Предок для членов модели.
 */
public abstract class ModelMember extends CompRt implements IModelLink, IModelLinkSet {

    private Model model;

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    protected void onClone(Comp r) {
        super.onClone(r);
        ((ModelMember) r).model = model;
    }
}
