package jandcode.dbm;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;
import org.apache.commons.logging.*;

/**
 * Сервис моделей. Хранит все модели приложения.
 */
public class ModelService extends CompRt implements IReloadAppRt, IActivate {

    protected static Log log = LogFactory.getLog(ModelService.class);

    private ListComp<Model> models = new ListComp<Model>();
    private ThreadLocal<IModelProvider> threadModelProviders = new ThreadLocal<IModelProvider>();


    public ModelService() {
        models.setNotFoundMessage("Model [{0}] not found");
    }

    /**
     * Все зарегистрированные модели
     */
    public ListComp<Model> getModels() {
        return models;
    }

    /**
     * Модель по умолчанию. Возвращает модель с именем 'default'
     */
    public Model getModel() {
        return getModel("default");
    }

    /**
     * Модель по имени.
     * Если не установлен провайдер моделей IModelProvider,
     * то возвращает модель по имени из собственного списка зарегистрированных,
     * иначе - делегирует вызов провайдеру моделей.
     */
    public Model getModel(String name) {
        IModelProvider provider = threadModelProviders.get();
        if (provider != null) {
            Model m = provider.getModel(name);
            if (m != null) {
                return m;
            }
        }
        return models.get(name);
    }

    /**
     * Регистрация модели
     *
     * @param name  имя модели
     * @param model модель
     */
    public void registerModel(String name, Model model) {
        if (log.isInfoEnabled()) {
            log.info(String.format("register model [%s], rtpath [%s], class [%s]", name, model.getRt().getPath(), model.getClass().getName()));
        }
        models.add(name, model);
    }

    /**
     * Регистрация из дочерних элементов типа:
     * <имя model="имя-модели"/>
     */
    protected void registerModelFromRt(Rt x) {
        if (x == null) {
            return;
        }
        for (Rt z1 : x.getChilds()) {
            String modelName = z1.getValueString("model");
            if (UtString.empty(modelName)) {
                modelName = z1.getName();
            }
            Rt mrt = getApp().getRt().getChild("model/" + modelName);
            Class mcl = getApp().getObjectFactory().getClass(mrt);
            Model m = (Model) getApp().getObjectFactory().create(mcl);
            m.setName(z1.getName());
            getApp().getObjectFactory().setRt(m, mrt);
            registerModel(z1.getName(), m);
        }
    }

    /**
     * Зарегистрировать все модели из настроек в собственном rt
     */
    public void activate() throws Exception {
        //
        registerModelFromRt(getApp().getRt().findChild("dbm/registermodel"));
        //
        for (Model model : models) {
            model.activate();
        }
        //
    }

    public void reloadAppRt() {
        for (Model model : models) {
            model.reloadAppRt();
        }
    }

    //////

    /**
     * Установить провайдера моделей для текущего потока.
     *
     * @param provider может быть null, в этом случае провайдер для потока сбрасывается
     */
    public void setThreadModelProvider(IModelProvider provider) {
        threadModelProviders.set(provider);
    }

}
