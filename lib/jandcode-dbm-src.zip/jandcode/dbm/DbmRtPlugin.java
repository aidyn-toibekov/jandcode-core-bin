package jandcode.dbm;

import jandcode.dbm.dataloader.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.io.*;
import jandcode.utils.rt.*;
import org.apache.commons.vfs2.*;

import java.util.*;

public class DbmRtPlugin extends RtPluginAdapter {

    public boolean handleSysChild(IRtLoader loader, Rt x, Rt sys) throws Exception {
        if (sys.hasName("x-dbdata")) {
            includeDbData(loader, x, sys);
            return true;
        }
        return false;
    }

    protected void includeDbData(IRtLoader loader, Rt x, Rt sys) {
        String path = sys.getValueString("path");
        if (UtString.empty(path)) {
            throw new XError("Не указан атрибут path");
        }
        String dbdata = sys.getValueString("dbdata");
        if (UtString.empty(dbdata)) {
            // dbdata атрибута нет. Значит каждый подкаталог в path имеет имя dbdata
            DirScannerVfs scanner = new DirScannerVfs();
            scanner.setRootDir(loader.getAbsPath(path));
            scanner.setRecursive(false);
            scanner.scan();
            for (FileObject dir : scanner.getDirs()) {
                dbdata = dir.getName().getBaseName();
                String pt = dir.toString();
                grabDbData(x, pt, dbdata);
            }
        } else {
            // есть dbdata - явное указание на каталог
            grabDbData(x, loader.getAbsPath(path), dbdata);
        }
    }

    /**
     * Сбор dbdata из указанного каталога
     *
     * @param modelRt куда собирать
     * @param dir     из какого каталога
     * @param dbdata  тип dbdata
     */
    protected void grabDbData(Rt modelRt, String dir, String dbdata) {
        DirScannerVfs scanner = new DirScannerVfs();
        scanner.setRootDir(dir);
        scanner.setRecursive(true);
        scanner.scan();
        for (FileObject f : scanner.getFiles()) {
            String domainName = UtDataLoader.filenameToDomainName(f.toString());
            String dataloaderName = UtDataLoader.filenameToDataloaderName(f.toString());
            Rt dataloaderRt = modelRt.findChild("dataloader/" + dataloaderName);
            if (dataloaderRt == null) {
                continue; // неизвестный dataloader
            }
            Rt domainRt = modelRt.findChild("domain/" + domainName);
            if (domainRt == null) {
                throw new XError(UtLang.t("Имеется файл с данными {0}, но нет домена {1}", f.toString(), domainName));
            }
            Rt ldrRt = domainRt.findChild("dataloader/i", true);
            ldrRt.setValue("parent", dataloaderName);
            ldrRt.setValue("file", f.toString());
            ldrRt.setValue("dbdata", dbdata);
        }
    }

    public void handleAfterLoad(IRtLoader loader, Rt root) throws Exception {
        //
        List<IRtPluginDomain> domainHandlers = loader.plugins(IRtPluginDomain.class);
        //
        HashSet<String> tags = new HashSet<String>();
        tags.add("tag.dao");
        tags.add("tag.db");
        tags.add("tag.dbview");
        tags.add("tag.dict");
        tags.add("tag.dataloader");
        Rt models = root.findChild("model");
        if (models != null) {
            // автоматически для всех моделей ставим x-root=true
            for (Rt model : models.getSelfChilds()) {
                loader.setXRoot(model, true);
            }
            // собираем теги со всех доменов
            for (Rt model : models.getSelfChilds()) {
                Rt domains = model.findChild("domain");
                if (domains != null) {
                    for (Rt domain : domains.getSelfChilds()) {
                        grabTag(domain, tags);
                    }
                }
            }
            // обрабатываем домены
            for (Rt model : models.getSelfChilds()) {
                Rt domains = model.findChild("domain");
                if (domains != null) {
                    List<Rt> tmp = new ArrayList<Rt>();
                    tmp.addAll(domains.getSelfChilds());
                    for (Rt domain : tmp) {
                        handleDomain(domain, tags);
                        // обработчики
                        for (IRtPluginDomain domainHandler : domainHandlers) {
                            domainHandler.handleDomain(domain, model);
                        }
                    }
                }
            }
        }
    }

    private void grabTag(Rt x, HashSet<String> tags) {
        for (IRtAttr attr : x.getSelfAttrs()) {
            String s1 = attr.getName().toLowerCase();
            if (s1.startsWith("tag.")) {
                if (!tags.contains(s1)) {
                    tags.add(s1);
                }
            }
        }
    }

    private void handleDomain(Rt domain, HashSet<String> tags) {
        if (!UtRt.isAbstract(domain)) {
            domain.setValue("abstract", false);
        }
        // таблица в базе
        if ((UtRt.isTagged(domain, "tag.db") || UtRt.isTagged(domain, "tag.dbview"))) {
            domain.setValue("tablename", domain.getName());
            domain.setValue("tag.db", true);
        }

        // сбрасываем несуществующие теги
        for (String tag : tags) {
            if (!domain.hasSelfAttr(tag)) {
                domain.setValue(tag, "");
            }
        }
        // ставим правильный ref
        Rt ref = domain.findChild("ref", true);
        ref.setValue("ref", domain.getName());

        // домен является словарем
        if (domain.hasSelfChild("dict")) {
            domain.setValue("tag.dict", true);
        }
        if (UtRt.isTagged(domain, "tag.dict")) {
            Rt dict = domain.findChild("dict", true);
            if (!ref.hasSelfAttr("dict")) {
                ref.setValue("dict", domain.getName());
            }
            // в словаре должен быть dao, хотя бы и в предке
            if (domain.findChild("dao/dict") != null) {
                domain.setValue("tag.dao", true);
            }
        }
        // домен имеет личные dao
        if (domain.hasSelfChild("dao")) {
            domain.setValue("tag.dao", true);
        }

        // валидаторы домена
        if (domain.hasSelfChild("validator")) {
            for (Rt v : domain.getChild("validator").getSelfChilds()) {
                handleValidator(v);
            }
        }

        // валидаторы полей
        if (domain.hasSelfChild("field")) {
            for (Rt field : domain.getChild("field").getSelfChilds()) {
                if (field.hasSelfChild("validator")) {
                    for (Rt v : field.getChild("validator").getSelfChilds()) {
                        handleValidator(v);
                    }
                }
            }
        }

        // домен имеет личные dataloader
        if (domain.hasSelfChild("dataloader")) {
            domain.setValue("tag.dataloader", true);
        }

    }

    private void handleValidator(Rt v) {
        String vclass = v.getValueString("class");
        if (UtString.empty(vclass)) {
            String vparent = v.getValueString("parent");
            if (UtString.empty(vparent)) {
                v.setValue("parent", v.getName());
            } else {
                throw new XError("У валидатора [{0}] не указан класс", v.getPath());
            }
        }
    }

}
