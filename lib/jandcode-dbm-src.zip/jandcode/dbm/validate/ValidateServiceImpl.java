package jandcode.dbm.validate;

import jandcode.app.*;
import jandcode.utils.rt.*;

import java.util.*;

public class ValidateServiceImpl extends ValidateService {

    protected ThreadLocalValidateErrors validateErrors = new ThreadLocalValidateErrors();

    class ThreadLocalValidateErrors extends ThreadLocal<ValidateErrors> {
        protected ValidateErrors initialValue() {
            return getModel().getObjectFactory().create(ValidateErrors.class);
        }
    }

    public Validator createValidator(String name) {
        Rt r = getModel().getRt().getChild("validator/" + name);
        Validator v = (Validator) getModel().getObjectFactory().create(r);
        return v;
    }

    public List<Validator> createValidators(Object forObject, String mode) {
        List<Validator> res = new ArrayList<Validator>();
        if (forObject instanceof CompRt) {
            Rt rt = ((CompRt) forObject).getRt();
            Rt z = rt.findChild("validator");
            if (z != null) {
                for (Rt z1 : z.getChilds()) {
                    Validator v;
                    v = (Validator) getModel().getObjectFactory().create(z1);
                    if (v.isModeCompatible(mode) && v.isEnabled()) {
                        res.add(v);
                    }
                }
            }
        }
        return res;
    }

    public ValidateErrors getErrors() {
        return validateErrors.get();
    }
}
