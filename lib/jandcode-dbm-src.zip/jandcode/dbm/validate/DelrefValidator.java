package jandcode.dbm.validate;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;

import java.util.*;

/**
 * Валидатор для проверки ссылок при удаления записи
 */
public class DelrefValidator extends Validator {

    protected String msg = "На запись имеются ссылки";

    protected void onValidate(DbUtils ut, DataRecord data, Field field, String mode, ValidateErrors errors) throws Exception {
        long id = data.getValueLong("id");
        //
        Domain domain = data.getDomain();
        ListDomain domains = getModel().getDomainsDb(false);
        List<ListDomain.RefInfo> refs = domains.getRefsTo(domain.getName());
        //
        DbFieldExt ex = new DbFieldExt(null);
        //
        for (ListDomain.RefInfo ref : refs) {
            ex.setComp(ref.getRef());
            if (ex.getRefCascade()) {
                continue;
            }
            String tn = ref.getSrc().getName(); // кто ссылается
            String sql = ut.subst("select count(*) as cnt from ${tn} where ${rf}=${id}",
                    "tn", tn,
                    "rf", ref.getRef().getName(),
                    "id", id
            );
            DataStore r = ut.loadSql(sql);
            if (r.getCurRec().getValueLong("cnt") != 0) {
                errors.addError(msg, data);
                return;
            }
        }
    }

}
