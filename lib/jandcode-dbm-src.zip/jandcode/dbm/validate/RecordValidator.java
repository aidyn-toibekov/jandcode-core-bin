package jandcode.dbm.validate;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;

import java.util.*;

/**
 * Проверка записи.
 * Сначала проверяются все поля. Если ошибок нет, проверяется запись.
 * Используются валидаторы, прикрепленные к домену записи (для проверки записи)
 * и к полю (для проверки поля).
 */
public class RecordValidator extends Validator {

    protected void onValidate(DbUtils ut, DataRecord data, Field field, String mode, ValidateErrors errors) {
        Domain domain = data.getDomain();
        Validator fieldValidator = createValidator("field");
        //
        int state = errors.getErrors().size(); // запоминаем для дальнейшего уточнения - возникли ли ошибки
        //
        for (Field field1 : domain.getFields()) {
            fieldValidator.validate(ut, data, field1.getName(), mode, errors);
        }
        if (errors.hasErrors(state)) {
            // в полях были ошибки, запись целиком проверять бессмысленно
            return;
        }
        // теперь проверяем запись полностью
        List<Validator> validators = createValidators(domain, mode);
        for (Validator validator : validators) {
            if (!validator.validate(ut, data, null, mode, errors)) {
                break; // на первом не сработавшем валидаторе - выходим, остальные врядли правильные
            }
        }

        // все...

    }

}
