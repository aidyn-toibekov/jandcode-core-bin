package jandcode.dbm.validate;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;

/**
 * Проверка обязательности значения
 */
public class ReqValidator extends Validator {

    protected String msg = "Значение для поля [${field.title}] обязательно";

    protected void onValidate(DbUtils ut, DataRecord data, Field field, String mode, ValidateErrors errors) throws Exception {
        if (UtCnv.isEmpty(data.getValue(field.getName()))) {
            errors.addError(msg, data, field);
        }
    }

}
