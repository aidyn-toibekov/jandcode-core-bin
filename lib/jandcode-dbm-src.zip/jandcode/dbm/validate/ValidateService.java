package jandcode.dbm.validate;

import jandcode.dbm.*;

import java.util.*;

/**
 * Сервис валидаторов
 */
public abstract class ValidateService extends ModelMember {

    /**
     * Создать валидатор по имени
     */
    public abstract Validator createValidator(String name);

    /**
     * Создать список валидаторов для объекта forObject (например Domain или Field)
     * и режима mode
     */
    public abstract List<Validator> createValidators(Object forObject, String mode);

    /**
     * Глобальный для потока объект с информацией об ошибках.
     * В нем накапливается информация об ошибках. При начале выполнения dao - очищается.
     */
    public abstract ValidateErrors getErrors();

}
