package jandcode.dbm.validate;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

import java.util.*;

/**
 * Объект для накопления ошибок валидации
 */
public class ValidateErrors extends ModelMember {

    protected List<ErrorInfo> errors = new ArrayList<ErrorInfo>();

    protected void onClone(Comp r) {
        super.onClone(r);
        ValidateErrors f = (ValidateErrors) r;
        for (ErrorInfo error : errors) {
            f.errors.add(error);
        }
    }

    //////

    public class ErrorInfo implements ISubstVar {
        String msg;
        DataRecord data;
        Field field;
        String fieldName;

        public String getMsg() {
            return UtString.substVar(msg, this);
        }

        public DataRecord getData() {
            return data;
        }

        public String getFieldName() {
            if (!UtString.empty(fieldName)) {
                return fieldName;
            }
            if (field != null) {
                return field.getName();
            }
            return null;
        }

        public Field getField() {
            if (field != null) {
                return field;
            }
            if (!UtString.empty(fieldName) && data != null) {
                return data.getDomain().findField(fieldName);
            }
            return null;
        }

        public String toString() {
            return getMsg();
        }

        public String onSubstVar(String v) {
            String s1 = UtString.removePrefix(v, "field.");
            if (s1 != null) {
                Field f = getField();
                if (f != null) {
                    if ("title".equalsIgnoreCase(s1)) {
                        return f.getTitle();
                    }
                }
            }
            return "";
        }
    }

    //////

    public List<ErrorInfo> getErrors() {
        return errors;
    }

    /**
     * Очистить ошибки
     */
    public void clear() {
        errors.clear();
    }

    //////

    public void addError(Object msg, DataRecord data, Field field) {
        ErrorInfo ei = new ErrorInfo();
        ei.msg = UtString.toString(msg);
        ei.data = data;
        ei.field = field;
        errors.add(ei);
    }

    public void addError(Object msg, DataRecord data, String fieldName) {
        ErrorInfo ei = new ErrorInfo();
        ei.msg = UtString.toString(msg);
        ei.data = data;
        ei.fieldName = fieldName;
        errors.add(ei);
    }

    public void addError(Object msg) {
        addError(msg, null, (Field) null);
    }

    public void addError(Object msg, DataRecord data) {
        addError(msg, data, (Field) null);
    }

    public void addError(Object msg, String fieldName) {
        ErrorInfo ei = new ErrorInfo();
        ei.msg = UtString.toString(msg);
        ei.fieldName = fieldName;
        errors.add(ei);
    }

    //////

    public void addErrorFatal(Object msg, DataRecord data, Field field) {
        addError(msg, data, field);
        checkErrors();
    }

    public void addErrorFatal(Object msg, DataRecord data, String fieldName) {
        addError(msg, data, fieldName);
        checkErrors();
    }

    public void addErrorFatal(Object msg) {
        addError(msg);
        checkErrors();
    }

    public void addErrorFatal(Object msg, DataRecord data) {
        addError(msg, data);
        checkErrors();
    }

    public void addErrorFatal(Object msg, String fieldName) {
        addError(msg, fieldName);
        checkErrors();
    }

    //////

    /**
     * Есть ли ошибки
     */
    public boolean hasErrors() {
        return errors.size() > 0;
    }

    /**
     * Есть ли ошибок больше, чем size
     */
    public boolean hasErrors(int size) {
        return errors.size() > size;
    }

    /**
     * Если есть ошибки, сгенерить XErrorValidate
     */
    public void checkErrors() {
        if (hasErrors()) {
            throw new XErrorValidate((ValidateErrors) this.clone());
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (ErrorInfo error : errors) {
            sb.append(error.toString()).append("\n");
        }
        return sb.toString().trim();
    }

}
