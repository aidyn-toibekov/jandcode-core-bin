package jandcode.dbm.validate;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * validator
 */
public abstract class Validator extends ModelMember {

    private String mode = "";
    private boolean enabled = true;

    /**
     * Выполнить проверку.
     * см {@link Validator#onValidate(DbUtils, DataRecord, Field, String, ValidateErrors)}
     *
     * @return true - если не было ошибок
     */
    public boolean validate(DbUtils ut, DataRecord data, String fieldName, String mode, ValidateErrors errors) {
        if (errors == null) {
            errors = getModel().getValidateService().getErrors();
        }
        int cnt = errors.getErrors().size();
        if (UtString.empty(mode)) {
            mode = "ins";
        }
        Field field = null;
        if (fieldName != null) {
            field = data.getDomain().f(fieldName);
        }
        try {
            onValidate(ut, data, field, mode, errors);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        return !errors.hasErrors(cnt);
    }

    /**
     * Реализация проверки
     *
     * @param data   что проверяем
     * @param field
     * @param mode   в каком режиме (ins,upd,del ...)
     * @param errors куда складывать ошибки
     */
    protected abstract void onValidate(DbUtils ut, DataRecord data, Field field, String mode, ValidateErrors errors) throws Exception;

    /**
     * Создать список валидаторов для объекта forObject и режима mode
     */
    public List<Validator> createValidators(Object forObject, String mode) {
        return getModel().getValidateService().createValidators(forObject, mode);
    }

    /**
     * Создать валидатор по имени
     */
    public Validator createValidator(String name) {
        return getModel().getValidateService().createValidator(name);
    }

    //////

    /**
     * Режим, в которых валидатор может работать
     */
    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    /**
     * Совместим ли режим getMode() с mode
     */
    public boolean isModeCompatible(String mode) {
        return UtString.isDelimitedIntersect(mode, getMode(), ",", true);
    }

    /**
     * Разрешен ли. Например в rt в потомках можно запретить некоторые валидаторы.
     */
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
}
