package jandcode.dbm.validate;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;

import java.text.*;
import java.util.*;

public class UniqueValidator extends Validator {

    private String _fields = "";

    /**
     * Список проверяемых полей (через ','). Если не задано, то проверяется
     * уникальность поля, к которому прикреплен валидатор. Если прикреплен к полю
     * и задано fields, то это дополниетельные поля к прикрепленному.
     */
    public void setFields(String fields) {
        _fields = fields;
    }

    public String getFields() {
        return _fields;
    }

    protected void onValidate(DbUtils ut, DataRecord data, Field field, String mode, ValidateErrors errors) throws Exception {
        String fields = getFields();
        if (field != null) {
            fields = fields + "," + field.getName();
        }
        List<String> flds = UtCnv.toList(fields);
        Domain domain = data.getDomain();
        //
        StringBuilder sb = new StringBuilder();
        sb.append("select count(*) as cnt from ");
        sb.append(domain.getTableName());
        sb.append(" where ");
        int n = 0;
        for (String fn : flds) {
            if (n != 0) {
                sb.append(" and ");
            }
            sb.append(fn).append("=:").append(fn);
            n++;
        }
        if (!"ins".equals(mode)) {
            sb.append(" and id<>:id");
        }
        DataStore t = ut.loadSql(sb, data);
        if (t.getCurRec().getValueLong("cnt") != 0) {
            if (flds.size() == 1) {
                errors.addError("Значение поля [${field.title}] не уникально", data, flds.get(0));
            } else {
                String titles = "";
                for (String fn : flds) {
                    if (titles.length() > 0) {
                        titles = titles + ",";
                    }
                    titles = titles + domain.f(fn).getTitle();
                }
                errors.addError(MessageFormat.format("Значения комбинаций полей [{0}] не уникальны", titles));
            }
        }
    }

}
