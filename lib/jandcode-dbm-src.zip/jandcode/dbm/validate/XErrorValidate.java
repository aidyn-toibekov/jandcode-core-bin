package jandcode.dbm.validate;

import jandcode.utils.error.*;

import java.util.*;

/**
 * Ошибка валидации
 */
public class XErrorValidate extends RuntimeException implements ErrorValidate {

    private ValidateErrors errors;

    public XErrorValidate(ValidateErrors errors) {
        this.errors = errors;
    }

    public ValidateErrors getErrors() {
        return errors;
    }

    public String toString() {
        return getErrors().toString();
    }

    public List<Map<String, String>> getValidateErrors() {
        List<Map<String, String>> res = new ArrayList<Map<String, String>>();
        for (ValidateErrors.ErrorInfo info : getErrors().getErrors()) {
            Map<String, String> m = new HashMap<String, String>();
            m.put(ErrorValidate.FIELD, info.getFieldName());
            m.put(ErrorValidate.TEXT, info.toString());
            res.add(m);
        }
        return res;
    }
}
