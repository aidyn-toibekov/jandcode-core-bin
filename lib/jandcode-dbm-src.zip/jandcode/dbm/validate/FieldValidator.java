package jandcode.dbm.validate;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;

import java.util.*;

/**
 * Проверка поля.
 */
public class FieldValidator extends Validator {

    protected void onValidate(DbUtils ut, DataRecord data, Field field, String mode, ValidateErrors errors) {
        Validator v;
        //
        Object value = data.getValue(field.getName());
        boolean empty = UtCnv.isEmpty(value);
        boolean req = field.isReq();
        boolean notnull = field.isNotNull();
        //
        if (req) {
            v = createValidator("req");
            if (!v.validate(ut, data, field.getName(), mode, errors)) {
                return;
            }
        }
        if (notnull) {
            v = createValidator("notnull");
            if (!v.validate(ut, data, field.getName(), mode, errors)) {
                return;
            }
        }
        if (!req && empty) {
            return; // дальше бессмысленно - поле пустое, проверки не пройдут все равно
        }
        //
        List<Validator> validators = createValidators(field, mode);
        for (Validator validator : validators) {
            if (!validator.validate(ut, data, field.getName(), mode, errors)) {
                break; // на первом не сработавшем валидаторе для поля - выходим, остальные врядли правильные
            }
        }

    }

}
