package jandcode.dbm;

/**
 * Член модели
 */
public interface IModelLink {

    /**
     * Ссылка на модель
     *
     * @return
     */
    Model getModel();


}
