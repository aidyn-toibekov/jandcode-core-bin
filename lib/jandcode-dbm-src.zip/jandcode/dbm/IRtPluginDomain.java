package jandcode.dbm;

import jandcode.utils.rt.*;

/**
 * Интерфейс для {@link IRtPlugin} для обработки доменов модели.
 * Используется внутри {@link DbmRtPlugin} для всех найденных доменов в модели.
 */
public interface IRtPluginDomain {

    /**
     * Обработать домен
     *
     * @param domain
     * @param model
     */
    void handleDomain(Rt domain, Rt model);

}
