package jandcode.dbm;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Домен
 */
public class Domain extends ModelMember {

    protected ListComp<Field> fields = new ListComp<Field>(this);
    protected HashMap<String, String> tags = new HashMap<String, String>();
    protected String title;
    protected String tableName;
    private boolean frozen;
    protected boolean modified;

    public Domain() {
        fields.setNotFoundMessage("Поле [{0}] не найдено");
    }

    protected void onClone(Comp r) {
        super.onClone(r);
        Domain f = (Domain) r;
        f.title = title;
        f.tableName = tableName;
        UtRt.joinSelf(f._rt, _rt); // создаем все узлы для полей
        f.tags.putAll(tags);
        Rt f_rt = f._rt.findChild("field", true);
        for (Field field : fields) {
            Field cloneField = (Field) field.clone();
            cloneField.internal_replaceRt(f_rt.findChild(cloneField.getName(), true));
            cloneField.index = f.fields.size();
            f.fields.add(cloneField);
        }
    }

    public void setRt(Rt rt) {
        super.setRt(rt);
        //
        modified = false;
    }

    protected void onSetRt(Rt rt) {
        checkFrozen();
        super.onSetRt(rt);
        //
        Rt z = rt.findChild("field", true);
        for (Rt child : z.getChilds()) {
            Field f = (Field) getModel().getObjectFactory().create(child);
            addField(f);
        }
    }

    /**
     * Заголовок
     */
    public String getTitle() {
        return title == null ? "" : title;
    }

    public void setTitle(String title) {
        checkFrozen();
        this.title = title;
    }


    ////// fields

    /**
     * Поля
     */
    public ListComp<Field> getFields() {
        return fields;
    }

    /**
     * Поле по имени
     *
     * @param name имя поля
     * @return null, если поле не найдено
     */
    public Field findField(String name) {
        return fields.find(name);
    }

    /**
     * Поле по имени
     *
     * @param name имя поля
     * @return ошибка, если поле не найдено
     */
    public Field f(String name) {
        return fields.get(name);
    }

    /**
     * Добавить поле
     *
     * @param name имя поля
     * @param type тип (имя поля из описания полей модели в rt). Фактически является
     *             значением атрибута parent для rt создаваемого поля.
     * @return созданное поле
     */
    public Field addField(String name, String type) {
        checkFrozen();
        Rt rt = getRt().findChild("field/" + name, true);
        rt.setValue("parent", type);
        Field f = (Field) getModel().getObjectFactory().create(rt);
        return addField(f);
    }

    protected Field addField(Field field) {
        checkFrozen();
        field.setOwner(this);
        field.onAddField();
        return field;
    }

    /**
     * Физическое добавление поля. Вызывается из поля в методе doAddField
     */
    public void doAddField(Field field) {
        field.index = fields.size();
        fields.add(field);
    }

    //////

    /**
     * Теги
     */
    public HashMap<String, String> getTags() {
        return tags;
    }

    /**
     * Есть ли тег
     */
    public boolean hasTag(String tag) {
        return tags.containsKey(tag);
    }

    ////// tablename

    /**
     * Имя таблицы в базе данных. Если явно не задано - имя домена.
     */
    public String getTableName() {
        return UtString.empty(tableName) ? getName() : tableName;
    }

    public void setTableName(String tableName) {
        checkFrozen();
        this.tableName = tableName;
    }

    ////// frozen

    /**
     * Признак замороженного домена. Такому домену нельзя изменять свойства.
     * Домены, которые созданы в модели и хранятся как прототипы - замороженные.
     */
    public boolean isFrozen() {
        return frozen;
    }

    /**
     * Заморозить домен
     */
    public void froze() {
        this.frozen = true;
    }

    protected void checkFrozen() {
        if (this.frozen) {
            throw new XError("Домен {0} заморожен");
        }
        // если проверка на заморозку прошла, то ставим домену флаг "изменен"
        setModified(true);
    }

    /**
     * Признак того, что структура или свойства домена изменились после его создания
     */
    public boolean isModified() {
        return modified;
    }

    public void setModified(boolean modified) {
        this.modified = modified;
    }
}
