package jandcode.dbm.field;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.lang.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

/**
 * Многоязыковое строковое поле.
 * При чтении забирает значение из соответсвующего языкового поля (xxx_ru, xxx_en).
 * Запись - игнорируется.
 */
public class LangStringField extends StringField {

    public LangStringField() {
        setCalc(true);
    }

    public void setRecordValue(DataRecord rec, Object value) {
    }

    public Object getRecordValue(DataRecord rec) {
        Lang lang = getModel().getDblangService().getCurrentLang();
        Field f = getOwner().f(getName() + "_" + lang.getName());
        if (!rec.isValueNull(f)) {
            return f.getRecordValue(rec);
        }
        for (Lang lang1 : getModel().getDblangService().getLangs()) {
            f = getOwner().f(getName() + "_" + lang1.getName());
            if (!rec.isValueNull(f)) {
                return f.getRecordValue(rec);
            }
        }
        return "";
    }

    protected void onAddField() {
        doAddField(this);
        //
        Rt realRt = getRt().getChild("field/real");
        ListNamed<Lang> langs = getModel().getDblangService().getLangs();
        for (Lang lang : langs) {
            Field f = getOwner().addField(getName() + "_" + lang.getName(), realRt.getPath());
            f.setReq(false);
            f.setNotNull(false);
            f.setTitle(getTitle() + " (" + lang.getName() + ")");
            if (!f.getTitle().equals(f.getTitleShort())) {
                f.setTitleShort(getTitleShort() + " (" + lang.getName() + ")");
            }
            f.setSize(getSize());
        }
    }
}
