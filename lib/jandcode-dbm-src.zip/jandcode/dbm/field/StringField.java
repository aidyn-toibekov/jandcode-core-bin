package jandcode.dbm.field;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

public class StringField extends Field {

    private boolean _trimSpace = true;

    public StringField() {
        setDataType(DataType.STRING);
        setDbDataType("string");
    }

    protected void onClone(Comp r) {
        super.onClone(r);
        StringField f = (StringField) r;
        f._trimSpace = _trimSpace;
    }

    public void setRecordValue(DataRecord rec, Object value) {
        if (value != null) {
            String s = UtCnv.toString(value);
            if (isTrimSpace() && s.length() > 0) {
                if (UtString.isWhiteChar(s.charAt(0)) ||
                        UtString.isWhiteChar(s.charAt(s.length() - 1))) {
                    s = s.trim();
                }
            }
            if (getSize() > 0) {
                if (s.length() > getSize()) {
                    s = s.substring(0, getSize());
                }
            }
            rec.setInternalValue(this, s);
        } else {
            rec.setInternalValue(this, value);
        }
    }

    public Object getRecordValue(DataRecord rec) {
        return UtCnv.toString(rec.getInternalValue(this));
    }

    //////

    /**
     * Обрезать ли пробелы. По умолчанию - true.
     */
    public void setTrimSpace(boolean trimSpace) {
        _trimSpace = trimSpace;
    }

    public boolean isTrimSpace() {
        return _trimSpace;
    }

}
