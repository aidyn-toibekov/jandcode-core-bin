package jandcode.dbm.field;

import jandcode.dbm.*;
import jandcode.dbm.data.*;

/**
 * Поле которое всегда возвращает null. Для скрытия некоторых полей
 * в результатах запроса. Например поле passwd
 */
public class NullField extends Field {

    public void setRecordValue(DataRecord rec, Object value) {
        rec.setInternalValue(this, null);
    }

    public Object getRecordValue(DataRecord rec) {
        return null;
    }
}
