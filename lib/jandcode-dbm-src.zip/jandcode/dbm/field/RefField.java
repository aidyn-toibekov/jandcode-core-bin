package jandcode.dbm.field;

/**
 * Предок для полей-ссылок.
 */
public class RefField extends LongField {

    public String getTitle() {
        if (title == null) {
            if (hasRef()) {
                return getModel().getDomain(getRefName()).getTitle();
            }
        }
        return super.getTitle();
    }

}
