package jandcode.dbm.field;

import jandcode.dbm.data.*;
import jandcode.utils.*;

/**
 * Поле с уникальным id-значением в пределах store
 */
public class UniIdField extends LongField {

    public UniIdField() {
        setCalc(true);
    }

    public void setRecordValue(DataRecord rec, Object value) {
        getRecordValue(rec); // записываем сгененеренное при чтении
    }

    public Object getRecordValue(DataRecord rec) {
        long v = UtCnv.toLong(rec.getInternalValue(this));
        if (v == 0) {
            String n = UniIdField.class.getName();
            v = UtCnv.toLong(rec.getStore().getProp(n));
            v++;
            rec.getStore().setProp(n, v);
            rec.setInternalValue(this, v);
        }
        return v;
    }
}
