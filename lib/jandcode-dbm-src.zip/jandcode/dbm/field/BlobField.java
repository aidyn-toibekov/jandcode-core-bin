package jandcode.dbm.field;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

public class BlobField extends Field {

    public BlobField() {
        setDataType(DataType.BLOB);
        setDbDataType("blob");
    }

    public void setRecordValue(DataRecord rec, Object value) {
        rec.setInternalValue(this, value);
    }

    public Object getRecordValue(DataRecord rec) {
        return UtCnv.toByteArray(rec.getInternalValue(this));
    }
}
