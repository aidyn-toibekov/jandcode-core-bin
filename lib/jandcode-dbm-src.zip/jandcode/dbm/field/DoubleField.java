package jandcode.dbm.field;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

public class DoubleField extends Field {
    public DoubleField() {
        setDataType(DataType.DOUBLE);
        setDbDataType("double");
    }

    public void setRecordValue(DataRecord rec, Object value) {
        if (value instanceof CharSequence && ((CharSequence) value).length() == 0) {
            value = null;
        }
        rec.setInternalValue(this, value);
    }

    public Object getRecordValue(DataRecord rec) {
        return UtCnv.toDouble(rec.getInternalValue(this));
    }
}
