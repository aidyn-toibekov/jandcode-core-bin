package jandcode.dbm.field;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import org.joda.time.*;

public class DateField extends Field {
    public DateField() {
        setDataType(DataType.DATETIME);
        setDbDataType("date");
    }

    public void setRecordValue(DataRecord rec, Object value) {
        if (value instanceof CharSequence && ((CharSequence) value).length() == 0) {
            value = null;
        }
        if (value != null) {
            DateTime dt = UtCnv.toDateTime(value);
            dt = UtDate.clearTime(dt);
            rec.setInternalValue(this, dt);
        } else {
            rec.setInternalValue(this, value);
        }
    }

    public Object getRecordValue(DataRecord rec) {
        return UtCnv.toDateTime(rec.getInternalValue(this));
    }
}
