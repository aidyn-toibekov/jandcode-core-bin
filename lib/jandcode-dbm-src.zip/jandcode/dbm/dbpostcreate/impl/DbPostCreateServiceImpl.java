package jandcode.dbm.dbpostcreate.impl;

import jandcode.app.*;
import jandcode.dbm.dbpostcreate.*;
import jandcode.utils.rt.*;

import java.util.*;

public class DbPostCreateServiceImpl extends DbPostCreateService {

    class ComparatorDbPostCreateHandler implements Comparator<DbPostCreateHandler> {
        public int compare(DbPostCreateHandler o1, DbPostCreateHandler o2) {
            Integer i1 = o1.getWeight();
            Integer i2 = o2.getWeight();
            int n = i1.compareTo(i2);
            if (n == 0) {
                i1 = o1.getIndex();
                i2 = o2.getIndex();
                n = i1.compareTo(i2);
            }
            return n;
        }
    }

    public ListComp<DbPostCreateHandler> getHandlers() throws Exception {
        ListComp<DbPostCreateHandler> items = new ListComp<DbPostCreateHandler>();
        Rt z = getModel().getRt().findChild("dbpostcreate");
        if (z == null) {
            return items;
        }
        //
        for (Rt rt1 : z.getChilds()) {
            DbPostCreateHandler f = (DbPostCreateHandler) getModel().getObjectFactory().create(rt1);
            f.setIndex(items.size());
            items.add(f);
        }
        Collections.sort(items, new ComparatorDbPostCreateHandler());
        return items;
    }

}
