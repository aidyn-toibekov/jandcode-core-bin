package jandcode.dbm.dbpostcreate;

import jandcode.app.*;
import jandcode.dbm.db.*;

/**
 * Обработчик для DbPostCreateService
 */
public abstract class DbPostCreateHandler extends CompRt {

    protected int index;
    protected int weight = 50;

    /**
     * Обработчик базы данных после создания
     *
     * @param ut утилиты для базы. Соединение установлено, транзакция НЕ стартована.
     * @throws Exception
     */
    public abstract void execPostCreate(DbUtils ut) throws Exception;

    //////

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    /////
}
