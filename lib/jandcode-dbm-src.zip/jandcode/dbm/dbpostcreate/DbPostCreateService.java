package jandcode.dbm.dbpostcreate;

import jandcode.app.*;
import jandcode.dbm.*;

/**
 * Сервис, которые предоставляет методы обработки только что созданной
 * базы данных.
 * Предоставляет возможность модифицировать базу и данные в ней в зависисмости от
 * конкретных условий и места создания базы.
 * <p/>
 * В моделе собираются теги <dbpostcreate name="" class=""/>
 * Класс должен быть наследником от jandcode.dbm.dbpostcreate.DbPostCreateHandler
 * Сортируются по весам.
 * Выполняются в рамках соединения с базой.
 */
public abstract class DbPostCreateService extends ModelMember {

    /**
     * Запустить процесс пост-обработки
     *
     * @throws Exception
     */
    public abstract ListComp<DbPostCreateHandler> getHandlers() throws Exception;

}
