package jandcode.dbm.cache.impl;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.cache.*;
import jandcode.utils.*;

import java.util.*;

public class CacheServiceImpl extends CacheService implements IActivate {

    protected long cacheVersion = 0;
    protected HashMapNoCase<Integer> dataNameIdx;
    protected String[] dataNames;
    protected long[] dataVersions;
    protected List<ICacheChange> notifers;

    public void activate() throws Exception {
        notifers = getModel().getServices().impl(ICacheChange.class);
        if (notifers.isEmpty()) {
            notifers = null;
        }
        recreateCache();
    }

    protected void recreateCache() {
        ListDomain dmns = getModel().getDomainsDb();
        dataNameIdx = new HashMapNoCase<Integer>();
        dataNames = new String[dmns.size()];
        dataVersions = new long[dmns.size()];
        int i = 0;
        for (Domain d : dmns) {
            dataNames[i] = d.getTableName();
            dataVersions[i] = cacheVersion;
            dataNameIdx.put(dataNames[i], i);
            i++;
        }
    }

    public void notifyChange(String dataName, Object dataId, String dataOperation) {
        synchronized (this) {
            cacheVersion++;
            Integer idx = dataNameIdx.get(dataName);
            if (idx != null) {
                dataVersions[idx] = cacheVersion;
            }
            if (notifers != null) {
                for (ICacheChange notifer : notifers) {
                    notifer.cacheChange(dataName, dataId, dataOperation);
                }
            }
        }
    }

    public long getCacheVersion() {
        return cacheVersion;
    }

    public List<String> getChangedFromVersion(long checkedVersion) {
        List<String> res = null;
        for (int i = 0; i < dataVersions.length; i++) {
            if (dataVersions[i] > checkedVersion) {
                if (res == null) {
                    res = new ArrayList<String>();
                }
                res.add(dataNames[i]);
            }
        }
        return res;
    }
}
