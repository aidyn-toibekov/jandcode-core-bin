package jandcode.dbm.cache;

import jandcode.dbm.*;

import java.util.*;

/**
 * Сервис кешированных данных.
 */
public abstract class CacheService extends ModelMember {

    public static final String OP_INS = "ins";
    public static final String OP_UPD = "upd";
    public static final String OP_DEL = "del";

    /**
     * Уведомление сервиса, что данные изменились
     *
     * @param dataName      имя данных (допустим имя таблицы в базе данных)
     * @param dataId        id записи в данных (может быть null)
     * @param dataOperation что за операция привела к изменению данных (может быть null)
     */
    public abstract void notifyChange(String dataName, Object dataId, String dataOperation);

    /**
     * Уведомление сервиса, что данные изменились
     *
     * @param dataName имя данных (допустим имя таблицы в базе данных)
     */
    public void notifyChange(String dataName) {
        notifyChange(dataName, null, null);
    }

    /**
     * Возвращает версию кеша. При каждой нотификации сервиса об изменения данных
     * версия кеша увеличивается
     */
    public abstract long getCacheVersion();

    /**
     * Возвращает список имен данных, которые изменились после версии cacheVersion
     *
     * @param checkedVersion проверяемая версия
     * @return null, если нет изменений
     */
    public abstract List<String> getChangedFromVersion(long checkedVersion);

}
