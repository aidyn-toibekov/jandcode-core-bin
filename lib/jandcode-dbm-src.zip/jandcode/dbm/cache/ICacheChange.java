package jandcode.dbm.cache;

/**
 * Интерфейс для сервисов модели, которые желают получать уведомления о том,
 * что данные поменялись.
 */
public interface ICacheChange {

    /**
     * Уведомление сервиса, что данные изменились
     *
     * @param dataName      имя данных (допустим имя таблицы в базе данных)
     * @param dataId        id записи в данных (может быть null)
     * @param dataOperation что за операция привела к изменению данных (может быть null)
     */
    void cacheChange(String dataName, Object dataId, String dataOperation);

}
