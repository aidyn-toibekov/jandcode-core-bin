package jandcode.dbm.jc

import jandcode.dbm.*
import jandcode.dbm.data.*
import jandcode.dbm.dataloader.*
import jandcode.dbm.db.*
import jandcode.dbm.dbpostcreate.*
import jandcode.jc.*
import jandcode.utils.*
import jandcode.utils.easyxml.*
import jandcode.utils.error.*

/**
 * Поддержка модуля jandcode.dbm в скриптах jc
 */
class DbmProjectExt extends ProjectExt {

    /**
     * Модель, откуда будем брать db
     */
    String modelName = "default"

    boolean appendModelNameToPath = true;

    /**
     * База данных по умолчанию
     */
    String dbName = "default";

    /**
     * Каталог, куда генерируются sql и данные. Самодостаточный для создания базы
     */
    private String _dbscript_dir = "temp/db.gen"

    // имена файлов для создания базы данных
    String sql_create = "create.sql"
    String sql_create_after = "create-after.sql"
    String sql_create_references = "create-references.sql"
    String sql_drop_references = "drop-references.sql"

    //////
    Db _db
    AppProjectExt _appProjectExt;

    /**
     * Расширение для приложения
     */
    AppProjectExt getApp() {
        if (_appProjectExt == null) {
            _appProjectExt = createExt(AppProjectExt.class) as AppProjectExt;
        }
        return _appProjectExt
    }

    /**
     * Модель
     */
    Model getModel() {
        return getApp().inst.service(ModelService).getModel(modelName);
    }

    /**
     * Все модели
     */
    List<Model> getModels() {
        return getApp().inst.service(ModelService).getModels();
    }

    String getDbscript_dir() {
        if (appendModelNameToPath) {
            return wd(_dbscript_dir + "/" + model.name)
        } else {
            return wd(_dbscript_dir)
        }
    }

    void setDbscript_dir(String dbscript_dir) {
        _dbscript_dir = dbscript_dir
    }

    /**
     * База данных
     */
    Db getDb() {
        if (_db == null) {
            return model.getDb(dbName)
        }
        return _db
    }

    /**
     * Установить явно базу данных
     */
    void setDb(Db db) {
        _db = db
    }

    /**
     * Информация о базе данных
     */
    void printDbInfo() {
        def ds = db.dbSource
        def m = [:]
        m["dbtype"] = ds.dbType
        m["jdbcDriver"] = ds.jdbcDriverClass
        m["url"] = ds.url
        m["urlAsIs"] = ds.urlAsIs
        m["host"] = ds.host
        m["database"] = ds.database
        m["username"] = ds.username
        m["password"] = ds.password
        m.putAll(ds.props)
        ut.printMapTab(m, "Модель: ${model.name}")
    }

    /**
     * Проверка соединения с базой данных
     */
    void checkConnect() {
        log "Check connect..."
        db.connect()
        db.disconnect()
        log "ОК"
    }

    /**
     * Выполнить скрипт (с разделителем '~~') через jandcode.dbm.db.Db
     * @param fn имя файла со скриптом
     * @param ignoreErrors true просто показать ошибку, иначе - throw
     */
    void execScript(String fn, boolean ignoreErrors = false) {
        fn = wd(fn)
        log "Выполнение скрипта ${fn}..."
        def sct = fu.loadString(fn, "utf-8")
        db.connect()
        try {
            db.execScriptNative(sct, new ErrorCallback() {
                boolean onErrorCallback(Throwable e) {
                    if (ignoreErrors) {
                        def ei = UtError.createErrorInfo(e)
                        log "ERROR execScript: ${ei.text}"
                        return true
                    }
                    return false
                }
            })
        } finally {
            db.disconnect()
        }
        log "ОК"
    }

    /**
     * Генерация скриптов для базы данных
     * @param basefilename базовое имя файла
     *                     генерируется файл 'temp/db.gen/basefilename.sql'
     */
    void gen(String basefilename) {
        def th = new DbModelExt(model)
        def sc = th.grabTemplateDdl(fu.removeExt(basefilename))
        def tmlfile = wd("temp/_${basefilename}_${model.name}.gsp")
        ut.cleanfile(tmlfile)
        fu.saveString(sc, new File(tmlfile))
        ut.cleanfile(dbscript_dir + "/" + basefilename)
        ut.generate(tmlfile, dbscript_dir, [th: th, outfile: basefilename])
    }

    /**
     * Создание списка загрузчиков для загрузки в базу данных
     * @param dataname либо тип dbdata (обычно prod или test),
     *                 либо имя каталога с файлами загрузчиков
     */
    List createDataLoaders(dataname) {
        def svc = new DataLoaderModelExt(model)
        if (dataname.indexOf('/') == -1 && dataname.indexOf('\\') == -1) {
            // просто имя
            return svc.createDataLoadersDbData(dataname)
        } else {
            // каталог
            return svc.createDataLoadersFromDir(dataname)
        }
    }

    /**
     * Загрузка данных
     * @param dataname либо тип dbdata (обычно prod или test),
     *                 либо имя каталога с файлами загрузчиков
     */
    void loadData(dataname, clearTables = false) {
        def ctab = [:]
        db.connect()
        try {
            log "Загрузка данных: ${dataname}"
            ut.startTimer()
            def ldr = createDataLoaders(dataname)
            def dbu = new DbUtils(db)
            for (loader in ldr) {
                loader.load()
                for (t in loader.datas) {
                    def tn = t.domain.name
                    log "- ${tn} (${t.size()}) ..."
                    if (clearTables) {
                        def tt = tn.toLowerCase()
                        if (ctab[tt] == null) {
                            ctab[tt] = tt
                            log "Удаление существующих записей..."
                            db.execSql("delete from ${tn}")
                        }
                    }
                    dbu.updateTable(tn, t)
                }
            }
            ut.stopTimer()
        } finally {
            db.disconnect()
        }
    }

    /**
     * Запись данных в формат xml
     * @param dataname либо тип dbdata (обычно prod или test),
     *                 либо имя каталога с файлами загрузчиков
     * @param todir в какой каталог записать
     */
    void saveDataToXml(dataname, todir) {
        log "Запись данных [${dataname}] (xml) в каталог [${todir}]"
        ant.mkdir(dir: wd(todir))
        //
        ut.startTimer()
        int n = 0
        def ldr = createDataLoaders(dataname)
        for (loader in ldr) {
            loader.load()
            for (t in loader.datas) {
                def tn = t.domain.name
                log "- ${tn} (${t.size()}) ..."
                def x = new EasyXml()
                UtData.saveToXml(t, x)
                n++
                x.save().toFile(wd("${todir}/${tn}-${n}.xml"))
            }
        }
        ut.stopTimer()
    }

    /**
     * Запись данных в формат outtable
     * @param dataname либо тип dbdata (обычно prod или test),
     *                 либо имя каталога с файлами загрузчиков
     * @param todir в какой каталог записать
     */
    void saveDataToText(dataname, todir) {
        log "Запись данных [${dataname}] (outtable) в каталог [${todir}]"
        ant.mkdir(dir: wd(todir))
        //
        ut.startTimer()
        int n = 0
        def ldr = createDataLoaders(dataname)
        for (loader in ldr) {
            loader.load()
            for (t in loader.datas) {
                def tn = t.domain.name
                log "- ${tn} (${t.size()}) ..."
                def sv = new OutTableSaver(t)
                n++
                sv.save().toFile(wd("${todir}/${tn}-${n}.txt"))
            }
        }
        ut.stopTimer()
    }

    /**
     * Восстановление id после массовых изменений данных
     */
    void recoverId() {
        log "recover id..."
        db.connect()
        try {
            db.service(GenIdService).recoverGenId()
        } finally {
            db.disconnect()
        }
        log "OK"
    }

    void execPostCreate() {
        def handlers = model.service(DbPostCreateService).getHandlers()
        if (handlers.size() == 0) {
            return
        }
        //
        log "postCreate..."
        //
        db.connect();
        try {
            DbUtils ut = new DbUtils(db);
            for (DbPostCreateHandler handler : handlers) {
                log "exec: ${handler.name} (${handler.class.name})..."
                handler.execPostCreate(ut);
            }
        } finally {
            db.disconnectForce();
        }
    }

    /**
     * Генерация скриптов на создание базы данных
     * @param includeData включая данные по умолчанию
     * @param includeTestData включая тестовые данные
     */
    void generateDbScript(boolean includeData, boolean includeTestData) {
        ut.cleandir(dbscript_dir)
        gen(sql_create)
        gen(sql_create_references)
        gen(sql_drop_references)
        if (includeData) {
            saveDataToXml("prod", dbscript_dir + "/data")
        }
        if (includeTestData) {
            saveDataToXml("test", dbscript_dir + "/testdata")
        }
    }

    /**
     * Существует ли база данных
     */
    boolean getExistsDb() {
        def man = db.service(DbManagerService)
        return man.existDatabase()
    }

    void dropDatabase() {
        db.disconnectForce()
        def man = db.service(DbManagerService)
        if (man.existDatabase()) {
            log "drop database"
            man.dropDatabase()
        } else {
            log "database not exist. skipped."
        }
    }

    /**
     * Создание базы данных
     *
     * @param useExistsDb true - использовать существующую базу. Она должна быть пустой
     * @param createStruct создавать ли структуру
     * @param doLoadData загружать данные по умолчанию
     * @param doLoadTestdata загружать тестовые данные
     */
    void createDatabase(boolean useExistsDb, boolean createStruct, boolean doLoadData, boolean doLoadTestdata) {
        db.disconnectForce()
        def man = db.service(DbManagerService)
        def existsDb = man.existDatabase()

        if (useExistsDb && existsDb) {
            def mds = db.service(MetaDataService)
            def tbls = mds.loadTables()
            if (tbls.size() > 0) {
                error("База данных должна быть пустой")
            }
        }

        if (!useExistsDb && existsDb) {
            log "drop database"
            man.dropDatabase()
        }

        if (!man.existDatabase()) {
            log "create database"
            man.createDatabase()
        }

        if (!createStruct) {
            return
        }

        execScript(dbscript_dir + "/" + sql_create)
        def ca = dbscript_dir + "/" + sql_create_after
        if (UtFile.exists(ca)) {
            execScript(ca)
        }

        if (doLoadData) {
            loadData(dbscript_dir + "/data")
        }
        if (doLoadTestdata) {
            loadData(dbscript_dir + "/testdata")
        }

        // postCreate
        execPostCreate()

        execScript(dbscript_dir + "/" + sql_create_references, true)

        recoverId()
    }

    /**
     * Создать references
     */
    void createRef(boolean ignoreErrors = false) {
        execScript(dbscript_dir + "/" + sql_create_references, ignoreErrors)
    }

    /**
     * Удалить references
     */
    void dropRef(boolean ignoreErrors = false) {
        execScript(dbscript_dir + "/" + sql_drop_references, ignoreErrors)
    }

    /**
     * Копировать все скрипты в указанный каталог
     */
    void copyDbScriptsTo(String todir, boolean includeData, boolean includeTestData) {
        ant.copy(file: dbscript_dir + "/" + sql_create, todir: todir, overwrite: true)
        if (UtFile.exists(dbscript_dir + "/" + sql_create_after)) {
            ant.copy(file: dbscript_dir + "/" + sql_create_after, todir: todir, overwrite: true)
        }
        ant.copy(file: dbscript_dir + "/" + sql_create_references, todir: todir, overwrite: true)
        ant.copy(file: dbscript_dir + "/" + sql_drop_references, todir: todir, overwrite: true)
        if (includeData) {
            ut.cleandir(todir + "/data")
            ant.copy(todir: todir + "/data") {
                fileset(dir: dbscript_dir + "/data")
            }
        }
        if (includeTestData) {
            ut.cleandir(todir + "/testdata")
            ant.copy(todir: todir + "/testdata") {
                fileset(dir: dbscript_dir + "/testdata")
            }
        }
    }

    /**
     * Добавить текст скрипта в create-after.sql
     */
    void appendCreateAfterSql(String sqltext) {
        ant.echo(message: sqltext + "\n~~\n", file: dbscript_dir + "/" + sql_create_after, append: true)
    }

}
