package jandcode.dbm.sqlfilter;

import jandcode.dbm.*;
import jandcode.dbm.db.*;

/**
 * Интерфейс для построения элементов запроса.
 * передается в метод onBuild элемента фильтра
 */
public interface ISqlFilterBuilder {

    /**
     * Добавить информационный заголовок для элемента фильтра.
     * Например addTitle("Наименование","точно равно '"+value+"'")
     *
     * @param title заголовок для значения
     * @param text  текст, описывающий значение
     */
    void addTitle(String title, String text);

    /**
     * Добавить кусочек where
     *
     * @param wherePart текст where. Самодостаточный, без пред и пост элементов типа 'and'.
     */
    void addWhere(String wherePart);

    /**
     * Добавить параметр со значением для использования при выполнении запроса.
     *
     * @param paramName  имя параметра. Должен быть получен с использованием
     *                   метода {@link ISqlFilterBuilder#getParamName(java.lang.String)}
     * @param paramValue значение параметра
     */
    void addParam(String paramName, Object paramValue);

    /**
     * Получить полное имя параметра с указанным суффиксом.
     * Используется для изоляции имен параметров из разных элементов фильтра.
     * При построении where обязательно нужно использовать этот метод. Т.е.
     * писать:
     * <p/>
     * b.addParam("value");
     * String w = "name = :"+b.getParamName("value");
     *
     * @param paramName имя параметра
     * @return полное значение параметра. Что то типа такого: 'name1_SUFFIX'
     */
    String getParamName(String paramName);

    /**
     * Утилиты базы данных связанные с фильтром.
     */
    DbUtils getUt();

    /**
     * Найти описание поля name. Фильтр связан с доменом, это поле ищется там.
     *
     * @param name имя поля
     * @return null если не найдено
     */
    Field findField(String name);

    /**
     * Текстовое представление значения. Используется в addTitle.
     * Если поле fieldName имеет справочник, то возвращается значение из справочника.
     *
     * @param fieldName имя поля
     * @param v         для значения
     * @return текст
     */
    String getTextValue(String fieldName, Object v);

    /**
     * Текстовое представление значения.
     * см. {@link ISqlFilterBuilder#getTextValue(java.lang.String, java.lang.Object)}
     * для поля элемента фильтра по умолчанию.
     *
     * @param v для значения
     * @return текст
     */
    String getTextValue(Object v);


}
