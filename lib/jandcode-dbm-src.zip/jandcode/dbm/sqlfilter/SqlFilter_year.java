package jandcode.dbm.sqlfilter;

import jandcode.utils.variant.*;
import org.joda.time.*;

/**
 * Поиск по году
 */
public class SqlFilter_year extends SqlFilterItem {

    protected void onBuild(ISqlFilterBuilder b, IVariantMap params) throws Exception {
        int sv = params.getValueInt(getParam());
        if (sv <= 0) {
            return;
        }
        String p1 = b.getParamName("1");
        String p2 = b.getParamName("2");

        b.addWhere(getSqlField() + ">=:" + p1 + " and " + getSqlField() + "<:" + p2);
        DateTime d1 = new DateTime("" + sv);
        b.addParam(p1, d1);
        b.addParam(p2, d1.plusYears(1));
        b.addTitle(getTitle(), "" + sv);
    }

}
