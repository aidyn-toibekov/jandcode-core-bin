package jandcode.dbm.sqlfilter.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.dbm.sqlfilter.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;

import java.util.*;

public class SqlFilterImpl implements SqlFilter {

    private SqlFilterService owner;
    private Domain domain;
    private DbUtils ut;
    private Params params = new Params();
    private List<SqlFilterItem> filters = new ArrayList<SqlFilterItem>();
    private HashMapNoCase<String> orderBys = new HashMapNoCase<String>();
    private boolean prepared = false;

    private String sqlPrepared;
    private String sqlLoad;
    private String sqlPaginate;
    private String sqlTotal;
    private VariantMap paramsPrepared;
    private List<Map<String, String>> titles;
    private HashMapNoCase<List<String>> wheres;

    //
    private boolean paginate = false;
    private boolean total = true;
    private String prefix = "";
    private String sql = "";

    //

    class Params extends VariantMap {
        public Object put(String key, Object value) {
            unprepare();
            return super.put(key, value);
        }

        public Object remove(Object key) {
            unprepare();
            return super.remove(key);
        }
    }

    //

    public void setOwner(SqlFilterService owner) {
        this.owner = owner;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
        unprepare();
    }

    public DbUtils getUt() {
        return ut;
    }

    public void setUt(DbUtils ut) {
        this.ut = ut;
        unprepare();
    }

    public Field findField(String name) {
        if (domain == null) {
            return null;
        }
        return domain.findField(name);
    }

    public void setPaginate(boolean flag) {
        paginate = flag;
        unprepare();
    }

    public void setParams(Map params) {
        this.params.clear();
        if (params != null) {
            this.params.putAll(params);
        }
        unprepare();
    }

    public IVariantMap getParams() {
        return params;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
        if (this.prefix == null) {
            this.prefix = "";
        }
        unprepare();
    }

    public String getPrefix() {
        return this.prefix;
    }

    public void setSql(String sql) {
        this.sql = sql;
        if (this.sql == null) {
            this.sql = "";
        }
        unprepare();
    }

    public void setTotal(boolean total) {
        this.total = total;
        unprepare();
    }

    public SqlFilterItem filter(Map attrs) {
        if (attrs == null) {
            attrs = new HashMap();
        }
        String type = UtString.toString(attrs.get("type"));
        if (UtString.empty(type)) {
            type = "equal";
        }
        //
        SqlFilterItem it = owner.createFilterItem(type);
        it.setOwner(this);
        it.getAttrs().putAll(attrs);
        filters.add(it);
        unprepare();
        return it;
    }

    public void orderBy(String name, String expr) {
        orderBys.put(name, expr);
        unprepare();
    }

    public void orderBy(Map orderBy) {
        if (orderBy != null) {
            orderBys.putAll(orderBy);
        }
        unprepare();
    }

    //////

    protected long getParamPaginateStart() {
        return params.getValueLong(P_START, 0);
    }

    protected long getParamPaginateLimit() {
        return params.getValueLong(P_LIMIT, 25);
    }

    protected void unprepare() {
        prepared = false;
    }

    protected void prepare() {
        if (prepared) {
            return;
        }
        sqlPrepared = null;
        sqlLoad = null;
        sqlTotal = null;
        sqlPaginate = null;
        try {
            // собираем все с фильтров
            SqlFilterBuilderImpl b = new SqlFilterBuilderImpl(this);
            for (SqlFilterItem filter : filters) {
                b.setFilterItem(filter);
                filter.build(b, params);
            }
            //
            titles = b.getTitles();
            paramsPrepared = b.getParams();
            wheres = b.getWheres();
            sqlPrepared = makeSqlPrepared();

            prepared = true;

        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    public Map<String, Object> getParamsPrepared() {
        prepare();
        return paramsPrepared;
    }

    protected String getSqlPrepared() {
        prepare();
        return sqlPrepared;
    }

    protected String makeSqlPrepared() {
        String s = sql;
        // where
        for (Map.Entry<String, List<String>> en : wheres.entrySet()) {
            String whereName = en.getKey();
            List<String> whereTexts = en.getValue();
            s = SqlFilterUtils.replaceWhere(s, whereName, whereTexts);
        }
        //
        return s;
    }

    public String getSqlLoad() {
        prepare();
        if (sqlLoad != null) {
            return sqlLoad;
        }
        sqlLoad = makeSqlLoad();
        return sqlLoad;
    }

    protected String makeSqlLoad() {
        String s = getSqlPrepared();
        String ordbs = params.getValueString(P_ORDERBY);
        if (!UtString.empty(ordbs)) {
            String expr = orderBys.get(ordbs);
            if (!UtString.empty(expr)) {
                s = SqlFilterUtils.replaceOrderBy(s, expr);
            }
        }
        return s;
    }

    public String getSqlPaginate() {
        prepare();
        if (sqlPaginate != null) {
            return sqlPaginate;
        }
        sqlPaginate = makeSqlPaginate();
        return sqlPaginate;
    }

    protected String makeSqlPaginate() {
        return getSqlLoad();
    }

    public String getSqlTotal() {
        prepare();
        if (sqlTotal != null) {
            return sqlTotal;
        }
        sqlTotal = makeSqlTotal();
        return sqlTotal;
    }

    protected String makeSqlTotal() {
        String s = getSqlPrepared();
        s = SqlFilterUtils.replaceSelect(s, "count(*) as cnt", false);
        s = SqlFilterUtils.replaceOrderBy(s, "");
        return s;
    }

    //////

    /**
     * Текст параметров в html
     */
    protected String titlesToHtml(List<Map<String, String>> textParams) {
        StringBuilder b = new StringBuilder();
        for (Map<String, String> p : textParams) {
            if (b.length() != 0) {
                b.append(", ");
            }
            b.append(p.get("title"));
            b.append(": <b>");
            b.append(p.get("value"));
            b.append("</b>");
        }
        return b.toString();
    }

    /**
     * Реализация загрузки
     *
     * @param toStore куда. Если не задано - создается по результатам запроса
     * @return
     * @throws Exception
     */
    protected DataStore doLoad(DataStore toStore) throws Exception {
        prepare();

        // sql
        String s;
        if (paginate) {
            s = getSqlPaginate();
        } else {
            s = getSqlLoad();
        }

        // грузим данные
        if (toStore == null) {
            toStore = ut.loadSql(s, getParamsPrepared());
        } else {
            ut.loadSql(toStore, s, getParamsPrepared());
        }

        // clientdata
        Map clientData = UtData.getPropClientData(toStore);

        // грузим total
        if (paginate && total) {
            s = getSqlTotal();
            DataRecord cnt = ut.loadSqlRec(s, getParamsPrepared());
            clientData.put("total", cnt.getValueLong("cnt"));
        }

        // ну и параметры в виде текста
        clientData.put("filterText", titlesToHtml(titles));
        clientData.put("filterTextData", titles);

        //
        return toStore;
    }

    public void load(DataStore toStore) throws Exception {
        doLoad(toStore);
    }

    public DataStore load() throws Exception {
        return doLoad(null);
    }

}
