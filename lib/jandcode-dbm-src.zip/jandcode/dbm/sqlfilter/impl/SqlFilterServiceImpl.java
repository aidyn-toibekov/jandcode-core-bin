package jandcode.dbm.sqlfilter.impl;

import jandcode.dbm.db.*;
import jandcode.dbm.sqlfilter.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

public class SqlFilterServiceImpl extends SqlFilterService {

    private Class sqlFilterClass;
    private ListNamed<Rt> filterItems = new ListNamed<Rt>();

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt z = getModel().getRt().getChild("sqlfilter");
        for (Rt x : z.getChilds()) {
            filterItems.add(x);
        }
    }

    public void setSqlFilter(Class cls) {
        sqlFilterClass = cls;
    }

    public SqlFilter createSqlFilter(DbUtils ut) {
        SqlFilterImpl res = (SqlFilterImpl) getDbSource().getObjectFactory().create(sqlFilterClass);
        res.setOwner(this);
        res.setUt(ut);
        return res;
    }

    public SqlFilterItem createFilterItem(String type) {
        if ("=".equals(type)) {
            type = "equal";
        }
        Rt rt = filterItems.find(type);
        if (rt == null) {
            throw new XError(UtLang.t("Тип фильтра {0} не найден", type));
        }
        String dbt = getDbSource().getDbType();
        String cn = rt.getValueString("class." + dbt);
        if (UtString.empty(cn)) {
            cn = rt.getValueString("class");
        }
        if (UtString.empty(cn)) {
            throw new XError("Для sqlfilter {0} не определен класс", rt.getPath());
        }
        SqlFilterItem it = (SqlFilterItem) getDbSource().getObjectFactory().create(getDbSource().getObjectFactory().getClass(cn));
        return it;
    }

}
