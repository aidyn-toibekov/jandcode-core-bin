package jandcode.dbm.sqlfilter.impl;

import jandcode.dbm.*;
import jandcode.dbm.db.*;
import jandcode.dbm.sqlfilter.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import java.util.*;

public class SqlFilterBuilderImpl implements ISqlFilterBuilder {

    private List<Map<String, String>> titles = new ArrayList<Map<String, String>>();
    private HashMapNoCase<String> usedNames = new HashMapNoCase<String>();
    private VariantMap params = new VariantMap();
    private HashMapNoCase<List<String>> wheres = new HashMapNoCase<List<String>>();

    private SqlFilterItem curItem;
    private SqlFilterImpl owner;
    private String baseParamName;

    public SqlFilterBuilderImpl(SqlFilterImpl owner) {
        this.owner = owner;
    }

    public void setFilterItem(SqlFilterItem it) {
        curItem = it;
        String nm = it.getField();
        if (UtString.empty(nm)) {
            nm = "p";
        }
        if (!UtString.isLatChar(nm.charAt(0))) {
            nm = "p_" + nm;
        }
        // добиваемся уникальности и запоминаем базовое имя
        String cn = nm;
        int i = 0;
        while (true) {
            if (!usedNames.containsKey(cn)) {
                usedNames.put(cn, cn);
                baseParamName = cn;
                return;
            }
            i++;
            cn = nm + "__" + i;
        }
    }

    public List<Map<String, String>> getTitles() {
        return titles;
    }

    public VariantMap getParams() {
        return params;
    }

    public HashMapNoCase<List<String>> getWheres() {
        return wheres;
    }

    //////

    public void addTitle(String title, String text) {
        if (curItem.isHidden()) {
            return;
        }
        Map<String, String> m = new HashMap<String, String>();
        m.put("title", title);
        m.put("value", text);
        titles.add(m);
    }

    public void addWhere(String wherePart) {
        String wn = curItem.getWhere();
        List<String> dt = wheres.get(wn);
        if (dt == null) {
            dt = new ArrayList<String>();
            wheres.put(wn, dt);
        }
        dt.add(wherePart);
    }

    public void addParam(String paramName, Object paramValue) {
        params.put(paramName, paramValue);
    }

    public String getParamName(String paramName) {
        return baseParamName + "_" + paramName;
    }

    public DbUtils getUt() {
        return owner.getUt();
    }

    public Field findField(String name) {
        return owner.findField(name);
    }

    public String getTextValue(String fieldName, Object v) {
        Field f = findField(fieldName);
        if (f != null) {
            if (f.hasDict()) {
                v = getUt().getDictText(v, f.getDictName());
            }
        }
        return UtCnv.toString(v);
    }

    public String getTextValue(Object v) {
        return getTextValue(curItem.getField(), v);
    }

    //////


}
