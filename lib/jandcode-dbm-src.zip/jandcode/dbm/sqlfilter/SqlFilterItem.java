package jandcode.dbm.sqlfilter;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Элемент фильтра
 */
public abstract class SqlFilterItem {

    protected VariantMap attrs = new VariantMap();
    protected SqlFilter owner;

    /**
     * Реализация build.
     * <p/>
     * Для получения значения параметра или проверки его существования следует
     * использовать имя {@link SqlFilterItem#getParam()} как ключ для params.
     * <p/>
     * Для получения поля домена следует
     * использовать имя {@link SqlFilterItem#getField()} как имя поля для b.findField().
     * И обязательно проверять, что метод не возвратил null.
     *
     * @param b      builder. С помощью его методов предоставить информацию о фильтре.
     * @param params параметры SqlFilter полученные от пользователя
     */
    protected abstract void onBuild(ISqlFilterBuilder b, IVariantMap params) throws Exception;

    //////

    /**
     * Все атрибуты, переданные фильтру при создании
     */
    public VariantMap getAttrs() {
        return attrs;
    }

    /**
     * Имя поля. Базовое имя поле для элемента фильтра. Используется как значение
     * по умолчанию для sqlfield и param (если они явно не заданы).
     * Обычно одно из полей связанного с фильтром домена (но не обязательно).
     */
    public String getField() {
        return getAttrs().getValueString("field");
    }

    /**
     * Имя поля из параметров. Имеется ввиду те параметры, которые назначены для фильтра.
     * Относительно него будут браться данные. Если явно не задано - равно field.
     */
    public String getParam() {
        String s = getAttrs().getValueString("param");
        if (UtString.empty(s)) {
            return getField();
        }
        return s;
    }

    /**
     * sql-поле: берется из свойства sqlfield. Если не указано, берется field с учетом
     * префикса, описанного в фильтре.
     */
    public String getSqlField() {
        String s = getAttrs().getValueString("sqlfield");
        if (UtString.empty(s)) {
            s = getField();
            String p = getOwner().getPrefix();
            if (!UtString.empty(p)) {
                s = p + "." + s;
            }
        }
        return s;
    }

    /**
     * Заголовок для фильтра. Если не указан, берется как заголовок поля.
     * Используется для формирования человеческого описания фильтра.
     */
    public String getTitle() {
        String s = getAttrs().getValueString("title");
        if (UtString.empty(s)) {
            Field f = getOwner().findField(getField());
            if (f != null) {
                s = f.getTitle();
                if (UtString.empty(s)) {
                    s = UtString.capFirst(f.getName());
                }
            }
        }
        return s;
    }

    /**
     * Конкретный where, для которого предназначен этот элемент.
     * sql может быть очень сложным и иметь несколько мест where для расположения
     * фильтров.
     * Если не указан, то используется where по умолчанию ('default').
     */
    public String getWhere() {
        return getAttrs().getValueString("where", "default");
    }

    /**
     * Скрытый фильтр. Если фильтр скрытый, он не отображается в заголовках.
     */
    public boolean isHidden() {
        return getAttrs().getValueBoolean("hidden", false);
    }

    ////// internal

    public void setAttrs(Map attrs) {
        this.attrs.putAll(attrs);
    }

    public SqlFilter getOwner() {
        return owner;
    }

    public void setOwner(SqlFilter owner) {
        this.owner = owner;
    }

    /**
     * Построить параметры и sql
     */
    public void build(ISqlFilterBuilder b, IVariantMap params) throws Exception {
        onBuild(b, params);
    }

}
