package jandcode.dbm.sqlfilter;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Построитель sql с фильтрацией и пагинацией
 */
public interface SqlFilter {

    /**
     * Имя параметра с первой записью для пагинации
     */
    public static final String P_START = "start";

    /**
     * Имя параметра с количеством записей для пагинации
     */
    public static final String P_LIMIT = "limit";

    /**
     * Имя параметра с указанием сортировки по умолчанию
     */
    public static final String P_ORDERBY = "orderBy";

    /**
     * Домен связанный с фильтром. из этого домена элементы фильтра будут
     * собирать себе заголовки и т.д.
     */
    void setDomain(Domain domain);

    /**
     * Найти поле по имени из связанного с фильтром домена.
     * Возвращает или поле, или null, если поле не найдено или домен не установлен.
     */
    Field findField(String name);

    /**
     * Заказ пагинации.
     * Если включено, то параметры start и limit берутся из параметров P_START и P_LIMIT
     *
     * @param flag true - пагинация нужна. По умолчанию - false
     */
    void setPaginate(boolean flag);

    /**
     * Установить параметры фильтра. То, что получено от пользователя.
     * Полностью заменяет существующие параметры.
     */
    void setParams(Map params);

    /**
     * Параметры фильтра. Можно изменять.
     *
     * @return
     */
    IVariantMap getParams();

    /**
     * Префикс по умолчанию для фильтруемых полей в sql.
     * Например для sql: "select t.* from aaa t", префикс должен быть t
     */
    void setPrefix(String prefix);

    /**
     * Установленный префикс по умолчанию.
     */
    String getPrefix();

    /**
     * Базовый sql
     *
     * @param sql
     */
    void setSql(String sql);

    /**
     * Установить флаг выявления общего количества записей при пагинации.
     * По умолчанию - true.
     */
    void setTotal(boolean total);

    /**
     * Создать и добавить фильтр
     *
     * @param attrs атрибуты. Самые важные 'field' и 'type'
     */
    SqlFilterItem filter(Map attrs);

    /**
     * Добавить вариант сортировки.
     */
    void orderBy(String name, String expr);

    /**
     * Добавить варианты сортировки.
     * Ключ - имя, значение - выражение. Для каждого элемента
     * вызывается {@link SqlFilter#orderBy(java.lang.String, java.lang.String)}
     */
    void orderBy(Map orderBy);

    //////

    /**
     * Параметры которые фильтры подготовили для sql
     */
    Map<String, Object> getParamsPrepared();

    /**
     * Подготовленный sql со всеми расставленными where и order by
     */
    String getSqlLoad();

    /**
     * Подготовленный sql со всеми расставленными where, order by и пагинацией
     */
    String getSqlPaginate();

    /**
     * Подготовленный sql со всеми расставленными where для получения общего
     * количесва записей для пагинации
     */
    String getSqlTotal();

    //////

    /**
     * Загрузить данные в указанный store.
     * В дополнение к данным в clientData будет информация о фильтрах
     * и общем количестве записей (в случае пагинации и заказе total).
     */
    void load(DataStore toStore) throws Exception;

    /**
     * Загрузить данные в новый store.
     * В дополнение к данным в clientData будет информация о фильтрах
     * и общем количестве записей (в случае пагинации и заказе total).
     */
    DataStore load() throws Exception;

}
