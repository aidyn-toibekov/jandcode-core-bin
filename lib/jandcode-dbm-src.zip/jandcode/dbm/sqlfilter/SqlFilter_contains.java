package jandcode.dbm.sqlfilter;

import jandcode.lang.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Фильтр для регистронезависимого поиска contains (like %S%) в многоязычных полях.
 * В sqlfields передается список полей, для который делать поиск. Если не указано,
 * поиск делаем только по полу sqlfield.
 * Если sqlfield (или элемент sqlfields) начинается с '*', то это поле рассматривается
 * как многоязычное поле.
 */
public class SqlFilter_contains extends SqlFilterItem {

    protected void onBuild(ISqlFilterBuilder b, IVariantMap params) throws Exception {
        String sv = params.getValueString(getParam());
        if (UtString.empty(sv)) {
            return;
        }
        // для каких полей
        List<String> fields = UtString.toList(getAttrs().getValueString("sqlfields", getSqlField()), ",");
        //
        String pname = b.getParamName("v");
        //
        StringBuilder sb = new StringBuilder();
        ListNamed<Lang> langs = b.getUt().getModel().getDblangService().getLangs();
        for (String f : fields) {
            String s = f;
            if (s.startsWith("*")) {
                s = s.substring(1);
                for (Lang lang : langs) {
                    if (sb.length() != 0) {
                        sb.append(" or ");
                    }
                    sb.append("upper(")
                            .append(s + "_" + lang.getName())
                            .append(") like upper(:")
                            .append(pname)
                            .append(")");
                }
            } else {
                if (sb.length() != 0) {
                    sb.append(" or ");
                }
                sb.append("upper(")
                        .append(s)
                        .append(") like upper(:")
                        .append(pname)
                        .append(")");
            }
        }
        //
        b.addParam(pname, "%" + sv + "%");
        b.addWhere("(" + sb.toString() + ")");
        b.addTitle(getTitle(), "..." + sv + "...");
    }

}
