package jandcode.dbm.sqlfilter;

import jandcode.dbm.db.*;

/**
 * Сервис фильтров
 */
public abstract class SqlFilterService extends DbSourceMember {

    /**
     * Создать фильтр
     *
     * @param ut контекст
     */
    public abstract SqlFilter createSqlFilter(DbUtils ut);

    /**
     * Создание элемента фильтра по типу
     *
     * @param type тип
     * @return новый экземпляр элемента фильтра
     */
    public abstract SqlFilterItem createFilterItem(String type);

}
