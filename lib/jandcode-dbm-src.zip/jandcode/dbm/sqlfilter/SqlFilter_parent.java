package jandcode.dbm.sqlfilter;

import jandcode.utils.variant.*;

/**
 * Фильтр для использования в деревьях id-parent. Настраивается на поле parent.
 * Для корневых элементов испоьзует проверку is null, для остальных - parent=:parent.
 */
public class SqlFilter_parent extends SqlFilterItem {

    protected void onBuild(ISqlFilterBuilder b, IVariantMap params) throws Exception {
        if (params.isValueNull(getParam())) {
            return;
        }
        String pname = b.getParamName("value");
        long v = params.getValueLong(getParam());
        String wh;
        if (v == 0) {
            wh = getSqlField() + " is null";
        } else {
            wh = getSqlField() + "=:" + pname;
            b.addParam(pname, v);
            b.addTitle(getTitle(), b.getTextValue(v));
        }
        b.addWhere(wh);
    }

}
