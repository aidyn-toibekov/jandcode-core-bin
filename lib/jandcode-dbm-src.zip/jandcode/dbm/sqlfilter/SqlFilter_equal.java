package jandcode.dbm.sqlfilter;

import jandcode.utils.variant.*;

/**
 * =
 */
public class SqlFilter_equal extends SqlFilterItem {

    protected void onBuild(ISqlFilterBuilder b, IVariantMap params) throws Exception {
        if (params.isValueNull(getParam())) {
            return;
        }
        String pname = b.getParamName("value");
        Object v = params.getValue(getParam());
        //
        b.addWhere(getSqlField() + "=:" + pname);
        b.addParam(pname, v);
        b.addTitle(getTitle(), b.getTextValue(v));
    }

}
