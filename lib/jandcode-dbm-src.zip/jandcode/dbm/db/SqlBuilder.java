package jandcode.dbm.db;

import jandcode.dbm.*;
import jandcode.utils.*;

import java.util.*;

/**
 * Построитель sql
 */
public class SqlBuilder implements IModelLink, IDbSourceLink, IDbSourceLinkSet {

    public static final String ID = "id";

    protected StringBuilder sb = new StringBuilder();
    protected DbSource dbSource;

    //////

    public DbSource getDbSource() {
        return dbSource;
    }

    public void setDbSource(DbSource dbSource) {
        this.dbSource = dbSource;
    }

    public Model getModel() {
        return getDbSource().getModel();
    }

    //////

    public String toString() {
        return sb.toString();
    }

    public SqlBuilder append(Object text) {
        sb.append(UtString.toString(text));
        return this;
    }

    //////

    /**
     * Делаем список полей из объекта
     *
     * @param fields поля. Может быть списком, строкой через ',', Map, Table, List
     * @return список полей
     */
    public List<String> makeFieldsList(Object fields, Object excludeFields) {
        List<String> res = new ArrayList<String>();
        if (fields instanceof Domain || fields instanceof IDomainLink) {
            Domain t;
            if (fields instanceof Domain) {
                t = (Domain) fields;
            } else {
                t = ((IDomainLink) fields).getDomain();
            }
            for (Field f : t.getFields()) {
                if (!f.isCalc()) {
                    res.add(f.getName());
                }
            }
        } else if (fields instanceof ListNamed) {
            ListNamed t = (ListNamed) fields;
            for (Object f : t) {
                res.add(((INamed) f).getName());
            }
        } else if (fields instanceof Map) {
            Map t = (Map) fields;
            for (Object f : t.keySet()) {
                res.add(UtString.toString(f));
            }
        } else {
            List t = UtString.toList(fields);
            for (Object f : t) {
                res.add(UtString.toString(f));
            }
        }
        if (excludeFields != null) {
            List<String> excl = makeFieldsList(excludeFields, null);
            if (excl.size() > 0) {
                List<String> res2 = new ArrayList<String>();
                for (String fn : res) {
                    boolean e = false;
                    for (String s1 : excl) {
                        if (s1.equalsIgnoreCase(fn)) {
                            e = true;
                        }
                    }
                    if (!e) {
                        res2.add(fn);
                    }
                }
                res = res2;
            }
        }
        return res;
    }

    /**
     * Делаем список полей из объекта
     *
     * @param fields поля. Может быть списком, строкой через ',', Map, Table, List
     * @return список полей
     */
    public List<String> makeFieldsList(Object fields) {
        return makeFieldsList(fields, null);
    }

    /**
     * Генерация sql на вставкув таблицу для всех полей
     *
     * @param tableName имя таблицы
     */
    public SqlBuilder insert(String tableName, Object fields) {
        Domain d = getModel().getDomain(tableName);
        if (fields == null) {
            fields = d;
        }
        List<String> flds = makeFieldsList(fields);
        sb.setLength(0);
        sb.append("insert into ");
        sb.append(tableName);
        sb.append("(");
        int cnt = 0;
        for (String f : flds) {
            if (d.findField(f) == null) {
                continue; // лишнее
            }
            if (cnt != 0) {
                sb.append(",");
            }
            sb.append(f);
            cnt++;
        }
        cnt = 0;
        sb.append(") values (");
        for (String f : flds) {
            if (d.findField(f) == null) {
                continue; // лишнее
            }
            if (cnt != 0) {
                sb.append(",");
            }
            sb.append(":");
            sb.append(f);
            cnt++;
        }
        sb.append(")");
        return this;
    }

    /**
     * Генерация sql на вставкув таблицу для всех полей
     *
     * @param tableName имя таблицы
     */
    public SqlBuilder insert(String tableName) {
        return insert(tableName, null);
    }

    /**
     * Генерация sql для update всех полей
     *
     * @param tableName     имя таблицы
     * @param fields        поля
     * @param excludeFields исключаемые поля
     */
    public SqlBuilder update(String tableName, Object fields, Object excludeFields) {
        Domain d = getModel().getDomain(tableName);
        if (fields == null) {
            fields = d;
        }
        List<String> flds = makeFieldsList(fields, excludeFields);
        sb.setLength(0);
        sb.append("update ");
        sb.append(tableName);
        sb.append(" set ");
        int cnt = 0;
        for (String f : flds) {
            if (d.findField(f) == null) {
                continue; // лишнее
            }
            if (f.equalsIgnoreCase(ID)) {
                continue;
            }
            if (cnt != 0) {
                sb.append(",");
            }
            sb.append(f);
            sb.append("=");
            sb.append(":");
            sb.append(f);
            cnt++;
        }
        sb.append(" where ").append(ID).append("=:").append(ID);
        return this;
    }

    /**
     * Генерация sql для update всех полей
     *
     * @param tableName имя таблицы
     */
    public SqlBuilder update(String tableName, Object fields) {
        return update(tableName, fields, null);
    }

    /**
     * Генерация sql для update всех полей
     *
     * @param tableName имя таблицы
     */
    public SqlBuilder update(String tableName) {
        return update(tableName, null);
    }

    /**
     * Генерация sql для delete
     *
     * @param tableName имя таблицы
     */
    public SqlBuilder delete(String tableName) {
        sb.setLength(0);
        sb.append("delete from ");
        sb.append(tableName);
        sb.append(" where ").append(ID).append("=:").append(ID);
        return this;
    }

    //////

    /**
     * Генерация sql на чтение одной записи таблицы
     *
     * @param tableName имя таблицы
     */
    public SqlBuilder selectRec(String tableName) {
        sb.setLength(0);
        sb.append("select * from ").append(tableName).append(" where id=:id");
        return this;
    }
}
