package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.impl.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.sql.*;

/**
 * Соединение с базой данных jdbc и работа с ним.
 */
public class Db extends DbSourceMember implements IServiceHolder {

    private Connection connection;
    protected int trnLevel;
    protected int connectLevel;
    protected ServiceContainer services;  // личные сервисы соединения
    protected String scriptDelimiter = "~~";

    //////

    public SqlBuilder createSqlBuilder() {
        return getDbSource().getSqlBuilderService().createSqlBuilder();
    }

    ////// connect

    /**
     * Установить соединение.
     * Вызовы connect/disconnect должны быть сбалансированы.
     */
    public void connect() throws Exception {
        if (connectLevel == 0) {
            connection = getDbSource().getConnectionService().connect();
        }
        connectLevel++;
    }

    /**
     * Обрыв соединения
     * Вызовы connect/disconnect должны быть сбалансированы.
     *
     * @throws Exception
     */
    public void disconnect() throws Exception {
        connectLevel--;
        if (connectLevel <= 0) {
            connectLevel = 0;
            try {
                getDbSource().getConnectionService().disconnect(connection);
            } finally {
                connection = null;
            }
        }
    }

    /**
     * Обрыв соединения с игнорированием баланса connect/disconnect.
     */
    public void disconnectForce() throws Exception {
        connectLevel = 0;
        disconnect();
    }

    /**
     * Текущее jdbc соединение.
     */
    public Connection getConnection() {
        if (connection == null) {
            throw new XError("Соединение не установлено");
        }
        return connection;
    }

    /**
     * Установленно ли соединение
     */
    public boolean isConnected() {
        return connection != null;
    }

    ////// tran

    /**
     * Генерация ошибки, если нет активной транзакции
     *
     * @throws Exception
     */
    protected void checkActiveTrn() throws Exception {
        if (!isTran()) {
            throw new XError("Нет активной транзакции");
        }
    }

    /**
     * Начать транзакцию
     */
    public void startTran() throws Exception {
        if (trnLevel == 0) {
            getConnection().setAutoCommit(false);
        }
        trnLevel++;
    }

    /**
     * Подтвердить транзакцию
     */
    public void commit() throws Exception {
        getConnection(); // проверка на соединение
        checkActiveTrn();
        trnLevel--;
        if (trnLevel <= 0) {
            trnLevel = 0;
            try {
                getConnection().commit();
            } catch (Exception e) {
                getConnection().rollback();
                throw e;
            } finally {
                getConnection().setAutoCommit(true);
            }
        }
    }

    /**
     * Откатить транзакцию
     */
    public void rollback() throws Exception {
        getConnection(); // проверка на соединение
        try {
            if (trnLevel != 0) {
                getConnection().rollback();
            }
        } finally {
            if (trnLevel != 0) {
                trnLevel = 0;
                getConnection().setAutoCommit(true);
            }
        }
    }

    /**
     * Откатить транзакцию и сгенерировать ошибку
     */
    public void rollback(Exception e) throws Exception {
        rollback();
        throw e;
    }

    /**
     * Находится ли база в транзакции
     *
     * @return true, если транзакция активна
     */
    public boolean isTran() {
        return trnLevel > 0;
    }

    ////// service

    /**
     * Получить экземпляр сервиса базы данных по классу.
     * Для сервисов, поддерживающих {@link IDbLinkSet} создаются клоны сервисов,
     * для остальных - возвращаются сервисы из {@link DbSource}.
     *
     * @param serviceClass класс сервиса базы данных
     * @param <AA>
     * @return
     */
    public <AA extends Object> AA service(Class<AA> serviceClass) {
        Comp res = (Comp) getDbSource().service(serviceClass);
        if (res instanceof IDbLinkSet) {
            if (services == null) {
                services = new ServiceContainer();
            }
            Comp exists = (Comp) services.find(serviceClass);
            if (exists == null) {
                res = (Comp) res.clone();
                ((IDbLinkSet) res).setDb(this);
                services.add(serviceClass, res);
            } else {
                return (AA) exists;
            }
        }
        return (AA) res;
    }

    public ServiceContainer getServices() {
        throw new XError("Unsupported getServices for Db");
    }

    ////// query

    /**
     * Создать запрос
     *
     * @param sql    запрос
     * @param params параметры
     * @return
     */
    public DbQuery createQuery(Object sql, Object params) {
        return new DbQueryImpl(this, sql, params);
    }

    /**
     * Создать запрос
     *
     * @param sql запрос
     * @return
     */
    public DbQuery createQuery(Object sql) {
        return createQuery(sql, null);
    }

    /**
     * Делает из ResultSet DbQuery. rs должен быть открыт и rs.next() не должен быть вызван
     */
    public DbQuery bindResultSet(ResultSet rs) throws Exception {
        DbQueryImpl q = new DbQueryImpl(this, "", null);
        q.bindResultSet(rs);
        return q;
    }

    ////// exec

    /**
     * Выполнить sql с параметрами, который не возвращает данных
     *
     * @param sql    sql
     * @param params параметры
     * @throws Exception
     */
    public void execSql(Object sql, Object params) throws Exception {
        DbQuery q = createQuery(sql, params);
        try {
            q.exec();
        } finally {
            q.close();
        }
    }


    /**
     * Выполнить sql, который не возвращает данных
     *
     * @param sql sql
     * @throws Exception
     */
    public void execSql(Object sql) throws Exception {
        execSql(sql, null);
    }

    /**
     * Выполнить нативный sql. Никаких преобразований не делается, параметры не назначаются
     *
     * @param sql sql
     * @throws Exception
     */
    public void execSqlNative(Object sql) throws Exception {
        DbQuery q = createQuery(sql);
        try {
            q.execNative();
        } finally {
            q.close();
        }
    }

    ////// open

    /**
     * Выполнить sql с параметрами, который возвращает данные
     *
     * @param sql    sql
     * @param params параметры
     * @return открытый запрос
     * @throws Exception
     */
    public DbQuery openSql(Object sql, Object params) throws Exception {
        DbQuery q = createQuery(sql, params);
        q.open();
        return q;
    }

    /**
     * Выполнить sql, который возвращает данные
     *
     * @param sql sql
     * @return открытый запрос
     * @throws Exception
     */
    public DbQuery openSql(Object sql) throws Exception {
        return openSql(sql, null);
    }

    /**
     * Выполнить нативный sql. Никаких преобразований не делается, параметры не назначаются
     *
     * @param sql sql
     * @return открытый запрос
     * @throws Exception
     */
    public DbQuery openSqlNative(Object sql) throws Exception {
        DbQuery q = createQuery(sql);
        q.openNative();
        return q;
    }

    ////// load

    /**
     * Загрузить результаты нативного sql в таблицу и возвратить результат.
     * Никаких преобразований не делается, параметры не назначаются.
     *
     * @param sql sql
     * @return таблица с результатом запроса
     */
    public DataStore loadSqlNative(Object sql) throws Exception {
        DataStore res;
        DbQuery q = openSqlNative(sql);
        try {
            res = UtData.createStore(q.getDomain());
            DataCopier cp = new DataCopier(q.getDomain(), q.getDomain());
            while (!q.eof()) {
                DataRecord rec = res.add();
                cp.copyRecord(q, rec);
                q.next();
            }
        } finally {
            q.close();
        }
        return res;
    }

    /**
     * Загрузить результаты нативного sql в список.
     * Никаких преобразований не делается, параметры не назначаются.
     *
     * @param to  куда загружать данные. Данные не очищаются
     * @param sql sql
     */
    public void loadSqlNative(DataStore to, Object sql) throws Exception {
        DbQuery q = openSqlNative(sql);
        try {
            DataCopier copier = UtData.createCopier(q.getDomain(), to.getDomain());
            while (!q.eof()) {
                DataRecord rec = to.add();
                copier.copyRecord(q, rec);
                q.next();
            }
        } finally {
            q.close();
        }
    }

    /**
     * Выполнить sql с параметрами, который возвращает данные
     *
     * @param to     куда загружать данные. Данные не очищаются
     * @param sql    sql
     * @param params параметры
     */
    public void loadSql(DataStore to, Object sql, Object params) throws Exception {
        DbQuery q = openSql(sql, params);
        try {
            DataCopier copier = UtData.createCopier(q.getDomain(), to.getDomain());
            while (!q.eof()) {
                DataRecord rec = to.add();
                copier.copyRecord(q, rec);
                q.next();
            }
        } finally {
            q.close();
        }
    }

    /**
     * Выполнить sql с параметрами, который возвращает данные
     *
     * @param to  куда загружать данные. Данные не очищаются
     * @param sql sql
     * @return таблица с данными
     * @throws Exception
     */
    public void loadSql(DataStore to, Object sql) throws Exception {
        loadSql(to, sql, null);
    }

    /**
     * Выполнить sql с параметрами, который возвращает данные
     *
     * @param sql    sql
     * @param params параметры
     * @return список записей
     * @throws Exception
     */
    public DataStore loadSql(Object sql, Object params) throws Exception {
        DataStore res;
        DbQuery q = openSql(sql, params);
        try {
            res = UtData.createStore(q.getDomain());
            DataCopier cp = new DataCopier(q.getDomain(), q.getDomain());
            while (!q.eof()) {
                DataRecord rec = res.add();
                cp.copyRecord(q, rec);
                q.next();
            }
        } finally {
            q.close();
        }
        return res;
    }

    /**
     * Выполнить sql, который возвращает данные
     *
     * @param sql sql
     * @throws Exception
     */
    public DataStore loadSql(Object sql) throws Exception {
        return loadSql(sql, null);
    }

    ////// script

    /**
     * Разделитель скриптов для execScript
     */
    public String getScriptDelimiter() {
        return scriptDelimiter;
    }

    public void setScriptDelimiter(String scriptDelimiter) {
        this.scriptDelimiter = scriptDelimiter;
    }

    /**
     * Исполнение скрипта. Скрипт - это набор sql операторов,
     * разделенных delimiter.
     *
     * @param script    текст скрипта
     * @param isNative  true - выполняется execSqlNative, иначе execSql
     * @param delimiter разделитель операторов
     * @param onError   обработчик ошибок. Если возвращает false, обработка прекращается
     */
    public void execScript(String script, boolean isNative, String delimiter, ErrorCallback onError) throws Exception {
        if (UtString.empty(script)) {
            return;
        }
        StringBuilder sbDelim = new StringBuilder();
        for (int i = 0; i < delimiter.length(); i++) {
            sbDelim.append("\\");
            sbDelim.append(delimiter.charAt(i));
        }
        String ar[] = script.split(sbDelim.toString());

        for (String sql1 : ar) {
            String sql2 = sql1.trim();
            if (sql2.length() == 0) {
                continue;
            }
            try {
                if (isNative) {
                    execSqlNative(sql2);
                } else {
                    execSql(sql2);
                }
            } catch (Exception e) {
                if (onError != null) {
                    if (!onError.onErrorCallback(e)) {
                        throw e;
                    }
                } else {
                    throw e;
                }
            }
        }

    }

    /**
     * Выполнить нативный скрипт с разделителем getScriptDelimiter()
     */
    public void execScriptNative(String script, ErrorCallback onError) throws Exception {
        execScript(script, true, getScriptDelimiter(), onError);
    }

    /**
     * Выполнить нативный скрипт с разделителем getScriptDelimiter()
     */
    public void execScriptNative(String script) throws Exception {
        execScript(script, true, getScriptDelimiter(), null);
    }

    /**
     * Выполнить ненативный скрипт с разделителем getScriptDelimiter()
     */
    public void execScript(String script, ErrorCallback onError) throws Exception {
        execScript(script, false, getScriptDelimiter(), onError);
    }

    /**
     * Выполнить ненативный скрипт с разделителем getScriptDelimiter()
     */
    public void execScript(String script) throws Exception {
        execScript(script, false, getScriptDelimiter(), null);
    }

    //////

    /**
     * Загружает данные из только что открытого ResultSet
     */
    public DataStore loadResultSet(ResultSet rs) throws Exception {
        DataStore res;
        DbQuery q = bindResultSet(rs);
        try {
            res = UtData.createStore(q.getDomain());
            DataCopier cp = new DataCopier(q.getDomain(), q.getDomain());
            while (!q.eof()) {
                DataRecord rec = res.add();
                cp.copyRecord(q, rec);
                q.next();
            }
        } finally {
            q.close();
        }
        return res;

    }

    /**
     * Загружает данные из только что открытого ResultSet
     */
    public void loadResultSet(DataStore to, ResultSet rs) throws Exception {
        DbQuery q = bindResultSet(rs);
        try {
            DataCopier cp = new DataCopier(q.getDomain(), to.getDomain());
            while (!q.eof()) {
                DataRecord rec = to.add();
                cp.copyRecord(q, rec);
                q.next();
            }
        } finally {
            q.close();
        }
    }

}
