package jandcode.dbm.db;

import java.sql.*;

/**
 * Сервис соединений jdbc. Пул в частности.
 */
public abstract class ConnectionService extends DbSourceMember {

    /**
     * Возвращает новое (или из пула) установленное соединение
     */
    public abstract Connection connect();

    /**
     * Разрыв соединения. Соединение возвращается в пул.
     *
     * @param conn что отключить.
     */
    public abstract void disconnect(Connection conn);

    /**
     * Разрыв всех соединений и очистка пула.
     */
    public abstract void disconnectAll();

}
