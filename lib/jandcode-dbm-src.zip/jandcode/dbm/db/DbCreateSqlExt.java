package jandcode.dbm.db;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Расширение для модели, которое работает с каталогом с файлами для создания базы данных.
 */
public class DbCreateSqlExt extends ModelExt {

    private String dbScriptsDir;

    // имена файлов для создания базы данных
    private static String sql_create = "create.sql";
    private static String sql_create_after = "create-after.sql";
    private static String sql_create_references = "create-references.sql";
    private static String dir_data = "data";

    public DbCreateSqlExt(Model comp) {
        super(comp);
    }

    /**
     * Каталог со скриптами на создание базы
     */
    public String getDbScriptsDir() {
        return dbScriptsDir;
    }

    public void setDbScriptsDir(String dbScriptsDir) {
        this.dbScriptsDir = dbScriptsDir;
    }

    public Db getDb() {
        return getModel().getDb();
    }

    /**
     * Выполнить скрипт из файла (с разделителем '~~') через getDb()
     *
     * @param fn имя файла со скриптом
     */
    protected void execScript(String fn) throws Exception {
        String sct = UtFile.loadString(fn, "utf-8");
        getDb().connect();
        try {
            getDb().execScriptNative(sct);
        } finally {
            getDb().disconnect();
        }
    }

    /**
     * Создание базы данных по информации из каталога со скриптами базы
     */
    public void createDatabase() throws Exception {
        getDb().disconnectForce();
        DbManagerService man = getDb().service(DbManagerService.class);

        // базы быть не должно
        if (man.existDatabase()) {
            throw new XError("База данных уже существует");
        }
        // создаем пустую
        man.createDatabase();

        String fsn;

        // создаем структуру
        fsn = getDbScriptsDir() + "/" + sql_create;
        execScript(fsn);

        // выполняем create-after.sql, если он есть
        fsn = getDbScriptsDir() + "/" + sql_create_after;
        if (UtFile.existsFileObject(fsn)) {
            execScript(fsn);
        }

        // загружаем данные
        fsn = getDbScriptsDir() + "/" + dir_data;
        if (UtFile.existsFileObject(fsn)) {
            DbUtils dbu = new DbUtils(getDb());
            DataLoaderModelExt dlme = new DataLoaderModelExt(getModel());
            List<DataLoader> lstLdr = dlme.createDataLoadersFromDir(fsn);
            for (DataLoader loader : lstLdr) {
                loader.load();
                for (DataStore t : loader.getDatas()) {
                    String tn = t.getDomain().getName();
                    dbu.updateTable(tn, t);
                }
            }
        }

        // выполняем create-references.sql, если он есть
        fsn = getDbScriptsDir() + "/" + sql_create_references;
        if (UtFile.existsFileObject(fsn)) {
            execScript(fsn);
        }

        // востанавливаем id до правильного состояния
        getDb().service(GenIdService.class).recoverGenId();

        // все...
    }

}
