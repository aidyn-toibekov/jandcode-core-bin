package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import jandcode.utils.variant.*;

import java.sql.*;
import java.util.*;

/**
 * Драйвер базы данных. Сводит различия jdbc реализаций к необходимому минимому
 */
public class DbDriver extends DbSourceMember {

    public static final String FIELDPROP_dbdatatypeLINK = "dbdatatypeLINK";

    private String _jdbcDriverClass;
    private String _url;
    private ListComp<DbDatatype> _dbDatatypes = new ListComp<DbDatatype>();
    private ClassLinks<DbDatatype> valueClass = new ClassLinks<DbDatatype>();
    private String dbType = "jdbc";

    public DbDriver() {
        _dbDatatypes.setNotFoundMessage("Not found dbdatatype [{0}]");
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        Rt z = rt.findChild("dbdatatype", true);
        if (z != null) {
            for (Rt rt1 : z.getChilds()) {
                DbDatatype dt = (DbDatatype) getDbSource().getObjectFactory().create(rt1);
                _dbDatatypes.add(dt);
            }
        }
        //
        z = rt.findChild("valueclass", true);
        if (z != null) {
            for (Rt rt1 : z.getChilds()) {
                String dbtName = rt1.getValueString("dbdatatype");
                DbDatatype dt = _dbDatatypes.get(dbtName);
                String javaClassName = rt1.getValueString("javaclass", rt1.getName());
                valueClass.add(javaClassName, dt);
            }
        }
    }

    //////

    /**
     * Класс jdbc-драйвера базы данных
     */
    public String getJdbcDriverClass() {
        return _jdbcDriverClass;
    }

    public void setJdbcDriverClass(String jdbcDriverClass) {
        _jdbcDriverClass = jdbcDriverClass;
    }

    //////

    /**
     * url по умолчанию для этого драйвера
     */
    public String getUrl() {
        return _url == null ? "" : _url;
    }

    public void setUrl(String url) {
        _url = url;
    }

    //////

    /**
     * Тип базы данных. Строка, которая обычно совпадает с именем драйвера (но может и не
     * совпадать). Используется для идентификации расширениями (например при генерации
     * скрипта на создании базы эти параметром определяется набор шаблонов)
     */
    public String getDbType() {
        return dbType;
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }

    //////

    /**
     * Для sql типа возвращает имя dbdatatype
     */
    public String getDbDatatypeName(int sqltype) {
        switch (sqltype) {

            case Types.BIT:
            case Types.BOOLEAN:
                return "boolean";

            case Types.TINYINT:
            case Types.SMALLINT:
                return "smallint";

            case Types.INTEGER:
                return "int";

            case Types.BIGINT:
                return "long";

            case Types.FLOAT:
            case Types.REAL:
            case Types.DOUBLE:
            case Types.NUMERIC:
            case Types.DECIMAL:
                return "double";

            case Types.CHAR:
            case Types.VARCHAR:
            case Types.LONGVARCHAR:
            case Types.CLOB:
            case Types.OTHER:
                return "string";

            case Types.DATE:
                return "date";

            case Types.TIME:
            case Types.TIMESTAMP:
                return "datetime";

            case Types.BLOB:
            case Types.BINARY:
            case Types.VARBINARY:
            case Types.LONGVARBINARY:
                return "blob";

            case Types.JAVA_OBJECT:
                return "object";

            default:
                throw new XError("For java.sql.Types=[{0}] not found dbdatatype", sqltype);
        }
    }

    /**
     * Для sql типа возвращает имя dbtype
     */
    protected String getDbDatatypeName(ResultSetMetaData md, int i) throws Exception {
        int ct = md.getColumnType(i);
        String dt = getDbDatatypeName(ct);
        if ("double".equals(dt)) {
            String cn = md.getColumnClassName(i);
            if ("java.lang.Integer".equals(cn)) {
                dt = "int";
            } else if ("java.lang.Long".equals(cn)) {
                dt = "long";
            }
        }
        return dt;
    }

    /**
     * Создает домен по ResultSet.
     */
    public Domain createDomain(ResultSet rs) throws Exception {
        Domain domain = getModel().createDomain("sys");
        ResultSetMetaData md = rs.getMetaData();
        for (int i = 1; i <= md.getColumnCount(); i++) {
            String dt = getDbDatatypeName(md, i);
            DbDatatype d = _dbDatatypes.get(dt);
            //
            String fn = md.getColumnLabel(i);
            if (domain.getFields().find(fn) != null) {
                fn = fn + "#" + i;
            }
            //
            Field f = domain.addField(fn, d.getFieldName());
            f.setProp(FIELDPROP_dbdatatypeLINK, d);
        }
        return domain;
    }

    /**
     * По типу sql возвращает имя поля, которым этот тип нужно представлять
     *
     * @param sqlType sql тип
     * @return имя поля
     */
    public String getFieldTypeName(int sqlType) {
        String dt = getDbDatatypeName(sqlType);
        DbDatatype d = _dbDatatypes.get(dt);
        return d.getFieldName();
    }

    /**
     * Присвоить null-параметр
     *
     * @param statement
     * @param paramIdx
     * @param datatype
     * @throws Exception
     */
    public void setNullParam(PreparedStatement statement, int paramIdx, int datatype) throws Exception {
        if (datatype == DataType.BOOLEAN) {
            statement.setNull(paramIdx, Types.INTEGER);
        } else {
            statement.setNull(paramIdx, Types.NULL);
        }
    }

    /**
     * Присвоить параметры
     *
     * @param statement      куда
     * @param paramValues    откуда
     * @param bindParamNames имена параметров в порядке появления '?' в sql
     */
    public void assignStatementParams(PreparedStatement statement, IVariantNamed paramValues, List<String> bindParamNames) throws Exception {
        for (int i = 0; i < bindParamNames.size(); i++) {
            String paramName = bindParamNames.get(i);
            int paramIdx = i + 1;

            int dt = paramValues.getDataType(paramName);

            if (paramValues.isValueNull(paramName)) {
                setNullParam(statement, paramIdx, dt);
            } else {
                Object value = paramValues.getValue(paramName);
                DbDatatype dbdt = valueClass.get(value.getClass());
                dbdt.setParam(statement, paramIdx, dt, value);
            }
        }
    }

    /**
     * Делает корткий идентификатор длиной maxLength
     *
     * @param src       Исходный
     * @param maxLength длина
     * @return часть исходного и crc
     */
    protected String makeShortIdn(String src, int maxLength) {
        if (src.length() <= maxLength) {
            return src;
        }
        String crc = UtString.crc32Str(src);
        String s = src.substring(0, maxLength - 9);
        return s + "_" + crc;
    }

    /**
     * Делает корткий идентификатор
     *
     * @param src Исходный
     * @return часть исходного и crc
     */
    public String makeShortIdn(String src) {
        return makeShortIdn(src, 30);
    }

    ////// dbDataTypes

    public ListComp<DbDatatype> getDbDatatypes() {
        return _dbDatatypes;
    }

}
