package jandcode.dbm.db;

import jandcode.dbm.*;
import jandcode.utils.*;

import java.sql.*;

/**
 * Тип данных db
 */
public class DbDatatype extends ModelMember {

    private String fieldName = "string";
    private String sqlType = "varchar(20)";

    //////

    /**
     * Имя поля, которым представляется этот тип данных
     */
    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    //////

    /**
     * sql тип. Допустимы подстановки ${xxx}, значения для которых берутся из поля
     * (например "varchar(${size})")
     */
    public String getSqlType() {
        return sqlType;
    }

    public void setSqlType(String sqlType) {
        this.sqlType = sqlType;
    }

    /**
     * Развернутый sqltype для конкретного поля
     */
    public String getSqlType(Field f) {
        final Field f1 = f;
        return UtString.substVar(sqlType, new ISubstVar() {
            public String onSubstVar(String v) {
                if ("size".equalsIgnoreCase(v)) {
                    return UtString.toString(f1.getSize());
                }
                return "";
            }
        });
    }

    ////// jdbc

    /**
     * Читать значение из ResultSet в соотвествии с полем Field
     *
     * @param rs        откуда
     * @param columnIdx индекс колонки
     * @param f         через какое поле
     * @return значение
     */
    public Object readValue(ResultSet rs, int columnIdx, Field f) throws Exception {
        return null;
    }

    /**
     * Установить значение параметра в null
     *
     * @param st       куда
     * @param paramIdx какой параметр (определяется из IVariant)
     * @param datatype какой тип данных
     * @throws Exception
     */
    public void setParamNull(PreparedStatement st, int paramIdx, int datatype) throws Exception {
        if (datatype == DataType.BOOLEAN) {
            st.setNull(paramIdx, Types.INTEGER);
        } else {
            st.setNull(paramIdx, Types.NULL);
        }
    }

    /**
     * Установить значение параметра (не null)
     *
     * @param st       куда
     * @param paramIdx какой параметр
     * @param datatype какой тип данных (определяется из IVariant)
     * @param value    значение (возможен любой тип)
     * @throws Exception
     */
    public void setParam(PreparedStatement st, int paramIdx, int datatype, Object value) throws Exception {
        st.setObject(paramIdx, value);
    }
}
