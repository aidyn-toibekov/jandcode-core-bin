package jandcode.dbm.db;

/**
 * Интерфейс для объектов, знающих о связанной базе данных
 */
public interface IDbLinkSet {

    /**
     * Установить ссылку на базу данных
     */
    void setDb(Db db);

}
