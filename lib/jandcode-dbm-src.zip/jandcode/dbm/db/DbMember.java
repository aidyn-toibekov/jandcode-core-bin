package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.*;

/**
 * Член Db
 */
public class DbMember extends ModelMember implements IDbSourceLink, IDbLink, IDbLinkSet {

    private Db db;

    protected void onClone(Comp r) {
        super.onClone(r);
        DbMember f = (DbMember) r;
        f.db = db;
    }

    public DbSource getDbSource() {
        return db.getDbSource();
    }

    public Db getDb() {
        return db;
    }

    public void setDb(Db db) {
        this.db = db;
    }
}
