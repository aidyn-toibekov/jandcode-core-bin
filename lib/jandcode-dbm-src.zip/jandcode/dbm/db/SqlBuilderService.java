package jandcode.dbm.db;

/**
 * Сервис для построения sql
 */
public class SqlBuilderService extends DbSourceMember {

    private Class sqlBuilderClass = SqlBuilder.class;

    public void setSqlBuilder(Class sqlBuilderClass) {
        this.sqlBuilderClass = sqlBuilderClass;
    }

    public SqlBuilder createSqlBuilder() {
        return (SqlBuilder) getDbSource().getObjectFactory().create(sqlBuilderClass);
    }

}
