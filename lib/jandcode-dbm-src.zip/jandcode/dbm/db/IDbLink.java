package jandcode.dbm.db;

/**
 * Интерфейс для объектов, знающих о связанной базе данных
 */
public interface IDbLink {

    /**
     * Ссылка на базу данных
     */
    Db getDb();

}
