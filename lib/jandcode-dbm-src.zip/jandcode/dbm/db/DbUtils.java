package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;
import jandcode.dbm.sqlfilter.*;
import jandcode.dbm.sqlfilter.impl.*;
import jandcode.dbm.validate.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Утилиты для базы данных. В основном предназначен для использования внутри dao
 * (через потомка DaoUtils), но может использоватся и самостоятельно.
 * <p/>
 * Внутри доступны:
 * getDb() - связанная база данных, если явно не установлена, берется из модели
 * getModel() - модель. Либо явно установлена, либо определяется по базе данных
 * getComp() - компонент, для которого создан DaoUtils. Может быть Db, Model
 */
public class DbUtils implements ISubstVar {

    protected Db db;
    protected Model model;
    protected Comp comp;

    protected DataStore tempStore;  // для кеширования данных словарей

    public DbUtils(Comp comp) {
        this.comp = comp;
    }

    //////

    /**
     * Для какого компонента созданы утилиты
     */
    public Comp getComp() {
        return comp;
    }

    //////

    /**
     * Ссылка на базу данных.
     * Если используется внутри dao, то: соединение установлено, транзакция стартована.
     * Если явно база не назначена, используется база данных по умолчанию из модели.
     */
    public Db getDb() {
        if (db == null) {
            if (comp instanceof Db) {
                db = (Db) comp;
                model = db.getModel();
            } else {
                db = getModel().getDb();
            }
        }
        return db;
    }

    public void setDb(Db db) {
        this.db = db;
    }

    //////

    public Model getModel() {
        if (model == null) {
            if (db != null) {
                model = db.getModel();
            } else if (comp instanceof Model) {
                model = (Model) comp;
            } else if (comp instanceof IModelLink) {
                model = ((IModelLink) comp).getModel();
            }
            if (model == null) {
                throw new XError("Модель не назначена");
            }
        }
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    ////// store

    /**
     * Создать новый домен указанной структуры
     */
    public Domain createDomain(String domainName) {
        return getModel().createDomain(domainName);
    }

    /**
     * Создать store указанной структуры
     */
    public DataStore createStore(Domain domain) {
        return UtData.createStore(domain);
    }

    /**
     * Создать store указанной структуры
     */
    public DataStore createStore(String domainName) {
        return UtData.createStore(getModel().getDomain(domainName));
    }

    /**
     * Создать store указанной структуры и загрузить в нее data
     * (только совпадающие по именам поля)
     */
    public DataStore createStore(String domainName, DataStore data) {
        DataStore z = createStore(domainName);
        UtData.copyStore(data, z);
        return z;
    }

    /**
     * Создать store указанной структуры и загрузить в нее data
     * (только совпадающие по именам поля)
     */
    public DataStore createStore(Domain domain, DataStore data) {
        DataStore z = createStore(domain);
        UtData.copyStore(data, z);
        return z;
    }

    /**
     * Создать store указанной структуры и загрузить в нее запись data
     * (только совпадающие по именам поля)
     */
    public DataStore createStore(String domainName, Map data) {
        DataStore z = createStore(domainName);
        z.add(data);
        return z;
    }

    /**
     * Создать store указанной структуры и загрузить в нее запись data
     * (только совпадающие по именам поля)
     */
    public DataStore createStore(Domain domain, Map data) {
        DataStore z = createStore(domain);
        z.add(data);
        return z;
    }

    /**
     * Создать store указанной структуры и загрузить в нее запись data
     * (только совпадающие по именам поля)
     */
    public DataStore createStore(String domainName, DataRecord data) {
        DataStore z = createStore(domainName);
        z.add(data);
        return z;
    }

    /**
     * Создать store указанной структуры и загрузить в нее запись data
     * (только совпадающие по именам поля)
     */
    public DataStore createStore(Domain domain, DataRecord data) {
        DataStore z = createStore(domain);
        z.add(data);
        return z;
    }

    ////// record

    /**
     * Создать запись указанной структуры
     */
    public DataRecord createRecord(Domain domain) {
        return createStore(domain).add();
    }

    /**
     * Создать запись указанной структуры
     */
    public DataRecord createRecord(String domainName) {
        return createStore(getModel().getDomain(domainName)).add();
    }

    /**
     * Создать запись указанной структуры и загрузить в нее data
     * (только совпадающие по именам поля)
     */
    public DataRecord createRecord(String domainName, DataRecord data) {
        DataRecord z = createRecord(domainName);
        UtData.copyRecord(data, z);
        return z;
    }

    /**
     * Создать запись указанной структуры и загрузить в нее data
     * (только совпадающие по именам поля)
     */
    public DataRecord createRecord(Domain domain, DataRecord data) {
        DataRecord z = createRecord(domain);
        UtData.copyRecord(data, z);
        return z;
    }

    /**
     * Создать запись указанной структуры и загрузить в нее data
     * (только совпадающие по именам поля)
     */
    public DataRecord createRecord(String domainName, Map data) {
        DataRecord z = createRecord(domainName);
        z.setValues(data);
        return z;
    }

    /**
     * Создать запись указанной структуры и загрузить в нее data
     * (только совпадающие по именам поля)
     */
    public DataRecord createRecord(Domain domain, Map data) {
        DataRecord z = createRecord(domain);
        z.setValues(data);
        return z;
    }

    ////// execsql

    public void execSql(Object sql, Object params) throws Exception {
        getDb().execSql(sql, params);
    }

    public void execSql(Object sql) throws Exception {
        getDb().execSql(sql);
    }

    public void execSqlNative(Object sql) throws Exception {
        getDb().execSqlNative(sql);
    }

    ////// open sql

    public DbQuery openSql(Object sql, Object params) throws Exception {
        return getDb().openSql(sql, params);
    }

    public DbQuery openSql(Object sql) throws Exception {
        return getDb().openSql(sql);
    }

    public DbQuery openSqlNative(Object sql) throws Exception {
        return getDb().openSqlNative(sql);
    }

    ////// load sql

    public DataStore loadSqlNative(Object sql) throws Exception {
        return getDb().loadSqlNative(sql);
    }

    public void loadSqlNative(DataStore toStore, Object sql) throws Exception {
        getDb().loadSqlNative(toStore, sql);
    }

    public void loadSql(DataStore toStore, Object sql, Object params) throws Exception {
        getDb().loadSql(toStore, sql, params);
    }

    public void loadSql(DataStore toStore, Object sql) throws Exception {
        loadSql(toStore, sql, null);
    }

    public DataStore loadSql(Object sql, Object params) throws Exception {
        return getDb().loadSql(sql, params);
    }

    public DataStore loadSql(Object sql) throws Exception {
        return loadSql(sql, null);
    }

    ////// load sql rec

    protected void checkOneLoadSqlRec(DataStore st) {
        if (st.size() == 0) {
            throw new XError("No result in sqlrec");
        }
        if (st.size() > 10) {
            throw new XError("Many result in sqlrec");
        }
    }

    public void loadSqlRec(DataRecord toRecord, Object sql, Object params) throws Exception {
        DataStore res = getDb().loadSql(sql, params);
        checkOneLoadSqlRec(res);
        toRecord.setValues(res.getCurRec().getValues());
    }

    public void loadSqlRec(DataRecord toRecord, Object sql) throws Exception {
        DataStore res = getDb().loadSql(sql);
        checkOneLoadSqlRec(res);
        toRecord.setValues(res.getCurRec().getValues());
    }

    public DataRecord loadSqlRec(Object sql, Object params) throws Exception {
        DataStore res = getDb().loadSql(sql, params);
        checkOneLoadSqlRec(res);
        return res.getCurRec();
    }

    public DataRecord loadSqlRec(Object sql) throws Exception {
        DataStore res = getDb().loadSql(sql);
        checkOneLoadSqlRec(res);
        return res.getCurRec();
    }

    ////// load typed

    /**
     * Загрузить запись из таблицы
     *
     * @param tableName откуда
     * @param id        какую
     * @return новая запись
     */
    public DataRecord loadRec(String tableName, long id) throws Exception {
        return loadRec(tableName, id, null);
    }

    /**
     * Загрузить запись из таблицы
     *
     * @param tableName    откуда
     * @param id           какую
     * @param toDomainName имя домена, в который грузим запись. Если не указано,
     *                     то в домен tableName
     * @return новая запись
     */
    public DataRecord loadRec(String tableName, long id, String toDomainName) throws Exception {
        if (UtString.empty(toDomainName)) {
            toDomainName = tableName;
        }
        DataStore r = createStore(toDomainName);
        loadSql(r, "select * from " + tableName + " where id=:id", id);
        checkOneLoadSqlRec(r);
        return r.getCurRec();
    }

    ////// genid

    public long getNextId(String name) {
        return getDb().service(GenIdService.class).getNextId(name);
    }

    ////// ide

    /**
     * Вставка записи из Map. id генерится автоматически.
     *
     * @param tableName куда
     * @param params    данные и поля
     * @return id новой записи
     */
    public long insertRec(String tableName, Map params) throws Exception {
        return insertRec(tableName, params, true);
    }

    /**
     * Вставка записи из Map.
     *
     * @param tableName  куда
     * @param params     данные и поля
     * @param generateId true - генерить id, false - если id не установлена, генерить
     * @return id новой записи
     */
    public long insertRec(String tableName, Map params, boolean generateId) throws Exception {
        Map p1 = new HashMap();
        p1.putAll(params);
        long id = UtCnv.toLong(p1.get("id"));
        if (generateId || id == 0) {
            id = getNextId(tableName);
            p1.put("id", id);
        }
        //
        SqlBuilder sql = getDb().createSqlBuilder();
        sql.insert(tableName, p1);
        //
        execSql(sql, p1);
        return id;
    }

    /**
     * Вставка записи из Table. id генерится автоматически.
     *
     * @param tableName куда
     * @param params    данные и поля
     * @return id новой записи. Так же прописывается в params
     */
    public long insertRec(String tableName, DataRecord params) throws Exception {
        return insertRec(tableName, params, true);
    }

    /**
     * Вставка записи из Table
     *
     * @param tableName  куда
     * @param params     данные и поля
     * @param generateId true - генерить id, false - если id не установлена, генерить
     * @return id новой записи. Так же прописывается в params
     */
    public long insertRec(String tableName, DataRecord params, boolean generateId) throws Exception {
        //
        SqlBuilder sql = getDb().createSqlBuilder();
        sql.insert(tableName, params);
        //
        long id = params.getValueLong("id");
        if (generateId || id == 0) {
            id = getNextId(tableName);
            params.setValue("id", id);
        }
        //
        execSql(sql, params);
        return id;
    }

    /**
     * Обновление записи из Map
     *
     * @param tableName куда
     * @param params    данные и поля (id должен быть)
     */
    public void updateRec(String tableName, Object params, Object includeFields, Object excludeFields) throws Exception {
        SqlBuilder sql = getDb().createSqlBuilder();
        if (includeFields == null) {
            includeFields = params;
        }
        sql.update(tableName, includeFields, excludeFields);
        execSql(sql, params);
    }

    /**
     * Обновление записи из Map
     *
     * @param tableName куда
     * @param params    данные и поля (id должен быть)
     */
    public void updateRec(String tableName, Object params, Object includeFields) throws Exception {
        updateRec(tableName, params, includeFields, null);
    }

    /**
     * Обновление записи из table
     *
     * @param tableName куда
     * @param params    данные и поля (id должен быть)
     */
    public void updateRec(String tableName, Object params) throws Exception {
        updateRec(tableName, params, null, null);
    }

    /**
     * Удаление записи
     *
     * @param tableName куда
     * @param id        что удалять
     */
    public void deleteRec(String tableName, long id) throws Exception {
        SqlBuilder sql = getDb().createSqlBuilder();
        sql.delete(tableName);
        execSql(sql, id);
    }

    ////// fieldlist

    /**
     * Список полей
     *
     * @param domainName    домен
     * @param excludeFields исключаемые поля
     * @return
     */
    public List<String> fieldList(String domainName, Object excludeFields) {
        SqlBuilder sql = getDb().createSqlBuilder();
        return sql.makeFieldsList(getModel().getDomain(domainName), excludeFields);
    }

    /**
     * Список полей
     *
     * @param domainName домен
     * @return
     */
    public List<String> fieldList(String domainName) {
        return fieldList(domainName, null);
    }

    /**
     * Список полей со значениями из записи. Поля isValueExist==false пропускаются
     *
     * @param rec       запись
     * @param includeId включать ли в список id
     * @return список полей
     */
    public List<String> fieldList(DataRecord rec, boolean includeId) {
        List<String> res = new ArrayList<String>();
        for (Field f : rec.getDomain().getFields()) {
            if (!includeId && f.hasName("id")) {
                continue;
            }
            if (!f.isCalc() && rec.isValueExists(f)) {
                res.add(f.getName());
            }
        }
        return res;
    }

    ////// subst

    /**
     * Подстановки
     */
    public String onSubstVar(String v) {
        return "";
    }

    /**
     * Подстановка переменных ${xxx} из params
     * (см. {@link UtData#toVariantNamed(Object)}).
     * Если xxx начинается с '@', то в качестве значения берется
     * результат метода onSubstVar
     */
    public String subst(Object text, Object params) {
        final IVariantNamed m = UtData.toVariantNamed(params);
        String s = UtString.toString(text);
        return UtString.substVar(s, new ISubstVar() {
            public String onSubstVar(String v) {
                if (v.startsWith("@")) {
                    return DbUtils.this.onSubstVar(v.substring(1));
                }
                return m.getValueString(v);
            }
        });
    }

    /**
     * args превращается в map (через UtCnv.toMap()) и вызывается {@link DbUtils#subst(Object, Object)}.
     */
    public String subst(Object text, Object... args) {
        Map m = UtCnv.toMap(args);
        return subst(text, m);
    }


    ////// validate

    /**
     * Ошибки валидации
     */
    public ValidateErrors getErrors() {
        return getModel().getValidateService().getErrors();
    }

    /**
     * Если есть ошибки валидации, генерируется исключение
     */
    public void checkErrors() {
        getErrors().checkErrors();
    }

    /**
     * Проверить запись (или поле) валидатором validatorName
     */
    public boolean validate(String validatorName, DataRecord data, String fieldName, String mode) {
        Validator v = getModel().getValidateService().createValidator(validatorName);
        return v.validate(this, data, fieldName, mode, getErrors());
    }

    /**
     * Проверить запись валидатором 'record'
     */
    public boolean validateRecord(DataRecord data, String mode) {
        return validate("record", data, null, mode);
    }

    /**
     * Проверить запись валидатором 'record'
     */
    public boolean validateRecord(DataRecord data) {
        return validate("record", data, null, null);
    }

    /**
     * Проверить поле валидатором 'field'
     */
    public boolean validateField(DataRecord data, String fieldName, String mode) {
        return validate("field", data, fieldName, mode);
    }

    /**
     * Проверить поле валидатором 'field'
     */
    public boolean validateField(DataRecord data, String fieldName) {
        return validate("field", data, fieldName, null);
    }

    /**
     * Проверка при удалении: на запись не должно быть ссылок
     *
     * @param tableName в какой таблице
     * @param id        id удаляемой записи
     */
    public boolean validateDelRef(String tableName, long id) {
        DataRecord rec = createRecord(tableName);
        rec.setValue("id", id);
        return validate("delref", rec, null, "del");
    }

    ////// table db update

    /**
     * Вставить данные в таблицу из store.
     * Вставка выполняется в рамках одной транзакции.
     *
     * @param tableName куда
     * @param data      данные
     * @throws Exception
     */
    public void insertTable(String tableName, DataStore data) throws Exception {
        if (data.size() == 0) {
            return;
        }
        SqlBuilder sql = getDb().createSqlBuilder();
        sql.insert(tableName);
        getDb().startTran();
        try {
            DbQuery q = getDb().createQuery(sql, null);
            try {
                for (DataRecord rec : data) {
                    q.setParams(rec);
                    q.exec();
                }
            } finally {
                q.close();
            }
            getDb().commit();
        } catch (Exception e) {
            getDb().rollback(e);
        }
    }

    /**
     * Обновить данные в базе по данным store.
     * Для каждой записи анализируется {@link UtData#getPropIde(DataRecord)}.
     * Для "ins" - запись добавляется
     * Для "upd" - запись обновляется (поле id - ключ). Проверка на существующую не делается.
     * Для "del" - запись удаляется (поле id - ключ). Проверка на существующую не делается.
     * При "ins" и "upd" используются только те поля, для которых isValueExist == true
     * <p/>
     * Выполняется в рамках одной транзакции.
     *
     * @param tableName куда
     * @param data      данные
     * @throws Exception
     */
    public void updateTable(String tableName, DataStore data) throws Exception {
        if (data.size() == 0) {
            return;
        }
        SqlBuilder sql = getDb().createSqlBuilder();
        getDb().startTran();
        try {
            List<String> fields;
            for (DataRecord rec : data) {
                String ide = UtData.getPropIde(rec);
                if (UtData.UPD.equals(ide)) {
                    fields = fieldList(rec, false);
                    if (fields.size() > 0) {
                        sql.update(tableName, fields);
                        execSql(sql, rec);
                    }
                } else if (UtData.DEL.equals(ide)) {
                    sql.delete(tableName);
                    execSql(sql, rec.getValue("id"));
                } else { // ins
                    fields = fieldList(rec, true);
                    sql.insert(tableName, fields);
                    execSql(sql, rec);
                }
            }
            getDb().commit();
        } catch (Exception e) {
            getDb().rollback(e);
        }
    }

    ////// dao

    /**
     * Создать dao по имени
     */
    public Dao createDao(String daoName) {
        return getModel().createDao(daoName);
    }

    /**
     * Создать dao по классу
     */
    public <A extends Dao> A createDao(Class<A> cls) {
        return getModel().createDao(cls);
    }

    /**
     * см. {@link Model#daoinvoke(java.lang.String, java.lang.String, java.lang.Object...)}
     */
    public Object daoinvoke(String daoName, String methodName, Object... args) throws Exception {
        return getModel().daoinvoke(daoName, methodName, args);
    }

    ////// dict

    /**
     * Загрузка resolve-словарей
     *
     * @param data  для чего (store | record)
     * @param force true - принудительная перегрузка
     * @return true, если был выполнен запрос
     */
    public boolean resolveDicts(Object data, boolean force) {
        return getModel().getDictService().resolveDicts(data, force);
    }

    /**
     * Загрузка resolve-словарей, которые еще не загружены
     *
     * @param data для чего (store | record)
     * @return true, если был выполнен запрос
     */
    public boolean resolveDicts(Object data) {
        return getModel().getDictService().resolveDicts(data);
    }

    /**
     * Возвращает словарь по имени. В контексте экземпляра DbUtils resolve словари
     * кешируются.
     *
     * @param dictName имя словаря
     * @return словарь
     */
    public Dict getDict(String dictName) {
        if (tempStore == null) {
            tempStore = createStore("id");
        }
        return tempStore.getDict(dictName);
    }

    /**
     * Получить значение из словаря
     *
     * @param key       ключ
     * @param dictName  имя словаря
     * @param dictField имя словарного поля (null для поля по умолчанию)
     * @return значение или null
     */
    public Object getDictValue(Object key, String dictName, String dictField) {
        Dict dict = getDict(dictName);
        Object res = dict.getValue(key, dictField);
        if (res == null && dict.isResolve()) {
            dict.resolveId(key);
            dict.load();
            res = dict.getValue(key, dictField);
        }
        return res;
    }

    /**
     * Получить значение из словаря (поле по умолчанию)
     *
     * @param key      ключ
     * @param dictName имя словаря
     * @return значение или null
     */
    public Object getDictValue(Object key, String dictName) {
        return getDictValue(key, dictName, null);
    }

    /**
     * Получить значение из словаря в виде строки
     *
     * @param key       ключ
     * @param dictName  имя словаря
     * @param dictField имя словарного поля (null для поля по умолчанию)
     * @return значение или null
     */
    public String getDictText(Object key, String dictName, String dictField) {
        return UtCnv.toString(getDictValue(key, dictName, dictField));
    }

    /**
     * Получить значение из словаря в виде строки (поле по умолчанию)
     *
     * @param key      ключ
     * @param dictName имя словаря
     * @return значение или null
     */
    public String getDictText(Object key, String dictName) {
        return UtCnv.toString(getDictValue(key, dictName));
    }

    /**
     * Получить запись из словаря
     *
     * @param key      ключ
     * @param dictName имя словаря
     * @return запись или null
     */
    public DataRecord getDictRec(Object key, String dictName) {
        Dict dict = getDict(dictName);
        DataRecord res = dict.getRecord(key);
        if (res == null && dict.isResolve()) {
            dict.resolveId(key);
            dict.load();
            res = dict.getRecord(key);
        }
        return res;
    }

    ////// clientdata

    /**
     * map с клиентскими данными store
     */
    public Map<String, Object> getClientData(DataStore store) {
        return UtData.getPropClientData(store);
    }

    /**
     * map с клиентскими данными store
     */
    public Map<String, Object> getClientData(DataRecord record) {
        return UtData.getPropClientData(record);
    }

    /**
     * Установить свойство в клиентских данных store
     *
     * @param store     для кого
     * @param propName  свойство
     * @param propValue значение
     */
    public void setClientData(DataStore store, String propName, Object propValue) {
        getClientData(store).put(propName, propValue);
    }

    /**
     * Установить свойство в клиентских данных record
     *
     * @param record    для кого
     * @param propName  свойство
     * @param propValue значение
     */
    public void setClientData(DataRecord record, String propName, Object propValue) {
        getClientData(record).put(propName, propValue);
    }

    //////

    /**
     * Создает фильтр
     *
     * @param domainName имя связанного с фильтром домена
     * @param params     данные для параметров фильтра
     */
    public SqlFilter createSqlFilter(String domainName, Map params) {
        SqlFilterImpl f = (SqlFilterImpl) getDb().getDbSource().service(SqlFilterService.class).createSqlFilter(this);
        f.setDomain(createDomain(domainName));
        if (params != null) {
            f.setParams(params);
        }
        return f;
    }

    ///// UtData delegates

    /**
     * Преобразовать объект в IVariantNamed
     *
     * @param ob исходный объект
     * @return враппер объекта
     */
    public IVariantNamed toVariantNamed(Object ob) {
        return UtData.toVariantNamed(ob);
    }

    /**
     * Копировать данные записи из src в dst
     */
    public void copyRecord(DataRecord src, DataRecord dst) {
        UtData.copyRecord(src, dst);
    }

    /**
     * Копировать все записи из src в dst
     */
    public void copyStore(DataStore src, DataStore dst) {
        UtData.copyStore(src, dst);
    }

    /**
     * Создать копию данных src
     */
    public DataStore copyStore(DataStore src) {
        return UtData.copyStore(src);
    }

    /**
     * Создать индекс для быстрого доступа к записям
     *
     * @param store     для какого store
     * @param fieldName для какого поля
     * @return индекс
     */
    public DataIndex createIndex(DataStore store, String fieldName) {
        return UtData.createIndex(store, fieldName);
    }

    /**
     * Возвращает список уникальных значений из указанного поля
     *
     * @param from      из какой таблицы
     * @param fieldName какое поле
     * @return
     */
    public Set uniqueValues(DataStore from, String fieldName) {
        return UtData.uniqueValues(from, fieldName);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     */
    public void outTable(DataStore t) {
        UtData.outTable(t);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     *
     * @param limit сколько максимум записей выводить
     */
    public void outTable(DataStore t, int limit) {
        UtData.outTable(t, limit);
    }

    /**
     * Для отладки. Вывести запись в виде таблицы на консоль
     */
    public void outTable(DataRecord t) {
        UtData.outTable(t);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     */
    public void outTable(DataTreeNode t) {
        UtData.outTable(t);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     *
     * @param limit сколько максимум записей выводить
     */
    public void outTable(DataTreeNode t, int limit) {
        UtData.outTable(t, limit);
    }

    /**
     * Сканирование дерева
     *
     * @param root        с какого начинать
     * @param includeRoot вызывать ли visitor для root
     * @param visitor     интерфейс визитера
     */
    public void scanTree(DataTreeNode root, boolean includeRoot, ITreeNodeVisitor visitor) {
        UtData.scanTree(root, includeRoot, visitor);
    }

    /**
     * Построение дерева по id-parent.
     *
     * @param store           для какого store
     * @param idFieldName     имя поля id
     * @param parentFieldName имя поля parent
     * @return корневой узел дерева (без записи)
     */
    public DataTreeNode createTreeIdParent(DataStore store, String idFieldName, String parentFieldName) {
        return UtData.createTreeIdParent(store, idFieldName, parentFieldName);
    }

    /**
     * Создает корневой DataTreeNode для store
     *
     * @param store store для корневого узла
     */
    public DataTreeNode createTreeNodeRoot(DataStore store) {
        return UtData.createTreeNodeRoot(store);
    }

    /**
     * Создает пустой DataTreeNode
     *
     * @param rec запись для узла. Можно передавать null, если для корневого узла не
     *            нужна запись
     */
    public DataTreeNode createTreeNode(DataRecord rec) {
        return UtData.createTreeNode(rec);
    }
}
