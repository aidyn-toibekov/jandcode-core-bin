package jandcode.dbm.db;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Расширение для домена: информация о домене как о таблице (или view) в базе данных.
 * Что выбирается:
 * <pre>{@code
 * <domain db.genidstart="1000" tag.dbview="true">
 *      <dbindex name="name1" fields="a1,*a2" unique="true"/>
 *      <ddl name="view">
 *         create view sql
 *      </ddl>
 * </domain>
 * }</pre>
 * <p/>
 * Для view текст sql должен быть полным ddl оператором.
 */
public class DbDomainExt extends DomainExt {

    public DbDomainExt(Domain domain) {
        super(domain);
    }

    /**
     * Индекс
     */
    public class Index extends Named {
        private ArrayList<IndexField> fields = new ArrayList<IndexField>();
        private boolean unique;

        public ArrayList<IndexField> getFields() {
            return fields;
        }

        /**
         * Установить поля в индексе. Значение - список имен полей через ','. Если
         * имя поля начинается со '*', то это означает что сортировать нужно в
         * обратном порядке (по убыванию)
         */
        public void setFields(String s) {
            fields.clear();
            if (s == null || s.length() == 0) {
                return;
            }
            List<String> ar = UtCnv.toList(s);
            for (String s1 : ar) {
                IndexField f = new IndexField();
                if (s1.startsWith("*")) {
                    f.desc = true;
                    f.setName(s1.substring(1));
                } else {
                    f.setName(s1);
                }
                fields.add(f);
            }
        }

        /**
         * Признак уникального индекса
         */
        public boolean isUnique() {
            return unique;
        }

    }

    //////

    /**
     * Описание поля индекса
     */
    public class IndexField extends Named {

        private boolean desc;

        /**
         * Сортировка в обратном порядке
         */
        public boolean isDesc() {
            return desc;
        }

    }

    //////

    /**
     * Индексы таблицы в базе данных
     */
    public List<Index> getIndexes() {
        List<Index> res = new ArrayList<Index>();
        Rt z = getRt().findChild("dbindex");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                Index ix = new Index();
                ix.setName(z1.getName());
                ix.setFields(z1.getValueString("fields"));
                ix.unique = z1.getValueBoolean("unique");
                res.add(ix);
            }
        }
        return res;
    }

    //////

    /**
     * С какого числа начинать генерацию id
     */
    public long getGenIdStart() {
        return getRt().getValueLong("db.genidstart", 1000);
    }

    //////

    /**
     * Поименнованный ddl
     *
     * @param name имя дочернего узла для узла sql
     * @return текст или "", если нет такого
     */
    public String getDdl(String name) {
        Rt r = getRt().findChild("ddl/" + name);
        if (r == null) {
            return null;
        }
        Sql sql = (Sql) getModel().getObjectFactory().create(r, Sql.class);
        return sql.getText();
    }

    /**
     * Возвращает список ddl операторов из домена
     */
    public List<String> getDdls() {
        List<String> res = new ArrayList<String>();
        Rt z = getRt().findChild("ddl");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                Sql sql = (Sql) getModel().getObjectFactory().create(z1, Sql.class);
                String s = sql.getText();
                if (!UtString.empty(s)) {
                    res.add(s);
                }
            }
        }
        return res;
    }

    /**
     * Возвращает true, если домен описывает view.
     */
    public boolean isView() {
        return getComp().hasTag("dbview");
    }

}
