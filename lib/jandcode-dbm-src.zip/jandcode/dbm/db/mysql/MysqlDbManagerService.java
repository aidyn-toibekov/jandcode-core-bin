package jandcode.dbm.db.mysql;

import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.dbm.db.jdbc.*;

public class MysqlDbManagerService extends JdbcDbManagerService {

    public boolean existDatabase() throws Exception {
        boolean res = false;
        Db dbsys = getSystemDb();
        dbsys.connect();
        try {
            DataStore a = dbsys.loadSql("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME=:id", getDbSource().getDatabase());
            res = a.size() == 1;
        } finally {
            dbsys.disconnect();
        }
        return res;
    }

    public void createDatabase() throws Exception {
        Db dbsys = getSystemDb();
        dbsys.connect();
        try {
            dbsys.execSqlNative("create database " +
                    getDbSource().getDatabase() +
                    " DEFAULT CHARACTER SET utf8");
        } finally {
            dbsys.disconnect();
        }
    }

    public void dropDatabase() throws Exception {
        Db dbsys = getSystemDb();
        dbsys.connect();
        try {
            dbsys.execSqlNative("drop database " +
                    getDbSource().getDatabase());
        } finally {
            dbsys.disconnect();
        }
    }
}
