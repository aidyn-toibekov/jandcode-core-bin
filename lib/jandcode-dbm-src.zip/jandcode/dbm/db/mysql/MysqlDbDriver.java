package jandcode.dbm.db.mysql;

import jandcode.dbm.db.*;

public class MysqlDbDriver extends DbDriver {
    public MysqlDbDriver() {
        setDbType("mysql");
    }
}
