package jandcode.dbm.db;

import jandcode.dbm.*;

/**
 * Расширение для поля: информация о поле в базе данных
 * Что выбирается:
 * <pre>{@code
 * <field db.refcascade="true">
 * </field>
 * }</pre>
 */
public class DbFieldExt extends FieldExt {

    public DbFieldExt(Field field) {
        super(field);
    }

    /**
     * true - нужно генерить каскадную ссылку
     */
    public boolean getRefCascade() {
        return getRt().getValueBoolean("db.refcascade");
    }

    /**
     * sql тип для поля
     */
    public String getSqlType() {
        return getModel().getDbSource().getDbDriver().getDbDatatypes().get(getComp().getDbDataType()).getSqlType(getComp());
    }
}
