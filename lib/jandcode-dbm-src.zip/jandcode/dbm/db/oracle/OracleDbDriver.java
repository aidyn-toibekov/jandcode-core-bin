package jandcode.dbm.db.oracle;

import jandcode.dbm.db.*;

import java.sql.*;

public class OracleDbDriver extends DbDriver {
    public OracleDbDriver() {
        setDbType("oracle");
    }

    /**
     * Для sql типа возвращает имя dbtype
     */
    protected String getDbDatatypeName(ResultSetMetaData md, int i) throws Exception {
        int ct = md.getColumnType(i);
        String dt = getDbDatatypeName(ct);
        if ("double".equals(dt)) {
            String cn = md.getColumnClassName(i);
            if ("java.lang.Integer".equals(cn)) {
                dt = "int";
            } else if ("java.lang.Long".equals(cn)) {
                dt = "long";
            } else {
                int scale = md.getScale(i);
                int prec = md.getPrecision(i);
                if (scale == 0 && prec != 0) {
                    if (prec > 10) {
                        dt = "long";
                    } else {
                        dt = "int";
                    }
                }
            }
        }
        return dt;
    }

    public String getDbDatatypeName(int sqltype) {
        switch (sqltype) {
            case Types.DATE:
                return "datetime";
            default:
                return super.getDbDatatypeName(sqltype);
        }
    }

}
