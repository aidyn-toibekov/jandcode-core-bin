package jandcode.dbm.db.oracle;

import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.dbm.db.jdbc.*;

public class OracleDbManagerService extends JdbcDbManagerService {

    public boolean existDatabase() throws Exception {
        boolean res = false;
        Db dbsys = getSystemDb();
        dbsys.connect();
        try {
            DataStore a = dbsys.loadSql("select * from all_users where username=upper(:id)", getDbSource().getUsername());
            res = a.size() == 1;
        } finally {
            dbsys.disconnect();
        }
        return res;
    }

    public void createDatabase() throws Exception {
        Db dbsys = getSystemDb();
        dbsys.connect();
        try {
            dbsys.execSqlNative("create user " +
                    getDbSource().getUsername() +
                    " IDENTIFIED BY \"" + getDbSource().getPassword() +
                    "\" DEFAULT TABLESPACE \"USERS\"");
            dbsys.execSqlNative("GRANT \"DBA\" TO " + getDbSource().getUsername());
            dbsys.execSqlNative("GRANT EXECUTE ON DBMS_LOCK TO " + getDbSource().getUsername());
        } finally {
            dbsys.disconnect();
        }
    }

    public void dropDatabase() throws Exception {
        Db dbsys = getSystemDb();
        dbsys.connect();
        try {
            dbsys.execSqlNative("drop user " +
                    getDbSource().getUsername() +
                    " cascade"
            );
        } finally {
            dbsys.disconnect();
        }
    }

}
