package jandcode.dbm.db.oracle;

import jandcode.dbm.sqlfilter.impl.*;

/**
 * Построитель sql с фильтрацией
 */
public class OracleSqlFilter extends SqlFilterImpl {

    protected String makeSqlPaginate() {
        long pgSt = getParamPaginateStart() + 1;
        long pgEnd = pgSt + getParamPaginateLimit();
        //
        String s = getSqlLoad();
        return "select * from ( select rownum as r__n, r__all.* from (\n\n" +
                s +
                "\n\n) r__all ) where r__n>=" + pgSt + " and r__n<" + pgEnd;
    }

}
