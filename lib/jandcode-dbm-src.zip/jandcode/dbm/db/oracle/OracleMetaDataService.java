package jandcode.dbm.db.oracle;

import jandcode.dbm.data.*;
import jandcode.dbm.db.jdbc.*;

public class OracleMetaDataService extends JdbcMetaDataService {

    protected String getCurrentSchema() throws Exception {
        DataStore t = getDbSource().getDb().loadSql("select user from dual");
        return t.getCurRec().getValueString("user");
    }

}
