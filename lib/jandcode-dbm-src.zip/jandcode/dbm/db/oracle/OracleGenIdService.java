package jandcode.dbm.db.oracle;

import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.logging.*;

public class OracleGenIdService extends GenIdService {

    protected static Log log = LogFactory.getLog(OracleGenIdService.class);

    private long recoverIncrement = 1000;

    private String seqPrefix = "SEQ_";

    //////

    public long getNextId(String name, long count) {
        Db db = getDbSource().getDb();
        long res = 0;
        try {
            name = name.toUpperCase();
            DbQuery qR;
            if (count == 1) {
                qR = db.openSql("select ${seq_name}.nextval new_id from dual",
                        UtCnv.toMap("seq_name", seqPrefix + name.toUpperCase()));
            } else {
                qR = db.openSql("select seq_pkg.get_next_id(:{seq_name},:{count}) new_id from dual",
                        UtCnv.toMap("seq_name", seqPrefix + name.toUpperCase(), "count", count));
            }

            try {
                res = qR.getValueLong("new_id");
            } finally {
                qR.close();
            }
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        return res;
    }

    public void setNextId(String name, long val) {
        try {
            getDbSource().getDb().execSql("begin\n" +
                    "seq_pkg.reset_seq(:{seq},:{val});\n" +
                    "end;",
                    UtCnv.toMap("seq", seqPrefix + name.toUpperCase(), "val", val));
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    public void recoverGenId() throws Exception {
        if (log.isInfoEnabled()) {
            log.info("Восстановление генераторов");
        }
        DataStore curTabs = getDbSource().getDb().loadSql("select table_name name from user_tables");
        DataIndex idxTabs = UtData.createIndex(curTabs, "name");
        //
        DataStore curGens = getDbSource().getDb().loadSql("select sequence_name name from user_sequences");
        for (DataRecord rec : curGens) {
            // имя генератора
            String genName = rec.getValueString("name").toUpperCase();
            String tabName = UtString.removePrefix(genName, seqPrefix);
            if (tabName == null) {
                // это не наш генератор, у него нет префикса
                continue;
            }
            DataRecord tb = idxTabs.get(tabName);
            if (tb == null) {
                // и это не наш генератор, нет такой таблицы
                continue;
            }
            //
            try {
                getDbSource().getDb().execSql("begin\n" +
                        "seq_pkg.recover_gen_id(:{seq},:{rec_inc},:{seq_pref});\n" +
                        "end;",
                        UtCnv.toMap(
                                "seq", genName,
                                "rec_inc", recoverIncrement,
                                "seq_pref", seqPrefix)
                );
                if (log.isInfoEnabled()) {
                    log.info("Генератор: " + genName + " обновлен");
                }
            } catch (Exception e) {
                if (log.isWarnEnabled()) {
                    log.warn("Ошибка при обновлении генератора: " + genName, e);
                }
            }
        }

        if (log.isInfoEnabled()) {
            log.info("Восстановление генераторов закончено");
        }
    }

}
