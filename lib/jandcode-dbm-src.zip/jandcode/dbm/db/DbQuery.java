package jandcode.dbm.db;

import jandcode.dbm.data.*;
import jandcode.dbm.data.impl.*;
import jandcode.utils.variant.*;

/**
 * Запрос к базе данных. Создается в {@link Db}.
 * После открытия через {@link DbQuery#open()} или {@link DbQuery#openNative()}
 * можно пользоваться как {@link DataRecord} с forward-only доступом (т.е. через
 * next(), eof()).
 * <p/>
 * После открытия запроса автоматически выполняется первый next().
 */
public abstract class DbQuery extends CustomDataRecord {

    /**
     * Оригинальный sql
     */
    public abstract String getSql();

    /**
     * Подготовленный к выполнению sql
     */
    public abstract String getSqlPrepared();

    /**
     * Параметры запроса. Можно свободно писать.
     */
    public abstract IVariantMap getParams();

    /**
     * Установить параметры
     */
    public abstract void setParams(Object params);

    //////

    /**
     * Выполнить нативно. Выполняется {@link DbQuery#getSql()} без параметров.
     */
    public abstract void execNative() throws Exception;

    /**
     * Открыть нативно. Выполняется {@link DbQuery#getSql()} без параметров.
     */
    public abstract void openNative() throws Exception;

    /**
     * Выполнить. Выполняется {@link DbQuery#getSqlPrepared()} c параметрами.
     */
    public abstract void exec() throws Exception;

    /**
     * Открыть. Выполняется {@link DbQuery#getSqlPrepared()} c параметрами.
     */
    public abstract void open() throws Exception;

    /**
     * Закрыть. Обязательно вызывать, если выполнялись методы {@link DbQuery#open()}
     * или {@link DbQuery#openNative()}.
     *
     * @throws Exception
     */
    public abstract void close() throws Exception;

    /**
     * Проверка на конец данных
     */
    public abstract boolean eof() throws Exception;

    /**
     * Загрузить следующую запись
     */
    public abstract void next() throws Exception;

}
