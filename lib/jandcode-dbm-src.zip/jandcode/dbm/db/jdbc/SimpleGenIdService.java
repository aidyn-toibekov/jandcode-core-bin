package jandcode.dbm.db.jdbc;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Простой генератор. Хранит данные в отдельной таблице, где каждая строка содержит имя таблицы
 * и последнее значение генератора.
 */
public class SimpleGenIdService extends GenIdService {

    private String _genTableName = "sys_jc_GenId";
    private long _recoverIncrement = 1000;

    //////

    public String getGenTableName() {
        return _genTableName;
    }

    public void setGenTableName(String genTableName) {
        _genTableName = genTableName;
    }

    //////

    public long getNextId(String name, long count) {
        Db db = getDbSource().getDb();
        long res = 0;
        try {
            name = name.toUpperCase();
            db.startTran();
            try {
                db.execSqlNative("update " + getGenTableName() + " set val=val+" + count +
                        " where name='" + name + "'");
                DbQuery q = db.openSqlNative("select val from " + getGenTableName() +
                        " where name='" + name + "'");
                try {
                    if (q.eof()) {
                        throw new XError("Не найден генератор [{0}]", name);
                    }
                    res = q.getValueLong("val");
                } finally {
                    q.close();
                }
                db.commit();
            } catch (Exception e) {
                db.rollback();
                throw e;
            }
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        return res;
    }

    public void setNextId(String name, long val) {
        try {
            getDbSource().getDb().execSqlNative("update " + getGenTableName() + " set val=" + val + " where name='" + name + "'");
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    public void recoverGenId() throws Exception {
        if (log.isInfoEnabled()) {
            log.info("Восстановление генераторов");
        }

        Db db = getDbSource().getDb();

        // берем текущие генераторы
        if (log.isInfoEnabled()) {
            log.info("Загрузка текущих генераторов");
        }
        DataStore tb = db.loadSql("select * from " + getGenTableName());
        HashMap<String, Long> gensCur = new HashMap<String, Long>();
        for (DataRecord t : tb) {
            gensCur.put(t.getValueString("name").toUpperCase(), t.getValueLong("val"));
        }

        // берем физические значения для генераторов
        if (log.isInfoEnabled()) {
            log.info("Загрузка текущих максимальных значений");
        }
        HashMap<String, Long> gensPhys = new HashMap<String, Long>();
        ListComp<Domain> tabsInDb = db.service(MetaDataService.class).loadTables();
        for (Domain t : tabsInDb) {
            if (log.isInfoEnabled()) {
                log.info("Таблица: " + t.getName());
            }
            if (t.findField("id") == null) {
                if (log.isInfoEnabled()) {
                    log.info(" - пропущена, нет id");
                }
                continue;
            }
            try {
                DataStore t1 = db.loadSql("select max(id) as mxv from " + t.getName());
                long max = t1.getCurRec().getValueLong("mxv");
                if (log.isInfoEnabled()) {
                    log.info(" - max(id) - " + max);
                }
                gensPhys.put(t.getName().toUpperCase(), max);
            } catch (Exception e) {
                log.error(" - error: " + e.getMessage());
            }
        }

        // проверяем
        for (Map.Entry<String, Long> entry : gensPhys.entrySet()) {
            Long cur = gensCur.get(entry.getKey());
            if (cur == null) {
                // нет такого, создаем
                DbQuery q = db.createQuery("insert into " + getGenTableName() +
                        "(name,val) values (:{name},:{val})");
                q.getParams().put("name", entry.getKey());
                long newVal = entry.getValue() + _recoverIncrement;
                q.getParams().put("val", newVal);
                q.exec();

                if (log.isInfoEnabled()) {
                    log.info("Создан генератор " + entry.getKey() + " со значением " + newVal);
                }

            } else {
                if (entry.getValue() > cur) {
                    // есть, но меньше - пересоздаем
                    DbQuery q = db.createQuery("update " + getGenTableName() +
                            " set val=:{val} where name=:{name}");
                    q.getParams().put("name", entry.getKey());
                    long newVal = entry.getValue() + _recoverIncrement;
                    q.getParams().put("val", entry.getValue() + _recoverIncrement);
                    q.exec();

                    if (log.isInfoEnabled()) {
                        log.info("Обновлен генератор " + entry.getKey() + " на значение " + newVal + " со значения " + cur);
                    }
                }
            }
        }

        if (log.isInfoEnabled()) {
            log.info("Восстановление генераторов закончено");
        }

        // все
    }

}
