package jandcode.dbm.db.jdbc;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.db.*;

import java.sql.*;

/**
 * Стандартная реализация MetaDataService через jdbc
 */
public class JdbcMetaDataService extends MetaDataService {

    protected String getCurrentSchema() throws Exception {
        return null;
    }

    protected String getCurrentCatalog() throws Exception {
        return null;
    }

    public ListComp<Domain> loadTables() throws Exception {
        ListComp<Domain> res = new ListComp<Domain>();

        Db db = getDbSource().getDb();
        db.connect();
        try {

            String sh = getCurrentSchema();
            String ct = getCurrentCatalog();

            DatabaseMetaData md = db.getConnection().getMetaData();

            // все таблицы
            ResultSet rs = md.getTables(ct, sh, null, null);

            try {
                while (rs.next()) {
                    String typ = rs.getString("TABLE_TYPE");
                    String nm = rs.getString("TABLE_NAME");
                    if (nm.startsWith("BIN$")) {
                        continue;
                    }
                    if ("TABLE".equals(typ) || "VIEW".equals(typ)) {
                        Domain t = getModel().createDomain("sys");
                        t.setName(nm);
                        res.add(t);
                    }
                }
            } finally {
                rs.close();
            }

            // все колонки
            rs = md.getColumns(ct, sh, null, null);
            try {
                while (rs.next()) {
                    Domain t = res.find(rs.getString("TABLE_NAME"));
                    if (t == null) {
                        continue;
                    }
                    String nm = rs.getString("COLUMN_NAME");
                    String tp = getDbSource().getDbDriver().getFieldTypeName(rs.getInt("DATA_TYPE"));
                    int sz = rs.getInt("COLUMN_SIZE");
                    Field f = t.addField(nm, tp);
                    if (sz > 0) {
                        f.setSize(sz);
                    }
                }
            } finally {
                rs.close();
            }
        } finally {
            db.disconnect();
        }
        return res;
    }

}
