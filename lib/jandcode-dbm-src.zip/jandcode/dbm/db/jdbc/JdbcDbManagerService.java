package jandcode.dbm.db.jdbc;

import jandcode.app.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;

import java.util.*;

public class JdbcDbManagerService extends DbManagerService {

    protected Db _systemDb;

    /**
     * Системная база данных. Определеяется как клон основной, где
     * свойства заменены свойствами с превиксом 'system.'
     */
    protected Db getSystemDb() {
        if (_systemDb == null) {
            DbSource dbdefsys = (DbSource) getDbSource().clone();
            IReflectClazz cr = getApp().service(ReflectService.class).getClazz(dbdefsys.getClass());
            Map<String, Object> props = dbdefsys.getProps();
            for (String a : props.keySet()) {
                String pn = UtString.removePrefix(a, "system.");
                if (pn != null) {
                    cr.invokeSetter(dbdefsys, pn, props.get(a));
                }
            }
            dbdefsys.setName("system");
            _systemDb = dbdefsys.getDb();
        }
        return _systemDb;
    }

    public boolean existDatabase() throws Exception {
        return false;
    }

    public void createDatabase() throws Exception {
    }

    public void dropDatabase() throws Exception {
    }

}
