package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.*;

/**
 * Метаданные базы данных
 */
public abstract class MetaDataService extends DbSourceMember {

    /**
     * Все таблицы базы данных в виде набора доменов
     */
    public abstract ListComp<Domain> loadTables() throws Exception;

}
