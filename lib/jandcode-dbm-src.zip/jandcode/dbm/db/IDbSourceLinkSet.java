package jandcode.dbm.db;

/**
 * Интерфейс для объектов, знающих о связанной базе данных
 */
public interface IDbSourceLinkSet {

    /**
     * Установить ссылкe на базу данных
     */
    void setDbSource(DbSource dbSource);


}
