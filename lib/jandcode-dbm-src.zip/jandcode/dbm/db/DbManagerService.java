package jandcode.dbm.db;

/**
 * Сервис для управления базой данных (создание/удаление/генерация ...)
 */
public abstract class DbManagerService extends DbSourceMember {

    /**
     * Существует ли база данных
     */
    public abstract boolean existDatabase() throws Exception;

    /**
     * Создание базы данных
     */
    public abstract void createDatabase() throws Exception;

    /**
     * Удаление базы данных
     */
    public abstract void dropDatabase() throws Exception;

}
