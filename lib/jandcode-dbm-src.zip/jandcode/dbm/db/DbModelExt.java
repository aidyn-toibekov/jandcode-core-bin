package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Расширение для модели, рассматривающее модель, как структуру базу данных.
 * Что выбирается:
 * <pre>{@code
 * <ddl>
 *     ddl sql operator
 * </ddl>
 * }</pre>
 */
public class DbModelExt extends ModelExt {

    private ListDomain _tables;
    private Domain domain;

    public DbModelExt(Model model) {
        super(model);
    }

    /**
     * Возвращает список текстов из <ddl> узлов объекта from
     *
     * @param from откуда
     * @param type тип (значение атрибута type у узла <ddl>, которое
     *             по умолчанию считается 'create')
     */
    public List<String> getDdls(CompRt from, String type) {
        List<String> res = new ArrayList<String>();
        Rt z = from.getRt().findChild("ddl");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                String type1 = z1.getValueString("type");
                if (UtString.empty(type1)) type1 = "create";
                if (!type1.equals(type)) continue;
                //
                Sql sql = (Sql) getModel().getObjectFactory().create(z1, Sql.class);
                String s = sql.getText();
                if (!UtString.empty(s)) {
                    res.add(s);
                }
            }
        }
        return res;
    }

    ////// for generation

    public DbDriver getDbDriver() {
        return getModel().getDbSource().getDbDriver();
    }

    /**
     * Разделитель sql операторов в скриптах (по умолчанию '~~').
     */
    public String getDelim() {
        return getModel().getDb().getScriptDelimiter();
    }

    /**
     * Все таблицы в базе данных (включая view)
     */
    public ListDomain tables() {
        if (_tables == null) {
            _tables = getModel().getDomainsDb();
        }
        return _tables;
    }

    /**
     * Все реальные поля домена (вычисляемые поля исключены)
     */
    public ListComp<Field> fields(Domain t) {
        ListComp<Field> res = new ListComp<Field>();
        for (Field f : t.getFields()) {
            if (f.isCalc()) {
                continue;
            }
            res.add(f);
        }
        return res;
    }

    /**
     * Домен по имени
     */
    public Domain table(String domainName) {
        return tables().get(domainName);
    }

    /**
     * Домен по имени
     */
    public Domain domain(String domainName) {
        return tables().get(domainName);
    }

    /**
     * Домен по имени. null, если не найден
     */
    public Domain findDomain(String domainName) {
        return tables().find(domainName);
    }

    /**
     * Информация о домене как о таблице в базе данных
     */
    public DbDomainExt dbtable(Domain t) {
        return new DbDomainExt(t);
    }

    /**
     * Информация о домене как о таблице в базе данных по имени
     */
    public DbDomainExt dbtable(String domainName) {
        return dbtable(domain(domainName));
    }

    /**
     * Информация о поле как о поле в базе данных
     */
    public DbFieldExt dbfield(Field t) {
        return new DbFieldExt(t);
    }

    /**
     * Информация о поле как о поле в базе данных
     */
    public DbFieldExt sqlfield(Field t) {
        return new DbFieldExt(t);
    }

    //////

    protected void appendDdl(StringBuilder sb, CompRt from, String type) {
        List<String> lst = getDdls(from, type);
        if (from instanceof Domain && lst.size() > 0) {
            sb.append("<% th.domain=th.tables().get('" + from.getName() + "'); %>\n");
        }
        for (String s : lst) {
            sb.append(s);
            sb.append("\n${th.delim}\n");
        }
    }

    /**
     * Возвращает шаблон для генерации полного create.sql для базы данных.
     * Шаблон предназначен для использования утилитой jc.
     * В шаблоне доступна переменная th типа jandcode.dbm.db.DbModelExt
     *
     * @param type тип (create, create-references, drop-references)
     * @return текст шаблона
     * @throws Exception
     */
    public String grabTemplateDdl(String type) throws Exception {
        StringBuilder sb = new StringBuilder();
        // из драйвера базы данных
        appendDdl(sb, getModel().getDbSource().getDbDriver(), type);
        // из всех доменов
        for (Domain domain : tables()) {
            appendDdl(sb, domain, type);
        }
        // из всех сервисов DbSource
        for (Object svc : getModel().getDbSource().getServices()) {
            if (svc instanceof CompRt) {
                appendDdl(sb, (CompRt) svc, type);
            }
        }
        // из всех сервисов модели
        for (Object svc : getModel().getServices()) {
            if (svc instanceof CompRt) {
                appendDdl(sb, (CompRt) svc, type);
            }
        }
        // из самой модели
        appendDdl(sb, getModel(), type);
        //
        return sb.toString();
    }

    /**
     * Текущий домен. Когда генерируется скрипт в рамках домена, в этом
     * свойстве (th.domain) будет ссылка на текущий домен
     */
    public Domain getDomain() {
        if (domain == null) {
            throw new XError("Текущий домен не определен");
        }
        return domain;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
    }
}
