package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.*;

/**
 * Член DbSource
 */
public class DbSourceMember extends ModelMember implements IDbSourceLink, IDbSourceLinkSet {

    private DbSource dbSource;

    protected void onClone(Comp r) {
        super.onClone(r);
        DbSourceMember f = (DbSourceMember) r;
        f.dbSource = dbSource;
    }

    public DbSource getDbSource() {
        return dbSource;
    }

    public void setDbSource(DbSource dbSource) {
        this.dbSource = dbSource;
    }

}
