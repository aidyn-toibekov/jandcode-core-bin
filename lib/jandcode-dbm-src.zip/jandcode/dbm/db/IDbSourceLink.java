package jandcode.dbm.db;

/**
 * Интерфейс для объектов, знающих о связанной базе данных
 */
public interface IDbSourceLink {

    /**
     * Ссылка на базу данных
     */
    DbSource getDbSource();


}
