package jandcode.dbm.db;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Описание базы данных.
 * <p/>
 * clone нужен для утилит командной строки (для формирования системных DbSource)
 */
public class DbSource extends ModelMember implements IServiceHolder, ISubstVar, IObjectFactoryLink, IIniter, IUnknownRtAttr {

    private String jdbcDriverClass;
    private String database;
    private String host;
    private String username;
    private String password;
    private String url;
    private String dbDriverName = "jdbc";
    private DbDriver dbDriver;
    protected ServiceContainer services = new ServiceContainer();
    private ThreadLocalDb threadLocalDb = new ThreadLocalDb();
    private String dbType;
    private Props props = new Props();
    private ObjectFactory objectFactory = new ObjectFactory(this);

    protected void onClone(Comp r) {
        super.onClone(r);
        DbSource a = (DbSource) r;
        a.jdbcDriverClass = jdbcDriverClass;
        a.database = database;
        a.host = host;
        a.username = username;
        a.password = password;
        a.url = url;
        a.dbDriverName = dbDriverName;
        a.dbType = dbType;
        a.props.putAll(props);
        for (Map.Entry<Class, Object> en : services.getItems().entrySet()) {
            Object svcClone = ((Comp) en.getValue()).clone();
            a.services.add(en.getKey(), svcClone);
        }
        a.getDbDriver();
    }

    /**
     * Потоковые переменные db
     */
    class ThreadLocalDb extends ThreadLocal<Db> {
        protected Db initialValue() {
            return createDb();
        }
    }

    /**
     * Свойства dbdef
     */
    class Props extends VariantMap {
        public Object get(Object key) {
            String nm = UtString.toString(key);
            if ("jdbcDriverClass".equalsIgnoreCase(nm)) {
                return getJdbcDriverClass();
            } else if ("database".equalsIgnoreCase(nm)) {
                return getDatabase();
            } else if ("host".equalsIgnoreCase(nm)) {
                return getHost();
            } else if ("username".equalsIgnoreCase(nm)) {
                return getUsername();
            } else if ("password".equalsIgnoreCase(nm)) {
                return getPassword();
            } else if ("url".equalsIgnoreCase(nm)) {
                return getUrl();
            } else if ("dbtype".equalsIgnoreCase(nm)) {
                return getDbType();
            }
            return super.get(key);
        }
    }

    //////

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);
        //
        // сервисы
        services.addAll(rt.findChild("service"), objectFactory);

        // конфигурирование
        String configKey = rt.getValueString("config.path", "db/" + getModel().getName());
        Rt cfg = getApp().getRt().findChild(configKey);
        if (cfg != null) {
            setRtAttrs(cfg);
        }

        // настройка драйвера
        getDbDriver();

    }

    /**
     * Все левые свойства попадают в props
     */
    public void onUnknownRtAttr(String name, Object value) {
        setProp(name, value);
    }

    public Props getProps() {
        return props;
    }

    public void setProp(String name, Object value) {
        props.put(name, value);
    }

    public Object getProp(String name) {
        return props.get(name);
    }

    public boolean hasProp(String name) {
        return props.containsKey(name);
    }

    public Object getProp(String name, Object defaultValue) {
        if (props.containsKey(name)) {
            return props.get(name);
        }
        return defaultValue;
    }

    ////// services

    public <A extends Object> A service(Class<A> clazz) {
        return services.get(clazz);
    }

    public ServiceContainer getServices() {
        return services;
    }

    public ConnectionService getConnectionService() {
        return service(ConnectionService.class);
    }

    public MetaDataService getMetaDataService() {
        return service(MetaDataService.class);
    }

    public GenIdService getGenIdService() {
        return service(GenIdService.class);
    }

    public SqlBuilderService getSqlBuilderService() {
        return service(SqlBuilderService.class);
    }

    //////

    public String getJdbcDriverClass() {
        if (UtString.empty(jdbcDriverClass)) {
            return getDbDriver().getJdbcDriverClass();
        }
        return jdbcDriverClass;
    }

    public void setJdbcDriverClass(String jdbcDriverClass) {
        this.jdbcDriverClass = jdbcDriverClass;
    }

    //////

    public String getDatabase() {
        return database == null ? "" : database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    //////

    public String getHost() {
        return host == null ? "" : host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    //////

    public String getUsername() {
        return username == null ? "" : username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean hasUsername() {
        return username != null;
    }

    //////

    public String getPassword() {
        return password == null ? "" : password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean hasPassword() {
        return password != null;
    }

    //////

    /**
     * Для подстановок
     */
    public String onSubstVar(String v) {
        return UtCnv.toString(getProp(v));
    }

    /**
     * Строка соединения. Можно использовать подстановки ${property}
     * (например '${username}')
     */
    public String getUrl() {
        return UtString.substVar(getUrlAsIs(), this);
    }

    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * Получить url как есть, без раскрытия
     */
    public String getUrlAsIs() {
        if (UtString.empty(url)) {
            return getDbDriver().getUrl();
        }
        return url == null ? "" : url;
    }

    //////

    public DbDriver getDbDriver() {
        if (dbDriver != null) {
            return dbDriver;
        }
        if (dbDriverName == null) {
            throw new XError("Драйвер dbdriver не назначен");
        }
        Rt z = getApp().getRt().getChild("dbdriver/" + dbDriverName);
        dbDriver = (DbDriver) objectFactory.create(z);
        // забираем сервисы драйвера себе
        services.addAll(dbDriver.getRt().findChild("service"), objectFactory);
        //
        return dbDriver;
    }

    public void setDbDriver(String driverName) {
        this.dbDriverName = driverName;
        if (UtString.empty(this.dbDriverName)) {
            this.dbDriverName = "jdbc";
        }
        dbDriver = null;
        this.dbDriverName = driverName;
    }

    /**
     * Тип базы данных
     */
    public String getDbType() {
        if (UtString.empty(dbType)) {
            return getDbDriver().getDbType();
        }
        return dbType;
    }

    public void setDbType(String dbType) {
        this.dbType = dbType;
    }

    //////

    /**
     * Создает новый экземпляр Db
     *
     * @return
     */
    public Db createDb() {
        Db db = objectFactory.create(Db.class);
        return db;
    }

    /**
     * Возвращает экземпляр Db. Этот экземпляр принадлежит потоку,
     * и в рамках потока всегда возвращается один и тот же.
     * <p/>
     * Соединение для экземпляра Db не устанавливается автоматически!
     */
    public Db getDb() {
        return threadLocalDb.get();
    }

    public ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    public void initObject(Object obj) throws Exception {
        getModel().initObject(obj);
        if (obj instanceof IDbSourceLinkSet) {
            ((IDbSourceLinkSet) obj).setDbSource(this);
        }
    }
}
