package jandcode.dbm.db;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

/**
 * Объект для хранения sql, описанного в rt. Обычно описываются в узлах sql.
 * Текст sql хранится либо в тексте узла, либо в файле, указанного в атрибуте 'file'.
 * Если есть дочерние узлы sql, то имя таких узлов определяет тип базы данных,
 * для которой предназначен sql
 * <pre>{@code
 * <sql>
 *     select * from aaa
 * </sql>
 * <sql file="#{path}/sqltext.sql"/>
 * <sql>
 *     select * from aaa
 *     <sql name="oracle">
 *         select * from aaa for oracle
 *     </sql>
 * </sql>
 * <sql file="#{path}/sqltext.sql" file.oracle="#{path}/sqltext-oracle.sql"/>
 * }</pre>
 */
public class Sql extends ModelMember {

    private String text;

    /**
     * Текст sql
     */
    public String getText() {
        if (text == null) {
            text = getTextFromRt();
        }
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    //////

    protected String getTextFromRt() {
        String dbtype = getModel().getDbSource().getDbType();
        Rt rt = getRt();
        String fn = rt.getValueString("file." + dbtype);
        if (!UtString.empty(fn)) {
            return getTextFromFile(fn);
        }
        fn = rt.getValueString("file");
        if (!UtString.empty(fn)) {
            return getTextFromFile(fn);
        }
        Rt z = rt.findChild("sql/" + dbtype);
        if (z != null) {
            return z.getValueString(Rt.TEXT);
        }
        return rt.getValueString(Rt.TEXT);
    }

    protected String getTextFromFile(String fn) {
        try {
            return UtFile.loadString(fn);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

}
