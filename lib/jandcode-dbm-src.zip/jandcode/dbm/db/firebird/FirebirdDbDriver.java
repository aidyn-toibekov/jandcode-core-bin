package jandcode.dbm.db.firebird;

import jandcode.dbm.db.*;

public class FirebirdDbDriver extends DbDriver {
    public FirebirdDbDriver() {
        setDbType("firebird");
    }
}
