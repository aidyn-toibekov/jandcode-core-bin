package jandcode.dbm.db.derby;

import jandcode.dbm.sqlfilter.impl.*;

public class DerbySqlFilter extends SqlFilterImpl {

    protected String makeSqlPaginate() {
        String s = getSqlLoad();
        return s + " offset " + getParamPaginateStart() + " rows fetch next " + getParamPaginateLimit() + " rows only";
    }

}
