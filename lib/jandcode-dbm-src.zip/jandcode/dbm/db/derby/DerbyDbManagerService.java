package jandcode.dbm.db.derby;

import jandcode.dbm.db.*;
import jandcode.dbm.db.jdbc.*;
import jandcode.utils.*;

import java.io.*;

public class DerbyDbManagerService extends JdbcDbManagerService {

    public boolean existDatabase() throws Exception {
        File f = new File(getDbSource().getDatabase());
        return f.exists() && f.isDirectory();
    }

    public void createDatabase() throws Exception {
        DbSource dbs = (DbSource) getDbSource().clone();
        dbs.setUrl(dbs.getUrlAsIs() + ";create=true");
        Db db = dbs.getDb();
        db.connect();
        db.disconnect();
    }

    public void dropDatabase() throws Exception {
        File f = new File(getDbSource().getDatabase());
        UtFile.cleanDir(f);
        f.delete();
    }
}
