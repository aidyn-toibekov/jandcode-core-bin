package jandcode.dbm.db.derby;

import jandcode.dbm.db.*;

import java.sql.*;

public class DerbyDbDriver extends DbDriver {
    public DerbyDbDriver() {
        setDbType("derby");
    }

    public void setNullParam(PreparedStatement statement, int paramIdx, int datatype) throws Exception {
        statement.setObject(paramIdx, null); // ха!
    }

}
