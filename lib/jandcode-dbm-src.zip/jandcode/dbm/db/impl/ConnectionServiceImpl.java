package jandcode.dbm.db.impl;

import jandcode.dbm.db.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import org.apache.commons.dbcp.*;

import java.sql.*;
import java.util.*;

/**
 * Реализация через org.apache.commons.dbcp.BasicDataSource
 */
public class ConnectionServiceImpl extends ConnectionService {

    private BasicDataSource datasource;

    public Connection connect() {
        try {
            return getDatasource().getConnection();
        } catch (SQLException e) {
            throw new XErrorWrap(e);
        }
    }

    public void disconnect(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                throw new XErrorWrap(e);
            }
        }
    }

    public void disconnectAll() {
        try {
            getDatasource().close();
        } catch (SQLException e) {
            throw new XErrorWrap(e);
        }
    }

    public BasicDataSource getDatasource() {
        if (datasource == null) {
            synchronized (this) {
                if (datasource != null) {
                    return datasource;
                }
                datasource = createDatasource();
            }
        }
        return datasource;
    }

    protected BasicDataSource createDatasource() {
        BasicDataSource bds = new BasicDataSource();
        DbSource dbSource = getDbSource();
        String cn = dbSource.getJdbcDriverClass();
        try {
            getApp().getClass(cn);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
        bds.setDriverClassName(cn);
        bds.setUrl(dbSource.getUrl());
        if (dbSource.hasUsername()) {
            bds.setUsername(dbSource.getUsername());
        }
        if (dbSource.hasPassword()) {
            bds.setPassword(dbSource.getPassword());
        }
        String db = dbSource.getDatabase();
        if (!UtString.empty(db)) {
            bds.setDefaultCatalog(db);
        }
        // connection properties
        Map<String, Object> props = dbSource.getProps();
        for (String key : props.keySet()) {
            String prop = UtString.removePrefix(key, "conn.");
            if (prop != null) {
                bds.addConnectionProperty(prop, UtCnv.toString(props.get(key)));
            }
        }
        //
        String vq = getValidationQuery();
        if (!UtString.empty(vq)) {
            bds.setValidationQuery(vq);
        }
        //
        return bds;
    }

    /**
     * Возвращает validationQuery для типа базы данных
     * @return
     */
    protected String getValidationQuery() {
        return getRt().getValueString("validationQuery." + getDbSource().getDbType());
    }

}
