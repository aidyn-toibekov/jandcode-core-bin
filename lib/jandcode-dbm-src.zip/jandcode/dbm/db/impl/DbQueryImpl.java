package jandcode.dbm.db.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import jandcode.dbm.impl.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.test.*;
import jandcode.utils.variant.*;
import org.apache.commons.logging.*;

import java.sql.*;

public class DbQueryImpl extends DbQuery {

    protected static Log log = LogFactory.getLog(DbQuery.class);
    protected static Log log_sqlPrepared = LogFactory.getLog(DbQuery.class.getName() + ".sqlPrepared");

    private Db db;
    private String sql;
    private String sqlPrepared;
    private SqlParamParser sqlParamParser;
    private TwoLevelVariantMap params;
    protected ResultSet resultSet;
    private Statement statement;

    private int lastRead = -1;
    private boolean eof;

    private StopWatch timer;

    protected Object[] data;
    protected Domain domain;

    public DbQueryImpl(Db db, Object sql, Object params) {
        this.db = db;
        this.params = new TwoLevelVariantMap();
        setParams(params);
        this.sql = sql.toString();
    }

    //////

    /**
     * Строит информацию для отладки и логирования
     */
    protected String buildDebugInfo() {
        String d = "~";
        int len = 45;
        StringBuilder sb = new StringBuilder();
        boolean razn = sqlPrepared != null && !sqlPrepared.trim().equalsIgnoreCase(sql.trim()) && log_sqlPrepared.isInfoEnabled();
        sb.append("\n").append(UtString.delim("SQL", d, len)).append("\n");
        sb.append(UtString.normalizeIndent(sql)).append("\n");
        if (razn) {
            sb.append(UtString.delim("SQL prepared", d, len)).append("\n");
            sb.append(UtString.normalizeIndent(sqlPrepared)).append("\n");
        }
        if (sqlParamParser != null && sqlParamParser.getParams().size() > 0) {
            sb.append(UtString.delim("Params", d, len)).append("\n");
            for (String pn : sqlParamParser.getParams()) {
                if (params.isValueNull(pn)) {
                    sb.append(pn).append("=<NULL>\n");
                } else if (params.getDataType(pn) == DataType.BLOB) {
                    sb.append(pn).append("=").append("<BLOB>").append("\n");
                } else {
                    sb.append(pn).append("=").append(params.getValueString(pn)).append("\n");
                }
            }
        }
        sb.append(UtString.delim("", d, len));
        return sb.toString();
    }

    protected void logSqlStart() {
        if (log.isInfoEnabled()) {
            timer = new StopWatch(false, false);
            timer.start("sql");
            log.info(buildDebugInfo());
        }
    }

    protected void logSqlStop() {
        if (log.isInfoEnabled()) {
            if (timer != null) {
                timer.stop();
                log.info(timer.getLastMessage());
                timer = null;
            }
        }
    }

    protected void markError(Throwable e) {
        if (!db.getApp().isRelease()) {
            throw new XErrorMark(e, buildDebugInfo());
        } else {
            throw new XErrorWrap(e);
        }
    }

    //////

    public void execNative() throws Exception {
        try {
            createStatement();
            logSqlStart();
            statement.execute(sql);
            logSqlStop();
        } catch (Exception e) {
            markError(e);
        }
    }

    public void openNative() throws Exception {
        try {
            createStatement();
            logSqlStart();
            resultSet = statement.executeQuery(sql);
            bindResultSet();
            logSqlStop();
        } catch (Exception e) {
            markError(e);
        }
    }

    public void exec() throws Exception {
        try {
            prepareStatement();
            assignParams();
            logSqlStart();
            ((PreparedStatement) statement).execute();
            logSqlStop();
        } catch (Exception e) {
            markError(e);
        }
    }

    public void open() throws Exception {
        try {
            prepareStatement();
            assignParams();
            logSqlStart();
            if (!((PreparedStatement) statement).execute()) {
                throw new XError("Запрос не вернул результатов");
            }
            resultSet = statement.getResultSet();
            bindResultSet();
            logSqlStop();
        } catch (Exception e) {
            markError(e);
        }
    }

    public void close() throws Exception {
        if (resultSet != null) {
            try {
                try {
                    resultSet.close();
                } catch (Exception e) {
                }
            } finally {
                resultSet = null;
            }
        }
        if (statement != null) {
            try {
                statement.close();
            } catch (Exception e) {
            }
        }
    }

    //////


    public String getSql() {
        return sql;
    }

    public String getSqlPrepared() {
        if (sqlPrepared == null) {
            sqlParamParser = new SqlParamParser(this.sql, this.params);
            sqlPrepared = sqlParamParser.getResult();
        }
        return sqlPrepared;
    }

    public IVariantMap getParams() {
        return params;
    }

    public void setParams(Object params) {
        this.params.setLevel2(UtData.toVariantNamed(params));
    }

    //////

    protected void prepareStatement() throws Exception {
        if (statement != null) {
            return;
        }
        statement = db.getConnection().prepareStatement(getSqlPrepared());
    }

    protected void createStatement() throws Exception {
        if (statement != null) {
            return;
        }
        statement = db.getConnection().createStatement();
    }

    protected void assignParams() throws Exception {
        db.getDbSource().getDbDriver().assignStatementParams((PreparedStatement) statement, params, sqlParamParser.getParams());
    }

    //////

    public DataStore getStore() {
        throw new XError("getStore unsupported for dbquery");
    }

    public Domain getDomain() {
        return domain;
    }

    protected void bindResultSet() throws Exception {
        if (resultSet == null) {
            return;
        }
        DbDriver driver = db.getDbSource().getDbDriver();
        domain = driver.createDomain(resultSet);
        data = new Object[domain.getFields().size()];
        eof = false;
        next();
    }

    public void bindResultSet(ResultSet rs) throws Exception {
        close();
        resultSet = rs;
        bindResultSet();
    }

    public void setInternalValue(Field field, Object value) {
        throw new XError("setInternalValue unsupported for dbquery");
    }

    public Object getInternalValue(Field field) {
        try {
            int index = field.getIndex();
            if (lastRead < index) {
                DbDriver driver = db.getDbSource().getDbDriver();
                // поле еще не читалось!
                // читаем последовательно до нужного
                for (int i = lastRead + 1; i <= index; i++) {
                    Field vf = domain.getFields().get(i);
                    DbDatatype dt = (DbDatatype) vf.getProp(DbDriver.FIELDPROP_dbdatatypeLINK);
                    data[i] = dt.readValue(resultSet, vf.getIndex() + 1, vf);
                }
                lastRead = index;
            }
            return data[index];
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    public boolean eof() throws Exception {
        return this.eof;
    }

    public void next() throws Exception {
        if (eof) {
            return;
        }
        lastRead = -1;
        try {
            eof = !resultSet.next();
        } catch (SQLException e) {
            throw new XErrorWrap(e);
        }
    }

    public boolean isValueExists(Field field) {
        // для query значение существует
        return true;
    }

    public void clearValue(Field field) {
        throw new XError("unsupported clearValue");
    }

    public void clearValues() {
        throw new XError("unsupported clearValues");
    }
}
