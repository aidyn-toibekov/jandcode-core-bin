package jandcode.dbm.db.impl.dbt;

import jandcode.dbm.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;

import java.sql.*;

public class Dbt_memo extends DbDatatype {
    public Object readValue(ResultSet rs, int columnIdx, Field f) throws Exception {
        Object value = rs.getString(columnIdx);
        if (rs.wasNull()) {
            value = null;
        }
        return value;
    }

    public void setParam(PreparedStatement st, int paramIdx, int datatype, Object value) throws Exception {
        st.setString(paramIdx, UtCnv.toString(value));
    }

}
