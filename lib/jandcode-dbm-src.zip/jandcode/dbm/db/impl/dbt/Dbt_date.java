package jandcode.dbm.db.impl.dbt;

import jandcode.dbm.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;

import java.sql.*;

public class Dbt_date extends DbDatatype {

    public Object readValue(ResultSet rs, int columnIdx, Field f) throws Exception {
        Object value = UtCnv.toDateTime(rs.getTimestamp(columnIdx));
        if (rs.wasNull()) {
            value = null;
        }
        return value;
    }

    public void setParam(PreparedStatement st, int paramIdx, int datatype, Object value) throws Exception {
        st.setDate(paramIdx, new Date(UtCnv.toDateTime(value).getMillis()));
    }

}

