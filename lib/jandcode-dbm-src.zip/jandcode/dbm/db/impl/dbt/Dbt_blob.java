package jandcode.dbm.db.impl.dbt;

import jandcode.dbm.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;
import jandcode.utils.io.*;

import java.io.*;
import java.sql.*;

public class Dbt_blob extends DbDatatype {

    public Object readValue(ResultSet rs, int columnIdx, Field f) throws Exception {
        Object value = rs.getObject(columnIdx);
        if (value instanceof Blob) { // читаем блоб
            Blob b = (Blob) value;
            long len = b.length();
            value = b.getBytes(1, (int) len);
        } else if (value instanceof Clob) {
            Clob b = (Clob) value;
            Reader strm = b.getCharacterStream();
            try {
                StringLoader ldr = new StringLoader();
                UtLoad.fromReader(ldr, strm);
                value = ldr.getResult();
            } finally {
                strm.close();
            }
        } else if (value instanceof byte[]) {
        } else {
            value = null;
        }

        if (rs.wasNull()) {
            value = null;
        }

        return value;
    }

    public void setParam(PreparedStatement st, int paramIdx, int datatype, Object value) throws Exception {
        st.setBytes(paramIdx, UtCnv.toByteArray(value));
    }

}
