package jandcode.dbm.db.impl.dbt;

import jandcode.dbm.*;
import jandcode.dbm.db.*;

import java.sql.*;

public class Dbt_null extends DbDatatype {
    public Object readValue(ResultSet rs, int columnIdx, Field f) throws Exception {
        return null;
    }

    public void setParam(PreparedStatement st, int paramIdx, int datatype, Object value) throws Exception {
        st.setObject(paramIdx, null);
    }

}
