package jandcode.dbm.db;

import org.apache.commons.logging.*;

/**
 * Генератор id
 */
public abstract class GenIdService extends DbSourceMember {

    protected static Log log = LogFactory.getLog(GenIdService.class);

    /**
     * Кешированный генератор уникальных ID.
     */
    public class GenIdCached {

        private long from;
        private long to;
        private long cacheSize;
        private String name;

        public GenIdCached(String name, long cacheSize) {
            this.name = name;
            this.cacheSize = cacheSize;
            loadNextBlock();
        }

        private void loadNextBlock() {
            to = GenIdService.this.getNextId(name, cacheSize);
            from = to - cacheSize;
        }

        public long getNextId() {
            if (from >= to) {
                loadNextBlock();
            }
            from++;
            return from;
        }

    }

    /**
     * Получить следующее уникальное значение
     *
     * @param name  имя генератора
     * @param count количество значений (может быть отрицательным)
     * @return новое уникальное значение
     */
    public abstract long getNextId(String name, long count);

    /**
     * Получить следующее уникальное значение
     *
     * @param name имя генератора
     * @return новое уникальное значение
     */
    public long getNextId(String name) {
        return getNextId(name, 1);
    }

    /**
     * Установить значение, которое будет возвращено следующим getNextId.
     * Сброс генератора.
     *
     * @param name имя генератора
     * @param val  новое значение генератора
     */
    public abstract void setNextId(String name, long val);

    /**
     * Возвращает объект для кешированного получения уникальных значений.
     *
     * @param name      имя генаратора
     * @param cacheSize размер кеша
     * @return кеш-генератор
     */
    public GenIdCached getGenIdCached(String name, long cacheSize) {
        return new GenIdCached(name, cacheSize);
    }

    /**
     * Восстановить состояние генераторов в соответствии с текущим положением в базе данных.
     * Используется обычно только в цикле разработки/установки.
     */
    public abstract void recoverGenId() throws Exception;

}
