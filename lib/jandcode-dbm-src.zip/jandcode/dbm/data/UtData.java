package jandcode.dbm.data;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.impl.*;
import jandcode.dbm.impl.*;
import jandcode.utils.*;
import jandcode.utils.easyxml.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Статические утилиты для данных
 */
public class UtData {

    // типы операция для записи
    public static final String INS = "ins";
    public static final String UPD = "upd";
    public static final String DEL = "del";

    public static final String PROP_IDE = "ide";
    public static final String PROP_CLIENTDATA = "clientdata";

    ////// variant

    /**
     * Преобразовать объект в IVariantNamed
     *
     * @param ob исходный объект
     * @return враппер объекта
     */
    public static IVariantNamed toVariantNamed(Object ob) {
        if (ob instanceof IVariantNamed) {
            return (IVariantNamed) ob;
        } else if (ob instanceof IValueNamed) {
            return new VnVariantNamedGet(ob);
        } else if (ob instanceof Map) {
            return new VariantMapWrap((Map) ob);
        } else {
            return new IdVariantNamedGet(ob);
        }
    }

    ////// store

    /**
     * Создать store для домена
     */
    public static DataStore createStore(Domain domain) {
        return new DataStoreImpl(domain);
    }

    ///// copier

    public static DataCopier createCopier(Domain src, Domain dst) {
        return new DataCopier(src, dst);
    }

    /**
     * Копировать данные записи из src в dst
     */
    public static void copyRecord(DataRecord src, DataRecord dst) {
        DataCopier cp = createCopier(src.getDomain(), dst.getDomain());
        cp.copyRecord(src, dst);
    }

    /**
     * Копировать все записи из src в dst
     */
    public static void copyStore(DataStore src, DataStore dst) {
        DataCopier cp = createCopier(src.getDomain(), dst.getDomain());
        cp.copyStore(src, dst);
    }

    /**
     * Создать копию данных src
     */
    public static DataStore copyStore(DataStore src) {
        DataStore dst = createStore(src.getDomain());
        copyStore(src, dst);
        return dst;
    }

    ////// index

    /**
     * Создать индекс для быстрого доступа к записям
     *
     * @param store     для какого store
     * @param fieldName для какого поля
     * @return индекс
     */
    public static DataIndex createIndex(DataStore store, String fieldName) {
        DataIndex idx = new DataIndexImpl(store, fieldName);
        idx.reindex();
        return idx;
    }

    ////// tree

    /**
     * Создает пустой DataTreeNode
     *
     * @param rec запись для узла. Можно передавать null, если для корневого узла не
     *            нужна запись
     */
    public static DataTreeNode createTreeNode(DataRecord rec) {
        return new DataTreeNodeImpl(rec);
    }

    /**
     * Создает корневой DataTreeNode для store
     *
     * @param store store для корневого узла
     */
    public static DataTreeNode createTreeNodeRoot(DataStore store) {
        return new DataTreeNodeRootImpl(store);
    }

    /**
     * Построение дерева по id-parent.
     *
     * @param store           для какого store
     * @param idFieldName     имя поля id
     * @param parentFieldName имя поля parent
     * @return корневой узел дерева (без записи)
     */
    public static DataTreeNode createTreeIdParent(DataStore store, String idFieldName, String parentFieldName) {
        DataTreeNode root = createTreeNodeRoot(store);
        //
        Field idField = store.getDomain().f(idFieldName);
        Field parentField = store.getDomain().f(parentFieldName);
        //

        ArrayList<DataTreeNode> lst = new ArrayList<DataTreeNode>();
        HashMap<Object, DataTreeNode> map = new HashMap<Object, DataTreeNode>();

        for (DataRecord r : store) {
            DataTreeNode node = createTreeNode(r);
            lst.add(node);
            map.put(r.getValue(idField), node);
        }

        // добавляем в списки дочерних
        for (DataTreeNode node : lst) {
            DataTreeNode p = map.get(node.getRecord().getValue(parentField));
            if (p != null) {
                p.addChild(node);
            } else {
                root.addChild(node);
            }
        }

        // дерево готово...
        return root;
    }

    /**
     * Сканирование дерева
     *
     * @param root        с какого начинать
     * @param includeRoot вызывать ли visitor для root
     * @param visitor     интерфейс визитера
     */
    public static void scanTree(DataTreeNode root, boolean includeRoot, ITreeNodeVisitor visitor) {
        if (includeRoot) {
            visitor.visitNode(root);
        }
        if (root.hasChilds()) {
            for (DataTreeNode node : root.getChilds()) {
                scanTree(node, true, visitor);
            }
        }
    }

    /**
     * Возвращает все store, записи из которых используются в дереве
     *
     * @param root с какого узла начинаем
     */
    public static Set<DataStore> getTreeStores(DataTreeNode root) {
        final HashSet<DataStore> res = new HashSet<DataStore>();
        scanTree(root, true, new ITreeNodeVisitor() {
            public void visitNode(DataTreeNode node) {
                if (node.getRecord() != null) {
                    DataStore st = node.getRecord().getStore();
                    if (!res.contains(st)) {
                        res.add(st);
                    }
                }
            }
        });
        return res;
    }

    //////

    /**
     * Записать данные в xml
     *
     * @param from откуда
     * @param to   куда
     */
    public static void saveToXml(DataStore from, EasyXml to) {
        for (DataRecord rec : from) {
            String rn = getPropIde(rec);
            if (INS.equals(rn)) {
                rn = "row";
            }
            EasyXml x1 = to.addChild(rn);
            IVariantMap attrs = x1.getAttrs();
            for (Field f : from.getDomain().getFields()) {
                if (!rec.isValueNull(f)) {
                    attrs.put(f.getName(), rec.getValue(f));
                }
            }
        }
    }

    //////

    /**
     * Возвращает список уникальных значений из указанного поля
     *
     * @param from      из какой таблицы
     * @param fieldName какое поле
     * @return
     */
    public static Set uniqueValues(DataStore from, String fieldName) {
        Field f = from.getDomain().f(fieldName);
        LinkedHashSet res = new LinkedHashSet();
        for (DataRecord rec : from) {
            if (rec.isValueNull(f)) {
                continue;
            }
            Object v = rec.getValue(f);
            if (!res.contains(v)) {
                res.add(v);
            }
        }
        return res;
    }

    ////// outTable

    /**
     * Для отладки. Вывести таблицу на консоль
     */
    public static void outTable(DataStore t) {
        OutTableSaver sv = new OutTableSaver(t);
        String s = sv.save().toString();
        System.out.println(s);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     *
     * @param limit сколько максимум записей выводить
     */
    public static void outTable(DataStore t, int limit) {
        OutTableSaver sv = new OutTableSaver(t);
        sv.setLimit(limit);
        String s = sv.save().toString();
        System.out.println(s);
    }

    /**
     * Для отладки. Вывести запись в виде таблицы на консоль
     */
    public static void outTable(DataRecord t) {
        DataStore st = createStore(t.getDomain());
        st.add(t);
        OutTableSaver sv = new OutTableSaver(st);
        String s = sv.save().toString();
        System.out.println(s);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     */
    public static void outTable(DataTreeNode t) {
        OutTableSaver sv = new OutTableSaver(t);
        String s = sv.save().toString();
        System.out.println(s);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     *
     * @param limit сколько максимум записей выводить
     */
    public static void outTable(DataTreeNode t, int limit) {
        OutTableSaver sv = new OutTableSaver(t);
        sv.setLimit(limit);
        String s = sv.save().toString();
        System.out.println(s);
    }

    ////// record as data for ide

    /**
     * Устанавливает для записи свойство ide=flag
     */
    public static void setPropIde(DataRecord rec, String flag) {
        rec.setProp(PROP_IDE, flag);
    }

    /**
     * Возвращает для записи свойство ide. Если свойство не установлено, возвращает ins
     */
    public static String getPropIde(DataRecord rec) {
        return UtString.toString(rec.getProp(PROP_IDE, INS));
    }

    /**
     * Возвращает свойство 'clientdata' из record или store
     *
     * @param prop record или store
     */
    public static Map<String, Object> getPropClientData(ICustomProp prop) {
        if (prop.hasProp(PROP_CLIENTDATA)) {
            return (Map<String, Object>) prop.getProp(PROP_CLIENTDATA);
        }
        Map<String, Object> res = new LinkedHashMap<String, Object>();
        prop.setProp(PROP_CLIENTDATA, res);
        return res;
    }

}
