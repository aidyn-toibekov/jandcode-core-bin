package jandcode.dbm.data;

import jandcode.utils.*;
import jandcode.utils.variant.*;
import org.joda.time.*;

import java.util.*;

/**
 * Специальный map для формирования контейнеров данных, что бы за раз
 * возвращать несколько объектов DataStore (или любых других) из Dao.
 * <p/>
 * Поддержка VariantNamed:
 * getValue("KEY") - возвращает значение get(KEY)
 * getValue("KEY/KEY2") - возвращает значение из get(KEY):
 * для IVariantNamed - getValue(KEY2)
 * для Map - get(KEY2)
 * для DataStore - getCurRec().getValue(KEY2)
 */
public class DataBox extends LinkedHashMap<String, Object> implements IVariantNamed {

    public Object getValue(String name) {
        if (UtString.empty(name)) {
            return null;
        }
        int a = name.indexOf('/');
        if (a == -1) {
            return get(name);
        } else {
            String ar[] = name.split("/");
            Object v1 = get(ar[0]);
            if (v1 instanceof IValueNamed) {
                return ((IValueNamed) v1).getValue(ar[1]);
            } else if (v1 instanceof DataStore) {
                return ((DataStore) v1).getCurRec().getValue(ar[1]);
            } else if (v1 instanceof Map) {
                return ((Map) v1).get(ar[1]);
            } else {
                return null;
            }
        }
    }

    public int getDataType(String name) {
        return DataType.getDataType(getValue(name));
    }

    public int getValueInt(String name) {
        return UtCnv.toInt(getValue(name));
    }

    public long getValueLong(String name) {
        return UtCnv.toLong(getValue(name));
    }

    public double getValueDouble(String name) {
        return UtCnv.toDouble(getValue(name));
    }

    public DateTime getValueDateTime(String name) {
        return UtCnv.toDateTime(getValue(name));
    }

    public String getValueString(String name) {
        return UtCnv.toString(getValue(name));
    }

    public boolean getValueBoolean(String name) {
        return UtCnv.toBoolean(getValue(name));
    }

    public boolean isValueNull(String name) {
        return getValue(name) == null;
    }

}

