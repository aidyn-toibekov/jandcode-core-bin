package jandcode.dbm.data.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;
import org.joda.time.*;

import java.util.*;

/**
 * Абстрактная реализация записи с данными
 */
public abstract class CustomDataRecord implements DataRecord {

    /**
     * Альтернативное значение null для внутренних значений
     */
    protected static final Object EXIST_NULL_VALUE = new Object();

    protected Map<String, Object> props;

    public Domain getDomain() {
        return getStore().getDomain();
    }

    //////


    public Object getValue(Field field) {
        return field.getRecordValue(this);
    }

    public void setValue(Field field, Object value) {
        field.setRecordValue(this, value);
    }

    public boolean isValueNull(Field field) {
        if (field.isCalc()) {
            return getValue(field) == null;
        }
        return getInternalValue(field) == null;
    }

    ////// IVariantNamed

    public int getDataType(String name) {
        return getDomain().f(name).getDataType();
    }

    public int getValueInt(String key) {
        return UtCnv.toInt(getValue(key));
    }

    public long getValueLong(String key) {
        return UtCnv.toLong(getValue(key));
    }

    public double getValueDouble(String key) {
        return UtCnv.toDouble(getValue(key));
    }

    public DateTime getValueDateTime(String key) {
        return UtCnv.toDateTime(getValue(key));
    }

    public String getValueString(String key) {
        return UtCnv.toString(getValue(key));
    }

    public boolean getValueBoolean(String key) {
        return UtCnv.toBoolean(getValue(key));
    }

    public boolean isValueNull(String key) {
        return isValueNull(getDomain().f(key));
    }

    //////

    public Object getValue(String name) {
        return getValue(getDomain().f(name));
    }

    public void setValue(String name, Object value) {
        setValue(getDomain().f(name), value);
    }

    //////

    public Object get(String fieldName) {
        return getValue(fieldName);
    }

    public void set(String fieldName, Object value) {
        setValue(fieldName, value);
    }

    //////

    public Map<String, Object> getValues() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        for (Field field : getDomain().getFields()) {
            if (isValueNull(field)) {
                continue;
            }
            m.put(field.getName(), getValue(field));
        }
        return m;
    }

    public void setValues(Map values) {
        if (values == null) return;
        for (Object key : values.keySet()) {
            Field f = getDomain().findField(UtString.toString(key));
            if (f == null) continue;
            setValue(f, values.get(key));
        }
    }

    //////

    public String getDictText(String fieldName, String dictField) {
        return UtCnv.toString(getDictValue(fieldName, dictField));
    }

    public String getDictText(String fieldName) {
        return UtCnv.toString(getDictValue(fieldName));
    }

    public Object getDictValue(String fieldName, String dictField) {
        Field f = getDomain().f(fieldName);
        Dict d = getStore().getDict(f.getDictName());
        if (d == null) {
            return null;
        }
        return d.getValue(getValue(f), dictField);
    }

    public Object getDictValue(String fieldName) {
        return getDictValue(fieldName, null);
    }

    //////

    public void setProp(String name, Object value) {
        if (props == null) {
            props = new HashMap<String, Object>();
        }
        props.put(name, value);
    }

    public Object getProp(String name) {
        if (props == null) {
            return null;
        }
        return props.get(name);
    }

    public boolean hasProp(String name) {
        if (props == null) {
            return false;
        }
        return props.containsKey(name);
    }

    public Object getProp(String name, Object defaultValue) {
        if (props == null) {
            return defaultValue;
        }
        if (props.containsKey(name)) {
            return props.get(name);
        }
        return defaultValue;
    }

    public Map<String, Object> getProps() {
        Map<String, Object> res = new HashMap<String, Object>();
        if (props != null) {
            res.putAll(props);
        }
        return res;
    }

    //////

    public boolean isValueExists(String name) {
        return isValueExists(getDomain().f(name));
    }

    public void clearValue(String name) {
        clearValue(getDomain().f(name));
    }
}
