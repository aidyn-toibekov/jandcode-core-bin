package jandcode.dbm.data.impl;

import jandcode.dbm.data.*;

public class DataTreeNodeRootImpl extends DataTreeNodeImpl {

    private DataStore store;

    public DataTreeNodeRootImpl(DataStore store) {
        super(null);
        this.store = store;
    }

    public DataStore getStore() {
        return this.store;
    }

}
