package jandcode.dbm.data.impl;

import jandcode.dbm.data.*;
import jandcode.utils.error.*;

import java.util.*;

public class DataTreeNodeImpl implements DataTreeNode {

    private DataRecord record;
    private DataTreeNode parent;
    private List<DataTreeNode> childs;

    public DataTreeNodeImpl(DataRecord record) {
        this.record = record;
    }

    public DataStore getStore() {
        if (this.record != null) {
            return this.record.getStore();
        }
        return null;
    }

    public DataRecord getRecord() {
        return record;
    }

    public List<DataTreeNode> getChilds() {
        if (childs == null) {
            childs = new ArrayList<DataTreeNode>();
        }
        return childs;
    }

    public boolean hasChilds() {
        return childs != null && childs.size() > 0;
    }

    public DataTreeNode addChild(DataRecord rec) {
        if (rec == null) {
            throw new XError("Запись для узла дерева не может быть null");
        }
        return addChild(new DataTreeNodeImpl(rec));
    }

    public DataTreeNode getParent() {
        return parent;
    }

    public DataTreeNode addChild(DataTreeNode node) {
        ((DataTreeNodeImpl) node).parent = this;
        getChilds().add(node);
        return node;
    }

    /**
     * Возвращает уровень, на котором находится узел.
     * Для корневого возвращается 0
     */
    public int getLevel() {
        int res = 0;
        DataTreeNodeImpl cur = this;
        while (cur != null) {
            if (cur.parent != null) {
                res++;
            }
            cur = (DataTreeNodeImpl) cur.parent;
        }
        return res;
    }

}
