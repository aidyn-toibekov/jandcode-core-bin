package jandcode.dbm.data.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.error.*;

/**
 * Прокси для getCurRec пустого store
 */
public class FirstEmptyRecordProxy extends CustomDataRecord {

    private DataRecord rec;
    private DataStore store;

    public FirstEmptyRecordProxy(DataStore store, DataRecord rec) {
        this.store = store;
        this.rec = rec;
    }

    public DataStore getStore() {
        return store;
    }

    private void createRec() {
        if (rec == null) {
            if (store.size() == 0) {
                rec = store.add();
            } else {
                rec = store.get(0);
            }
        }
    }

    public Object getInternalValue(Field field) {
        return null;
    }

    public void setInternalValue(Field field, Object value) {
    }

    public Object getValue(Field field) {
        if (rec == null) {
            return field.getRecordValue(this);
        }
        return rec.getValue(field);
    }

    public void setValue(Field field, Object value) {
        createRec();
        rec.setValue(field, value);
    }

    public boolean isValueNull(Field field) {
        if (rec == null) {
            return true;
        }
        return rec.isValueNull(field);
    }

    public boolean isValueExists(Field field) {
        if (rec == null) {
            return false;
        }
        return rec.isValueExists(field);
    }

    public void clearValue(Field field) {
        if (rec == null) {
            return;
        }
        rec.clearValue(field);
    }

    public void clearValues() {
        if (rec == null) {
            return;
        }
        rec.clearValues();
    }
}
