package jandcode.dbm.data.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;

import java.util.*;

public class DataIndexImpl implements DataIndex {

    private DataStore store;
    private Field field;
    private HashMap<Object, DataRecord> index = new HashMap<Object, DataRecord>();

    public DataIndexImpl(DataStore store, String fieldName) {
        this.store = store;
        this.field = store.getDomain().f(fieldName);
    }

    public DataStore getStore() {
        return store;
    }

    public DataRecord get(Object key) {
        key = DataType.toDataType(key, field.getDataType());
        return index.get(key);
    }

    public void reindex() {
        index = new HashMap<Object, DataRecord>();
        for (DataRecord record : store) {
            index.put(record.getValue(field), record);
        }
    }
}
