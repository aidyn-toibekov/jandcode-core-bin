package jandcode.dbm.data.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;

/**
 * Стандартная реализация записи с данными
 */
public class DataRecordImpl extends CustomDataRecord {

    private DataStore store;
    protected Object[] data;

    public DataRecordImpl(DataStore store) {
        this.store = store;
        this.data = new Object[store.getDomain().getFields().size()];
    }

    public DataStore getStore() {
        return store;
    }

    public Object getInternalValue(Field field) {
        Object v = this.data[field.getIndex()];
        if (v == EXIST_NULL_VALUE) {
            v = null;
        }
        return v;
    }

    public void setInternalValue(Field field, Object value) {
        if (value == null) {
            value = EXIST_NULL_VALUE;
        }
        this.data[field.getIndex()] = value;
    }

    public boolean isValueExists(Field field) {
        if (field.isCalc()) {
            return true;
        }
        return this.data[field.getIndex()] != null;
    }

    public void clearValue(Field field) {
        this.data[field.getIndex()] = null;
    }

    public void clearValues() {
        this.data = new Object[getDomain().getFields().size()];
    }
}
