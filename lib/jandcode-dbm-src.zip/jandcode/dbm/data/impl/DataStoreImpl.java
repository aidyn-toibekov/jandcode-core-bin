package jandcode.dbm.data.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;

/**
 * Стандартная реализация store
 */
public class DataStoreImpl extends CustomDataStore {

    protected Domain domain;

    public DataStoreImpl(Domain domain) {
        this.domain = domain;
    }

    protected DataRecord createRecord() {
        return new DataRecordImpl(this);
    }

    public Domain getDomain() {
        return domain;
    }
}
