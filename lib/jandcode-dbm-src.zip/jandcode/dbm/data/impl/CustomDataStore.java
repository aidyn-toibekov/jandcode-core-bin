package jandcode.dbm.data.impl;

import jandcode.app.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Абстрактная реализация store
 */
public abstract class CustomDataStore implements DataStore, INamed {

    protected List<DataRecord> records = new ArrayList<DataRecord>();
    protected ListComp<Dict> dicts;
    protected String name;
    protected DataRecord curRec;
    protected Map<String, Object> props;

    //////

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name == null ? getDomain().getName() : name;
    }

    //////

    public Dict getDict(String dictName) {
        if (dicts == null) {
            dicts = new ListComp<Dict>();
        }
        Dict d = dicts.find(dictName);
        if (d == null) {
            d = getDomain().getModel().getDictService().getDict(dictName);
            dicts.add(d);
        }
        return d;
    }

    //////

    /**
     * Создать новую пустую запись
     */
    protected abstract DataRecord createRecord();

    public List<DataRecord> getRecords() {
        return records;
    }

    public Iterator<DataRecord> iterator() {
        return records.iterator();
    }

    public int size() {
        return records.size();
    }

    public DataRecord get(int index) {
        return records.get(index);
    }

    public int indexOf(DataRecord rec) {
        return records.indexOf(rec);
    }

    //////

    public DataRecord add() {
        DataRecord r = createRecord();
        records.add(r);
        return r;
    }

    public DataRecord add(Map values) {
        DataRecord r = createRecord();
        r.setValues(values);
        records.add(r);
        return r;
    }

    public DataRecord add(DataRecord rec) {
        DataRecord r = createRecord();
        r.setValues(rec.getValues());
        records.add(r);
        return r;
    }

    //////

    public void clear() {
        records.clear();
    }

    public void remove(int index) {
        DataRecord rec = records.remove(index);
    }

    public void remove(DataRecord rec) {
        records.remove(rec);
    }

    //////

    public DataRecord getCurRec() {
        DataRecord r = curRec;
        if (r == null) {
            if (size() == 0) {
                r = new FirstEmptyRecordProxy(this, null);
            } else {
                r = get(0);
            }
        }
        return r;
    }

    public void setCurRec(DataRecord rec) {
        if (rec != null && rec.getStore() != this) {
            throw new XError("setCurRec допустим только для записи из этого store");
        }
        curRec = rec;
    }

    public void setCurRec(int index) {
        if (size() == 0) {
            curRec = null;
        } else {
            curRec = get(index);
        }
    }

    //////


    public void setProp(String name, Object value) {
        if (props == null) {
            props = new HashMap<String, Object>();
        }
        props.put(name, value);
    }

    public Object getProp(String name) {
        if (props == null) {
            return null;
        }
        return props.get(name);
    }

    public boolean hasProp(String name) {
        if (props == null) {
            return false;
        }
        return props.containsKey(name);
    }

    public Object getProp(String name, Object defaultValue) {
        if (props == null) {
            return defaultValue;
        }
        if (props.containsKey(name)) {
            return props.get(name);
        }
        return defaultValue;
    }

    public Map<String, Object> getProps() {
        Map<String, Object> res = new HashMap<String, Object>();
        if (props != null) {
            res.putAll(props);
        }
        return res;
    }

}
