package jandcode.dbm.data;

/**
 * Интерфейс для сканирования узлов дерева
 */
public interface ITreeNodeVisitor {

    /**
     * Вызывается для каждого узла
     *
     * @param node узел дерева
     */
    void visitNode(DataTreeNode node);

}
