package jandcode.dbm.data;

import jandcode.dbm.*;

import java.util.*;

/**
 * Копировщик данных для DataStore
 */
public class DataCopier {

    protected List<FieldLink> fieldLink = new ArrayList<FieldLink>();

    public static class FieldLink {
        public Field src;
        public Field dst;

        public FieldLink(Field src, Field dst) {
            this.src = src;
            this.dst = dst;
        }
    }

    public DataCopier(Domain src, Domain dst) {
        createFieldLink(src, dst);
    }

    public void createFieldLink(Domain src, Domain dst) {
        fieldLink.clear();
        for (Field f1 : src.getFields()) {
            Field f2 = dst.findField(f1.getName());
            if (f2 != null) {
                fieldLink.add(new FieldLink(f1, f2));
            }
        }
    }

    public void copyRecord(DataRecord src, DataRecord dst) {
        for (FieldLink link : fieldLink) {
            if (src.isValueNull(link.src)) {
                dst.setValue(link.dst, null);
            } else {
                dst.setValue(link.dst, src.getValue(link.src));
            }
        }
    }

    public void copyStore(DataStore src, DataStore dst) {
        for (DataRecord rec : src) {
            DataRecord recNew = dst.add();
            copyRecord(rec, recNew);
        }
    }

}
