package jandcode.dbm.data;

import jandcode.dbm.*;
import jandcode.dbm.dict.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Обертка вокруг DataStore
 */
public class WrapperDataStore implements DataStore {

    protected DataStore wrapped;

    //////

    public DataStore getWrapped() {
        if (wrapped == null) {
            throw new XError("wrapped DataStore not assigned");
        }
        return wrapped;
    }

    public void setWrapped(DataStore wrapped) {
        this.wrapped = wrapped;
    }

    //////

    public Dict getDict(String dictName) {
        return getWrapped().getDict(dictName);
    }

    public int size() {
        return getWrapped().size();
    }

    public DataRecord get(int index) {
        return getWrapped().get(index);
    }

    public int indexOf(DataRecord rec) {
        return getWrapped().indexOf(rec);
    }

    public List<DataRecord> getRecords() {
        return getWrapped().getRecords();
    }

    public DataRecord add() {
        return getWrapped().add();
    }

    public DataRecord add(Map values) {
        return getWrapped().add(values);
    }

    public DataRecord add(DataRecord rec) {
        return getWrapped().add(rec);
    }

    public void clear() {
        getWrapped().clear();
    }

    public void remove(int index) {
        getWrapped().remove(index);
    }

    public void remove(DataRecord rec) {
        getWrapped().remove(rec);
    }

    public DataRecord getCurRec() {
        return getWrapped().getCurRec();
    }

    public void setCurRec(DataRecord rec) {
        getWrapped().setCurRec(rec);
    }

    public void setCurRec(int index) {
        getWrapped().setCurRec(index);
    }

    public String getName() {
        return getWrapped().getName();
    }

    public void setName(String name) {
        getWrapped().setName(name);
    }

    public Domain getDomain() {
        return getWrapped().getDomain();
    }

    public Iterator<DataRecord> iterator() {
        return getWrapped().iterator();
    }

    public void setProp(String name, Object value) {
        getWrapped().setProp(name, value);
    }

    public Object getProp(String name) {
        return getWrapped().getProp(name);
    }

    public boolean hasProp(String name) {
        return getWrapped().hasProp(name);
    }

    public Object getProp(String name, Object defaultValue) {
        return getWrapped().getProp(name, defaultValue);
    }

    public Map<String, Object> getProps() {
        return getWrapped().getProps();
    }
}
