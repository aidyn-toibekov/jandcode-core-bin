package jandcode.dbm.data;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;

import java.util.*;

/**
 * Хранилище записей данных. Представляет собой список записей.
 * <p/>
 * Имеет имя, которое по умолчанию совпадает с именем домена. Можно свободно менять.
 */
public interface DataStore extends INamed, INamedSet, IDomainLink, Iterable<DataRecord>, ICustomProp {


    /**
     * Возвращает ссылку на словарь, задействованный в этом store
     *
     * @param dictName имя словаря
     * @return null или ссылка на словарь, может быть как глобальной (для обычных словарей),
     *         так и локальной (для resolve-словарей).
     */
    Dict getDict(String dictName);

    //////

    /**
     * Количество записей в списке
     */
    int size();

    /**
     * Получить запись по индексу
     */
    DataRecord get(int index);

    /**
     * Индекс записи
     */
    int indexOf(DataRecord rec);

    /**
     * Все записи из store в виде списка. Это ссылка на внутренний список записей,
     * так что манипуляции с ним отражаются на самом store. Например его можно
     * отсортировать
     */
    List<DataRecord> getRecords();

    //////

    /**
     * Добавить пустую запись
     */
    DataRecord add();

    /**
     * Добавить запись, полученную из map
     */
    DataRecord add(Map values);

    /**
     * Добавить новую запись и инициализировать ее из записи rec
     */
    DataRecord add(DataRecord rec);

    //////

    /**
     * Удалить все записи
     */
    void clear();

    /**
     * Удалить запись по индексу
     */
    void remove(int index);

    /**
     * Удалить запись
     */
    void remove(DataRecord rec);

    //////

    /**
     * Возвращает "текущую запись". Это виртуальная запись, которая при пустом store
     * на чтение всегда дает null, а при записи - создает новую пустую запись.
     * Если store не пустой и явно текущая запись не установлена, то возвращается
     * первая запись.
     */
    DataRecord getCurRec();

    /**
     * Явно установить текущую запись
     *
     * @param rec запись (должна быть из этого store)
     */
    void setCurRec(DataRecord rec);

    /**
     * Явно установить текущую запись
     *
     * @param index номер записи из этого store
     */
    void setCurRec(int index);

}
