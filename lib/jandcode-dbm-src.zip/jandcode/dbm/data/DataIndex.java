package jandcode.dbm.data;

/**
 * Индекс для быстрого доступа к записям по ключу
 */
public interface DataIndex {

    /**
     * Для какого store
     */
    DataStore getStore();

    /**
     * Получить запись по ключу
     *
     * @param key ключ
     * @return null, если не найдено
     */
    DataRecord get(Object key);

    /**
     * Переиндексировать
     */
    void reindex();

}
