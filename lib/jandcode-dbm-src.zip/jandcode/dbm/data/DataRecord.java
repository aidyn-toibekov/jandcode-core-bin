package jandcode.dbm.data;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Интерфейс записи с данными
 */
public interface DataRecord extends IDomainLink,
        IValueNamed, IValueNamedSet, IVariantNamed, ICustomProp {

    /**
     * Какому store принадлежит
     */
    DataStore getStore();

    //////

    /**
     * Установить внутреннее значение (без преобразований) для поля.
     * Используется только в методе поля getRecordValue
     */
    Object getInternalValue(Field field);

    /**
     * Получить внутренне значение поля (без преобразований) для поля.
     * Используется только в методе поля setRecordValue
     */
    void setInternalValue(Field field, Object value);

    /**
     * Проверка на null значения по индексу поля
     */
    boolean isValueNull(Field field);

    /**
     * Получить значение поля
     */
    Object getValue(Field field);

    /**
     * Установить значение поля
     */
    void setValue(Field field, Object value);


    //////

    /**
     * Значение из словаря, если поле словарное
     *
     * @param fieldName имя поля с данными
     * @param dictField имя словарного поля. null для поля словаря по умолчанию
     * @return текст из словаря
     */
    String getDictText(String fieldName, String dictField);

    /**
     * Значение из словаря, если поле словарное. Используется поле словаря по умолчанию
     *
     * @param fieldName имя поля с данными
     * @return текст из словаря
     */
    String getDictText(String fieldName);

    /**
     * Значение из словаря, если поле словарное
     *
     * @param fieldName имя поля с данными
     * @param dictField имя словарного поля. null для поля словаря по умолчанию
     * @return значение из словаря
     */
    Object getDictValue(String fieldName, String dictField);

    /**
     * Значение из словаря, если поле словарное. Используется поле словаря по умолчанию
     *
     * @param fieldName имя поля с данными
     * @return значение из словаря
     */
    Object getDictValue(String fieldName);

    //////

    /**
     * Значения всех полей, которые не null, в виде map
     */
    Map<String, Object> getValues();

    /**
     * @param values
     */
    void setValues(Map values);

    ////// для groovy

    /**
     * Синоним для {@link DataRecord#getValue(String)}
     */
    Object get(String fieldName);

    /**
     * Синоним для {@link DataRecord#setValue(String, Object)}
     */
    void set(String fieldName, Object value);

    //////

    /**
     * Существует ли значение (было ли явно присвоено).
     * Если явно присвоить значению null, значит значение существует.
     */
    boolean isValueExists(Field field);

    /**
     * Существует ли значение (было ли явно присвоено).
     * Если явно присвоить значению null, значит значение существует.
     */
    boolean isValueExists(String name);

    /**
     * Очистить значение поле. После выполнения isValueExists==false
     */
    void clearValue(Field field);

    /**
     * Очистить значение поле. После выполнения isValueExists==false
     */
    void clearValue(String name);

    /**
     * Очистить все поля.  После выполнения isValueExists==false для всех полей.
     */
    void clearValues();
}
