package jandcode.dbm.data;

import jandcode.dbm.*;
import jandcode.utils.*;
import jandcode.utils.io.*;

import java.io.*;
import java.util.*;

/**
 * Запись DataStore в виде таблицы в текст для просмотра во время отладки.
 */
public class OutTableSaver implements ISaver {

    protected DataStore data;
    protected int limit = -1;

    public OutTableSaver(DataStore data) {
        this.data = data;
    }

    public OutTableSaver(DataTreeNode tree) {
        this.data = treeToDataStore(tree);
    }

    class VisiterDomain implements ITreeNodeVisitor {

        Domain domain;
        HashSet<Domain> usedDomains = new HashSet<Domain>();

        private void checkFields(Domain d) {
            if (usedDomains.contains(d)) {
                return;
            }
            usedDomains.add(d);
            for (Field f : d.getFields()) {
                if (domain.getFields().find(f.getName()) != null) {
                    return;
                }
                Field f1 = (Field) f.clone();
                domain.doAddField(f1);
            }
        }

        public void visitNode(DataTreeNode node) {
            if (domain == null) {
                if (node.getStore() != null) {
                    domain = node.getStore().getDomain().getModel().createDomain("sys");
                    domain.addField("__LEVEL__", "string");
                    checkFields(node.getStore().getDomain());
                }
                return;
            }
            //
            DataRecord rec = node.getRecord();
            if (rec != null) {
                checkFields(rec.getDomain());
            }
        }

    }

    class VisiterData implements ITreeNodeVisitor {
        DataStore st;

        VisiterData(DataStore st) {
            this.st = st;
        }

        public void visitNode(DataTreeNode node) {
            //
            DataRecord rec = node.getRecord();
            if (rec != null) {
                DataRecord r1 = st.add(rec);
                int lev = node.getLevel();
                r1.setValue("__LEVEL__", UtString.repeat("- ", lev - 1) + "{" + lev + "}");
            }
        }
    }

    protected DataStore treeToDataStore(DataTreeNode tree) {
        VisiterDomain vs = new VisiterDomain();
        UtData.scanTree(tree, false, vs);
        DataStore st = UtData.createStore(vs.domain);
        VisiterData vsd = new VisiterData(st);
        UtData.scanTree(tree, false, vsd);
        return st;
    }

    /**
     * Сколько записей выводить. По умолчанию - все
     */
    public void setLimit(int limit) {
        this.limit = limit;
    }

    protected String getFieldValue(DataRecord rec, Field f) {
        String v = "";
        if (rec.isValueNull(f.getName())) {
            v = "<NULL>";
        } else {
            if (f.hasDict()) {
                v = rec.getDictText(f.getName()) + "[" + rec.getValueString(f.getName()) + "]";
            } else {
                v = rec.getValueString(f.getName());
            }
        }
        return v;
    }

    public SaveTo save() {
        return new SaveTo(this);
    }

    public void saveTo(Writer writer) throws Exception {
        Domain domain = data.getDomain();

        int[] maxWidths = new int[domain.getFields().size()];
        // размер имен
        int i = 0;
        for (Field field : domain.getFields()) {
            maxWidths[i] = field.getName().length();
            i++;
        }
        // размеры данных
        for (DataRecord rec : data) {
            i = 0;
            for (Field field : domain.getFields()) {
                String v = getFieldValue(rec, field);
                maxWidths[i] = Math.max(maxWidths[i], v.length());
                i++;
            }
        }

        // общая ширина
        int widthAll = 2;
        i = 0;
        for (Field field : domain.getFields()) {
            widthAll = widthAll + maxWidths[i] + 1;
        }

        // разделитель линий
        StringBuilder linedelim = new StringBuilder();
        i = 0;
        linedelim.append("+");
        for (Field field : domain.getFields()) {
            linedelim.append(UtString.repeat("-", maxWidths[i])).append("+");
            i++;
        }
        linedelim.append("\n");

        writer.append(linedelim);

        // заголовки
        i = 0;
        writer.append("|");
        for (Field field : domain.getFields()) {
            writer.append(UtString.padCenter(field.getName(), maxWidths[i])).append("|");
            i++;
        }
        writer.append("\n");


        //
        writer.append(linedelim);

        int numrec = 0;
        boolean limited = false;
        // данные
        for (DataRecord rec : data) {
            if (limit > 0 && numrec >= limit) {
                limited = true;
                break;
            }
            numrec++;
            i = 0;
            writer.append("|");
            for (Field field : domain.getFields()) {
                String val = getFieldValue(rec, field);

                if (!field.hasDict() && (DataType.isNumber(field.getDataType()))) {
                    val = UtString.padLeft(val, maxWidths[i]);
                } else {
                    val = UtString.padRight(val, maxWidths[i]);
                }

                writer.append(val).append("|");
                i++;
            }
            writer.append("\n");
        }


        //
        writer.append(linedelim);
        writer.append("records: ").append(UtCnv.toString(data.size()));
        if (limited) {
            writer.append(", print records: ").append(UtCnv.toString(numrec));
        }

    }

}
