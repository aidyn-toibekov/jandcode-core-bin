package jandcode.dbm.impl;

import jandcode.utils.variant.*;

/**
 * Двухуровневая map. Пишет всегда в себя, читает сначала из себя, если нету, то
 * со второго уровня.
 */
public class TwoLevelVariantMap extends VariantMapNoCase {

    private IVariantNamed level2;

    public TwoLevelVariantMap() {
    }

    public TwoLevelVariantMap(IVariantNamed level2) {
        setLevel2(level2);
    }

    public void setLevel2(IVariantNamed level2) {
        this.level2 = level2;
    }

    public Object get(Object key) {
        if (super.containsKey(key)) {
            return super.get(key);
        }
        if (level2 == null) {
            return null;
        }
        String sk = (String) key;
        if (level2.isValueNull(sk)) {
            return null;
        }
        return level2.getValue(sk);
    }

}
