package jandcode.dbm.impl;

/**
 * Имя = id -> возвращается значение, в остальных случаях - null.
 */
public class IdVariantNamedGet extends CustomWrapperVariantNamedGet {
    public IdVariantNamedGet(Object wrapped) {
        super(wrapped);
    }

    public Object getValue(String name) {
        if ("id".equalsIgnoreCase(name)) {
            return wrapped;
        }
        return null;
    }
}
