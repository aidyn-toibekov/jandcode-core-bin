package jandcode.dbm.impl;

import jandcode.utils.*;
import jandcode.utils.variant.*;
import org.joda.time.*;

/**
 * Предок для простого создания оберток для IVariantNamed.
 */
public abstract class CustomWrapperVariantNamedGet implements IVariantNamed {

    protected Object wrapped;

    public CustomWrapperVariantNamedGet(Object wrapped) {
        this.wrapped = wrapped;
    }

    //////

    public Object getWrapped() {
        return wrapped;
    }

    public void setWrapped(Object wrapped) {
        this.wrapped = wrapped;
    }

    //////

    public int getDataType(String name) {
        return DataType.getDataType(getValue(name));
    }

    public int getValueInt(String key) {
        return UtCnv.toInt(getValue(key));
    }

    public long getValueLong(String key) {
        return UtCnv.toLong(getValue(key));
    }

    public double getValueDouble(String key) {
        return UtCnv.toDouble(getValue(key));
    }

    public DateTime getValueDateTime(String key) {
        return UtCnv.toDateTime(getValue(key));
    }

    public String getValueString(String key) {
        return UtCnv.toString(getValue(key));
    }

    public boolean getValueBoolean(String key) {
        return UtCnv.toBoolean(getValue(key));
    }

    public boolean isValueNull(String key) {
        return getValue(key) == null;
    }

}
