package jandcode.dbm.impl;

import jandcode.utils.variant.*;

/**
 * Обертка для поименнованного значения.
 */
public class VnVariantNamedGet extends CustomWrapperVariantNamedGet {
    public VnVariantNamedGet(Object wrapped) {
        super(wrapped);
    }

    public Object getValue(String name) {
        return ((IValueNamed) wrapped).getValue(name);
    }
}
