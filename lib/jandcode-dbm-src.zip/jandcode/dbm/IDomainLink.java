package jandcode.dbm;

/**
 * Интерфейс для объектов, владеющих доменом
 */
public interface IDomainLink {

    /**
     * Домен
     */
    Domain getDomain();

}
