package jandcode.dbm.dict;

import jandcode.app.*;
import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Универсальный словарь. Создается по структуре домена
 */
public class Dict extends ModelMember {

    public static final String DAOMETHOD_LOADDICT = "dict/loadDict";

    protected boolean resolve;
    protected boolean loaded;
    protected String domainName;
    protected Domain domain;
    protected String defaultField;
    protected String defaultFieldBinded;
    protected DataStore data;
    protected DataIndex dataIndex;
    private Set resolveIds = new HashSet();


    protected void onClone(Comp r) {
        super.onClone(r);
        Dict f = (Dict) r;
        f.resolve = resolve;
        f.domainName = domainName;
        f.domain = null;
        f.defaultField = defaultField;
    }

    /**
     * Установить домен. Домен domain является прототипом, на основе которого
     * формируется собственный домен словаря. Домен присваивается до того,
     * как будет загружена структура словаря. Если домен не присвоен,
     * то по умолчанию сичитается равным имени словаря.
     */
    public void setDomainName(String domainName) {
        this.domainName = domainName;
        if (UtString.empty(this.domainName)) {
            this.domainName = null;
        }
        this.domain = null;
    }

    /**
     * Домен со структурой словаря.
     */
    public Domain getDomain() {
        if (domain == null) {
            String dn = domainName;
            if (UtString.empty(dn)) {
                dn = getName();
            }
            domain = getModel().createDomain(dn);
            //
            defaultFieldBinded = null;
            if (defaultField != null) {
                // явно указано
                defaultFieldBinded = defaultField;
            } else {
                // выявляем - берем первое поле после id
                if (domain.getFields().size() == 0) {
                    throw new XError("В домене нет полей");
                }
                if (domain.getFields().size() == 1) {
                    // только одно поле
                    defaultFieldBinded = domain.getFields().get(0).getName();
                } else {
                    for (Field f : domain.getFields()) {
                        if (f.hasName("id")) {
                            continue;
                        }
                        defaultFieldBinded = f.getName();
                        break;
                    }
                }
            }
            //
            if (domain.findField(defaultFieldBinded) == null) {
                throw new XError("Для словаря {0} указано поле по умолчанию {1}, " +
                        "которого нет в структуре домена {2}",
                        getName(), defaultFieldBinded, domain.getName());
            }
        }
        return domain;
    }

    /**
     * Признак resolve-словаря
     */
    public boolean isResolve() {
        return resolve;
    }

    public void setResolve(boolean resolve) {
        this.resolve = resolve;
    }

    public String getDefaultField() {
        if (domain == null) {
            getDomain();  // биндим домен и поле по умолчанию
        }
        // поле либо явно назначеное, либо выявленное при назначении домена
        return defaultFieldBinded;
    }

    public void setDefaultField(String defaultField) {
        this.defaultField = defaultField;
        if (UtString.empty(this.defaultField)) {
            this.defaultField = null;
        }
    }

    /**
     * Данные словаря. Только для чтения
     */
    public DataStore getData() {
        if (data == null) {
            data = UtData.createStore(getDomain());
            dataIndex = UtData.createIndex(data, "id");
        }
        return data;
    }

    /**
     * Реализация преобразования
     *
     * @param id        значение id
     * @param fieldName имя поля словаря. Например  может быть "text","textShort","icon"
     *                  (если словарь это поддерживает)
     * @return сконвертированное значение или null, если конвертация невозможна (например
     *         указано не поддерживаемое поле словаря)
     */
    public Object getValue(Object id, String fieldName) {
        Domain d = getDomain(); // берем его перед getDefaultField()!
        if (fieldName == null) {
            fieldName = getDefaultField();
        }
        Field f = d.findField(fieldName);
        if (f == null) {
            return null;
        }
        getData(); // создаем, если еще нету
        DataRecord rec = dataIndex.get(id);
        if (rec == null) {
            return null;
        }
        return rec.getValue(fieldName);
    }

    /**
     * Найти запись из словаря по id
     *
     * @return null, если не найдено
     */
    public DataRecord getRecord(Object id) {
        getData(); // создаем, если еще нету
        return dataIndex.get(id);
    }


    /**
     * Загрузить словарь, если еще не загружен
     */
    public void load() {
        if (loaded) {
            return;
        }
        synchronized (this) {
            if (loaded) {
                return;
            }
            loaded = true; // если словарь дерево, то он второй раз загружаться не должен
            try {
                onLoad();
            } catch (Exception e) {
                throw new XErrorWrap(e);
            }
            resolveIds.clear();
        }
    }

    /**
     * Перезагрузить словарь
     */
    public void reload() {
        resolveIds.clear();
        loaded = false;
        if (resolve) {
            getData().clear();
            Field idField = getData().getDomain().f("id");
            for (DataRecord rec : getData()) {
                resolveIds.add(rec.getValue(idField));
            }
        }
        load();
    }

    public boolean isLoaded() {
        return loaded;
    }

    /**
     * Установить флаг загруженности словаря
     */
    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }

    /**
     * Реализация загрузки словаря
     */
    protected void onLoad() throws Exception {
        if (!resolve) {
            getData().clear();  // очищаем обычный словарь
        }
        try {
            getModel().daoinvoke(getName(), DAOMETHOD_LOADDICT, this);
        } finally {
            getData(); // создаем, если еще нету
            dataIndex.reindex();
        }
    }

    ////// resolve

    /**
     * Заказ на определенную id. Если такой id нет, она запоминается и
     * загружается при вызове load
     */
    public void resolveId(Object id) {
        if (!isResolve()) {
            return;
        }
        if (resolveIds.contains(id)) {
            return;
        }
        loaded = false;
        resolveIds.add(id);
    }

    /**
     * Набор id, которые нужно разрешить для словаря. Заказываются через resolveId
     */
    public Set getResolveIds() {
        return resolveIds;
    }

    //////


}
