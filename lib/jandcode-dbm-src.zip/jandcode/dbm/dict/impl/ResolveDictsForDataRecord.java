package jandcode.dbm.dict.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;

import java.util.*;

public class ResolveDictsForDataRecord {

    private DataRecord record;
    private HashMap<Dict, DictInfo> dicts = new HashMap<Dict, DictInfo>();
    private boolean force;

    class DictInfo {
        Dict dict;
        List<Field> fields = new ArrayList<Field>();
    }

    public ResolveDictsForDataRecord(DataRecord record, boolean force) {
        this.record = record;
        this.force = force;
    }

    /**
     * Загрузка
     *
     * @return возвращает true, если запросы были сделаны
     */
    public boolean load() {
        // собираем все resolve словари
        for (Field f : record.getStore().getDomain().getFields()) {
            if (f.hasDict()) {
                Dict d = record.getStore().getDict(f.getDictName());
                if (d.isResolve()) {
                    //
                    DictInfo di = dicts.get(d);
                    if (di == null) {
                        di = new DictInfo();
                        di.dict = d;
                        dicts.put(d, di);
                    }
                    di.fields.add(f);
                }
            }
        }
        //
        if (dicts.size() == 0) {
            return false; // нет словарей
        }

        // собираем все значения из всех нужных полей
        boolean needQuery = false;
        for (DictInfo di : dicts.values()) {
            for (Field f : di.fields) {
                if (record.isValueNull(f)) {
                    continue; // нет значения
                }
                Object v = record.getValue(f);
                if (!force) {
                    DataRecord r = di.dict.getRecord(v);
                    if (r != null) {
                        continue; // запись уже есть
                    }
                }
                needQuery = true;
                di.dict.resolveId(v);
            }
        }
        //
        if (!needQuery) {
            return false;
        }
        // загружаем словари
        for (DictInfo di : dicts.values()) {
            di.dict.load();
        }
        // все...
        return true;
    }
}
