package jandcode.dbm.dict.impl;

import jandcode.dbm.cache.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;
import jandcode.utils.*;

import java.util.*;

public class DictServiceImpl extends DictService implements ICacheChange {

    protected ListNamed<Dict> dicts = new ListNamed<Dict>();

    public DictServiceImpl() {
        dicts.setNotFoundMessage("Не найден словарь [{0}]");
    }

    public boolean hasDict(String name) {
        return dicts.find(name) != null;
    }

    public void addDict(Dict dict) {
        dicts.add(dict);
    }

    public Dict getDict(String name, boolean autoLoad) {
        Dict res = dicts.get(name);
        if (res.isResolve()) {
            return (Dict) res.clone();
        }
        if (autoLoad) {
            res.load();
        }
        return res;
    }


    public List<String> getDictNames() {
        ArrayList<String> res = new ArrayList<String>();
        for (Dict dict : dicts) {
            res.add(dict.getName());
        }
        return res;
    }

    protected boolean resolveDictsInStore(DataStore data, boolean force) {
        ResolveDictsForDataStore ldr = new ResolveDictsForDataStore(data, force);
        return ldr.load();
    }

    protected boolean resolveDictsInRecord(DataRecord data, boolean force) {
        ResolveDictsForDataRecord ldr = new ResolveDictsForDataRecord(data, force);
        return ldr.load();
    }

    public boolean resolveDicts(Object res, boolean force) {
        HashSet<DataStore> stores = new HashSet<DataStore>();
        HashSet<DataRecord> records = new HashSet<DataRecord>();

        // ищем все DataStore & DataRecord
        if (res instanceof DataStore) {
            stores.add((DataStore) res);

        } else if (res instanceof DataRecord) {
            records.add((DataRecord) res);

        } else if (res instanceof DataTreeNode) {
            stores.addAll(UtData.getTreeStores((DataTreeNode) res));

        } else if (res instanceof Map) {
            for (Object v : ((Map) res).values()) {
                if (v instanceof DataStore) {
                    stores.add((DataStore) v);
                } else if (v instanceof DataRecord) {
                    records.add((DataRecord) v);
                }
            }

        } else if (res instanceof List) {
            for (Object v : (List) res) {
                if (v instanceof DataStore) {
                    stores.add((DataStore) v);
                } else if (v instanceof DataRecord) {
                    records.add((DataRecord) v);
                }
            }

        }

        // ресолвим
        boolean ret = false;
        for (DataStore store : stores) {
            if (resolveDictsInStore(store, force)) {
                ret = true;
            }
        }
        for (DataRecord record : records) {
            if (resolveDictsInRecord(record, force)) {
                ret = true;
            }
        }

        return ret;
    }

    public DataStore getDictData(String dictName, Collection ids) {
        LinkedHashSet idset = new LinkedHashSet();
        idset.addAll(ids);
        //
        Dict dict = getDict(dictName);
        if (dict.isResolve()) {
            for (Object id : idset) {
                dict.resolveId(id);
            }
            dict.load();
        }
        DataStore res = UtData.createStore(dict.getData().getDomain());
        res.setName(dict.getName());
        //
        for (Object id : idset) {
            DataRecord r = dict.getRecord(id);
            if (r != null) {
                res.add(r);
            }
        }
        //
        return res;
    }

    public void cacheChange(String dataName, Object dataId, String dataOperation) {
        // если изменились данные в таблице, которая связана со словарем, то словарь
        // нужно будет перегрузить при следующем обращении
        Dict d = dicts.find(dataName);
        if (d != null) {
            if (!d.isResolve()) {
                d.setLoaded(false);
            }
        }
    }
}
