package jandcode.dbm.dict.impl;

import jandcode.dbm.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dict.*;

import java.util.*;

public class ResolveDictsForDataStore {

    private DataStore store;
    private HashMap<Dict, DictInfo> dicts = new HashMap<Dict, DictInfo>();
    private boolean force;

    class DictInfo {
        Dict dict;
        List<Field> fields = new ArrayList<Field>();
    }

    public ResolveDictsForDataStore(DataStore store, boolean force) {
        this.store = store;
        this.force = force;
    }

    /**
     * Загрузка
     *
     * @return возвращает true, если запросы были сделаны
     */
    public boolean load() {
        // собираем все resolve словари
        for (Field f : store.getDomain().getFields()) {
            if (f.hasDict()) {
                Dict d = store.getDict(f.getDictName());
                if (d.isResolve()) {
                    //
                    DictInfo di = dicts.get(d);
                    if (di == null) {
                        di = new DictInfo();
                        di.dict = d;
                        dicts.put(d, di);
                    }
                    di.fields.add(f);
                }
            }
        }
        //
        if (dicts.size() == 0) {
            return false; // нет словарей
        }

        // собираем все значения из всех нужных полей
        boolean needQuery = false;
        for (DataRecord rec : store) {
            for (DictInfo di : dicts.values()) {
                for (Field f : di.fields) {
                    if (rec.isValueNull(f)) {
                        continue; // нет значения
                    }
                    Object v = rec.getValue(f);
                    if (!force) {
                        DataRecord r = di.dict.getRecord(v);
                        if (r != null) {
                            continue; // запись уже есть
                        }
                    }
                    needQuery = true;
                    di.dict.resolveId(v);
                }
            }
        }
        //
        if (!needQuery) {
            return false;
        }
        // загружаем словари
        for (DictInfo di : dicts.values()) {
            di.dict.load();
        }
        // все...
        return true;
    }
}
