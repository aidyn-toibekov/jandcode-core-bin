package jandcode.dbm.dict;

/**
 * Интерфейс для dao, который умеет загружать словарь
 */
public interface ILoadDict {

    /**
     * Этот dao-метод загружает данные словаря.
     * Загружать данные нужно в свойство {@link Dict#getData()}.
     * Если словарь resolve, то набор id, которые нужно загрузить, берем из
     * {@link Dict#getResolveIds()}.
     *
     * @param dict загружаемый словарь
     */
    void loadDict(Dict dict) throws Exception;

}
