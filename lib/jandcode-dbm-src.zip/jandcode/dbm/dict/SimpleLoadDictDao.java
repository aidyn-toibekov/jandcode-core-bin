package jandcode.dbm.dict;

import jandcode.dbm.dao.*;

/**
 * Простой dao для загрузки простых словарей.
 * Используется как прототип, но можно и напрямую использовать.
 */
public class SimpleLoadDictDao extends CustomDao implements ILoadDict {

    protected String getLoadSql() {
        return ut.subst("select * from ${@table}");
    }

    @DaoMethod
    public void loadDict(Dict dict) throws Exception {
        ut.loadSql(dict.getData(), getLoadSql());
    }

}
