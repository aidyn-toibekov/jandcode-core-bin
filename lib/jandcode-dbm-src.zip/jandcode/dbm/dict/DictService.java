package jandcode.dbm.dict;

import jandcode.dbm.*;
import jandcode.dbm.data.*;

import java.util.*;

/**
 * Сервис для словарей. Принадлежит модели.
 */
public abstract class DictService extends ModelMember {

    /**
     * Получить загруженный словарь по имени. Для resolve-словарей всегда возвращает новый экземпляр - клон.
     *
     * @param name имя словаря
     * @return словарь
     */
    public Dict getDict(String name) {
        return getDict(name, true);
    }

    /**
     * Получить загруженный словарь по имени. Для resolve-словарей всегда возвращает новый экземпляр - клон.
     *
     * @param name     имя словаря
     * @param autoLoad true - звгружать при получении словария
     * @return словарь
     */
    public abstract Dict getDict(String name, boolean autoLoad);

    /**
     * Добавить словарь
     *
     * @param dict словарь с правильным именем
     */
    public abstract void addDict(Dict dict);

    /**
     * Для объекта данных DataStore или DataRecord загружет все resolve словари.
     * Автоматически выделяет все store из data (например из списков и map).
     * Если данные словаря для ключа уже есть, то загрузка не производится.
     */
    public boolean resolveDicts(Object data) {
        return resolveDicts(data, false);
    }

    /**
     * Для объекта данных DataStore загружет все resolve словари.
     * Автоматически выделяет все store из data (например из списков и map)
     *
     * @param force true - перезагрузка (если данные для словарей есть, то все равно они загружаются)
     */
    public abstract boolean resolveDicts(Object data, boolean force);

    /**
     * Список всех имен словарей
     */
    public abstract List<String> getDictNames();

    /**
     * Существует ли словарь
     */
    public abstract boolean hasDict(String name);

    /**
     * Получить store с записями, соответсвующими id, переданными в ids
     */
    public abstract DataStore getDictData(String dictName, Collection ids);

}
