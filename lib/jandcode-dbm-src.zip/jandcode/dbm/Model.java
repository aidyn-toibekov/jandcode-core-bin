package jandcode.dbm;

import jandcode.app.*;
import jandcode.dbm.cache.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.*;
import jandcode.dbm.db.*;
import jandcode.dbm.dblang.*;
import jandcode.dbm.dict.*;
import jandcode.dbm.validate.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.rt.*;

import java.util.*;

/**
 * Модель данных. Хранит и создает все, что связанно с данными
 * (домены, dao, словари ...).
 */
public class Model extends CompRt implements IServiceHolder, IObjectFactoryLink, IIniter, IActivate, IReloadAppRt {

    protected ListDomain domains = new ListDomain();
    protected ListNamed<DbSource> dbsources = new ListNamed<DbSource>();
    protected ServiceContainer services = new ServiceContainer();
    protected ObjectFactory objectFactory = new ObjectFactory(this);

    //////

    public Model() {
        domains.setNotFoundMessage("Домен [{0}] не найден");
        dbsources.setNotFoundMessage("db [{0}] не найдена");
    }

    /**
     * Модель пользуется глобальной ссылкой на rt, для оптимизации.
     */
    protected boolean isUseCloneRt() {
        return false;
    }

    protected void onSetRt(Rt rt) {
        super.onSetRt(rt);

        // сервисы
        services.addAll(rt.findChild("service"), objectFactory);

        // домены
        loadCache();

        // базы данных (личные)
        Rt z = rt.findChild("db");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                DbSource di = (DbSource) objectFactory.create(z1);
                dbsources.add(di);
            }
        }

    }

    public void reloadAppRt() {
        internal_replaceRt(getApp().getRt().getChild(getRt().getPath()));
        loadCache();
        for (IReloadAppRt svc : services.impl(IReloadAppRt.class)) {
            svc.reloadAppRt();
        }
    }

    public void activate() throws Exception {
        for (IActivate svc : services.impl(IActivate.class)) {
            svc.activate();
        }
    }

    /**
     * Создание прототипа домена
     */
    protected Domain createDomainPrototype(Rt rt) {
        // связанный словарь
        if (rt.getValueBoolean("tag.dict") && !rt.getValueBoolean("abstract")) {
            Rt dictRt = rt.findChild("dict");
            if (dictRt != null) {
                Dict dct = (Dict) objectFactory.create(dictRt, Dict.class);
                dct.setName(rt.getName());
                getDictService().addDict(dct);
            }
        }
        // экземпляр
        Domain inst = (Domain) objectFactory.create(rt);

        // собираем теги
        for (IRtAttr attr : rt.getAttrs()) {
            String key = attr.getName();
            String tag = UtString.removePrefix(key, "tag.");
            if (tag != null) {
                String v = UtCnv.toString(attr.getValue());
                if (!UtString.empty(v) && !"false".equalsIgnoreCase(v)) {
                    inst.getTags().put(tag, v);
                }
            }
        }
        //

        return inst;
    }

    protected void loadCache() {
        Rt z;
        // домены
        domains.clear();
        z = getRt().findChild("domain");
        if (z != null) {
            for (Rt z1 : z.getChilds()) {
                Domain d = createDomainPrototype(z1);
                domains.add(d);
            }
        }
        // замораживаем
        for (Domain domain : domains) {
            domain.froze();
        }

    }

    ////// services

    public <A extends Object> A service(Class<A> clazz) {
        return services.get(clazz);
    }

    public ServiceContainer getServices() {
        return services;
    }

    //

    public DictService getDictService() {
        return service(DictService.class);
    }

    public DaoService getDaoService() {
        return service(DaoService.class);
    }

    public ValidateService getValidateService() {
        return service(ValidateService.class);
    }

    public CacheService getCacheService() {
        return service(CacheService.class);
    }

    public DblangService getDblangService() {
        return service(DblangService.class);
    }

    ////// factory

    public ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    public void initObject(Object obj) throws Exception {
        getApp().initObject(obj);
        if (obj instanceof IModelLinkSet) {
            ((IModelLinkSet) obj).setModel(this);
        }
    }

    ////// domains

    /**
     * Получить ссылку на глобальный экземпляр домена в модели.
     *
     * @param name см. {@link Model#createDomain(java.lang.String)}
     */
    public Domain getDomain(String name) {
        if (name != null && name.startsWith("/")) {
            return createDomain(name);
        }
        return domains.get(name);
    }

    /**
     * Создать новый экземпляр домена.
     * <p/>
     * В качестве имени может быть указано имя ресурса (полный путь к файлу домена
     * внутри classpath). В этом случае в файле должен быть описан домен с именем
     * default. Созданный по ресурсу домен в качестве имени будет содержать имя ресурса.
     */
    public Domain createDomain(String name) {
        if (name != null && name.startsWith("/")) {
            // это имя ресурса, грузим домен из него
            //todo кешировать это
            Rt r = getRt().createRt("root");
            try {
                r.load().fromRes(name);
                Rt domainRt = r.findChild("domain/default");
                if (domainRt == null) {
                    throw new XError("Не объявлен домен с именем default");
                }
                Domain domain = (Domain) objectFactory.create(domainRt);
                domain.setName(name);
                return domain;
            } catch (Exception e) {
                throw new XErrorMark(e, name);
            }
        }
        // создание по имени
        return (Domain) domains.get(name).clone();
    }

    /**
     * Все домены модели
     */
    public ListDomain getDomains() {
        ListDomain res = new ListDomain();
        for (Domain item : domains) {
            res.add(item);
        }
        return res;
    }

    /**
     * Все домены модели, которые в базе данных (которые имеют тег 'db').
     * Включая view.
     */
    public ListDomain getDomainsDb() {
        return getDomainsDb(true);
    }

    /**
     * Все домены модели, которые в базе данных (которые имеют тег 'db').
     *
     * @param includeView true - включая view, иначе - только таблицы
     */
    public ListDomain getDomainsDb(boolean includeView) {
        ListDomain res = new ListDomain();
        for (Domain item : domains) {
            if (item.hasTag("db")) {
                if (!includeView && item.hasTag("dbview")) {
                    continue;
                }
                res.add(item);
            }
        }
        return res;
    }

    ////// data

    public DataStore createStore(String domainName) {
        return UtData.createStore(createDomain(domainName));
    }

    public DataRecord createRecord(String domainName) {
        return createStore(domainName).add();
    }

    ////// dao

    /**
     * Выполнить dao-метод
     *
     * @param daoName    комбинация "domain/dao/method" или "domain/dao" или "domain"
     * @param methodName комбинация "dao/method" или "dao" или null, в зависимости от
     *                   параметра daoName
     * @param args       аргументы dao-метода
     */
    public Object daoinvoke(String daoName, String methodName, Object... args) throws Exception {
        return getDaoService().daoinvoke(daoName, methodName, args);
    }

    /**
     * Выполнить dao-метод
     *
     * @param contextParams контекстные параметры dao. см: {@link Dao#getContextParams()}
     * @param daoName       комбинация "domain/dao/method" или "domain/dao" или "domain"
     * @param methodName    комбинация "dao/method" или "dao" или null, в зависимости от
     *                      параметра daoName
     * @param args          аргументы dao-метода
     */
    public Object daoinvoke(Map contextParams, String daoName, String methodName, Object... args) throws Exception {
        return getDaoService().daoinvoke(contextParams, daoName, methodName, args);
    }

    /**
     * Выполнить dao-метод
     *
     * @param dao        экземпляр dao
     * @param methodName имя метода
     * @param args       аргумента dao-метода
     */
    public Object daoinvoke(Dao dao, String methodName, Object... args) throws Exception {
        return getDaoService().daoinvoke(dao, methodName, args);
    }

    /**
     * Создать dao, методы которого можно свободно вызывать
     *
     * @param daoName комбинация "domain/dao" или "domain"
     */
    public Dao createDao(String daoName) {
        return getDaoService().createDao(daoName);
    }

    /**
     * Создать dao, методы которого можно свободно вызывать
     */
    public <A extends Dao> A createDao(Class<A> cls) {
        return getDaoService().createDao(cls);
    }

    ////// db

    /**
     * DbSource по имени
     */
    public DbSource getDbSource(String name) {
        return dbsources.get(name);
    }

    /**
     * DbSource по имени 'default'
     */
    public DbSource getDbSource() {
        return getDbSource("default");
    }

    /**
     * Db с именем 'default'
     */
    public Db getDb() {
        return getDbSource().getDb();
    }

    /**
     * Db с именем name
     */
    public Db getDb(String name) {
        return getDbSource(name).getDb();
    }

    ////// dataloader

    public DataLoader createDataLoader(String name) {
        return (DataLoader) objectFactory.create(getRt().getChild("dataloader/" + name));
    }

}
