package jandcode.dbm;

import jandcode.app.*;

/**
 * Предок для расширений модели.
 */
public abstract class ModelExt extends CompRtExt {

    public ModelExt(Model comp) {
        super(comp);
    }

    public Model getComp() {
        return (Model) comp;
    }

    public Model getModel() {
        return (Model) comp;
    }

}
