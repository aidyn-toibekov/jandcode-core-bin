package jandcode.dbm;

import jandcode.app.*;

/**
 * Предок для расширений для компонентов ModelMember
 */
public abstract class ModelMemberExt extends CompRtExt {

    public ModelMemberExt(ModelMember comp) {
        super(comp);
    }

    public ModelMember getComp() {
        return (ModelMember) comp;
    }

    public Model getModel() {
        return getComp().getModel();
    }

}
