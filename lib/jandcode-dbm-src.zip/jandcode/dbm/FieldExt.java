package jandcode.dbm;

import jandcode.app.*;

/**
 * Предок для расширений поля.
 */
public abstract class FieldExt extends CompRtExt {

    public FieldExt(Field comp) {
        super(comp);
    }

    public Field getComp() {
        return (Field) comp;
    }

    public Model getModel() {
        return getComp().getModel();
    }

    public Domain getDomain() {
        return getComp().getOwner();
    }

}
