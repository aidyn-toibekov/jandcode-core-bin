package jandcode.dbm.test;

import jandcode.app.*;
import jandcode.app.test.*;
import jandcode.dbm.*;
import jandcode.dbm.dao.*;
import jandcode.dbm.data.*;
import jandcode.dbm.dataloader.*;
import jandcode.dbm.db.*;
import jandcode.utils.*;
import jandcode.utils.rt.*;
import jandcode.utils.test.*;

public class TestExtDbm extends TestExt {

    private Model model;
    private Db db;
    private DbUtils dbUtils;

    public App getApp() {
        return test.getExt(TestExtApp.class).getApp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
        if (db != null) {
            db.disconnectForce();
        }
    }

    /**
     * Модель default
     */
    public Model getModel() {
        if (model == null) {
            return getApp().service(ModelService.class).getModel();
        }
        return model;
    }

    /**
     * Установить модель по умолчанию для этого объекта
     */
    public void setModel(Model model) {
        this.model = model;
    }

    /**
     * Установить модель по умолчанию для этого объекта
     */
    public void setModel(String modelName) {
        setModel(getModel(modelName));
    }

    /**
     * Модель modelName
     */
    public Model getModel(String modelName) {
        return getApp().service(ModelService.class).getModel(modelName);
    }

    /**
     * Создать домен из модели по умолчанию
     */
    public Domain createDomain(String domainName) {
        return getModel().createDomain(domainName);
    }

    /**
     * Создать store из модели по умолчанию
     */
    public DataStore createStore(String domainName) {
        return UtData.createStore(getModel().createDomain(domainName));
    }

    /**
     * Создать record из модели по умолчанию
     */
    public DataRecord createRecord(String domainName) {
        return UtData.createStore(getModel().createDomain(domainName)).add();
    }

    public Dao createDao(String daoName) {
        return getModel().createDao(daoName);
    }

    public <A extends Dao> A createDao(Class<A> cls) {
        return getModel().createDao(cls);
    }

    /**
     * daoinvoke для модели по умолчанию
     */
    public Object daoinvoke(String domainName, String daoMethod, Object... args) throws Exception {
        return getModel().daoinvoke(domainName, daoMethod, args);
    }

    /**
     * Вывести таблицу на консоль
     */
    public void outTable(DataStore t) {
        UtData.outTable(t);
    }

    /**
     * Вывести таблицу на консоль
     *
     * @param limit сколько записей выводить
     */
    public void outTable(DataStore t, int limit) {
        UtData.outTable(t, limit);
    }

    /**
     * Вывести запись в виде таблицы на консоль
     */
    public void outTable(DataRecord t) {
        UtData.outTable(t);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     */
    public void outTable(DataTreeNode t) {
        UtData.outTable(t);
    }

    /**
     * Для отладки. Вывести таблицу на консоль
     *
     * @param limit сколько максимум записей выводить
     */
    public void outTable(DataTreeNode t, int limit) {
        UtData.outTable(t, limit);
    }

    /**
     * Загружает rt из ресурса. Загрузка производится в контексте getModel.getRt(),
     * т.е. в загружаемом файле будут правильно распознаны все parent.
     */
    public Rt loadRt(String resPath) throws Exception {
        Rt r = getModel().getRt().createRt("root");
        r.load().fromRes(test.replaceTestName(resPath));
        return r;
    }

    /**
     * Загрузить данные из dataloader домена.
     *
     * @param domainName     имя домена
     * @param dataloaderName имя dataloader
     * @return store с именем default из dataloader
     */
    public DataStore loadDataLoader(String domainName, String dataloaderName) throws Exception {
        ListNamed<DataStore> lst = loadDataLoaderAll(domainName, dataloaderName);
        return lst.get(DataLoader.DEFAULT);
    }

    /**
     * Загрузить данные из dataloader домена.
     *
     * @param domainName     имя домена
     * @param dataloaderName имя dataloader
     * @return список всех store из dataloader
     */
    public ListNamed<DataStore> loadDataLoaderAll(String domainName, String dataloaderName) throws Exception {
        Domain domain = createDomain(domainName);
        DataLoaderDomainExt ldr = new DataLoaderDomainExt(domain);
        return ldr.loadDataLoader(dataloaderName);
    }

    /**
     * Загрузить db-данные из домена.
     *
     * @param domainName имя домена
     * @param dbdata     тип данных (prod/test)
     * @return store с db-данными для домена
     */
    public DataStore loadDbData(String domainName, String dbdata) throws Exception {
        ListNamed<DataStore> lst = loadDbDataAll(domainName, dbdata);
        return lst.get(domainName);
    }

    /**
     * Загрузить db-данные из домена.
     *
     * @param domainName имя домена
     * @param dbdata     тип данных (prod/test)
     * @return список всех store с db-данными для всех доменов, которые создали загрузчики
     */
    public ListNamed<DataStore> loadDbDataAll(String domainName, String dbdata) throws Exception {
        Domain domain = createDomain(domainName);
        DataLoaderDomainExt ldr = new DataLoaderDomainExt(domain);
        return ldr.loadDbData(dbdata);
    }

    /**
     * Загрузить данные из файла описывающего dataloader.
     *
     * @param filename имя файла. Обычно лежит в dbdata/test или dbdata/prod
     * @return список всех store из dataloader
     */
    public ListNamed<DataStore> loadDataLoaderAll(String filename) throws Exception {
        DataLoaderModelExt me = new DataLoaderModelExt(getModel());
        DataLoader ldr = me.createDataLoaderFromFile(filename);
        ldr.load();
        return ldr.getDatas();
    }

    /**
     * Загрузить данные из файла описывающего dataloader.
     *
     * @param filename имя файла. Обычно лежит в dbdata/test или dbdata/prod
     * @return данные по умолчанию из dataloader
     */
    public DataStore loadDataLoader(String filename) throws Exception {
        DataLoaderModelExt me = new DataLoaderModelExt(getModel());
        DataLoader ldr = me.createDataLoaderFromFile(filename);
        ldr.load();
        return ldr.getData();
    }

    /**
     * База данных по умолчанию из модели по умолчанию. Соединение установлено.
     * disconnect будет сделан автоматически при выходе из теста.
     */
    public Db getDb() throws Exception {
        if (db == null) {
            db = getModel().getDb();
        }
        if (!db.isConnected()) {
            db.connect();
        }
        return db;
    }

    /**
     * Утилиты, связанные с базой getDb().
     * Соединение установлено.
     * disconnect будет сделан автоматически при выходе из теста.
     */
    public DbUtils getDbUtils() throws Exception {
        if (dbUtils == null) {
            dbUtils = new DbUtils(getDb());
        }
        return dbUtils;
    }

    /**
     * Синоним для getDbUtils()
     */
    public DbUtils getUt() throws Exception {
        return getDbUtils();
    }

}
