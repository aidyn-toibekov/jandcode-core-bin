package jandcode.dbm.test;

import jandcode.app.test.*;

public class DbmTestCase extends AppTestCase {

    public TestExtDbm dbm = createExt(TestExtDbm.class);

}
