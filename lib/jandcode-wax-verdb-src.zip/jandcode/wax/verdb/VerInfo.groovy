package jandcode.wax.verdb

import jandcode.dbm.dataloader.*
import jandcode.dbm.db.*
import jandcode.dbm.jc.*
import jandcode.utils.*
import jandcode.utils.error.*
import jandcode.wax.verdb.dbdriver.*

/**
 * Информация о версии
 */
class VerInfo extends Named implements Comparable<VerInfo> {

    /**
     * Владелец
     */
    VerdbProjectExt owner

    /**
     * Номер версии
     */
    int num

    /**
     * Каталог с версией
     */
    String path


    VerInfo(VerdbProjectExt owner, String path, int num) {
        this.owner = owner
        this.path = path
        this.num = num
        if (this.num == 0) {
            String numS = UtFile.filename(path)
            this.num = UtCnv.toInt(numS)
            if (this.num == 0) {
                throw new XError("Каталог ${path} имеет не числовое имя")
            }
        }
        this.name = UtString.padLeft(UtString.toString(this.num), 5, '0')
        if (this.path == null) {
            this.path = owner.data_dir + "/" + this.name
        }
    }

    int compareTo(VerInfo o) {
        return num <=> o.num
    }

    String toString() {
        return name;
    }

    /**
     * Возвращает имена файлов с шагами миграции. Файл должен иметь расширение groovy, xml, sql
     * и имя должно начинаться с цифры
     */
    List getMigrateSteps() {
        def fs = owner.ant.fileset(dir: path) {
            include(name: "*.sql")
            include(name: "*.groovy")
            include(name: "*.xml")
        }
        def res = []
        for (f in fs) {
            def fn = f.toString()
            def fn1 = UtFile.filename(fn)
            if (UtString.isNumChar(fn1.charAt(0))) {
                res.add(fn)
            }
        }
        res.sort()
        return res
    }

    /**
     * Собирает полный create-all.sql в каталоге outdir и возвращает его полное имя
     */
    String makeBundleCreateSql(String outdir) {
        String outfile = UtFile.join(outdir, name + "-create-all.sql")
        owner.ant.concat(destfile: outfile) {
            filelist(dir: path,
                    files: "create.sql,create-references.sql")
        }
        return outfile
    }

    /**
     * Создает экземпляр DbmProjectExt настроенный на базу этой версии
     * с указанным суффиксом
     * @param suffix
     * @return
     */
    DbmProjectExt createDbmext(String suffix = null) {
        if (suffix == null) suffix = "_" + name
        VerdbDbSupportService vdb
        vdb = owner.dbmext.db.service(jandcode.wax.verdb.dbdriver.VerdbDbSupportService)
        def dbs = vdb.cloneDbSource(suffix)
        dbs.name = "v" + suffix
        DbmProjectExt res = owner.createExt(DbmProjectExt)
        res.appendModelNameToPath = false
        res.modelName = owner.modelName
        res.dbscript_dir = path
        res.db = dbs.db
        return res
    }

    /**
     * Принять все шаги миграции
     */
    void applyMigrateSteps(DbmProjectExt dest) {
        dest.ut.delim("apply migrate steps: ${name}")
        def steps = getMigrateSteps()
        //
        dest.db.connect()
        try {
            for (f in steps) {
                dest.ut.delim("exec file: ${f}")
                def ext = UtFile.ext(f)
                if (ext == 'groovy') {
                    dest.ut.execscript(f, [db: dest.db])
                } else if (ext == 'sql') {
                    dest.execScript(f)
                } else if (ext == 'xml') {
                    XmlDataLoader ldr = dest.model.createDataLoader("xml")
                    ldr.setFile(f)
                    ldr.load()
                    DbUtils dbu = new DbUtils(dest.db)
                    dbu.updateTable(ldr.getData().getDomain().getName(), ldr.getData())
                } else {
                    throw new XError("Неправильное расширение файла")
                }
            }
            //
            dest.log "update verdb num: ${this.num}"
            def vsvc = dest.db.service(WaxVerdbService)
            vsvc.updateCurrentVer(this.num)
            //
        } finally {
            dest.db.disconnect()
        }
    }

}
