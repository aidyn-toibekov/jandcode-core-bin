package jandcode.wax.verdb.dbdriver

class DerbyVerdbDbSupportService extends VerdbDbSupportService {

    void grabFlatStruct(Writer f) {
        db.connect()

        try {
            // tables & columns
            def t = db.loadSqlNative("""
                    select * from SYS.SYSTABLES t, SYS.SYSCOLUMNS c
                        where c.referenceid = t.TABLEID and t.TABLETYPE<>'S'
                        order by t.TABLENAME, c.COLUMNNAME
            """)
            _out_table("tables/columns", t, f, [
                    "TABLEID", "SCHEMAID", "REFERENCEID"])

        } finally {
            db.disconnect()
        }

    }

}
