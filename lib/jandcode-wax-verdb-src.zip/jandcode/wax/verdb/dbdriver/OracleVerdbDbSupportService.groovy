package jandcode.wax.verdb.dbdriver

import jandcode.dbm.db.*

class OracleVerdbDbSupportService extends VerdbDbSupportService {


    void grabFlatStruct(Writer f) {
        db.connect()

        try {
            def exc_col = [
                    "OWNER", "LAST_CHANGE", "LAST_ANALYSED",
                    "LOW_VALUE", "HIGH_VALUE", "DENSITY"]

            // tables & columns
            def t = db.loadSql("""
              select * from user_tab_columns order by table_name, column_name
            """)
            _out_table("user_tab_columns", t, f, exc_col + ["COLUMN_ID"])
            // constrains
            t = db.loadSql("""
              select * from user_constraints order by table_name, constraint_name
            """)
            _out_table("user_constraints", t, f, exc_col)
            // constrains
            t = db.loadSql("""
              select * from user_cons_columns order by table_name, constraint_name
            """)
            _out_table("user_cons_columns", t, f, exc_col)
            // constrains
            t = db.loadSql("""
              select * from user_sequences order by sequence_name
            """)
            _out_table("user_sequences", t, f, exc_col + ["LAST_NUMBER"])
            // source
            t = db.loadSql("""
              select * from user_source order by name, type, line
            """)
            _out_table("user_source", t, f, exc_col)

        } finally {
            db.disconnect()
        }

    }

    DbSource cloneDbSource(String suffix) {
        DbSource d = getDbSource().clone()
        d.name = d.name + suffix
        d.username = d.username + suffix
        return d
    }


}
