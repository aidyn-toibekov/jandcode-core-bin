package jandcode.wax.verdb.dbdriver

import jandcode.dbm.db.*

/**
 * Поддержка отличий баз данных для verdb
 */
abstract class VerdbDbSupportService extends DbMember {

    /**
     * Собирает структуру реальной базы данных в виде некоторого текста,
     * который пригоден для сравнения в целях выяснения отличий 2-х структур
     * @param w куда писать
     */
    public abstract void grabFlatStruct(Writer w);

    //////

    protected void _out_table(title, t, r, excl, new_line_fields = null) {
        if (new_line_fields == null) {
            new_line_fields = []
        }
        r.write("\n${title}\n")
        r.write("----------------------------------------------------------------------\n")
        for (q in t) {
            r.write(title)
            r.write("> ")
            for (f in t.domain.fields) {
                def ignore = false;
                for (ex in excl) {
                    if (f.name.toUpperCase().indexOf(ex.toUpperCase()) != -1) {
                        ignore = true;
                    }
                }
                for (ex in new_line_fields) {
                    if (f.name.toUpperCase().indexOf(ex.toUpperCase()) != -1) {
                        ignore = true;
                    }
                }
                if (ignore) {
                    continue
                }
                r.write(f.name)
                r.write("=")
                r.write(q.getValueString(f.name))
                r.write("; ")
            }
            // new line fields
            if (!new_line_fields.empty) {
                for (f in t.domain.fields) {
                    def ignore = false;
                    for (ex in new_line_fields) {
                        if (f.name.toUpperCase().indexOf(ex.toUpperCase()) == -1) {
                            ignore = true;
                        }
                    }
                    if (ignore) {
                        continue
                    }
                    r.write("\n")
                    r.write(f.name)
                    r.write("=")
                    r.write("\n")
                    r.write(q.getValueString(f.name))
                    r.write("\n")
                }
            }

            r.write("\n")
        }
        r.write("----------------------------------------------------------------------\n")
    }

    public DbSource cloneDbSource(String suffix) {
        DbSource d = getDbSource().clone()
        d.name = d.name + suffix
        d.database = d.database + suffix
        return d
    }

}
