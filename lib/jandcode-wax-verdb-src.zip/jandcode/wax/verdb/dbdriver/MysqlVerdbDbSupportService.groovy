package jandcode.wax.verdb.dbdriver

class MysqlVerdbDbSupportService extends VerdbDbSupportService {

    void grabFlatStruct(Writer f) {
        db.connect()

        try {
            // tables & columns
            def t = db.loadSqlNative("""
                select * from information_schema.columns
                where table_schema='${dbSource.database}'
                order by table_name, column_name
            """)
            _out_table("tables/columns", t, f, [
                    "TABLE_CATALOG", "TABLE_SCHEMA", "ORDINAL_POSITION",
                    "PRIVILEGES", "COLUMN_COMMENT", "COLLATION_NAME",
                    "CHARACTER_OCTET_LENGTH", "CHARACTER_SET_NAME",
                    "DATA_TYPE"])

            // indexes
            t = db.loadSqlNative("""
                select * from information_schema.key_column_usage where
                table_schema='${dbSource.database}'
                order by table_name, column_name, ordinal_position
            """)
            _out_table("indexes", t, f, [
                    "CONSTRAINT_CATALOG", "CONSTRAINT_SCHEMA",
                    "TABLE_CATALOG", "TABLE_SCHEMA",
                    "REFERENCED_TABLE_SCHEMA"
            ])

            // stored
            t = db.loadSqlNative("""
                select * from information_schema.routines
                where routine_schema='${dbSource.database}'
            """)
            _out_table("routines", t, f, [
                    "ROUTINE_CATALOG", "ROUTINE_SCHEMA", "CHARACTER_OCTET_LENGTH",
                    "CHARACTER_SET_NAME", "COLLATION_NAME", "COLLATION_CONNECTION",
                    "DATABASE_COLLATION", "CHARACTER_SET_CLIENT", "LAST_ALTERED",
                    "CREATED"
            ], ["ROUTINE_DEFINITION"])

            // triggers
            t = db.loadSqlNative("""
                select * from information_schema.triggers
                where trigger_schema='${dbSource.database}'

            """)
            _out_table("triggers", t, f, [
                    "TRIGGER_CATALOG", "TRIGGER_SCHEMA", "CHARACTER_OCTET_LENGTH",
                    "CHARACTER_SET_NAME", "COLLATION_NAME", "COLLATION_CONNECTION",
                    "DATABASE_COLLATION", "CHARACTER_SET_CLIENT", "LAST_ALTERED",
                    "CREATED", "EVENT_OBJECT_SCHEMA"

            ], ["ACTION_STATEMENT"])

        } finally {
            db.disconnect()
        }

    }

}
