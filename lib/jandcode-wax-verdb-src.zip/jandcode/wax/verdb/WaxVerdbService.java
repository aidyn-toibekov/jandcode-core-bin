package jandcode.wax.verdb;

import jandcode.dbm.data.*;
import jandcode.dbm.db.*;
import org.apache.commons.logging.*;

/**
 * Сервис для управления версией базы данных
 */
public class WaxVerdbService extends DbSourceMember {

    protected static Log log = LogFactory.getLog(WaxVerdbService.class);
    private String tableName = "Wax_VerDb";

    /**
     * Возвращает версию текущей базы данных
     */
    public long getCurrentVer() throws Exception {
        Db db = getDbSource().getDb();
        db.connect();
        try {
            DataStore t = db.loadSql("select * from " + tableName + " where id=1");
            if (t.size() == 0) {
                return 0;
            }
            return t.get(0).getValueLong("ver");
        } finally {
            db.disconnect();
        }
    }

    /**
     * Возвращает версию базы данных, которая требуется.
     * Версия хранится в "verdb:ver" у модели
     */
    public long getNeedVer() throws Exception {
        return getModel().getRt().getValueLong("verdb:ver", 0);
    }

    /**
     * Установить версию базы
     *
     * @param num Номер версии
     */
    public void updateCurrentVer(long num) throws Exception {
        log.info("begin updateCurrentVer to " + num);
        Db db = getDbSource().getDb();
        db.connect();
        try {
            DataStore t = db.loadSql("select * from " + tableName + " where id=1");
            if (t.size() == 0) {
                db.execSql("insert into table " + tableName + " (id,ver) values (1,:id)", num);
            } else {
                db.execSql("update " + tableName + " set ver=:{id} where id=1", num);
            }
        } finally {
            db.disconnect();
        }
        log.info("end updateCurrentVer to " + num);
    }

}
