package jandcode.wax.verdb;


import jandcode.dbm.jc.*
import jandcode.jc.*
import jandcode.utils.*
import jandcode.utils.easyxml.*
import jandcode.utils.error.*
import jandcode.wax.verdb.dbdriver.*

public class VerdbProjectExt extends ProjectExt {

    static String not_committed_file = "not_committed.properties"

    private String _data_dir = "scripts/verdb"
    private List<VerInfo> _verInfos
    private String _temp_dir = "temp/verdb"

    private VerInfo _currentVerInfo

    DbmProjectExt dbmext

    protected void onSetProject() {
        dbmext = createExt(DbmProjectExt)
    }

    void setModelName(String v) {
        dbmext.modelName = v
    }

    String getModelName() {
        return dbmext.modelName
    }

    /**
     * Каталог с данными verdb
     */
    String getData_dir() {
        return wd(_data_dir + "/" + dbmext.model.name)
    }

    void setData_dir(String data_dir) {
        _data_dir = data_dir
    }

    /**
     * Каталог с временными данными verdb
     */
    String getTemp_dir() {
        def d = wd(_temp_dir + "/" + dbmext.model.name)
        if (!fu.exists(d)) {
            ant.mkdir(dir: d)
        }
        return d
    }

    //////

    /**
     * Список всех версий
     */
    List<VerInfo> getVerInfos() {
        if (_verInfos == null) {
            List<VerInfo> tmp = new ArrayList<VerInfo>()
            if (UtFile.exists(data_dir)) {
                for (f in ut.dirlist("*", data_dir)) {
                    VerInfo vi = new VerInfo(this, f, 0)
                    tmp.add(vi)
                }
                Collections.sort(tmp)
            }
            _verInfos = tmp
        }
        return _verInfos
    }

    /**
     * Получить версию по номеру
     */
    VerInfo getVerInfo(int num) {
        for (v in verInfos) {
            if (v.num == num) return v
        }
        throw new XError("Не найдена версия: ${num}")
    }

    private int indexOfVerInfo(int num) {
        for (i in 0..verInfos.size() - 1) {
            if (verInfos[i].num == num) return i
        }
        return -1;
    }

    /**
     * Получить список версий с номерами в указанном диапазоне
     * @param from если не указана, то предыдущая для to
     * @param to если не указана, то последняя
     * @return
     */
    List<VerInfo> getVerInfoRange(int from, int to) {
        if (verInfos.size() < 2) {
            throw new XError("Для получения диапазона версий должно быть хотя бы 2 версии")
        }
        if (to <= 0) {
            to = verInfos[-1].num
        }
        if (from <= 0) {
            def i = indexOfVerInfo(to)
            if (i == 0) {
                throw new XError("Версия ${to} первой версией. Для нее нельзя получить предыдущую")
            }
            from = verInfos[i - 1].num
        }
        def res = new ArrayList<VerInfo>()
        for (v in verInfos) {
            if (v.num >= from && v.num <= to) res.add(v)
        }
        return res
    }

    /**
     * Закомичена ли последняя версия
     */
    boolean getCommited() {
        return !UtFile.exists(data_dir + "/" + not_committed_file)
    }

    /**
     * Установить/сбросить флаг коммита
     * @param value
     */
    void setCommited(boolean value) {
        if (value) {
            ant.delete(file: data_dir + "/" + not_committed_file)
        } else {
            ant.echo(message: "-", file: data_dir + "/" + not_committed_file)
        }
    }

    /**
     * Номер последней закомиченной версии
     */
    VerInfo getVerInfoLastCommited() {
        if (getCommited()) {
            return verInfos[-1]
        } else {
            return verInfos[-2]
        }
    }

    /**
     * Последняя версия
     */
    VerInfo getVerInfoLast() {
        return verInfos[-1]
    }

    /**
     * Новая версия
     * @return
     */
    VerInfo getVerInfoNew() {
        if (verInfos.empty) {
            return new VerInfo(this, null, 1)
        } else {
            return new VerInfo(this, null, verInfos[-1].num + 1)
        }
    }

    /**
     * Текущая версия
     */
    VerInfo getVerInfoCurrent() {
        if (_currentVerInfo == null) {
            _currentVerInfo = new VerInfo(this, dbmext.dbscript_dir, 999999)
            _currentVerInfo.name = "CURRENT"
            dbmext.generateDbScript(true, false)
        }
        return _currentVerInfo
    }

    //////

    /**
     * Сравнение 2-х файлов
     */
    void diff(File f1, File f2, boolean showUi) {
        log "Сравнение файлов: [${f1}] и [${f2}]"
        try {
            ut.runexe(cmd: "fc ${f1.getAbsolutePath()} ${f2.getAbsolutePath()}", showout: false, saveout: false)
        } catch (e) {
            def msg = "Файлы отличаются: [${f1}] и [${f2}]"
            log msg
            if (showUi) {
                log "Запуск ui diff"
                ant.exec(executable: "diff.bat") {
                    arg(line: "${f1.getAbsolutePath()} ${f2.getAbsolutePath()}")
                }
            }
            error msg
        }
        log "Различия не найдены"
    }

    /**
     * Проверка наличие изменений в sql
     */
    void diff(VerInfo v1, VerInfo v2, boolean showUi) {
        String f1 = v1.makeBundleCreateSql(temp_dir)
        String f2 = v2.makeBundleCreateSql(temp_dir)
        diff(new File(f1), new File(f2), showUi)
    }

    /**
     * Делает текстовый файл с реальной структурой базы (для сравнения структур)
     * @param dbe для кого
     * @return созданный файл
     */
    File makeFlatDbStruct(DbmProjectExt dbe) {
        def svc = dbe.db.service(VerdbDbSupportService)
        File outfile = new File(temp_dir + "/dbstruct-${dbe.db.dbSource.name}.txt")
        log "create file: ${outfile}"
        FileWriter f = new FileWriter(outfile)
        svc.grabFlatStruct(f)
        f.close()
        return outfile
    }

    /**
     * Сравнение физических структур баз данных
     */
    void diffDbStruct(DbmProjectExt v1, DbmProjectExt v2, boolean showUi) {
        File f1 = makeFlatDbStruct(v1)
        File f2 = makeFlatDbStruct(v2)
        diff(f1, f2, showUi)
    }

    /**
     * Обновить версию базы данных в файле module.rt проекта
     */
    public void updateVerdbInModule(long newVer) {
        String moduleFile = wd("src/" + project.package_root_dir + "/module.rt")
        if (!UtFile.exists(moduleFile)) {
            error("Не найден файл модуля: ${moduleFile}")
        }
        //
        EasyXml x = new EasyXml()
        def ldr = new EasyXmlLoader(x)
        ldr.setCommentNodeName("~")
        ldr.setTrimSpace(false)
        ldr.load().fromFile(moduleFile)
        //
        def pv = dbmext.model.rt.path + "/verdb/@ver";
        long oldVer = x.getValueLong(pv)
        if (oldVer != newVer) {
            x.setValue(pv, newVer)
            //
            def svr = new EasyXmlSaver(x)
            svr.setCommentNodeName("~")
            svr.setUseIndent(false)
            svr.save().toFile(moduleFile)
        }
    }

    //////

    /**
     * Реализация команды verdb-newver
     * @param updateLast обновить последнюю незакомиченную
     */
    void cm_newver(boolean updateLast) {
        if (updateLast) {
            if (commited) {
                error("Нет незакомиченных версий")
            }
            def nv = getVerInfoLast()
            dbmext.generateDbScript(true, false)
            dbmext.copyDbScriptsTo(nv.path, true, false)
        } else {
            if (!commited) {
                error("Существует незакомиченная версия. Используете параметр -u для обновления")
            }
            def nv = getVerInfoNew()
            dbmext.generateDbScript(true, false)
            ant.mkdir(dir: nv.path)
            dbmext.copyDbScriptsTo(nv.path, true, false)
            nv.createDbmext().appendCreateAfterSql("update Wax_VerDb set ver=${nv.num} where id=1")
            commited = false
        }
    }

    /**
     * Реализация команды сравнения структур
     * @param num1 первая
     * @param num2 вторая
     * @param showUi показывать ли ui diff
     */
    void cm_diff(int num1, int num2, boolean showUi) {
        VerInfo v1, v2
        if (verInfos.empty) {
            error("Нет информации о версиях баз данных")
        }
        if (num1 == 0 && num2 == 0) {
            if (commited || verInfos.size() < 2) {
                v1 = getVerInfoLast()
                v2 = getVerInfoCurrent()
            } else {
                v1 = getVerInfoLastCommited()
                v2 = getVerInfoLast()
            }
        } else {
            v1 = getVerInfo(num1)
            if (num2 == 0) {
                v2 = getVerInfoCurrent()
            } else {
                v2 = getVerInfo(num2)
            }
        }
        //
        log "Сравнение версий: ${v1.name} & ${v2.name}"
        //
        diff(v1, v2, showUi)
    }

    /**
     * Проверка правильности выполнения смены структуры
     * @param num1 первая
     * @param num2 вторая
     * @param showUi показывать ли ui diff
     * @param forceCreateDbV2 Принудительно пересоздавать базу версии v2
     */
    void cm_validate(int num1, int num2, boolean showUi, boolean forceCreateDbV2) {
        def v1, v2
        if (num1 == 0 && num2 == 0) {
            if (commited) {
                error("Версия закомичена и неуказаны версии для сравнения")
            }
            v1 = getVerInfoLastCommited()
            v2 = getVerInfoLast()
        } else {
            v1 = getVerInfo(num1)
            if (num2 == 0) {
                v2 = getVerInfoLast()
            } else {
                v2 = getVerInfo(num2)
            }
        }
        if (v2.num <= v1.num) {
            error("Первая версия должна быть меньше второй (${v1.num} < ${v2.num})")
        }
        log "verdb validate: ${v1.name} => ${v2.name} "
        def vs = getVerInfoRange(v1.num + 1, v2.num)
        log "changeset order: ${vs}"

        //
        def db1 = v1.createDbmext("_${v1.name}_${v2.name}")
        ut.delim "create database 1"
        db1.printDbInfo()
        db1.createDatabase(false, true, true, false)
        for (vs1 in vs) {
            vs1.applyMigrateSteps(db1)
        }
        //
        def db2 = v2.createDbmext("_${v2.name}")
        db2.printDbInfo()
        if (forceCreateDbV2 || !db2.existsDb) {
            db2.createDatabase(false, true, true, false)
        } else {
            log "Используется уже существующая база данных"
        }
        //
        diffDbStruct(db1, db2, showUi)
    }

    /**
     * commit последней версии
     */
    void cm_commit() {
        if (commited) {
            error("Нет незакомиченной версии")
        }
        def v = getVerInfoLast()
        if (v.migrateSteps.empty) {
            error("В версии ${v.name} нет скриптов миграции")
        }
        updateVerdbInModule(v.num)
        commited = true
        log """
*********************************************************
  Закомичена версия базы: ${v.name}
  Были изменены исходные тексты модуля.
  Незабудьте сделать commit исходников
*********************************************************
"""
    }

}
