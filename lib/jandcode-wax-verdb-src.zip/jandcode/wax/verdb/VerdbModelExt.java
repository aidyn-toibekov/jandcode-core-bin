package jandcode.wax.verdb;

import jandcode.dbm.*;
import jandcode.utils.rt.*;

/**
 * Утилиты для verdb и модели
 */
public class VerdbModelExt extends ModelExt {

    public VerdbModelExt(Model model) {
        super(model);
    }

    /**
     * Собираем чистую структуру базы в виде rt. Только домены и поля без всяких
     * дополнений
     */
    public Rt grabFlatDbStruct() {
        Rt res = new RtRoot();
        Rt domainsRt = res.findChild("domain", true);
        ListDomain domains = getComp().getDomainsDb();
        for (Domain domain : domains) {
            Rt domainRt = domainsRt.findChild(domain.getName(), true);
            if (domain.hasTag("dbview")) {
                domainRt.setValue("tag.dbview", true);
            }
            Rt fieldsRt = domainRt.findChild("field", true);
            for (Field f : domain.getFields()) {
                Rt fieldRt = fieldsRt.findChild(f.getName(), true);
                fieldRt.setValue("dbdatatype", f.getDbDataType());
                if (f.getSize() > 0) {
                    fieldRt.setValue("size", f.getSize());
                }
                if (f.hasRef()) {
                    fieldRt.setValue("ref", f.getRefName());
                }
            }
        }
        return res;
    }

}
