package jandcode.jboss.fixvfs;

import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.provider.*;
import org.apache.commons.vfs2.provider.url.*;
import org.jboss.vfs.VFS;
import org.jboss.vfs.*;

import java.net.*;

public class JbossFileProvider extends UrlFileProvider {

    public synchronized FileObject findFile(FileObject baseFile, String uri, FileSystemOptions fileSystemOptions) throws FileSystemException {

        try {
            final String key = this.getClass().getName();
            FileSystem fs = findFileSystem(key, fileSystemOptions);
            if (fs == null) {
                URL rootUrl = new URL("vfs://ROOT");
                String extForm = rootUrl.toExternalForm();
                final FileName rootName = getContext().parseURI(extForm);
                fs = new JbossFileSystem(rootName, fileSystemOptions);
                addFileSystem(key, fs);
            }
            //
            StringBuilder buf = new StringBuilder(80);
            UriParser.extractScheme(uri, buf);
            String resourceName = buf.toString();
            //
            VirtualFile jbossVF = VFS.getChild(resourceName);
            JbossFileObject res = JbossFileObject.create_JbossFileObject(jbossVF, fs);
            //
            return res;
        } catch (final Exception e) {
            throw new FileSystemException(e);
        }

    }

}

