package jandcode.jboss.fixvfs;

import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.FileSystem;
import org.apache.commons.vfs2.impl.*;
import org.apache.commons.vfs2.provider.*;
import org.jboss.vfs.*;

import java.io.*;
import java.util.*;

public class JbossFileObject extends AbstractFileObject implements FileObject {

    VirtualFile jbossVF;

    protected static JbossFileObject create_JbossFileObject(VirtualFile file, FileSystem fs) {
        VirtualFileName vfn = new VirtualFileName("vfs:", file.getPathName(), file.isDirectory() ? FileType.FOLDER : FileType.FILE);
        return new JbossFileObject(vfn, (AbstractFileSystem) fs, file);
    }


    protected JbossFileObject(AbstractFileName name, AbstractFileSystem fs, VirtualFile jbossVF) {
        super(name, fs);
        this.jbossVF = jbossVF;
    }


    protected FileType doGetType() throws Exception {
        if (jbossVF.isDirectory()) {
            return FileType.FOLDER;
        }
        return FileType.FILE;
    }

    protected FileObject[] doListChildrenResolved() throws Exception {
        List<VirtualFile> ch = jbossVF.getChildren();
        if (ch == null) {
            return new FileObject[0];
        }
        FileObject[] res = new FileObject[ch.size()];
        int i = 0;
        for (VirtualFile file : ch) {
            res[i] = create_JbossFileObject(file, getFileSystem());
            i++;
        }
        return res;

    }

    protected String[] doListChildren() throws Exception {
        throw new RuntimeException("doListChildren not implemented for " + getClass());
    }

    protected long doGetContentSize() throws Exception {
        return jbossVF.getSize();
    }

    protected InputStream doGetInputStream() throws Exception {
        return jbossVF.openStream();
    }

    protected long doGetLastModifiedTime() throws Exception {
        return jbossVF.getLastModified();
    }

    public boolean exists() throws FileSystemException {
        return jbossVF.exists();
    }

    public FileObject resolveFile(String path) throws FileSystemException {
        VirtualFile ch = jbossVF.getChild(path);
        return create_JbossFileObject(ch, getFileSystem());
    }

    public String toString() {
        return "vfs:" + jbossVF.getPathName();
    }

    public FileObject getParent() throws FileSystemException {
        VirtualFile parent = jbossVF.getParent();
        return create_JbossFileObject(parent, getFileSystem());
    }
}
