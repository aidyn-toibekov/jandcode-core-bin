package jandcode.jboss.fixvfs;

import org.apache.commons.vfs2.*;
import org.apache.commons.vfs2.provider.url.*;

import java.util.*;

public class JbossFileSystem extends UrlFileSystem {
    protected JbossFileSystem(FileName rootName, FileSystemOptions fileSystemOptions) {
        super(rootName, fileSystemOptions);
    }

    protected void addCapabilities(Collection<Capability> caps) {
        super.addCapabilities(caps);
        caps.add(Capability.LIST_CHILDREN);

    }
}
