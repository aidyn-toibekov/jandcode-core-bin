package jandcode.jc;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.vdir.*;

import java.util.*;

/**
 * Репозиторий проектов. Виртуальный каталог, составленный из каталогов проектов.
 */
public class Repo {

    private VDirLocal virtualdir = new VDirLocal();
    private LibHolder libHolder;
    private JcService jcService;

    public Repo(JcService jcService) {
        this.jcService = jcService;
        this.libHolder = new LibHolder(jcService);
    }

    public void addRoot(String path) {
        virtualdir.addRoot(path);
        String pathLib = UtFile.join(path, JcService.LIB_DIR);
        if (UtFile.exists(pathLib)) {
            libHolder.addDir(pathLib);
        }
    }

    /**
     * Зарегистрированные корневые каталоги
     */
    public List<String> getRoots() {
        return new ArrayList<String>(virtualdir.getRoots());
    }

    ////// files

    public String findFile(String path) {
        VFile z = virtualdir.findFile(path);
        if (z == null) {
            return null;
        }
        return z.getRealPath();
    }

    public String getFile(String path) {
        String f = findFile(path);
        if (f == null) {
            throw new XError("Не найден файл [{0}]", path);
        }
        return f;
    }

    public List<String> findFileList(String path) {
        List<VFile> z = virtualdir.findFiles(path);
        List<String> res = new ArrayList<String>();
        for (VFile item : z) {
            res.add(item.getRealPath());
        }
        return res;
    }

    public VFile findVFile(String path) {
        return virtualdir.findFile(path);
    }

    public VFile getVFile(String path) {
        VFile f = findVFile(path);
        if (f == null) {
            throw new XError("Не найден файл [{0}]", path);
        }
        return f;
    }

    ////// libs

    /**
     * Библиотека по имени
     */
    public Lib getLib(String name) {
        return libHolder.getLib(name);
    }

    /**
     * Библиотеки по имени, включая зависимости
     *
     * @param libs либо имя библиотеки, либо список имен библиотек.
     */
    public ListLib getLibs(Object libs) {
        return libHolder.getLibs(libs);
    }

    /**
     * Библиотеки по имени, включая зависимости
     *
     * @param libs                 либо имя библиотеки, либо список имен библиотек.
     * @param ignoreRecompileError true - игнорировать ошибки перекомпиляции
     */
    public ListLib getLibs(Object libs, boolean ignoreRecompileError) {
        ListLib res = libHolder.getLibs(libs);
        if (!ignoreRecompileError) {
            for (Lib it : res) {
                if (it.getProject() != null && it.getRecompileException() != null) {
                    throw new XErrorWrap(it.getRecompileException());
                }
            }
        }
        return res;
    }

    /**
     * Все доступные библиотеки
     */
    public ListLib getLibs() {
        ListLib res = new ListLib();
        res.addAll(libHolder.getItems());
        return res;
    }

    /**
     * Добавить каталог с библиотеками
     */
    public void addLibDir(String path) {
        if (UtFile.exists(path)) {
            libHolder.addDir(path);
        }
    }

    /**
     * Создать (или получить существующую) библиотеку
     *
     * @param name имя библиотеки
     */
    public Lib addLib(String name) {
        return libHolder.findOrCreate(name, "");
    }

    /**
     * Добавить в classpath набор библиотек
     */
    public void addClasspath(Object libs) {
        ListLib itms = getLibs(libs);
        for (Lib itm : itms) {
            String a = itm.getJar();
            if (!UtString.empty(a)) {
                jcService.getLog().debug("addclasspath: " + a);
                UtClass.addClasspath(a);
            }
        }
    }

}
