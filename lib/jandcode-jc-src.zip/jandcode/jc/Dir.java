package jandcode.jc;

import jandcode.utils.*;

/**
 * Каталог
 */
public class Dir {

    private String _path = "";

    /**
     * Создать экземпляр
     *
     * @param path путь. Превращается в абсолютный путь
     */
    public Dir(String path) {
        _path = UtFile.abs(path);
    }

    /**
     * Путь до каталога
     */
    public String getPath() {
        return _path;
    }

    /**
     * Установить путь (без преобразований)
     */
    public void setPath(String path) {
        _path = path;
    }

    //////

    public String toString() {
        return getPath();
    }

    public int hashCode() {
        return getPath().hashCode();
    }

    public boolean equals(Object obj) {
        if (obj instanceof Dir) {
            return getPath().equals(((Dir) obj).getPath());
        } else if (obj instanceof CharSequence) {
            return getPath().equals(obj.toString());
        } else {
            return false;
        }
    }

    //////

    /**
     * Объеденить с указанным путем и возвратить результат как абсолютный путь
     */
    public String join(CharSequence path) {
        if (path == null) {
            path = "";
        }
        return UtFile.abs(UtFile.join(getPath(), path.toString()));
    }

    /**
     * Вызов join
     */
    public String call(CharSequence path) {
        return join(path);
    }

    /**
     * Имя каталога
     */
    public String getName() {
        return UtFile.filename(getPath());
    }

    /**
     * Новый экземпляр Dir
     *
     * @param path
     * @return
     */
    public Dir dir(String path) {
        return new Dir(join(path));
    }

}