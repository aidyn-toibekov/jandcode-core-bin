package jandcode.jc.test;

import jandcode.app.test.*;

/**
 * Предок для тестов утилиты jc
 */
public class JcTestCase extends AppTestCase {

    public TestExtJc jc = createExt(TestExtJc.class);

}
