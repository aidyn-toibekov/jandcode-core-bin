package jandcode.jc.test;

import jandcode.app.*;
import jandcode.jc.*;
import jandcode.utils.*;
import jandcode.utils.test.*;

/**
 * Поддержка тестирования в контексте утилиты jc
 * В каталоге тестов нужно создать подкаталог для проектов jc.
 * Там поместить файл test.rt:
 * <root>
 * <x-include module="jandcode.jc"/>
 * </root>
 * Файлы *.jc (например project.jc) загружать через loadProject
 */
public class TestExtJc extends TestExt {

    /**
     * Ссылка на последний загруженный проект
     */
    public ProjectScript project;

    /**
     * true = jc -v
     * Устанавилвать перед загрузкой проекта\
     */
    public boolean verbose = false;

    /**
     * Загрузить проект из каталога с классом
     *
     * @param filename имя файла проекта
     */
    public ProjectScript loadProject(String filename) {
        //
        String path = test.getTestFile(filename);
        //

        App app = AppLoader.load(UtFile.path(path), "res:jandcode/jc/module.rt");
        JcService svc = app.service(JcService.class);
        svc.setVerbose(verbose);
        // кеш для тестов отключаем
        svc.getScriptHolder().getCompiler().setCompiledCacheDir(null);
        //
        Project p = svc.getProjectHolder().load(path, null, null);
        project = new ProjectScript();
        project.setDelegate(p);
        return project;
    }

    public ProjectScript loadProject() {
        return loadProject("project.jc");
    }

    public String getHelp() {
        Main m = new Main();
        return m.help(project.getProject());
    }

    public String showHelp() {
        String s = getHelp();
        System.out.println(s);
        return s;
    }

    public String getHelp(String cm) {
        Main m = new Main();
        return m.helpCm(cm, project.getProject().getCm(cm));
    }

    public String showHelp(String cm) {
        String s = getHelp(cm);
        System.out.println(s);
        return s;
    }

}
