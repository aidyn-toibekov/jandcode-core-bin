package jandcode.jc;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.io.*;

import java.io.*;
import java.util.*;

/**
 * Хранилище библиотек
 */
public class LibHolder {

    private ListLib items = new ListLib();
    private HashSet<String> usedPaths = new HashSet<String>();
    private JcService jcService;

    public LibHolder(JcService jcService) {
        this.jcService = jcService;
    }

    /**
     * Список библиотек
     */
    public ListLib getItems() {
        return items;
    }

    /**
     * Загрузка всех библиотек из указанного каталога
     */
    public void addDir(String path) {
        path = UtFile.abs(path);
        if (usedPaths.contains(path)) {
            return;
        }
        usedPaths.add(path);
        //
        DirScannerLocal fs = new DirScannerLocal();
        fs.setRecursive(false);
        fs.setRootPath(UtFile.join(path, "*.*"));
        fs.scan();
        for (File file : fs.getFiles()) {
            addFile(file.getAbsolutePath());
        }
    }

    /**
     * Добавить файл - часть библиотеки. Это может быть *.jar, *-src.zip, *.ini
     */
    public void addFile(String filename) {
        filename = UtFile.abs(filename);
        String path = UtFile.path(filename);
        String ext = UtFile.ext(filename);
        String basename = UtFile.basename(filename);
        String libname = removeVersionFromBasename(basename);

        if ("jar".equals(ext)) {
            Lib lib = findOrCreate(libname, path);
            lib.setJar(filename);

        } else if ("ini".equals(ext)) {
            Lib lib = findOrCreate(libname, path);
            lib.setIni(filename);
            Properties p = new Properties();
            PropertiesLoader loader = new PropertiesLoader(p);
            try {
                UtLoad.fromFile(loader, filename);
            } catch (Exception e) {
                throw new XErrorWrap(e);
            }
            for (Object key : p.keySet()) {
                lib.setProperty(UtString.toString(key), UtString.toString(p.get(key)));
            }

        } else if ("zip".equals(ext)) {
            String s = UtString.removeSuffix(basename, "-src");
            if (s != null) {
                Lib lib = findOrCreate(removeVersionFromBasename(s), path);
                lib.setSrc(filename);
            }

        }
    }

    protected Lib findOrCreate(String name, String libPath) {
        Lib res = items.find(name);
        if (res == null) {
            res = new Lib(jcService);
            res.setName(name);
            res.setLibPath(libPath);
            items.add(res);
        }
        return res;
    }

    //////

    /**
     * Библиотека по имени
     */
    public Lib getLib(String name) {
        Lib res = items.get(name);
        return res;
    }

    /**
     * Библиотеки по имени.
     *
     * @param libs либо имя библиотеки, либо список имен библиотек.
     *             Список формируется вместе с зависимостями
     */
    public ListLib getLibs(Object libs) {
        ListLib res = new ListLib();
        List<String> lst = UtCnv.toList(libs);
        for (String s : lst) {
            res.addWithDep(s, this);
        }
        return res;
    }

    /**
     * Из имени типа 'xxx-yyy-1.0' убирает версию и делает имя 'xxx-yyy'
     */
    protected String removeVersionFromBasename(String basename) {
        StringBuilder res = new StringBuilder();
        StringTokenizer tk = new StringTokenizer(basename, "-");
        while (tk.hasMoreTokens()) {
            String s = tk.nextToken();
            if (s.length() > 0) {
                char c = s.charAt(0);
                if (UtString.isNumChar(c)) {
                    // начало версии. досвиданья
                    break;
                }
            }
            if (res.length() != 0) {
                res.append('-');
            }
            res.append(s);
        }
        return res.toString();
    }

}
