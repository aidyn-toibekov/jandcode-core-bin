package jandcode.jc;

import jandcode.utils.*;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Список библиотек
 */
public class ListLib extends ListNamed<Lib> {

    public ListLib() {
        setNotFoundMessage("Library [{0}] not found");
    }

    public void addWithDep(String name, LibHolder libHolder) {
        Lib lib = libHolder.getLib(name);
        for (String depLib : lib.getDepends()) {
            addWithDep(depLib, libHolder);
        }
        if (!contains(name)) {
            add(lib);
        }
    }

    //////

    /**
     * classpath из jar библиотек + appendClasspath
     */
    public String classpath(String appendClasspath) {
        StringBuilder sb = new StringBuilder();
        for (Lib a : this) {
            if (sb.length() != 0) {
                sb.append(";");
            }
            sb.append(a.getJar());
        }
        if (!UtString.empty(appendClasspath)) {
            if (sb.length() > 0) {
                sb.append(";");
            }
            sb.append(appendClasspath);
        }
        return sb.toString();
    }

    /**
     * classpath из jar библиотек
     */
    public String classpath() {
        return classpath(null);
    }

    /**
     * Массив URL из jar библиотек. Для ClassLoader.
     */
    public URL[] urls() throws Exception {
        ArrayList<URL> lst = new ArrayList<URL>();
        for (Lib a : this) {
            File f = new File(a.getJar());
            lst.add(f.toURI().toURL());
        }
        return lst.toArray(new URL[]{});
    }

}
