package jandcode.jc;

import groovy.util.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Базовый скрипт
 */
public class BaseScript {

    private static UtFile fuInst = new UtFile();
    private static UtString suInst = new UtString();

    protected Base delegate;

    /**
     * Запуск скрипта
     */
    public void run() throws Exception {
    }

    ////// delegate

    /**
     * Для кого предназначен скрипт
     */
    public Base getDelegate() {
        return delegate;
    }

    public void setDelegate(Base delegate) {
        if (this.delegate != null) {
            throw new XError("Readonly property 'delegate'");
        }
        this.delegate = delegate;
    }

    /**
     * Проект, в контексте которого работает скрипт.
     */
    public Project getProject() {
        return getDelegate().getProject();
    }

    public JcService getJcService() {
        return getProject().getJcService();
    }

    ////// dynamic

    /**
     * Map с набором динамических переменных (свойства и методы).
     * Можно свободно писать и читать.
     */
    public IVariantMap getVars() {
        return getDelegate().getVars();
    }

    public Object propertyMissing(String name) {
        return getDelegate().propertyMissing(name);
    }

    public void propertyMissing(String name, Object value) {
        getDelegate().propertyMissing(name, value);
    }

    public Object methodMissing(String name, Object args) {
        return getDelegate().methodMissing(name, args);
    }

    //////

    /**
     * Включить выполнение скрипта в контексте текущего выполняемого скрипта.
     * Каждый скрипт включается только один раз. Если он уже был включен, то вызов игнорируется.
     *
     * @param path путь до скрипта. Путь рассматривается в следующей последовательности:
     *             <ul>
     *             <li>Если path абсолютный, то используется он</li>
     *             <li>относительно текущего выполняемого скрипта (относительно каталога scriptdir)</li>
     *             <li>относительно виртуального каталога <code>/</code> в репозитории</li>
     *             </ul>
     *             Используется первый найденный вариант. Если файл не найден - генерируется ошибка. Если
     *             расширение не указано, подразумевается jc. Если расширение gsp, то подразумевается,
     *             что скрипт оформлен в виде шаблона.
     */
    public void include(String path) {
        getDelegate().include(path);
    }

    /**
     * Загрузить проект из указанного места.
     *
     * @param path  или каталог, в котором лежит project.jc, или полный путь до файла
     *              проекта (который может и не иметь имя project.jc). Если путь относительный,
     *              то он рассматривается относительно проекта, из которого был произведен вызов
     * @param props свойства проекта. Эти свойства присваиваются проекту перед тем, как
     *              для него будет выполнен afterLoad. Может быть null. Эти свойства присваиваются
     *              проекту только при его первой загрузке.
     * @return загруженный проект. Каждый проект загружается только один раз в сеансе работы
     */
    public Project load(String path, Map props) {
        return getJcService().getProjectHolder().load(path, getProject(), props);
    }

    /**
     * Вызов {@link BaseScript#load(java.lang.String, java.util.Map)}
     * с параметром props==null
     */
    public Project load(String path) {
        return load(path, null);
    }

    /**
     * Создать расширение проекта
     */
    public ProjectExt createExt() {
        return createExt(ProjectExt.class);
    }

    /**
     * Создать расширение проекта
     */
    public ProjectExt createExt(Class cls) {
        ProjectExt ext = (ProjectExt) UtClass.createInst(cls);
        ext.setProject(getProject());
        return ext;
    }

    /**
     * Создать расширение проекта
     */
    public ProjectExt createExt(String clsName) {
        ProjectExt ext = (ProjectExt) UtClass.createInst(clsName);
        ext.setProject(getProject());
        return ext;
    }

    /**
     * Каталог, из которого запущен текущий скрипт
     */
    public Dir getScriptdir() {
        return getJcService().getScriptHolder().getScriptdir();
    }

    /**
     * Аргументы командной строки. Это один экземпляр для всего процесса выполнения.
     * В контекте команды (внутри Closure команды) в этом параметре находятся параметры вызова команды,
     * если команда явно вызвана из другой команды.
     */
    public IVariantMap getArgs() {
        return getJcService().getArgs();
    }

    /**
     * Репозиторий проектов
     */
    public Repo getRepo() {
        return getJcService().getRepo();
    }

    /**
     * Набор утилит для работы с файлами и их именами
     */
    public UtFile getFu() {
        return fuInst;
    }

    /**
     * Набор утилит для работы со строками
     */
    public UtString getSu() {
        return suInst;
    }

    /**
     * Коллекция утилит проекта
     */
    public Ut getUt() {
        return getProject().getUt();
    }

    /**
     * Прерывание работы скрипта с генерацией ошибки
     */
    public void error(Object msg) {
        throw new XError(UtString.toString(msg));
    }

    /**
     * Рабочий каталог текущего проекта.
     */
    public Dir getWd() {
        return getProject().getWd();
    }

    /**
     * getWd().join(path)
     */
    public String wd(CharSequence path) {
        return getWd().join(path);
    }

    /**
     * AntBuilder для рабочего каталога проекта
     */
    public AntBuilder getAnt() {
        return getJcService().getAntHolder().get(getWd());
    }

    ////// logging

    public JcLog getLog() {
        return getJcService().getLog();
    }

    public void log(Object msg) {
        getLog().info(msg);
    }

    public void debug(Object msg) {
        getLog().debug(msg);
    }

    //////

}
