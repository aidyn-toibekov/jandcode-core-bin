package jandcode.jc;

import groovy.lang.*;
import groovy.util.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Проект
 */
public class Project extends Base implements INamed {

    private String name;
    private Dir wd;
    private String projectFile;
    private List<Closure> afterLoadList = new ArrayList<Closure>();
    private Ut ut;
    private HashSet<Object> dependsCalled = new HashSet<Object>();
    private HashMap<String, List<Closure>> events = new HashMap<String, List<Closure>>();
    private JcService jcService;

    public Project(String projectFile, JcService jcService) {
        this.jcService = jcService;
        this.projectFile = projectFile;
        this.project = this;
        wd = new Dir(UtFile.abs(UtFile.path(projectFile)));
        name = wd.getName();
        ut = new Ut();
        ut.setProject(this);
    }

    public JcService getJcService() {
        return jcService;
    }

    //////

    /**
     * Имя проекта. По умолчанию - имя каталога.
     */
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    //////

    public String getProjectFile() {
        return projectFile;
    }

    public Dir getWd() {
        return wd;
    }

    public String wd(CharSequence path) {
        return getWd().join(path);
    }

    public AntBuilder getAnt() {
        return getJcService().getAntHolder().get(getWd());
    }

    /**
     * Коллекция утилит проекта
     */
    public Ut getUt() {
        return ut;
    }

    //////

    /**
     * Добавить afterLoad
     */
    public void setAfterLoad(Closure closure) {
        afterLoadList.add(closure);
    }

    /**
     * Список afterLoad
     *
     * @return
     */
    public List<Closure> getAfterLoadList() {
        return afterLoadList;
    }

    ////// cm

    public Cm findCm(String cmName) {
        cmName = cmName.replace('-', '_');
        if (cmName.startsWith("-")) {
            // игнорируем команды, которые начинаются с '_'
            return null;
        }
        Object a = getVars().get(cmName);
        if (a instanceof Cm) {
            return (Cm) a;
        }
        return null;
    }

    public Cm getCm(String cmName) {
        Cm cm = findCm(cmName);
        if (cm == null) {
            throw new XError(UtLang.t("Команда [{0}] не найдена"), cmName);
        }
        return cm;
    }

    public Map<String, Cm> getCms() {
        Map<String, Cm> res = new HashMap<String, Cm>();
        for (Map.Entry<String, Object> en : vars.entrySet()) {
            if (en.getValue() instanceof Cm) {
                String cmName = en.getKey();
                if (cmName.startsWith("_")) {
                    continue; // игнорируем команды, которые начинаются с '_'
                }
                res.put(cmName, (Cm) en.getValue());
            }
        }
        return res;
    }

    protected void addDepend(Object a) {
        if (dependsCalled.contains(a)) {
            return;
        }
        dependsCalled.add(a);
    }

    public void depend(Object... args) {
        for (Object a : args) {
            if (dependsCalled.contains(a)) {
                continue;
            }
            dependsCalled.add(a);
            if (a instanceof Closure) {
                ((Closure) a).call();
            } else if (a instanceof Cm) {
                ((Cm) a).call();
            } else {
                throw new XError("depend может быть использован только для команд и closure");
            }
        }
    }

    /**
     * Подписка на событие
     *
     * @param eventName имя событие (регистрозависимое)
     * @param code      код события
     */
    public void event(String eventName, Closure code) {
        List<Closure> lst = events.get(eventName);
        if (lst == null) {
            lst = new ArrayList<Closure>();
            events.put(eventName, lst);
        }
        lst.add(code);
    }

    /**
     * Инициация события с аргументами
     *
     * @param eventName имя события
     * @param args      аргументы
     */
    public void fireEvent(String eventName, Map args) {
        List<Closure> lst = events.get(eventName);
        if (lst == null) {
            return;
        }
        for (Closure cls : lst) {
            if (cls == null) {
                continue;
            }
            cls.call(args);
        }
    }

    /**
     * Инициация события без аргументов
     *
     * @param eventName имя события
     */
    public void fireEvent(String eventName) {
        fireEvent(eventName, null);
    }

}
