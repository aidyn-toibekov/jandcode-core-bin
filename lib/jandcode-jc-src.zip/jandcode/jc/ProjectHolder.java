package jandcode.jc;

import groovy.lang.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import org.codehaus.groovy.runtime.*;

import java.io.*;
import java.util.*;

/**
 * Список загруженных проектов
 */
public class ProjectHolder {

    private JcService jcService;
    private LinkedHashMap<String, Project> items = new LinkedHashMap<String, Project>();

    public ProjectHolder(JcService jcService) {
        this.jcService = jcService;
    }

    /**
     * Получение проекта из кеша
     *
     * @param curProject относительно какого проекта грузить. Может быть null,
     *                   тогда относительные ссылки не работают
     * @param path
     * @param props      свойства, которые присваиваются проекту при первой загрузки до выполнения
     *                   afterLoad
     * @return
     * @throws Exception
     */
    public Project load(String path, Project curProject, Map props) {
        String curPath = null;
        if (curProject != null) {
            curPath = curProject.getWd().getPath();
        }
        path = normalizeProjectPath(path, curPath);
        Project p = items.get(path);
        if (p != null) {
            return p;
        }

        JcLog lg = jcService.getLog();

        lg.debug("load project: " + path);
        // не существует проект, создаем
        p = new Project(path, jcService);
        // кешируем
        items.put(path, p);
        // включаем в виртуальный путь каталог проекта
        jcService.getRepo().addRoot(p.getWd().getPath());
        // инициализация
        if (UtFile.exists(p.getProjectFile())) {
            jcService.getScriptHolder().runScript(p, p.getProjectFile());
        }
        //
        if (props != null) {
            for (Object key : props.keySet()) {
                InvokerHelper.setProperty(p, UtString.toString(key), props.get(key));
            }
        }

        // выполняем afterLoad
        for (Closure closure : p.getAfterLoadList()) {
            closure.call(p);
        }

        // готово
        lg.debug("OK load project: " + path);
        return p;
    }

    /**
     * Список проектов
     */
    public List<Project> getList() {
        List<Project> res = new ArrayList<Project>();
        res.addAll(items.values());
        return res;
    }

    /**
     * Нормализация пути проекта
     */
    public String normalizeProjectPath(String path, String curPath) {
        if (curPath != null) {
            if (!UtFile.isAbsolute(path)) {
                path = UtFile.join(curPath, path);
            }
        }
        path = UtFile.abs(path);
        File f = new File(path);
        if (f.isDirectory()) {
            f = new File(f, JcService.PROJECT_FILE);
        }
        if (f.exists()) {
            if (f.isFile()) {
                return f.getAbsolutePath();
            } else {
                throw new XError("Project file [{0}]] is directory", f.getAbsolutePath());
            }
        } else {
            if (f.getName().equals(JcService.PROJECT_FILE)) {
                return f.getAbsolutePath();
            }
            throw new XError("Project file [{0}] not found", f.getAbsolutePath());
        }
    }

}
