package jandcode.jc;


import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.cli.*;
import jandcode.utils.error.*;
import jandcode.utils.error.impl.*;
import jandcode.utils.test.*;
import org.apache.commons.logging.*;

import java.io.*;
import java.util.*;

//todo все же для использования в скриптах нужна спец map, не VariantMap, а что то заточенное

/**
 * Запуск приложения jc
 */
public class Main {

    protected static Log log = LogFactory.getLog(Main.class);

    private boolean verbose;
    private boolean errorShowFullStack;
    public App jcapp;

    public static void main(String[] args) throws Exception {
        Main main = new Main();
        try {
            main.run(args);
        } catch (Exception e) {
            String msg = new ErrorFormatterDefault(true, main.verbose,
                    main.errorShowFullStack).getMessage(UtError.createErrorInfo(e));
            System.out.println(msg);
            System.exit(1);
        }
    }

    public void run(String[] args) throws Exception {
        String s;

        // кодировка консоли
        UtConsole.setupConsoleCharset();

        // аргументы командной строки
        CliMap cli = new CliMap(args);

        // отключаем логирование для начала
        UtLog.logOff();

        // логирование
        String opt = "log";
        if (cli.containsKey(opt)) {
            s = cli.getValueString(opt);
            if (s.length() != 0) {
                UtLog.loadProperties(s);
            }
            UtLog.logOn();
            errorShowFullStack = true;
            cli.remove(opt);
        }

        // verbose
        opt = "v";
        if (cli.containsKey(opt)) {
            verbose = true;
        }

        StopWatch sw = new StopWatch();
        if (verbose) {
            sw.start();
        }

        log.info("start jc");

        // load app
        s = System.getProperty("jandcode.appdir");
        if (s == null) {
            s = UtFile.getWorkdir().getAbsolutePath();
        }
        jcapp = AppLoader.load(s, "res:jandcode/jc/jc-app.rt");

        //
        JcService svc = jcapp.service(JcService.class);
        svc.setVerbose(verbose);
        svc.setArgs(cli);

        String compilerCacheDir = svc.getScriptHolder().getCompiler().getCompiledCacheDir();

        if (verbose) {
            svc.getLog().debug("jc home: " + jcapp.getAppdir());
            svc.getLog().debug("jc script cache: " + compilerCacheDir);
        }

        // auto csc
        String cscCheckFile = UtFile.join(compilerCacheDir, "_csc_flag");
        String cscCur = copyright();
        String cscPrev = "";
        try {
            cscPrev = UtFile.loadString(cscCheckFile);
        } catch (Exception e) {
        }
        //
        opt = "csc";
        if (cli.containsKey(opt) || !cscCur.equals(cscPrev)) {
            svc.getLog().info("clear script cache: " + compilerCacheDir);
            UtFile.cleanDir(compilerCacheDir);
            UtFile.saveString(cscCur, new File(cscCheckFile));
        }

        // каталог проекта
        String projectPath = UtFile.getWorkdir().getAbsolutePath();

        // переопределение файла проекта
        opt = "f";
        if (cli.containsKey(opt)) {
            projectPath = cli.getValueString(opt);
            if (UtString.empty(projectPath)) {
                throw new XError(UtLang.t("Не указано имя файла в опции -f"));
            }
            cli.remove(opt);
        }

        // загружаем корневой проект (тот, где установлена jc)
        svc.getProjectHolder().load(jcapp.getAppdir(), null, null);

        // переопределение автозагружаемых проектов
        opt = "load";
        if (cli.containsKey(opt)) {
            String loadProjects = cli.getValueString(opt);
            cli.remove(opt);
            if (UtString.empty(loadProjects)) {
                throw new XError(UtLang.t("Не указаны проекты в опции -load"));
            }
            svc.getLog().debug("-load:" + loadProjects);
            String[] ar = loadProjects.split(",");
            for (String ar1 : ar) {
                svc.getProjectHolder().load(ar1, null, null);
            }
        }

        // загружаем запускаемый проект
        Project project = svc.getProjectHolder().load(projectPath, null, null);

        // если файл проекта несуществует - подгружаем скрипт empty
        if (!UtFile.exists(project.getProjectFile())) {
            String ss = JcService.SCRIPTS_DIR + "/empty.jc";
            String fn = svc.getScriptHolder().findScript(ss, false);
            if (fn != null) {
                project.include(ss);
            }
        }

        // проект загружен

        if (cli.getParams().size() == 0) {
            // нет команды
            System.out.println(help(project));
            return;
        }

        // запуск команды
        String cmName = cli.getParams().get(0);
        cli.getParams().remove(0);
        Cm cm = project.getCm(cmName);

        if (cli.containsKey("h") || cli.containsKey("?")) {
            // просто помощь по команде
            System.out.println(helpCm(cmName, cm));
            return;
        }

        System.out.println(homepath(jcapp));
        cm.call(cli);

        log.info("stop jc");

        if (verbose) {
            sw.stop();
        }

    }

    ////// help

    private String copyright() {
        VersionInfo vi = new VersionInfo("jandcode.jc");
        return "Jandcode Jc Version " + vi.getVersion() + " (C) 2011-2012 Sergey Kravchenko";
    }

    private String homepath(App app) {
        return "jc home path: " + app.getAppdir();
    }

    private String usage() {
        CliHelp h = new CliHelp();
        h.setHelpToNextLine(true);
        h.addParam("jc COMMAND [OPTIONS]", "Запуск команды COMMAND");
        h.addParam("jc COMMAND -h", "Помощь по указанной команде");
        h.addParam("jc", "Список доступных команд");
        return h.toString();
    }

    private String commonOpt() {
        CliHelp z = new CliHelp();
        z.addOption("log", "Включение логирования. ARG - имя файла в формате log4j.\n" +
                "Можно не указывать, тогда используются настройки по умолчанию", true);
        z.addOption("v", "Включение режима с большим числом сообщений");
        z.addOption("f", "Имя файла проекта. По умолчанию " + JcService.PROJECT_FILE + " в текущем каталоге",
                true);
        z.addOption("h", "Помощь по команде");
        z.addOption("csc", "Очистить кеш скриптов перед запуском");
        z.addOption("load", "Список проектов через запятую, которые будут загружены\nдо основного проекта", true);
        return z.toString();
    }

    public String help(Project project) {
        StringBuilder sb = new StringBuilder();
        sb.append(copyright()).append("\n");
        sb.append(homepath(project.getJcService().getApp())).append("\n");
        sb.append("Файл проекта: ").append(project.getProjectFile());
        if (!UtFile.exists(project.getProjectFile())) {
            sb.append(" (НЕСУЩЕСТВУЕТ)");
        }
        sb.append("\n\n");
        sb.append("Использование:").append("\n");
        sb.append(usage()).append("\n");
        sb.append("Опции:").append("\n");
        sb.append(commonOpt()).append("\n\n");
        //
        Map<String, Cm> res = project.getCms();
        if (res.size() == 0) {
            sb.append("Нет доступных команд").append("\n");
        } else {
            sb.append("Команды:").append("\n");
            CliHelp h = new CliHelp();
            for (Map.Entry<String, Cm> en : res.entrySet()) {
                h.addParam(en.getKey().replace('_', '-'), UtString.getLine(en.getValue().getHelp(), 0));
            }
            sb.append(h.toString()).append("\n");
        }
        //
        return sb.toString();
    }

    public String helpCm(String cmName, Cm cm) {
        cmName = cmName.replace('_', '-');
        StringBuilder sb = new StringBuilder();
        sb.append(copyright()).append("\n");
        sb.append(homepath(cm.getProject().getJcService().getApp())).append("\n\n");
        //
        sb.append("Команда: ").append(cmName).append("\n\n");
        //
        sb.append(cm.getHelp()).append("\n\n");
        //
        sb.append("Общие опции:").append("\n");
        sb.append(commonOpt()).append("\n\n");
        //
        CliHelp z = new CliHelp();
        for (Cm.Arg arg : cm.getArgs()) {
            z.addOption(arg.getName(), arg.getHelp(), arg.hasArg());
        }
        String s = z.toString();
        if (s.length() > 0) {
            sb.append("Опции:").append("\n");
            sb.append(s);
        }
        //
        return sb.toString();
    }


}
