package jandcode.jc;

import groovy.lang.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

import java.util.*;

/**
 * Команда проекта
 */
public class Cm {

    private static final String NO_HELP = "(нет описания)"; // NLS

    private Project project;
    private String help;
    private ListNamed<Arg> args = new ListNamed<Arg>();
    private Closure closure;

    public class Arg extends Named {
        String help;
        Object value = false;

        public boolean hasArg() {
            return getDataType() != DataType.BOOLEAN;
        }

        public String getHelp() {
            return help == null ? UtLang.t(NO_HELP) : help;
        }

        public Object getValue() {
            return value;
        }

        public int getDataType() {
            return DataType.getDataType(value);
        }
    }

    public Cm(Project project, String help, Map args, Closure closure) {
        this.project = project;
        this.help = help;
        this.closure = closure;
        this.setArgs(args);

    }

    //////

    public Project getProject() {
        return project;
    }

    public String getHelp() {
        return help == null ? UtLang.t(NO_HELP) : UtString.trimLast(help);
    }

    public ListNamed<Arg> getArgs() {
        return args;
    }

    public Closure getClosure() {
        return closure;
    }

    //////

    private void setArgs(Map args) {
        if (args == null) {
            return;
        }
        for (Object key : args.keySet()) {
            Arg arg = new Arg();
            arg.setName(key.toString());
            Object v = args.get(key);
            if (v instanceof CharSequence) {
                arg.value = v.toString();
            } else if (v instanceof Map) {
                Map m = (Map) v;
                if (m.containsKey("help")) {
                    arg.help = m.get("help").toString();
                }
                if (m.containsKey("value")) {
                    arg.value = m.get("value");
                }
            }
            this.args.add(arg);
        }
    }

    /**
     * Создать адаптированную к описанным параметрам map по переданному
     */
    protected IVariantMap adaptArgs(Map map) {
        VariantMap res = new VariantMap();
        //
        if (map != null) {
            for (Object key : map.keySet()) {
                String nm = key.toString();
                res.put(nm, map.get(key));
            }
        }
        //
        for (Arg arg : args) {
            if (res.containsKey(arg.getName())) {
                int dt = arg.getDataType();
                Object v = res.get(arg.getName());
                if (dt == DataType.BOOLEAN) {
                    if (v instanceof String && ((String) v).length() == 0) {
                        res.put(arg.getName(), true);
                    } else {
                        res.put(arg.getName(), DataType.toDataType(v, dt));
                    }
                } else {
                    res.put(arg.getName(), DataType.toDataType(v, dt));
                }
            } else {
                res.put(arg.getName(), arg.getValue());
            }
        }
        //
        return res;
    }

    /**
     * Выполнить команду
     */
    public Object call(Map args) {
        project.addDepend(this); // добавляем команду как выполнившуюся в проект
        //
        IVariantMap saveArgs = project.getJcService().getArgs();
        try {
            IVariantMap newArgs = adaptArgs(args);
            project.getJcService().setArgs(newArgs);
            return getClosure().call();
        } finally {
            project.getJcService().setArgs(saveArgs);
        }
    }

    /**
     * Выполнить команду
     */
    public Object call() {
        return call(new HashMap());
    }

}
