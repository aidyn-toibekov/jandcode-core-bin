package jandcode.jc.langtools;

/**
 * Для уведомления парзинга
 */
public interface ISourceStrParserListener {

    void notifyParser(SourceStrParser parser, String token, int tokenType);

}
