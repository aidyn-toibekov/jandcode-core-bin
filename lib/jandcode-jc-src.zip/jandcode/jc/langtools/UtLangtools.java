package jandcode.jc.langtools;

import java.util.*;

public class UtLangtools {

    public static boolean isRusStr(String s) {
        if (s == null) {
            return false;
        }
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c > 255) {
                return true;
            }
        }
        return false;
    }

    /**
     * Удалить из списка дубликаты
     *
     * @param data
     * @return
     */
    public static List<StrItem> removeDup(List<StrItem> data) {
        List<StrItem> res = new ArrayList<StrItem>();
        HashSet<String> tmp = new HashSet<String>();
        for (StrItem z : data) {
            String s = z.getStr().toLowerCase();
            if (tmp.contains(s)) {
                continue;
            }
            res.add(z);
            tmp.add(s);
        }
        return res;
    }

    public static class SortMapComparator implements Comparator {
        public int compare(Object o1, Object o2) {
            String s1 = o1.toString();
            String s2 = o2.toString();
            return s1.compareToIgnoreCase(s2);
        }
    }

    /**
     * Сортировка данных
     */
    public static Map sortMap(Map data) {
        LinkedHashMap tmp = new LinkedHashMap();
        List keys = new ArrayList();
        for (Object s : data.keySet()) {
            keys.add(s);
        }
        Collections.sort(keys, new SortMapComparator());
        for (Object s : keys) {
            tmp.put(s, data.get(s));
        }
        return tmp;
    }


}

