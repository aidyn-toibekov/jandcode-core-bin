package jandcode.jc.langtools

import jandcode.jc.*
import jandcode.lang.impl.*
import jandcode.utils.*
import jandcode.utils.easyxml.*
import jandcode.utils.error.*

/**
 * Утилиты для локализации проекта
 */
class LocalizeProjectExt extends ProjectExt {

    /**
     * Сбор всех строк из указанного файла
     */
    List<StrItem> parseFile(String filename) {
        String fn = UtFile.filename(filename)
        SourceStrParser p = new SourceStrParser();
        StrGrabber g = new StrGrabber();
        p.setParserListener(g);
        p.load().fromFile(filename);
        for (f in g.getItems()) {
            f.filename = filename;
        }
        return g.getItems()
    }

    /**
     * Сбор всех строк из указанного файла
     * @param dirs из каких каталогов
     * @param masks какие файлы
     */
    List<StrItem> parseDirs(List dirs, List masks) {
        List res = new ArrayList<StrItem>()
        for (d in dirs) {
            def files = ut.filelist(masks, d)
            for (f in files) {
                def r1 = parseFile(f)
                res.addAll(r1)
            }
        }
        return res
    }

    /**
     * Вытаскивание строк из xml файла. Только из атрибутов attrs и значений детей childs
     */
    List<StrItem> parseFileXml(String fn, List attrs, List childs) {
        List res = new ArrayList<StrItem>()
        Map m_attrs = [:]
        Map m_childs = [:]
        if (attrs != null) {
            for (a in attrs) {
                m_attrs.put(a.toLowerCase(), "")
            }
        }
        if (childs != null) {
            for (a in childs) {
                m_childs.put(a.toLowerCase(), "")
            }
        }
        //
        EasyXml x = new EasyXml()
        x.load().fromFileObject(fn)
        //
        _parseNodeXml(res, x, m_attrs, m_childs)
        //
        return res
    }

    void _parseNodeXml(List res, EasyXml root, Map m_attrs, Map m_childs) {
        String s;
        if (m_childs.containsKey(root.name.toLowerCase())) {
            s = root.getValueString()
            if (UtLangtools.isRusStr(s)) {
                res.add(new StrItem(s))
            }
        }
        if (root.hasAttrs()) {
            for (a in root.getAttrs()) {
                if (m_attrs.containsKey(a.key.toLowerCase())) {
                    s = a.value
                    if (UtLangtools.isRusStr(s)) {
                        res.add(new StrItem(s))
                    }
                }
            }
        }
        if (root.hasChilds()) {
            for (b in root.getChilds()) {
                _parseNodeXml(res, b, m_attrs, m_childs)
            }
        }
    }

    /**
     * Загрузка файла с переводом или просто ключами
     */
    Map loadTranslateFile(String fn) {
        TranslateLoader ldr = new TranslateLoader();
        try {
            ldr.load().fromFileObject(fn);
        } catch (Exception e) {
            throw new XErrorMark(e, fn);
        }
        def data = UtLangtools.sortMap(ldr.data)
        return data
    }

}
