package jandcode.jc.langtools;

/**
 * Представление строки из исходников
 */
public class StrItem implements Comparable<StrItem> {

    public static String nonNlsMark = "NON-NLS";
    public static String nlsMark = "NLS";

    private String str = "";
    private int lineNo;
    private String func = "";
    private String mark = "";
    private String filename = "";

    public StrItem() {
    }

    public StrItem(String str) {
        this.str = str;
    }

    /**
     * Содержимое строки
     *
     * @return
     */
    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        if (str == null) {
            str = "";
        }
        this.str = str.trim();
    }

    /**
     * Номер строки в исходном файле
     *
     * @return
     */
    public int getLineNo() {
        return lineNo;
    }

    public void setLineNo(int lineNo) {
        this.lineNo = lineNo;
    }

    /**
     * Маркировка строки NON-NLS (не требует локализации) или NLS (требует локализации)
     */
    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        if (mark == null) {
            mark = "";
        }
        this.mark = mark.toUpperCase();
    }

    /**
     * Функция, в которую обернута строка (например UtLang.t). Для простых
     * констант - пусто (в случае String s = "xxx").
     *
     * @return
     */
    public String getFunc() {
        return func;
    }

    public void setFunc(String func) {
        this.func = func;
    }

    /**
     * Имя файла
     */
    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public int compareTo(StrItem o) {
        return str.compareToIgnoreCase(o.str);
    }
}
