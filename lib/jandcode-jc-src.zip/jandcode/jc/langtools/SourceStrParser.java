package jandcode.jc.langtools;

import jandcode.utils.*;
import jandcode.utils.io.*;

/**
 * Парзер java/groovy/js кода для извлечения строковых констант.
 * гарантировано работать будет только с синтаксически правильными исходными текстами.
 */
public class SourceStrParser extends TextParser {

    public static final int T_SIGN = 1;
    public static final int T_IDN = 2;
    public static final int T_STR = 3;
    public static final int T_COMMENT = 4;

    private ISourceStrParserListener parserListener;

    public void setParserListener(ISourceStrParserListener parserListener) {
        this.parserListener = parserListener;
    }

    protected void onParse() throws Exception {
        while (true) {
            char c = next();
            if (c == EOF) {
                break; // конец
            }
            if (UtString.isIdnStartChar(c)) {
                parseIdn();
            } else if (c == '/') {
                char c1 = next();
                if (c1 == '/') {
                    parseCommentLine();
                } else if (c1 == '*') {
                    parseCommentBlock();
                } else {
                    push(c1);
                    notifyToken(c, T_SIGN);
                }
            } else if (c == '\'') {
                parseCharConst();
            } else if (c == '\"') {
                parseStrConst();
            } else if (UtString.isWhiteChar(c)) {
                parseWhite();
            } else {
                parseSign();
            }
        }
    }

    //////

    protected void notifyToken(String s, int tokenType) {
        if (parserListener != null) {
            parserListener.notifyParser(this, s, tokenType);
        }
    }

    private void notifyToken(char s, int tokenType) {
        notifyToken("" + s, tokenType);
    }

    private void parseSign() {
        // прочитано @
        notifyToken(last, T_SIGN);
    }

    private void parseWhite() throws Exception {
        while (true) {
            char c = next();
            if (c == EOF) {
                break;
            } else if (!UtString.isWhiteChar(c)) {
                push(c);
                break;
            }
        }
    }

    private void parseStrConst() throws Exception {
        String s = parseSTR();
        notifyToken(s, T_STR);
    }

    private void parseCharConst() throws Exception {
        String s = parseSTR();
        notifyToken(s, T_STR);
    }

    private String parseSTR() throws Exception {
        // прочитано "
        char bound = last;
        StringBuilder b = new StringBuilder();
        //
        boolean multiline = false;
        char x1 = next();
        char x2 = next();
        if (x1 == bound && x2 == bound) {
            multiline = true;
        } else {
            push(x2);
            push(x1);
        }
        while (true) {
            char c = next();
            if (c == EOF) {
                break;
            } else if (c == '\\') {
                char c1 = next();
                if (c1 == 'b') {
                    c = '\b';
                } else if (c1 == 't') {
                    c = '\t';
                } else if (c1 == 'n') {
                    c = '\n';
                } else if (c1 == 'f') {
                    c = '\f';
                } else if (c1 == 'r') {
                    c = '\r';
                } else if (c1 == '\"') {
                    c = '\"';
                } else if (c1 == '\'') {
                    c = '\'';
                } else if (c1 == '\\') {
                    c = '\\';
                } else if (UtString.isNumChar(c1)) {
                    // octal
                    StringBuilder b1 = new StringBuilder();
                    b1.append(c1);
                    b1.append(next());
                    b1.append(next());
                    try {
                        c = (char) Integer.parseInt(b1.toString(), 8);
                    } catch (NumberFormatException e) {
                        c = ' ';
                    }
                } else if (c1 == 'u') {
                    // unicode
                    StringBuilder b1 = new StringBuilder();
                    b1.append(next());
                    b1.append(next());
                    b1.append(next());
                    b1.append(next());
                    try {
                        c = (char) Integer.parseInt(b1.toString(), 16);
                    } catch (NumberFormatException e) {
                        c = ' ';
                    }
                } else {
                    c = c1;
                }
            } else if (c == bound) {
                if (!multiline) {
                    break;
                } else {
                    char c1 = next();
                    char c2 = next();
                    if (c1 == bound && c2 == bound) {
                        break;
                    } else {
                        push(c2);
                        push(c1);
                    }
                }
            }
            b.append(c);
        }
        return b.toString();
    }

    private void parseCommentBlock() throws Exception {
        // прочитано //
        StringBuilder b = new StringBuilder();
        while (true) {
            char c = next();
            if (c == EOF) {
                break;
            }
            if (c == '*') {
                char c1 = next();
                if (c1 == '/') {
                    break;
                } else {
                    push(c1);
                }
            }
            b.append(c);
        }
        notifyToken(b.toString(), T_COMMENT);
    }

    private void parseCommentLine() throws Exception {
        // прочитано //
        StringBuilder b = new StringBuilder();
        while (true) {
            char c = next();
            if (c == EOF || c == '\n') {
                break;
            }
            b.append(c);
        }
        notifyToken(b.toString(), T_COMMENT);
    }

    private void parseIdn() throws Exception {
        // прочитано A
        StringBuilder b = new StringBuilder();
        b.append(last);
        while (true) {
            char c = next();
            if (last == EOF) {
                break;
            }
            if (UtString.isIdnChar(c) || c == '.') {
                b.append(c);
            } else {
                push(last);
                break;
            }
        }
        notifyToken(b.toString(), T_IDN);
    }


}
