package jandcode.jc.langtools;

import java.util.*;

public class StrGrabber implements ISourceStrParserListener {

    private List<StrItem> items = new ArrayList<StrItem>();

    // предыдущее состояние
    private int tt2 = 0;       // -2
    private String ts2 = "";
    private int tt1 = 0;       // -1
    private String ts1 = "";

    private StrItem last;
    private int lastStrLineNo = 0;
    private int lastMarkLineNo = 0;
    private String lastMark = null;

    /**
     * Заграбленные элементы
     */
    public List<StrItem> getItems() {
        return items;
    }

    public void notifyParser(SourceStrParser parser, String token, int tokenType) {
        if (tokenType == SourceStrParser.T_COMMENT) {
            String[] ar = token.trim().split(" ");
            String mark = null;
            for (String s : ar) {
                if (s.equalsIgnoreCase(StrItem.nonNlsMark) || s.equalsIgnoreCase(StrItem.nlsMark)) {
                    mark = s;
                    break;
                }
            }
            if (mark != null) {
                int commLineNo = parser.getRow();
                if (commLineNo == lastStrLineNo) {
                    // коментарий в строке, где имеется константа
                    if (last != null) {
                        last.setMark(mark);
                    }
                    lastMarkLineNo = 0;
                } else {
                    // запоминаем. Возможно указано перед строкой
                    lastMarkLineNo = commLineNo;
                    lastMark = mark;
                }
            }
            return; // пока игнорим
        }

        if (tokenType == SourceStrParser.T_STR) {
            lastStrLineNo = parser.getRow();
            // флаг non-nls был ли в предыдущей строке?
            boolean marked = lastStrLineNo == lastMarkLineNo + 1;
            lastMarkLineNo = 0;
            if (tt2 == SourceStrParser.T_STR && tt1 == SourceStrParser.T_SIGN && ts1.equals("+")) {
                // предыдущий был +, объединяем строку с предыдущей
                if (last != null) {
                    last.setStr(last.getStr() + token);
                    if (marked) {
                        last.setMark(lastMark);
                    }
                }
            } else {
                // это новыя строка
                last = new StrItem();
                items.add(last);
                last.setStr(token);
                last.setLineNo(parser.getRow());
                if (marked) {
                    last.setMark(lastMark);
                }
                if (tt1 == SourceStrParser.T_SIGN && ts1.equals("(") && tt2 == SourceStrParser.T_IDN) {
                    // она обернута в функцию
                    last.setFunc(ts2);
                } else {
                    // она не обернута в функцию
                }
            }
        }

        // сдвигаем
        tt2 = tt1;
        ts2 = ts1;
        tt1 = tokenType;
        ts1 = token;
    }

}
