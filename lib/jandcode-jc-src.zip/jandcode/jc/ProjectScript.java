package jandcode.jc;

import groovy.lang.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Скрипт проекта
 */
public class ProjectScript extends BaseScript {

    public Project getDelegate() {
        return (Project) super.getDelegate();
    }

    ////// commands

    public Cm cm(Map args, String help, Closure closure) {
        if (closure == null) {
            throw new XError("Closure for command not defined");
        }
        return new Cm(getProject(), help, args, closure);
    }

    public Cm cm(Closure exec) {
        return cm(null, null, exec);
    }

    public Cm cm(String help, Closure exec) {
        return cm(null, help, exec);
    }

    ////// depend

    public void depend(Object... args) {
        getDelegate().depend(args);
    }

}
