package jandcode.jc;

import groovy.lang.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;
import org.codehaus.groovy.runtime.*;

import java.util.*;

/**
 * Объект с динамическими свойствами и методами.
 */
public class Base {

    protected VariantMap vars = new VariantMap();
    protected Project project;
    private HashSet<String> includeUsed = new HashSet<String>();

    public Base() {
    }

    public Base(Project project) {
        this.project = project;
    }

    //////

    /**
     * Map с набором динамических переменных (свойства и методы).
     * Можно свободно писать и читать.
     */
    public IVariantMap getVars() {
        return vars;
    }

    /**
     * Проект, в контексте которого работает скрипт.
     */
    public Project getProject() {
        return project;
    }

    public JcService getJcService() {
        return getProject().getJcService();
    }

    //////

    /**
     * Если vars содержит getXXX и значение closure - возвращаем.
     * Если vars содержит такое свойство - возвращаем его.
     * Иначе ошибка.
     */
    public Object propertyMissing(String name) {
        String getterName = "get" + UtString.capFirst(name);
        Object getter = getVars().get(getterName);
        if (getter instanceof Closure) {
            return ((Closure) getter).call();
        }
        if (getVars().containsKey(name)) {
            return getVars().get(name);
        }
        throw new MissingPropertyException(name, this.getClass());
    }

    /**
     * Если vars содержит setXXX и значение closure - вызываем.
     * Иначе пишем в vars.
     */
    public void propertyMissing(String name, Object value) {
        String setterName = "set" + UtString.capFirst(name);
        Object setter = getVars().get(setterName);
        if (setter instanceof Closure) {
            ((Closure) setter).call(value);
            return;
        }
        getVars().put(name, value);
    }

    /**
     * Если vars содержит свойство и оно - Closure, то вызываем.
     * Иначе ошибка.
     */
    public Object methodMissing(String name, Object args) {
        if (!getVars().containsKey(name)) {
            throw new MissingMethodException(name, this.getClass(), (Object[]) args);
        }
        Object pr = getVars().get(name);
        if (pr instanceof Closure) {
            return ((Closure) pr).call((Object[]) args);
        } else {
            return InvokerHelper.invokeMethod(pr, "call", args);
        }
    }

    /**
     * Включить выполнение скрипта в контексте текущего выполняемого скрипта.
     * Каждый скрипт включается только один раз. Если он уже был включен, то вызов игнорируется.
     *
     * @param path путь до скрипта. Путь рассматривается в следующей последовательности:
     *             <ul>
     *             <li>Если path абсолютный, то используется он</li>
     *             <li>относительно текущего выполняемого скрипта (относительно каталога scriptdir)</li>
     *             <li>относительно виртуального каталога <code>/</code> в репозитории</li>
     *             </ul>
     *             Используется первый найденный вариант. Если файл не найден - генерируется ошибка. Если
     *             расширение не указано, подразумевается jc. Если расширение gsp, то подразумевается,
     *             что скрипт оформлен в виде шаблона.
     */
    public void include(String path) {
        String fn = getJcService().getScriptHolder().findScript(path, true);
        //
        if (includeUsed.contains(fn)) {
            return;
        }
        includeUsed.add(fn);
        //
        getJcService().getScriptHolder().runScript(this, fn);
    }

}