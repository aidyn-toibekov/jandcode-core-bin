package jandcode.jc;

import jandcode.app.*;
import jandcode.utils.*;
import jandcode.utils.variant.*;

public class JcService extends Comp implements IActivate {

    /**
     * Имя файла проекта по умолчанию.
     */
    public static final String PROJECT_FILE = "project.jc";

    /**
     * Каталог со скриптами по умолчанию
     */
    public static final String SCRIPTS_DIR = "scripts";

    /**
     * Каталог со библиотеками по умолчанию
     */
    public static final String LIB_DIR = "lib";

    public static String SCRIPT_CACHE_DIR = "_jandcode.jc.scriptcache";

    private ProjectHolder projectHolder;
    private ScriptHolder scriptHolder;
    private AntHolder antHolder;
    private boolean verbose;
    private IVariantMap args = new VariantMap();
    private JcLog log;
    private Repo repo;

    public JcService() {
        projectHolder = new ProjectHolder(this);
        scriptHolder = new ScriptHolder(this);
        antHolder = new AntHolder(this);
        log = new JcLog(this);
        repo = new Repo(this);
    }

    public void activate() throws Exception {
        // кеш скомпилированных скриптов
        if (!UtString.empty(SCRIPT_CACHE_DIR)) {
            String scdir = UtFile.join(System.getProperty("java.io.tmpdir"), SCRIPT_CACHE_DIR);
            getScriptHolder().getCompiler().setCompiledCacheDir(scdir);
        }
    }

    ////// holders

    public ProjectHolder getProjectHolder() {
        return projectHolder;
    }

    public ScriptHolder getScriptHolder() {
        return scriptHolder;
    }

    public AntHolder getAntHolder() {
        return antHolder;
    }

    ////// verbose


    public boolean isVerbose() {
        return verbose;
    }

    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    ////// args

    public IVariantMap getArgs() {
        return args;
    }

    public void setArgs(IVariantMap args) {
        this.args = args;
    }

    ////// _log

    public JcLog getLog() {
        return log;
    }

    ////// repo

    public Repo getRepo() {
        return repo;
    }

    //////

//todo    public void handleGroovyDirective(HashMap<String, String> directives) {
//        for (String s : directives.keySet()) {
//            if ("classpath".equals(s)) {
//                String cp = directives.get(s);
//                getRepo().addClasspath(cp);
//            }
//        }
//    }

}
