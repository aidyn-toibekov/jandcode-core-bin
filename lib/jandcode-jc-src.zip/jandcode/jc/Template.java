package jandcode.jc;

import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.io.*;

import java.io.*;

/**
 * Шаблон для генерации
 */
public class Template extends Base {

    private Dir outdir;
    private String charset = UtString.UTF8;
    private StackList<OutFile> stack = new StackList<OutFile>();

    class OutFile {
        IndentWriter writer;
        String filename;
        boolean append;

        public IndentWriter getWriter() {
            if (writer == null) {
                try {
                    String dir = UtFile.path(filename);
                    if (!UtFile.exists(dir)) {
                        File ff = new File(dir);
                        ff.mkdirs();
                    }
                    //
                    FileOutputStream f = new FileOutputStream(filename, append);
                    Writer w = new OutputStreamWriter(f, getCharset());
                    writer = new IndentWriter(w);
                } catch (Exception e) {
                    throw new XErrorWrap(e);
                }
            }
            return writer;
        }

        public void close() {
            if (writer != null) {
                try {
                    writer.close();
                } catch (Exception e) {
                    throw new XErrorWrap(e);
                }
                writer = null;
            }
        }
    }

    public Template(Project project, String outdir) {
        this.project = project;
        this.outdir = new Dir(UtFile.abs(outdir));
        //
        OutFile f = new OutFile();
        f.filename = this.outdir.join("out.txt");
        stack.add(f);
    }

    //////

    protected IndentWriter getWriter() {
        return stack.last().getWriter();
    }

    //////

    public Dir getOutdir() {
        return outdir;
    }

    public void setCharset(String v) {
        charset = v;
    }

    public String getCharset() {
        return charset;
    }

    //////

    public String getOutfile() {
        return stack.last().filename;
    }

    public void setOutfile(String filename) {
        changeFile(filename, false, false);
    }

    public void changeFile(String filename, boolean append, boolean push) {
        OutFile f;
        if (push) {
            f = new OutFile();
            f.filename = getOutdir().join(filename);
            f.append = append;
            stack.add(f);
        } else {
            f = stack.last();
            f.close();
            f.filename = getOutdir().join(filename);
            f.append = append;
        }
    }

    public void popFile() {
        if (stack.size() <= 1) {
            throw new XError("popFile без pushFile");
        }
        OutFile f = stack.last();
        f.close();
        stack.pop();
    }

    public void flush() {
        for (OutFile f : stack) {
            f.close();
        }
        stack.clear();
    }

    //////

}
