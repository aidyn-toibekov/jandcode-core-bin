package jandcode.jc;

import jandcode.groovy.*;
import jandcode.utils.*;
import jandcode.utils.error.*;

import java.util.*;

/**
 * Скрипты
 */
public class ScriptHolder {

    public static String COMPILER_NAME = "jc-script";

    private JcService jcService;
    private Dir scriptdir = new Dir("");
    private HashSet<String> scriptFilesCache = new HashSet<String>();


    public ScriptHolder(JcService jcService) {
        this.jcService = jcService;
    }

    public GroovyCompiler getCompiler() {
        return jcService.getApp().service(GroovyService.class).getCompiler(COMPILER_NAME);
    }

    /**
     * Каталог текущего скрипта. Актуален, пока работает скрипт.
     */
    public Dir getScriptdir() {
        return scriptdir;
    }

    /**
     * Найти полное имя файла скрипта. Если расширение не указано,
     * подразумевается <code>.jc</code>.
     *
     * @param path            путь файла
     * @param errorIfNotExist true - если не найден - ошибка
     * @return полное имя файла или null, если не найден
     */
    public String findScript(String path, boolean errorIfNotExist) {
        String ext = UtFile.ext(path);
        if (UtString.empty(ext)) {
            path = path + ".jc";
        }

        String fn = path;
        if (!UtFile.isAbsolute(fn)) {

            // сначала относительно каталога текущего скрипта
            fn = getScriptdir().join(path);
            if (UtFile.exists(fn)) {
                return fn;
            }

            // относительно каталога scripts репозитория
            String spath = JcService.SCRIPTS_DIR + "/" + path;
            fn = jcService.getRepo().findFile(spath);
            if (fn != null && UtFile.exists(fn)) {
                return fn;
            }

            // относительно каталога репозитория
            fn = jcService.getRepo().findFile(path);
            if (fn != null && UtFile.exists(fn)) {
                return fn;
            }

        } else {
            // абсолютный путь
            if (UtFile.exists(fn)) {
                return fn;
            }
        }

        if (errorIfNotExist) {
            throw new XError("Script not found [{0}]", path);
        }

        return null;
    }

    /**
     * Выполнить скрипт
     *
     * @param delegate для кого
     * @param filename полное имя файла. В зависимости от расширения используются разные
     *                 базовые классы для скриптов:
     *                 .jc=ProjectScript, .gsp=TemplateScript, .groovy=BaseScript
     */
    public void runScript(Base delegate, String filename) {
        // fix для "Не найден файл res:jandcode/app/module.rt"
        VFS_fix.doFix();

        // определяем базовый скрипт
        String ext = UtFile.ext(filename);
        Class baseClass;
        if ("jc".equals(ext)) {
            baseClass = ProjectScript.class;
        } else if ("gsp".equals(ext)) {
            baseClass = TemplateScript.class;
        } else if ("groovy".equals(ext)) {
            baseClass = BaseScript.class;
        } else {
            throw new XError("Расширение скрипта не распознано: [{0}]", filename);
        }

        //
        String saveScriptdir = scriptdir.getPath();
        try {
            //
            if (!scriptFilesCache.contains(filename)) {
                // первый раз
                scriptFilesCache.add(filename);
            }
            //
            runScriptInternal(delegate, baseClass, filename);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        } finally {
            scriptdir.setPath(saveScriptdir);
        }
    }

    /**
     * Выполнить скрипт из текста
     *
     * @param delegate для кого
     * @param ext      подразумеваемое расширение скрипта
     * @param text     текст скрипта
     */
    public void runScriptText(Base delegate, String ext, String text) {
        // определяем базовый скрипт
        Class baseClass;
        if ("jc".equals(ext)) {
            baseClass = ProjectScript.class;
        } else if ("gsp".equals(ext)) {
            baseClass = TemplateScript.class;
        } else if ("groovy".equals(ext)) {
            baseClass = BaseScript.class;
        } else {
            throw new XError("Расширение скрипта не распознано: [{0}]", ext);
        }

        //
        try {
            runScriptInternalText(delegate, baseClass, text);
        } catch (Exception e) {
            throw new XErrorWrap(e);
        }
    }

    protected void runScriptInternal(Base delegate, Class baseClass, String filename) throws Exception {
        if (jcService.isVerbose()) {
            jcService.getLog().debug("exec script: " + UtFile.filename(filename) +
                    " [" + filename + "]");
        }
        //
        GroovyClazz ssrc = getCompiler().getClazz(baseClass, "void run()",
                UtFile.getFileObject(filename), baseClass == TemplateScript.class);
        BaseScript inst = (BaseScript) ssrc.createInst();
        inst.setDelegate(delegate);
        inst.run();
        //
        if (jcService.isVerbose()) {
            jcService.getLog().debug("OK exec script: " + UtFile.filename(filename) +
                    " [" + filename + "]");
        }
    }

    protected void runScriptInternalText(Base delegate, Class baseClass, String text) throws Exception {
        //
        GroovyClazz ssrc = getCompiler().getClazz(baseClass, "void run()",
                text, baseClass == TemplateScript.class);
        BaseScript inst = (BaseScript) ssrc.createInst();
        inst.setDelegate(delegate);
        inst.run();
    }

}
