package jandcode.jc;

import jandcode.app.*;
import jandcode.groovy.*;

import java.util.regex.*;

public class ClasspathGroovyPreprocessor extends Comp implements GroovyPreprocessor {

    public String preprocessScriptText(String text, String className, Class baseClass, String sign) {
        // directives
        Pattern z = Pattern.compile("\\/\\/#(\\w*)\\s*=\\s*(.*)");
        Matcher m = z.matcher(text);
        while (m.find()) {
            String n = m.group(1);
            String v = m.group(2);
            //
            if ("classpath".equals(n)) {
                getApp().service(JcService.class).getRepo().addClasspath(v);
            }
            //
        }
        return text;
    }

}
