package jandcode.jc;

import jandcode.utils.*;
import org.apache.commons.logging.*;

/**
 * Логирование процесса выполнения скриптов.
 */
public class JcLog {

    protected static Log log = LogFactory.getLog(JcLog.class);
    private static String pfxInfo = " (jc) ";
    private static String pfxDebg = " (JC) ";
    private JcService jcService;

    //////

    public JcLog(JcService jcService) {
        this.jcService = jcService;
    }

    protected void out(Object msg, String pfx) {
        String msgs = pfx + msg;
        if (UtLog.isOn()) {
            log.info(msgs.trim());
        } else {
            System.out.println(msgs);
        }
    }

    /**
     * Вывод лог-сообщения
     */
    public void info(Object msg) {
        out(msg, pfxInfo);
    }

    /**
     * Вывод лог-сообщения, которое будет видимо в режиме verbose.
     */
    public void debug(Object msg) {
        if (!isVerbose()) {
            return;
        }
        out(msg, pfxDebg);
    }

    /**
     * true - включен verbose
     */
    public boolean isVerbose() {
        return jcService.isVerbose();
    }
}
