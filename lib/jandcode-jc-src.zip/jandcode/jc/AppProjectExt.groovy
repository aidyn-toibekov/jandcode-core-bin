package jandcode.jc

import jandcode.app.*

import java.text.*

/**
 * Поддержка приложения jandcode.app.App в скриптах.
 */
class AppProjectExt extends ProjectExt {

    // кешированный экземпляр app.inst
    App _inst = null

    /**
     * Файл app.rt для загрузки приложения
     */
    String apprt_file = "app.rt"

    // библиотеки для приложения, если не указаны, генерятся
    List _libs = null

    //////

    /**
     * Экземпляр приложения jandcode.app.App
     * Загружается при первом вызове
     */
    App getInst() {
        if (_inst != null) {
            return _inst  // уже загружено
        }
        String af = wd(apprt_file)
        ut.startTimer("load app")
        ut.delim("Load app: ${af}")
        //
        log "classpath:" + libs
        repo.addClasspath(libs)
        //
        log.debug("Start AppLoader from ${af}")
        _inst = AppLoader.load(af)
        //
        ut.stopTimer()
        //
        ut.delim()
        return _inst
    }

    /**
     * Библиотеки приложения, которые нужно включать в classpath
     * @return
     */
    List getLibs() {
        if (_libs != null) {
            return _libs;
        }
        def res = []
        if (project.vars.modules) {
            res.addAll(su.toList(project.vars.modules))
        }
        if (project.vars.PROJECT_JAVA) {
            res.addAll([project.name])
        }
        return res
    }

    /**
     * Установить библиотеки для включения в classpath приложения
     */
    void setLibs(List libs) {
        _libs = libs
    }

    /**
     * Запись App.getRt() в файлы
     * @param fileMask маска файлов. {0} заменяется на expanded/normal
     */
    void saveapprt(String fileName) {
        def rt = inst.rt
        //
        def f = MessageFormat.format(fileName, "normal")
        log "Запись файла: ${f}"
        ut.cleanfile(f)
        rt.save(false).toFile(f)
        //
        f = MessageFormat.format(fileName, "expanded")
        log "Запись файла: ${f}"
        ut.cleanfile(f)
        rt.save(true).toFile(f)
    }

}
