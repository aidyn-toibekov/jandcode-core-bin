package jandcode.jc;

import groovy.lang.*;
import jandcode.utils.*;

import java.util.*;
import java.util.jar.*;

/**
 * Описание java-библиотеки
 */
public class Lib extends Named implements ISubstVar {

    private JcService jcService;

    private String jar = "";
    private String src = "";
    private String ini = "";
    private List<String> depends = new ArrayList<String>();
    private String version;
    private String libPath = "";
    private boolean prepared;
    protected Project project;
    protected Closure recompileClosure;
    protected Exception recompileException;
    protected boolean virtual;

    public Lib(JcService jcService) {
        this.jcService = jcService;
    }

    /**
     * Проект, который является исходником для библиотеки
     */
    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    /**
     * Closure, которая предназначена для проверки и перекомпилирования проекта
     */
    public Closure getRecompileClosure() {
        return recompileClosure;
    }

    public void setRecompileClosure(Closure recompileClosure) {
        this.recompileClosure = recompileClosure;
    }

    /**
     * Если не null, то значение - ошибка компиляции проекта
     */
    public Exception getRecompileException() {
        return recompileException;
    }

    //////

    /**
     * jar-файл библиотеки
     */
    public String getJar() {
        if (!prepared) {
            if (recompileClosure != null) {
                recompileException = null;
                jcService.getLog().debug("Check recompiled: " + project.getName());
                try {
                    recompileClosure.call();
                } catch (Exception e) {
                    recompileException = e;
                }
            }
            prepared = true;
        }
        return jar == null ? "" : jar;
    }

    public void setJar(String jar) {
        this.jar = UtFile.abs(expandString(jar));
    }

    //////

    /**
     * zip-файл с исходниками библиотеки
     */
    public String getSrc() {
        return src == null ? "" : src;
    }

    public void setSrc(String src) {
        this.src = UtFile.abs(expandString(src));
    }

    //////

    /**
     * ini файл с настройками библиотеки
     */
    public String getIni() {
        return ini == null ? "" : ini;
    }

    public void setIni(String ini) {
        this.ini = UtFile.abs(expandString(ini));
    }

    //////

    /**
     * признак виртуальной библиотеки. Она существует только как ini файл.
     */
    public boolean isVirtual() {
        return virtual;
    }

    public void setVirtual(boolean virtual) {
        this.virtual = virtual;
    }

    //////

    /**
     * Каталог, из которого библиотека получена
     */
    public String getLibPath() {
        return libPath;
    }

    public void setLibPath(String libPath) {
        this.libPath = libPath;
    }


    //////

    /**
     * Список имен библиотек, от которых зависит эта
     *
     * @return
     */
    public List<String> getDepends() {
        return depends;
    }

    /**
     * Версия библиотеки
     */
    public String getVersion() {
        if (version == null) {
            String jarV = getJarVersion(getJar());
            if (jarV == null) {
                jarV = "0.1";
            }
            version = jarV;
        }
        return version;
    }

    public void setVersion(String version) {
        this.version = expandString(version);
    }

    /**
     * Установить свойство из ini-файла библиотеки
     */
    public void setProperty(String name, String value) {
        if (value == null) {
            return;
        }
        value = value.trim();
        //
        if ("depends".equals(name)) {
            depends.clear();
            depends.addAll(UtCnv.toList(value));

        } else if ("jar".equals(name)) {
            setJar(value);

        } else if ("src".equals(name)) {
            setSrc(value);

        } else if ("version".equals(name)) {
            setVersion(value);

        } else if ("virtual".equals(name)) {
            setVirtual(UtCnv.toBoolean(value));

        }
    }

    ////// internal

    protected String expandString(String s) {
        return UtString.substVar(s, this);
    }

    /**
     * Замены:
     * lib.path = getLibPath()
     * остальное = System.getProperty()
     */
    public String onSubstVar(String v) {
        if ("lib.path".equals(v)) {
            return getLibPath();
        }
        String z = System.getProperty(v);
        if (z == null) {
            return "";
        }
        return z;
    }

    /**
     * Версия из jar-файла
     */
    protected String getJarVersion(String jar) {
        try {
            JarFile jf = new JarFile(jar);
            try {
                Manifest mn = jf.getManifest();
                String v = internal_getJarVersion_Attrs(mn.getMainAttributes());
                if (v != null) {
                    return v;
                }
                for (Map.Entry<String, Attributes> en : mn.getEntries().entrySet()) {
                    v = internal_getJarVersion_Attrs(en.getValue());
                    if (v != null) {
                        return v;
                    }
                }
            } finally {
                jf.close();
            }
        } catch (Exception e) {
        }
        return null;
    }

    private String internal_getJarVersion_Attrs(Attributes at) {
        String v;
        v = at.getValue("Implementation-Version");
        if (v != null) {
            return v;
        }
        v = at.getValue("Specification-Version");
        if (v != null) {
            return v;
        }
        return null;
    }

    public String toString() {
        return getName() + ":" + getVersion();
    }
}
