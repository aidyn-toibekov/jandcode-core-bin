package jandcode.jc

import jandcode.utils.*
import jandcode.utils.io.*
import jandcode.utils.test.*
import jandcode.utils.variant.*
import org.codehaus.groovy.runtime.*

/**
 * Разные утилиты
 */
class Ut extends ProjectExt {

    ////// timer

    private StopWatch _stopWatch;

    /**
     * Максимальный размер памяти для компиляции javac и groovyc
     */
    public String javac_memoryMaximumSize = '800m'

    /**
     * Начать засекать время
     */
    public void startTimer(String msg) {
        if (_stopWatch == null) {
            _stopWatch = new StopWatch(false, false);
        }
        _stopWatch.start(msg);
    }

    /**
     * Начать засекать время
     */
    public void startTimer() {
        startTimer(null);
    }

    /**
     * Закончить засекать время и напечатать результат
     */
    public long stopTimer() {
        if (_stopWatch == null) {
            return 0;
        }
        long n = _stopWatch.stop();
        log _stopWatch.lastMessage
        return n
    }

    ////// clean

    /**
     * Очистка каталога. После выполнения команды имеем существующий пустой каталог
     * @param dir
     *    Какой каталог чистить
     */
    public void cleandir(dir) {
        if (su.empty(dir)) {
            error("Не указан каталог для очистки")
        }
        log.debug "Clean dir [${dir}]"
        ant.mkdir(dir: dir);
        ant.delete(includeemptydirs: true) {
            fileset(dir: dir) {
                include(name: "**/*")
            }
        }
    }

    /**
     * Очистка файла. После выполнения команды имеем существующий пустой каталог,
     * в котором должен лежать файл и файл не существует
     * @param file
     *    Какой файл чистить
     */
    public void cleanfile(file) {
        if (su.empty(file)) {
            error("Не указан файл для очистки")
        }
        log.debug "Clean file [${file}]"
        ant.mkdir(dir: fu.path(file))
        ant.delete(file: file)
    }

    ////// run

    /**
     * Запуск внешнего приложения без использования ant
     *
     * @param cmd
     *    Строка с параметрами, разделенная пробелами или список параметров.
     *    Например params:['cmd.exe','/c','dir'] или params:'cmd.exe /c dir'
     *
     * @param dir :String
     *    Рабочий каталог запуска. Если не указан, используется рабочий каталог проекта
     *
     * @param charset :String
     *    Кодировка консоли. По умолчанию совпадает с той, в которой запущена xc
     *
     * @param showout :boolean
     *    Показывать вывод на консоль. По умолчанию true
     *
     * @param saveout : boolean
     *    Запоминать вывод на консоль. В этом случае команда возвращает массив строк с выводом
     *
     * @param err : boolean
     *    При true (по умолчанию) генерить ошибку если код возврата не 0
     */
    public List runexe(Map pp) {
        def p = asVariantMap(pp)
        //
        List params = []
        String dir = p.get('dir', project.wd)
        String charset = p.get('charset', UtConsole.getConsoleCharset())
        def showout = p.get('showout', true)
        def saveout = p.get('saveout', true)
        def err = p.get('err', true)
        //
        if (p.cmd instanceof List) {
            params.addAll(p.cmd)
        } else if (!su.empty(p.cmd)) {
            def lp = p.cmd.split(" ")
            for (a in lp) {
                params << a
            }
        }
        //
        if (params.size() == 0) {
            error UtLang.t("Параметр cmd не задан")
        }

        log.debug "runexe: " + params

        ProcessBuilder pb = new ProcessBuilder(params)
        pb.redirectErrorStream(true);
        pb.directory(new File(dir))

        def result = []

        Process pr = pb.start();
        BufferedReader inr = new BufferedReader(new InputStreamReader(pr.getInputStream(), charset));
        String line = inr.readLine();
        while (line != null) {
            if (showout) {
                System.out.println(line)
            }
            if (saveout) {
                result << line
            }
            line = inr.readLine();
        }
        pr.waitFor()
        def rescode = pr.exitValue()
        if (err) {
            if (rescode > 0) {
                def c = params.join(' ')
                c = "Ошибка при выполнении [${c}]"
                def r = result.join('\n')
                if (r != "") {
                    c = c + "\n[console]>>>\n${r}\n<<<"
                }
                error c;
            }
        }

        return result
    }

    /**
     * Получение списка каталогов по различным критериям
     *
     * @param masks
     *    Маски каталогов как строка через ',' (в формате ant) или как список масок (list)
     * @param dir
     *    Каталог, из которого нужно получить подкаталоги.
     *    По умолчанию - рабочий каталог проекта
     *
     */
    public List dirlist(masks, dir = "") {
        dir = project.getWd().join(dir)
        masks = UtCnv.toList(masks)
        //
        def result = []
        for (j in masks) {
            def scanner
            if (fu.isAbsolute(j)) {
                scanner = ant.dirset(dir: fu.path(j)) {
                    include(name: fu.filename(j))
                }
            } else {
                scanner = ant.dirset(dir: dir) {
                    include(name: j)
                }
            }
            for (f in scanner) {
                result << f.toString()
            }
        }
        return result
    }

    /**
     * Получение списка файлов по различным критериям
     *
     * @param masks
     *    Маски файлов как строка через ',' (в формате ant) или как список масок (list)
     * @param dir
     *    Каталог, из которого нужно получить файлы.
     *    По умолчанию - рабочий каталог проекта.
     * @param req
     *    При значении true - если не найдены файлы, генерится ошибка.
     *    По умолчанию - false.
     *
     */
    public List filelist(masks, dir = "") {
        dir = project.getWd().join(dir)
        masks = UtCnv.toList(masks)
        //
        def result = []
        for (j in masks) {
            def scanner
            if (fu.isAbsolute(j)) {
                scanner = ant.fileset(dir: fu.path(j), erroronmissingdir: false) {
                    include(name: fu.filename(j))
                }
            } else {
                scanner = ant.fileset(dir: dir, erroronmissingdir: false) {
                    include(name: j)
                }
            }
            for (f in scanner) {
                result << f.toString()
            }
        }
        return result
    }

    ////// generate

    public void generate(String templatePath, String outdir, Map vars) {
        String fn = getJcService().getScriptHolder().findScript(templatePath, true);
        if (fn == null) {
            return;
        }
        //
        getLog().info("generate template [" + fn + "] to [" + outdir + "]")
        startTimer("generate template")
        Template tml = new Template(getProject(), outdir);
        if (vars != null) {
            for (Object key : vars.keySet()) {
                // и обычные свойства и динамические
                InvokerHelper.setProperty(tml, UtString.toString(key), vars.get(key));
            }
        }
        stopTimer()
        try {
            getJcService().getScriptHolder().runScript(tml, fn);
        } finally {
            tml.flush();
        }
        //
    }

    public void generate(String templatePath, String outdir) {
        generate(templatePath, outdir, null);
    }

    ////// execscript

    public Base execscript(String scriptFile, Map vars) {
        String fn = getJcService().getScriptHolder().findScript(scriptFile, true);
        if (fn == null) {
            return;
        }
        //
        getLog().debug("exec script [" + fn + "]")
        Base inst = new Base(getProject());
        if (vars != null) {
            for (Object key : vars.keySet()) {
                // и обычные свойства и динамические
                InvokerHelper.setProperty(inst, UtString.toString(key), vars.get(key));
            }
        }
        getJcService().getScriptHolder().runScript(inst, fn);
        //
        return inst
    }

    public Base execscript(String scriptFile) {
        return execscript(scriptFile, null);
    }

    //////  convertors

    /**
     * Возвращает IVariantMap для указанного Map.
     * Если m==null, возвращается пустой Map. Используется для анализа параметров в Closure.
     */
    public IVariantMap asVariantMap(Map m) {
        if (m == null) {
            m = new LinkedHashMap();
        }
        return new VariantMapWrap(m);
    }

    ////// prints

    public String makeDelim(text = "") {
        return UtString.delim(text, "-", 76)
    }

    /**
     * Рисует разделитель в log
     *
     * @param text
     *    Текст в заголовке разделителя
     */
    public void delim(text = "") {
        log.info(makeDelim(text))
    }

    /**
     * Напечатать map как таблицу
     */
    public void printMapTab(map, title = "") {
        int mx = 0
        for (a in map) {
            def len = UtString.toString(a.key).length()
            if (len > mx) {
                mx = len
            }
        }
        //
        println makeDelim(title)
        def format = "  %-" + mx + "s  %s"
        for (a in map) {
            println String.format(format, UtString.toString(a.key), UtString.toString(a.value))
        }
        println makeDelim()
    }

    /**
     * Показать список библиотек
     * @param libs список объектов Lib
     */
    public void showlibs(libs, title = "") {
        ListNamed lst = new ListNamed()
        for (lib in libs) {
            def s = lib.jar // что бы сначала recompile сработало
            lst.add(lib)
        }
        lst.sort()
        println makeDelim(title)
        for (lib in lst) {
            println String.format("%-25s  %-12s  %s", lib.name, lib.version, lib.jar)
        }
        println makeDelim()
    }

    /**
     * Копировать список библиотек в каталог
     * @param libs список объектов Lib
     * @param todir куда копировать
     * @param includeSource true-копировать и исходники тоже
     */
    public void copylibs(libs, todir, includeSource = false) {
        ListNamed lst = new ListNamed()
        for (lib in libs) {
            def s = lib.jar // что бы сначала recompile сработало
            lst.add(lib)
        }
        for (lib in lst) {
            if (!lib.virtual) {
                ant.copy(file: lib.jar, todir: todir)
            }
            if (lib.src != "" && includeSource) {
                ant.copy(file: lib.src, todir: todir)
            }
            if (lib.project != null) {
                // в исходниках
                def s = su.join(lib.depends, " ")
                if (s.length() > 0) {
                    ant.echo(message: "depends=" + s, file: todir + "/${lib.name}.ini")
                }
            } else {
                if (UtFile.exists(lib.ini)) {
                    ant.copy(file: lib.ini, todir: todir)
                }
            }
        }
    }

    ////// java

    /**
     * Компиляция java исходников.
     * Если в исходниках встречаются groovy файлы, то они тоже прозрачно компиляются.
     *
     * @param destdir
     *    Куда помещать скомпилированные файлы
     *
     * @param srcs
     *    Каталоги с исходными файлами
     *
     * @param libs
     *    Библиотеки
     *
     * @param debug
     *    Включать ли отладочную информацию
     *
     * @param exclude_res
     *    Игнорируемые ресурсы при сборке. Все остальные файлы из каталогов с
     *    исходниками включаются в выходной каталог
     *
     * @param classpath
     *    Дополнительный classpath, используется как добавка к libs (например при компилировании
     *    тестов в путь должны включаться только что скомпилированные исходники модуля)
     *
     * @param encoding
     *    Кодировка исходных файлов
     */
    public void compile_java(Map pp) {
        def p = asVariantMap(pp)
        //
        def destdir = p.get('destdir', wd("temp/compiled"))
        def srcs = p.get('srcs', [wd("src")])
        def libs = p.get('libs', [])
        def debug = p.get('debug', true)
        def exclude_res = p.get('exclude_res', ["**/*.java", "**/*.groovy"])
        def classpath = p.get('classpath', "")
        def encoding = p.get('encoding', "utf-8")
        def sourceVersion = "1.6"
        def targetVersion = "1.6"
        //

        repo.addClasspath "jdk-tools"

        log.debug "Compile to [${destdir}]"
        cleandir(destdir)

        // определяем наличие groovy
        boolean isGroovy = false
        for (s in srcs) {
            def lst = filelist("**/*.groovy", s)
            if (lst.size() > 0) {
                isGroovy = true
                break
            }
        }
        if (isGroovy) {
            log.debug "GROOVY compile mode on"
        }

        //
        def rlibs = repo.getLibs(libs)
        def cp = rlibs.classpath(classpath)

        if (log.verbose) {
            log.debug "Using classpath:"
            def ar = cp.split(";")
            for (a in ar) {
                log.debug " | -> ${a}"
            }
        }

        if (!isGroovy) {
            ant.javac(destdir: destdir, debug: debug, includeantruntime: false, fork: true,
                    classpath: cp, encoding: encoding, source: sourceVersion, target: targetVersion,
                    memoryMaximumSize: javac_memoryMaximumSize
            ) {
                for (s in srcs) {
                    src(path: s)
                }
                include(name: "**/*.java")
            }
        } else {
            ant.taskdef(name: "groovyc", classname: "org.codehaus.groovy.ant.Groovyc")
            ant.groovyc(destdir: destdir, includeantruntime: false, fork: true,
                    classpath: cp, encoding: encoding,
                    memoryMaximumSize: javac_memoryMaximumSize
            ) {
                for (s in srcs) {
                    src(path: s)
                }
                javac(debug: debug, encoding: encoding, source: sourceVersion, target: targetVersion)
            }

        }
        ant.copy(todir: destdir, overwrite: "true") {
            for (s in srcs) {
                fileset(dir: s) {
                    include(name: "**/*")
                    for (ex in exclude_res) {
                        exclude(name: ex)
                    }
                }
            }
        }

    }

    //////

    /**
     * Номер ревизии исходников
     */
    public String revno() {
        try {
            def f
            // hg
            f = UtFile.findFileUp(".hg", wd(""))
            if (f != null) {
                def a = runexe(cmd: 'hg identify -n', saveout: true, showout: false)
                if (a.size() > 0) {
                    def s = a[0]
                    s = s.replace('+', 'DEV')
                    return s
                }
            }
        } catch (e) {
            //
        }
        return "DEV"
    }

    /**
     * Автогенерируемая версия (по тегам в hg)
     */
    public String version(String dir = null) {
        if (dir == null) {
            dir = wd("")
        }
        def v = ""
        try {
            def f
            // hg
            f = UtFile.findFileUp(".hg", dir)
            if (f != null) {
                def a = runexe(cmd: 'hg identify -t', dir: dir, saveout: true, showout: false)
                v = ""
                if (a.size() > 0) {
                    if (a[0].startsWith("v-")) {
                        v = a[0].substring(2)
                    }
                }
            }
        } catch (e) {
            //
        }
        if (v == "") {
            def vers = listVersions()
            if (vers.size() > 0) {
                v = vers[0] + "-r" + revno()
            } else {
                v = "SNAPSHOT-" + revno()
            }
        }
        return v
    }

    /**
     * Возвращает список версий. Первая в списке - самая последняя
     */
    public List listVersions(String dir = null) {
        if (dir == null) {
            dir = wd("")
        }
        def v = []
        try {
            def f
            // hg
            f = UtFile.findFileUp(".hg", dir)
            if (f != null) {
                def a = runexe(cmd: 'hg tags', dir: dir, saveout: true, showout: false)
                if (a.size() > 0) {
                    for (vs in a) {
                        def b = vs.split(" ")
                        if (b.length > 1) {
                            if (b[0].startsWith("v-")) {
                                v.add(b[0].substring(2))
                            }
                        }
                    }
                }
            }
        } catch (e) {
            //
        }
        return v
    }

    /**
     * Возвращает последнюю версию (по тегам hg)
     */
    public String lastVersion(String dir = null) {
        def v = listVersions(dir)
        if (v.size() == 0) {
            return ""
        } else {
            return v[0]
        }
    }

    //////

    /**
     * Создание ClassLoader для указанного набора библиотек
     */
    public ClassLoader classLoader(Object libs) {
        ListLib rlibs = getRepo().getLibs(libs)
        URL[] u = rlibs.urls()
        //
        ClassLoader cloader = new URLClassLoader(u, ClassLoader.getSystemClassLoader());
        return cloader
    }

    /**
     * Выполнить closure в контексте ClassLoader
     * @param ob ClassLoader, объект или класс
     * @param closure что выполнить
     * @return результат работы closure
     */
    public Object withClassLoader(Object ob, Closure closure) {
        ClassLoader ldr
        if (ob instanceof ClassLoader) {
            ldr = ob
        } else if (ob instanceof Class) {
            ldr = ob.classLoader
        } else {
            ldr = ob.class.classLoader
        }
        def saveldr = Thread.currentThread().getContextClassLoader()
        Thread.currentThread().setContextClassLoader(ldr)
        def res
        try {
            res = closure()
        } finally {
            Thread.currentThread().setContextClassLoader(saveldr)
        }
        return res
    }

    /**
     * Возвращает имя jc.bat в зависимости от os
     */
    public String getJcbat() {
        if (File.separator == "/") {
            // unix
            return "jc"
        } else {
            // windows
            return "jc.bat"
        }
    }

}
