package jandcode.jc;

import groovy.util.*;

import java.util.*;

/**
 * Кеш AntBuilder
 */
public class AntHolder {

    private JcService jcService;
    private HashMap<String, AntBuilder> items = new HashMap<String, AntBuilder>();

    public AntHolder(JcService jcService) {
        this.jcService = jcService;
    }

    /**
     * Возвращает кешированный экземпляр AntBuilder для указанного базового каталога
     */
    public AntBuilder get(String basedir) {
        AntBuilder a = items.get(basedir);
        if (a == null) {
            a = new AntBuilder();
            a.getProject().setBasedir(basedir);
            items.put(basedir, a);
        }
        return a;
    }

    /**
     * AntBuilder для этого каталога
     */
    public AntBuilder get(Dir dir) {
        return get(dir.getPath());
    }

}