package jandcode.jc;

/**
 * Расширение проекта. Создаем через createExt
 */
public class ProjectExt extends BaseScript {

    public ProjectExt() {
        setDelegate(new Base());
    }

    protected void setProject(Project project) {
        getDelegate().project = project;
        onSetProject();
    }

    /**
     * Вызывается после установки проекта
     */
    protected void onSetProject() {
    }

}
