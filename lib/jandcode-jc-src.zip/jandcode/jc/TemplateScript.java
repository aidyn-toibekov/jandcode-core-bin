package jandcode.jc;

import groovy.lang.*;
import jandcode.groovy.*;
import jandcode.utils.*;
import jandcode.utils.error.*;
import jandcode.utils.io.*;

import java.util.*;

/**
 * Скрипт-шаблон для генерации
 */
public class TemplateScript extends BaseScript implements IGspTemplate {

    public Template getDelegate() {
        return (Template) super.getDelegate();
    }

    //////

    protected IndentWriter getWriter() {
        return getDelegate().getWriter();
    }

    //////

    public Dir getOutdir() {
        return getDelegate().getOutdir();
    }

    public void out(Object z) throws Exception {
        getWriter().write(UtString.toString(z));
    }

    public void setCharset(String v) {
        getDelegate().setCharset(v);
    }

    public String getCharset() {
        return getDelegate().getCharset();
    }

    //////

    public String getOutfile() {
        return getDelegate().getOutfile();
    }

    public void setOutfile(String filename) {
        changeFile(filename);
    }

    public void changeFile(String filename, boolean append, boolean push) {
        getDelegate().changeFile(filename, append, push);
    }

    public void changeFile(String filename, boolean append) {
        changeFile(filename, append, false);
    }

    public void changeFile(String filename) {
        changeFile(filename, false, false);
    }

    public void pushFile(String filename) {
        changeFile(filename, false, true);
    }

    public void pushFile(String filename, boolean append) {
        changeFile(filename, append, false);
    }

    public void popFile() {
        getDelegate().popFile();
    }

    public void flush() {
        getDelegate().flush();
    }

    //////

    public int getIndentDelta() {
        return getWriter().getIndentDelta();
    }

    public void setIndentDelta(int indentDelta) {
        getWriter().setIndentDelta(indentDelta);
    }

    public char getIndentChar() {
        return getWriter().getIndentChar();
    }

    public void setIndentChar(char charIndent) {
        getWriter().setIndentChar(charIndent);
    }

    public void indentInc(int count) {
        getWriter().indentInc(count);
    }

    public void indentInc(String str) {
        getWriter().indentInc(str);
    }

    public void indentDec(String str) {
        getWriter().indentDec(str);
    }

    public void indentDec(int count) {
        getWriter().indentDec(count);
    }

    public void indentInc() {
        getWriter().indentInc();
    }

    public void indentDec() {
        getWriter().indentDec();
    }

    //////

    public void outTag(String tmlName, Map args, Closure cls) throws Exception {
        throw new XError("Unsupported outTag");
    }

    public void outTag(Map args, String tmlName, Closure cls) throws Exception {
        outTag(tmlName, args, cls);
    }

    public void outTag(Map args, String tmlName) throws Exception {
        outTag(tmlName, args, null);
    }

    public void outTag(String tmlName) throws Exception {
        outTag(tmlName, null, null);
    }

    public void outTag(String tmlName, Map args) throws Exception {
        outTag(tmlName, args, null);
    }

    public void outTag(String tmlName, Closure cls) throws Exception {
        outTag(tmlName, null, cls);
    }

    //////

    /**
     * Выполнить скрипт-шаблон и вывести его результат
     *
     * @param template
     */
    public void outTemplate(String template) {
        getJcService().getScriptHolder().runScriptText(getDelegate(), "gsp", template);
    }

}
